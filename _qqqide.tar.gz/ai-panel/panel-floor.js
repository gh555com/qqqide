'use strict';

// ═══ 楼层 txt 归档：单 all.txt，完整时间线（分隔线区分 USER/HOUSE/ROOM/ANSWER） ═══
async function generateFloorTxt(ag, questId) {
    if (!ag || !questId) return;
    // ★ 跨面板写保护：只有建楼中的 agent 或刚完成的 agent 有权写 all.txt
    //   非建楼面板 restore 出来的 agent（stopState='idle' + floorCompletedCleanly=false）禁止覆写
    if (ag._stopState !== 'sending' && !ag._floorCompletedCleanly) return;
    var root = questStore.getProjectRoot();
    if (!root) return;
    var houses = ag._houses;
    if (!houses || houses.length === 0) return;
    // ★ 优先使用 _currentFloorNum（未可变），降级到 _ctx.totalFloors
    var floorNum = ag._currentFloorNum;

    // ★ 优先使用 _floorMeta 中的未可变路径，降级到 ag._allTxtPath
    var meta = (floorNum && ag._floorMeta && ag._floorMeta[floorNum]) ? ag._floorMeta[floorNum] : null;
    var allTxtPath = meta ? meta.allTxtPath : (ag._allTxtPath || '');
    var dir = '';
    if (allTxtPath) {
        dir = allTxtPath.replace(/\/all\.txt$/, '/');
    } else {
        var quests = await questStore.list();
        var questEntry = quests.find(function (q) { return q.id === questId; }) || null;
        var rawQTitle = (questEntry && questEntry.title && questEntry.title !== 'New Chat') ? questEntry.title : '';
        var qNumericId = (questEntry && questEntry.numericId) ? questEntry.numericId : parseInt(questId.replace('q', ''), 10) || 0;
        var qDirName = await _resolveQuestDirName(root, questId, qNumericId, rawQTitle);
        var _uiFallback = ag._lastUserInput;
        var _uiTextFallback = (_uiFallback && _uiFallback.text) ? _uiFallback.text.replace(/\n/g, ' ').trim() : '';
        var fDirName = _makeName('f', floorNum, _uiTextFallback || '');
        dir = root + '/qqq/quests/' + qDirName + '/' + fDirName + '/';
    }
    try {
        if (!(window.parent && window.parent.qqqideBridge && window.parent.qqqideBridge.fs)) return;
        var bridge = window.parent.qqqideBridge;
        await bridge.fs.mkdir(dir);
        var timing = ag._floorTiming;
        var lines = [];

        // ═══ 计算 body size ═══
        var ui = ag._lastUserInput;
        var fmtK = function (bytes) { return (bytes / 1024).toFixed(3) + 'k'; };
        var userText = (ui && ui.text) ? ui.text.trim() : '';
        var visionText = (ui && ui.vision) ? ui.vision.trim() : '';
        var askBytes = userText ? new TextEncoder().encode(userText).length : 0;
        var sourceBytes = visionText ? new TextEncoder().encode(visionText).length : 0;
        var promptBytes = 0;
        var ruleBytes = 0;
        var memoryBytes = 0;
        var conv = ag.conversation;
        for (var ci = 0; ci < conv.length; ci++) {
            var cm = conv[ci];
            if (!cm || typeof cm.content !== 'string') continue;
            var cb = new TextEncoder().encode(cm.content).length;
            if (cm._persistent) {
                if (typeof SYSTEM_PROMPT !== 'undefined' && cm.content.indexOf(SYSTEM_PROMPT) === 0) {
                    promptBytes += cb;
                } else {
                    ruleBytes += cb;
                }
            } else if (cm.role === 'user' && cm._floor === floorNum) {
                memoryBytes += Math.max(0, cb - askBytes - sourceBytes);
            } else {
                memoryBytes += cb;
            }
        }
        var totalBytes = askBytes + sourceBytes + promptBytes + ruleBytes + memoryBytes;

        // ═══ floor 头 ═══
        var floorTs = timing && timing.floorStartServerMs ? new Date(timing.floorStartServerMs) : now;
        lines.push('floor.' + floorNum + '   ' + _fmtTime(floorTs));
        lines.push('');
        lines.push('(body ' + fmtK(totalBytes) + ': ask ' + fmtK(askBytes) + ' + rule ' + fmtK(ruleBytes) + ' + Source code ' + fmtK(sourceBytes) + ' + prompt ' + fmtK(promptBytes) + ' + memory ' + fmtK(memoryBytes) + ')');
        lines.push('');
        if (userText) { lines.push(userText); lines.push(''); }
        if (visionText) { lines.push(visionText); lines.push(''); }

        // ═══ HOUSE + ROOM 块 ═══
        for (var hi = 0; hi < houses.length; hi++) {
            var h = houses[hi];
            var houseTs = h.ts ? new Date(h.ts) : now;
            lines.push('\u2550\u2550\u2550\u2550 HOUSE ' + h.index + ' \u2550\u2550\u2550\u2550 ' + _fmtTime(houseTs) + ' [' + h.ms + 'ms] \u2550\u2550\u2550\u2550');


            if (h.reasoning) {
                lines.push('<thinking>');
                lines.push(h.reasoning);
                lines.push('</thinking>');
                lines.push('');
            }

            if (h.tools && h.tools.length > 0) {
                for (var ti = 0; ti < h.tools.length; ti++) {
                    var t = h.tools[ti];
                    var argsStr = (typeof t.args === 'string') ? t.args : JSON.stringify(t.args || {});
                    lines.push('  \u2500\u2500 ROOM ' + h.index + '.' + (ti + 1) + '  ' + t.name + '(' + argsStr + ') \u2500\u2500');
                    if (h.toolResults && h.toolResults[ti]) {
                        lines.push(h.toolResults[ti]);
                        lines.push('');
                    }
                }
            }

            if (h.type === 'final' && h.answer) {
                lines.push('  <answer>');
                lines.push(h.answer);
                lines.push('  </answer>');
            }

            lines.push('');
        }

        // ═══ floor stats + az 区（每层楼私有） ═══
        if (timing) {
            lines.push('\u2550\u2550\u2550\u2550 floor ' + floorNum + ' stats \u2550\u2550\u2550\u2550');
            lines.push('network: ' + (timing.networkMs ? timing.networkMs.toFixed(0) : '0') + 'ms  AI: ' + (timing.aiMs ? timing.aiMs.toFixed(0) : '0') + 'ms  tool: ' + (timing.otherMs ? timing.otherMs.toFixed(0) : '0') + 'ms  cost: ' + (ag._floorCostWge / 10000).toFixed(4) + ' ge');
            // az 区文本化
            var _floorDataForAz = { houses: houses, allTxtPath: ag._allTxtPath || '', costWge: ag._floorCostWge, floorFree: ag._floorCostWge === 0, a4Snapshots: ag._a4Snapshots || {} };
            var _questMetaForAz = { floorTimings: ag._floorTimings || [] };
            var _azLines2 = _buildAzText(floorNum, _floorDataForAz, _questMetaForAz);
            for (var _azi2 = 0; _azi2 < _azLines2.length; _azi2++) {
                lines.push(_azLines2[_azi2]);
            }
        }

        // 写入前检查总大小（唯一真理守卫 4MB）
        if (!_guardAllTxtSize(lines)) return;
        var _txtContent = lines.join('\n');
        await bridge.fs.write(dir + 'all.txt', _txtContent);
        // [silent] floor txt written
    } catch (e) {
        console.warn('[quests] generateFloorTxt failed:', e);
    }
}

// ═══ 构建 az 区文本（每层楼私有：A1 统计 + 时钟 + 文件变更） ═══
function _buildAzText(floorNum, floorData, questMeta) {
    var lines = [];
    var houses = floorData.houses || [];
    var hCount = houses.length;
    var rCount = 0;
    for (var hi = 0; hi < houses.length; hi++) {
        if (houses[hi].tools) rCount += houses[hi].tools.length;
    }

    var a4Snapshots = floorData.a4Snapshots || {};
    var timings = (questMeta && questMeta.floorTimings) || [];

    // A4: 文件快照明细
    if (a4Snapshots && typeof a4Snapshots === 'object') {
        var a4Paths = Array.isArray(a4Snapshots) ? a4Snapshots : Object.keys(a4Snapshots);
        if (a4Paths.length > 0) {
            for (var a4i = 0; a4i < a4Paths.length; a4i++) {
                var s = Array.isArray(a4Snapshots) ? a4Paths[a4i] : a4Snapshots[a4Paths[a4i]];
                if (!s || !s.path) continue;
                var fname = s.path.replace(/\\/g, '/').split('/').pop() || s.path;
                var opLabel = s.op === 'create_file' ? '[new]' : s.op === 'delete_file' ? '[del]' : '[mod]';
                var statStr = (s.added > 0 ? '+' + s.added : '') + (s.deleted > 0 ? ' -' + s.deleted : '');
                if (!statStr) statStr = '~0';
                lines.push('az> ' + opLabel + ' ' + fname + '  ' + statStr);
            }
        }
    }

    // A1: 楼层统计（行1: Floor/House/Room, 行2: FILE/ROW）
    var allTxtSize = '';
    if (floorData.allTxtPath && floorData.allTxtPath.length > 0) {
        allTxtSize = ' [all.txt: ' + floorData.allTxtPath.split('/').pop() + ']';
    }
    lines.push('az> Floor ' + floorNum + '  House ' + hCount + '  Room ' + rCount + allTxtSize);
    var fs = _computeFileStats(houses, a4Snapshots);
    if (fs.fileCount > 0 || fs.added > 0 || fs.deleted > 0) {
        lines.push('az> FILE ' + fs.fileCount + '   ROW +' + fs.added + ' -' + fs.deleted);
    }

    // A3: 时钟
    for (var tii = 0; tii < timings.length; tii++) {
        if (timings[tii].floorIndex === floorNum) {
            var t = timings[tii];

            var durS = Math.round((t.durationMs || 0) / 1000);
            var min = Math.floor(durS / 60);
            var sec = durS % 60;
            var netS = Math.round((t.networkMs || 0) / 1000);
            var aiS = Math.round((t.aiMs || 0) / 1000);
            var toolS = Math.round((t.otherMs || 0) / 1000);
            lines.push('az> \u23f1 ' + min + 'm' + (sec < 10 ? '0' : '') + sec + 's  Net:' + netS + 's  AI:' + aiS + 's  Tool:' + toolS + 's');
            break;
        }
    }

    // 成本
    if (floorData.costWge) {
        var ge = (floorData.costWge / 10000).toFixed(4);
        lines.push('az> \ud83d\udcb0 ' + ge + ' ge');
    }

    return lines;
}

async function _appendToSearchQuest(questId, floorNum) {
    if (!questId || !floorNum) return;
    var root = questStore.getProjectRoot();
    if (!root) { console.error('[search_quest] no project root'); return; }
    var bridge = window.parent && window.parent.qqqideBridge;
    if (!bridge) { console.error('[search_quest] no bridge'); return; }

    try {
        // 读 floor 数据（唯一真理 SQLite）
        var floorData = await questStore.loadFloor(questId, floorNum);
        if (!floorData) { console.error('[search_quest] loadFloor returned null for q=' + questId + ' f=' + floorNum); return; }
        var questMeta = await questStore.load(questId);

        // 解析 quest 目录路径：优先从 floor 数据推导，回退到磁盘搜索
        var questDir = '';
        if (floorData.allTxtPath) {
            // 从 all.txt 路径反推：.../quests/q{n}.xxx/f{n}.xxx/all.txt → .../quests/q{n}.xxx/
            var parts = floorData.allTxtPath.replace(/\\/g, '/').split('/');
            var questIdx = parts.indexOf('quests');
            if (questIdx >= 0 && questIdx + 1 < parts.length) {
                questDir = parts.slice(0, questIdx + 2).join('/') + '/';
            }
        }
        if (!questDir) {
            // 回退：磁盘搜索以 questId 为前缀的目录
            var questsDir = root + '/qqq/quests/';
            try {
                var entries = await bridge.fs.list(questsDir);
                for (var ei = 0; ei < entries.length; ei++) {
                    if (entries[ei].name.startsWith(questId + '.') && entries[ei].isDir) {
                        questDir = questsDir + entries[ei].name + '/';
                        break;
                    }
                }
            } catch (_) { }
        }
        if (!questDir) return;  // 无法解析目录，静默跳过
        var searchPath = questDir + 'search_quest.txt';

        // 提取时间戳
        var now = new Date();
        var floorTs = now;
        if (questMeta && questMeta.floorTimings) {
            for (var ti = 0; ti < questMeta.floorTimings.length; ti++) {
                var ft = questMeta.floorTimings[ti];
                if (ft.floorIndex === floorNum && ft.finishedAt) {
                    floorTs = new Date(new Date(ft.finishedAt).getTime() - (ft.durationMs || 0));
                    break;
                }
            }
        }

        // 标记行，用于去重检测
        var marker = '\u2550\u2550\u2550\u2550\u2550 Floor ' + floorNum + ' \u2550\u2550\u2550\u2550\u2550';

        // 读已有内容（若存在），检查是否已写过本层楼
        var existing = '';
        var fileExists = await bridge.fs.exists(searchPath);
        if (fileExists) {
            try { existing = await bridge.fs.read(searchPath); } catch (_) { }
        }
        if (existing.indexOf(marker) >= 0) return;  // 已存在，跳过

        // 提取 AI 最终回答（最后一个 final 类型 house 的 answer）
        var houses = floorData.houses || [];
        var answer = '';
        for (var hi = houses.length - 1; hi >= 0; hi--) {
            if (houses[hi].type === 'final' && houses[hi].answer) {
                answer = houses[hi].answer;
                break;
            }
        }

        // 构建条目
        var lines = [];
        if (existing) lines.push('');  // 与上一楼层间隔一行
        lines.push(marker + '   ' + _fmtTime(floorTs));
        var cleanQuestion = (floorData.question || '').replace(/\[File: [^\]]+\]\s*\x0A\`\`\`[\s\S]*?\`\`\`/g, '').replace(/\x0A{3,}/g, '\x0A\x0A').trim(); lines.push('\u25a0 Q: ' + cleanQuestion);
        lines.push('\u25a0 A: ' + (answer || '(no answer)'));

        // ═══ az 区文本化（每层楼私有 A1 + 时钟数据） ═══
        var _azLines = _buildAzText(floorNum, floorData, questMeta);
        for (var _azi = 0; _azi < _azLines.length; _azi++) {
            lines.push(_azLines[_azi]);
        }
        lines.push('');

        // 确保目录存在
        try { await bridge.fs.mkdir(questDir); } catch (_) { }

        // 追加写入
        var newContent = existing + lines.join('\n');
        await bridge.fs.write(searchPath, newContent);
        // [silent] search_quest appended
    } catch (e) {
        console.warn('[search_quest] failed:', e && e.message);
    }
}

var _switching = false;  // 互斥锁：防止快速双击 tab 导致并发切任务
// ═══ 从 questStore 恢复 agent 全量状态（conversation + metadata） ═══
async function _restoreAgentFromStore(questId, ag) {
    if (!questId || !ag) return;
    // ★ 跨面板隔离：agent 正在建楼/恢复中 → 不覆写内存状态
    //    agent 持有最新 conversation / _houses / cost / timing，比磁盘数据更权威。
    //    switchQuest 切回时只 rebind _activeAiDiv，不重建 agent 内部状态。
    if (ag._stopState === 'sending' || ag._recoveryInProgress) return;
    try {
        var data = await questStore.load(questId);
        var allFloors = await questStore.loadAllFloors(questId);

        // 重建 conversation：聚合所有楼层
        ag.conversation = [];
        // ★ 从 conversation 重建 _questErrorLogByFloor（重启后复原分楼层聚合红框）
        ag._questErrorLogByFloor = {};
        ag._questErrorDivByFloor = {};
        for (var fi = 0; fi < allFloors.length; fi++) {
            var fData = allFloors[fi].data;
            var fConv = fData.conversation;
            if (fConv && fConv.length) {
                for (var mi = 0; mi < fConv.length; mi++) {
                    ag.conversation.push(fConv[mi]);
                }
            }
        }
        // ★ 扫描所有 _error 消息重建分楼层错误日志
        for (var _eli = 0; _eli < ag.conversation.length; _eli++) {
            var _em = ag.conversation[_eli];
            if (_em._error && _em.role === 'assistant' && _em.content) {
                var _efn = _em._floor || 0;
                if (!ag._questErrorLogByFloor[_efn]) ag._questErrorLogByFloor[_efn] = [];
                ag._questErrorLogByFloor[_efn].push({ time: '', reason: _em.content });
            }
        }

        // ★ 恢复 _billingSeq：扫描所有楼层 houses，取最大 billingSeq（重启后累加不中断）
        ag._billingSeq = 0;
        for (var _bsfi = 0; _bsfi < allFloors.length; _bsfi++) {
            var _bsfHouses = allFloors[_bsfi].data && allFloors[_bsfi].data.houses;
            if (_bsfHouses && _bsfHouses.length) {
                for (var _bshi = 0; _bshi < _bsfHouses.length; _bshi++) {
                    var _bs = _bsfHouses[_bshi].billingSeq;
                    if (_bs > ag._billingSeq) ag._billingSeq = _bs;
                }
            }
        }
        for (var _bsfi = 0; _bsfi < allFloors.length; _bsfi++) {
            var _bsfHouses = allFloors[_bsfi].data && allFloors[_bsfi].data.houses;
            if (_bsfHouses && _bsfHouses.length) {
                for (var _bshi = 0; _bshi < _bsfHouses.length; _bshi++) {
                    var _bs = _bsfHouses[_bshi].billingSeq;
                    if (_bs > ag._billingSeq) ag._billingSeq = _bs;
                }
            }
        }


        // ★ 恢复 _passbyBase：优先从 quest 元数据（已持久化），降级到上楼层快照
        ag._passbyBaseHouses = 0;
        ag._passbyBaseWge = 0;
        ag._passbyBaseTokens = 0;
        if (data && typeof data.passbyBaseHouses === 'number') {
            ag._passbyBaseHouses = data.passbyBaseHouses;
            ag._passbyBaseWge = data.passbyBaseWge || 0;
            ag._passbyBaseTokens = data.passbyBaseTokens || 0;
        } else {
            for (var _pbfi = 0; _pbfi < allFloors.length; _pbfi++) {
                var _pbData = allFloors[_pbfi].data;
                if (_pbData && allFloors[_pbfi].floorNum === ag._currentFloorNum - 1) {
                    if (typeof _pbData.passbyHouses === 'number') ag._passbyBaseHouses = _pbData.passbyHouses;
                    if (typeof _pbData.passbyWge === 'number') ag._passbyBaseWge = _pbData.passbyWge;
                    if (typeof _pbData.passbyTokens === 'number') ag._passbyBaseTokens = _pbData.passbyTokens;
                    break;
                }
            }
        }
        ag._passbyBaseFloorNum = ag._passbyBaseHouses > 0 ? (ag._currentFloorNum - 1) : 0;
        // ★ 重建 _floorMeta（未可变楼层元数据）
        ag._floorMeta = {};
        for (var _fmfi = 0; _fmfi < allFloors.length; _fmfi++) {
            var _fmfData = allFloors[_fmfi].data;
            if (_fmfData) {
                var _fmfn = allFloors[_fmfi].floorNum;
                ag._floorMeta[_fmfn] = {
                    floorStartIdx: _fmfData._floorStartIdx,
                    allTxtPath: _fmfData.allTxtPath || '',
                    _fDir: _fmfData._fDir || '',
                    createdAt: _fmfData.createdAt || Date.now()
                };
            }
        }

        // ★ a4Snapshots 不恢复：每楼层的 a4 块由 card-pool._buildFloorDOM 通过
        //   _a4RestoreBlock 从 all.json 独立渲染，恢复到 ag 会导致串台——下一楼层
        //   在 sendMessage 清除 ag._a4Snapshots 之前的 auto-save 竞态窗口内会将
        //   上楼层 a4 数据误写入本楼层 all.json。

        // 恢复 metadata
        if (data) {
            ag.totalCostGe = data.totalCostGe || 0;
            ag._lastApiPromptTokens = data.lastApiPromptTokens || 0;
            ag._lastApiTotalTokens = data.lastApiTotalTokens || 0;
            ag._lastApiCompletionTokens = data.lastApiCompletionTokens || 0;
            ag._accumulatedCompletionTokens = data.accumulatedCompletionTokens || 0;
            ag._lastTier = data.lastTier || null;
            ag._uncleanShutdown = data.uncleanShutdown || false;
            ag._ctx.lastCompressedFloor = (data.ctx && data.ctx.lastCompressedFloor) || 0;
            ag._ctx.floorArchives = (data.ctx && data.ctx.floorArchives) || [];
            ag._ctx.totalFloors = (data.ctx && data.ctx.totalFloors) || 0;
            if (data.ctx && data.ctx.narrative) ag._ctx.narrative = data.ctx.narrative;
            if (data.ctx && data.ctx.facts) ag._ctx.facts = data.ctx.facts;
            if (data.ctx && data.ctx.treasures) ag._ctx.treasures = data.ctx.treasures;
            ag._floorTimings = data.floorTimings || [];
            ag._serverDrift = data.serverDrift || 0;
            ag._queue = data.queue || [];
            ag._rulesVersion = data.rulesVersion || '';
            ag._persistentCount = data.persistentCount || 0;
            // ★ 恢复楼层计数器（旧 quest 无此字段时回退到已保存楼层数）
            ag._currentFloorNum = data.currentFloorNum || 0;
        }
        // ★ 恢复 _houses / _floorCostWge / _lastFloorTimingRecord（防重启后 az 区丢失）
        if (ag._currentFloorNum > 0 && allFloors && allFloors.length) {
            for (var _rhfi = allFloors.length - 1; _rhfi >= 0; _rhfi--) {
                if (allFloors[_rhfi].floorNum === ag._currentFloorNum) {
                    var _rhData = allFloors[_rhfi].data;
                    if (_rhData) {
                        if (_rhData.houses && _rhData.houses.length) {
                            ag._houses = _rhData.houses.slice();
                            ag._houseIndex = ag._houses.length;
                        }
                        if (_rhData.costWge) ag._floorCostWge = _rhData.costWge;
                        if (_rhData.clockTiming) ag._lastFloorTimingRecord = _rhData.clockTiming;
                        // ★ 恢复 _lastUserInput（防 switchQuest 重写 all.json 时 question_clean 变空）
                        if (_rhData.lastUserInput) ag._lastUserInput = _rhData.lastUserInput;
                        // ★ 恢复 aq1 指示器字段（跨面板迁移不丢 AI 启动时间）
                        if (_rhData.aiStartTime) ag._aiStartTime = _rhData.aiStartTime;
                        if (_rhData.tierLabel) ag._aiTierLabel = _rhData.tierLabel;
                        // ★ 恢复 _lastAutoSaveLen 防止空 houses 安全网误杀新楼层首存
                        ag._lastAutoSaveLen = (ag.conversation ? ag.conversation.length : 0);
                    }
                    break;
                }
            }
        }
        // ★ B3: 检测「无 house 1」僵尸楼层（agent.send() 未产出 house 1）
        //   统一处理：无 house 1 → 合成 error log → 红字框 + 继续任务（同楼层 0-house 重试）
        if (ag._currentFloorNum > 0 && (!ag._houses || ag._houses.length === 0)) {
            var _hasUserMsg3 = false;
            var _lastUserContent3 = '';
            for (var _mcj = ag.conversation.length - 1; _mcj >= 0; _mcj--) {
                var _mc3 = ag.conversation[_mcj];
                if (_mc3._floor === ag._currentFloorNum) {
                    if (_mc3.role === 'user') {
                        _hasUserMsg3 = true;
                        _lastUserContent3 = _mc3.content || '';
                        break;
                    }
                }
                if (_mc3._floor < ag._currentFloorNum) break;
            }
            if (_hasUserMsg3) {
                // ★ 恢复 _lastUserMsg（0-house 恢复需要原消息）
                if (_lastUserContent3) ag._lastUserMsg = _lastUserContent3;
                // ★ 若无已有 error log → 合成一条（让红框有内容可渲染）
                if (!ag._questErrorLogByFloor[ag._currentFloorNum] || ag._questErrorLogByFloor[ag._currentFloorNum].length === 0) {
                    if (!ag._questErrorLogByFloor[ag._currentFloorNum]) ag._questErrorLogByFloor[ag._currentFloorNum] = [];
                    ag._questErrorLogByFloor[ag._currentFloorNum].push({
                        time: '',
                        reason: '未收到 AI 回复'
                    });
                }
                // ★ 设置 fatal 态（使 panel-quest-ui 重建循环能渲染红框）
                ag._floorFatal = true;
                ag.setStopState('fatal');
                ag._exitReason = ag._exitReason || '未收到 AI 回复';
            }
        }
        // ★ fatal 态持久化恢复：最后一层楼 floorFatal → 死胡同模式
        if (allFloors && allFloors.length > 0) {
            var _lastFloor = allFloors[allFloors.length - 1];
            var _lfData = _lastFloor.data;
            if (_lfData && _lfData.floorFatal) {
                ag.setStopState('fatal');
                ag._floorFatal = true;
                ag._exitReason = _lfData.exitReason || '';
            }
        }
        // ★ 崩溃恢复：上次关闭时正在压缩 → 修复可能的半成品状态
        if (ag._uncleanShutdown) {
            ag._uncleanShutdown = false;
            console.warn("[restore] unclean shutdown detected — state cleaned");
        }
        // ★ 刷新服务器城市（Cloudflare 透传，用于 passby 地理位置展示）
        _refreshServerCity(ag);

        // [silent] restored agent state
    } catch (e) {
        console.warn('[quests] _restoreAgentFromStore error:', e && e.message);
    }
}

// ★ 刷新服务器城市（Cloudflare X-Original-City 透传）
// 直连 gh555.com（不走 direct，防超时）；5s 超时 + 静默失败
async function _refreshServerCity(ag) {
    try {
        var _ctrl = new AbortController();
        var _tid = setTimeout(function () { _ctrl.abort(); }, 5000);
        var resp = await fetch('https://gh555.com/api/geo', { signal: _ctrl.signal });
        clearTimeout(_tid);
        if (resp && resp.ok) {
            var data = await resp.json();
            if (data && data.city) {
                ag._serverCity = data.city;
            }
        }
    } catch (_) { /* 静默 */ }
}

// ★ 计算当前楼层 tokens（prompt + completion）
function _computeFloorTokens(ag) {
    if (!ag || !ag._houses || !ag._houses.length) return 0;
    var _sum = 0;
    for (var i = 0; i < ag._houses.length; i++) {
        var _u = ag._houses[i].usage;
        if (_u) _sum += (_u.prompt_tokens || 0) + (_u.completion_tokens || 0);
    }
    return _sum;
}
