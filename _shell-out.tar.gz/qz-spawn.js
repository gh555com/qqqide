"use strict";
// ============================================================================
// qz-spawn.ts
// Unified spawn entry (qz subsystem).
//
// Tier 1: ghrun.exe  — Rust, full anti-hang, primary
// Tier 2: Node        — child_process.spawn, always-available fallback
//
// Protocol contract:
//   in : {cmd, args, cwd, env, timeout, stallMs, captureOutput}
//   out: {exitCode, stdout, stderr, killReason, tier, pid, durationMs}
//
// ghrun anti-hang (surpasses runner.py):
//   - deadline + stall watchdogs (100ms granularity)
//   - Windows: CREATE_NEW_PROCESS_GROUP + CREATE_NO_WINDOW + taskkill /F /T
//   - POSIX:   process_group(0) → killpg via kill -9 -<pid> + fallback
//   - Output safety-net at IPC level (64KB) — AI-facing limit is in tools.js
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QzSpawn = void 0;
const child_process_1 = require("child_process");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
// Output safety-net cap: prevents huge stdout/stderr from inflating IPC payloads.
// This is NOT the AI-facing limit — that lives in tools.js (OUTPUT_DEFAULT / OUTPUT_MAX).
// Set generously (64KB) so it never interferes with the AI-facing cap.
const MAX_OUTPUT = 65536;
function _capOutput(r) {
    if (r.stdout.length > MAX_OUTPUT) {
        r.stdout = r.stdout.slice(0, MAX_OUTPUT) + '\n...(truncated)';
    }
    if (r.stderr.length > MAX_OUTPUT) {
        r.stderr = r.stderr.slice(0, MAX_OUTPUT);
    }
    return r;
}
// ── System-level hard limits (defense-in-depth against runaway commands) ──
const SYSTEM_MAX_TIMEOUT = 1800000; // 30 min — no command runs longer than this
const MEM_LIMIT_BYTES = 2 * 1024 * 1024 * 1024; // 2GB — kill if child exceeds this
/** Memory guard: polls process tree every 5s, kills if total WorkingSetSize > limit. */
function _startMemGuard(pid, killFn, limit) {
    if (process.platform !== 'win32')
        return null; // TODO: cgroups on Linux
    if (!pid || limit <= 0)
        return null;
    const interval = setInterval(() => {
        try {
            // Sum WorkingSetSize of pid + all descendants via WMI (server-side filter, fast)
            const out = (0, child_process_1.execSync)(`powershell -NoProfile -Command "$sum=0; Get-CimInstance -ClassName Win32_Process -Filter 'ProcessId=${pid} OR ParentProcessId=${pid}' -ErrorAction SilentlyContinue | ForEach-Object { $sum+=$_.WorkingSetSize }; $sum"`, { windowsHide: true, timeout: 5000, encoding: 'utf8' }).trim();
            const bytes = parseInt(out, 10);
            if (!isNaN(bytes) && bytes > limit) {
                console.warn(`[qz] mem-guard: pid ${pid} tree at ${(bytes / 1024 / 1024).toFixed(0)}MB > ${(limit / 1024 / 1024).toFixed(0)}MB, killing tree`);
                killFn();
            }
        }
        catch { /* guard itself must never throw */ }
    }, 5000);
    return interval;
}
// Windows built-in commands (not real executables; need cmd /c wrapper)
const IS_WIN = process.platform === 'win32';
const WIN_BUILTINS = new Set([
    'dir', 'type', 'echo', 'copy', 'del', 'erase', 'set', 'cd', 'chdir',
    'md', 'mkdir', 'rmdir', 'rd', 'ren', 'rename', 'move', 'cls',
    'date', 'time', 'ver', 'vol', 'path', 'prompt', 'title', 'color',
    'assoc', 'ftype', 'pushd', 'popd', 'mklink', 'fc', 'comp',
    'find', 'findstr', 'more', 'sort', 'start',
]);
/** Normalize brief before dispatch: wrap Windows builtins with cmd /c */
function _normalizeBrief(brief) {
    if (!IS_WIN) {
        return;
    }
    if (!brief.cmd) {
        return;
    }
    if (WIN_BUILTINS.has(brief.cmd.toLowerCase())) {
        brief.args = ['/c', brief.cmd, ...(brief.args || [])];
        brief.cmd = 'cmd';
        brief.shell = false;
    }
}
// ---------------------------------------------------------------------------
// Tier resolution helpers
// ---------------------------------------------------------------------------
let _ghrunBinCache = undefined; // undefined=未探测
function resolveGhrunBin(appRoot) {
    if (_ghrunBinCache !== undefined) {
        return _ghrunBinCache;
    }
    const env = process.env.QQQIDE_QDIR_GHRUN;
    if (env && fs.existsSync(env)) {
        _ghrunBinCache = env;
        return env;
    }
    // also probe portable convention: $QQQIDE_QDIR/ghrun.exe
    const qdir = process.env.QQQIDE_QDIR;
    if (qdir) {
        const ext = process.platform === 'win32' ? '.exe' : '';
        const p = path.join(qdir, 'ghrun' + ext);
        if (fs.existsSync(p)) {
            _ghrunBinCache = p;
            return p;
        }
    }
    // also probe engines/ghrun.exe under app root
    if (appRoot) {
        const ext = process.platform === 'win32' ? '.exe' : '';
        const p = path.join(appRoot, 'engines', 'ghrun' + ext);
        if (fs.existsSync(p)) {
            _ghrunBinCache = p;
            return p;
        }
    }
    _ghrunBinCache = null;
    return null;
}
// ---------------------------------------------------------------------------
// Tier 2: Node child_process spawn (always available)
// ---------------------------------------------------------------------------
function nodeTier(brief, appRoot) {
    return new Promise((resolve) => {
        const start = Date.now();
        const args = brief.args || [];
        // A1: cap all timeouts at SYSTEM_MAX_TIMEOUT (10 min hard ceiling)
        const rawTimeout = brief.timeout != null ? brief.timeout : 60000;
        const timeoutMs = rawTimeout > 0 ? Math.min(rawTimeout, SYSTEM_MAX_TIMEOUT) : SYSTEM_MAX_TIMEOUT;
        const stallMs = brief.stallMs != null ? brief.stallMs : 0;
        const capture = brief.captureOutput !== false;
        const inheritEnv = brief.inheritEnv !== false;
        const useShell = brief.shell === true;
        const env = inheritEnv ? { ...process.env, ...(brief.env || {}) } : { ...(brief.env || {}) };
        let proc;
        try {
            proc = (0, child_process_1.spawn)(brief.cmd, args, {
                cwd: brief.cwd || appRoot,
                windowsHide: true,
                shell: useShell,
                env,
                detached: process.platform !== 'win32', // POSIX: own process group
            });
        }
        catch (err) {
            return resolve({
                exitCode: -1,
                stdout: '',
                stderr: String(err && err.message || err),
                killReason: 'spawn-error',
                tier: 'node',
                durationMs: Date.now() - start,
            });
        }
        let stdout = '';
        let stderr = '';
        let killed = false;
        let killReason = '';
        let lastIOAt = Date.now();
        const killTree = () => {
            if (!proc.pid) {
                return;
            }
            try {
                if (process.platform === 'win32') {
                    // Tree kill: taskkill /F /T /PID <pid>
                    (0, child_process_1.spawn)('taskkill', ['/F', '/T', '/PID', String(proc.pid)], { windowsHide: true });
                }
                else {
                    try {
                        process.kill(-proc.pid, 'SIGKILL');
                    }
                    catch {
                        try {
                            proc.kill('SIGKILL');
                        }
                        catch { /* ignore */ }
                    }
                }
            }
            catch { /* ignore */ }
        };
        if (capture && proc.stdout) {
            proc.stdout.setEncoding('utf8');
            proc.stdout.on('data', (d) => { stdout += d; lastIOAt = Date.now(); });
        }
        if (capture && proc.stderr) {
            proc.stderr.setEncoding('utf8');
            proc.stderr.on('data', (d) => { stderr += d; lastIOAt = Date.now(); });
        }
        // A4: memory guard — poll child WorkingSet64 every 5s, kill if > 2GB
        const memGuardInterval = proc.pid ? _startMemGuard(proc.pid, () => {
            killed = true;
            killReason = 'mem-guard';
            killTree();
        }, MEM_LIMIT_BYTES) : null;
        // A1/A3: deadline timer — always active (timeoutMs guaranteed ≤ SYSTEM_MAX_TIMEOUT)
        const deadlineTimer = setTimeout(() => {
            killed = true;
            killReason = 'deadline';
            killTree();
        }, timeoutMs);
        let stallTimer = null;
        if (stallMs > 0) {
            const tick = () => {
                if (killed) {
                    return;
                }
                if (Date.now() - lastIOAt > stallMs) {
                    killed = true;
                    killReason = 'stall';
                    killTree();
                    return;
                }
                stallTimer = setTimeout(tick, Math.max(1000, Math.floor(stallMs / 4)));
            };
            stallTimer = setTimeout(tick, Math.max(1000, Math.floor(stallMs / 4)));
        }
        const cleanup = () => {
            clearTimeout(deadlineTimer);
            if (stallTimer) {
                clearTimeout(stallTimer);
            }
            if (memGuardInterval) {
                clearInterval(memGuardInterval);
            }
        };
        proc.on('exit', (code) => {
            cleanup();
            const extra = killed ? `\n[killed: ${killReason} after ${Date.now() - start}ms]` : '';
            resolve({
                exitCode: killed ? -1 : (code ?? -1),
                stdout,
                stderr: stderr + extra,
                killReason,
                tier: 'node',
                pid: proc.pid,
                durationMs: Date.now() - start,
            });
        });
        proc.on('error', (err) => {
            cleanup();
            resolve({
                exitCode: -1,
                stdout,
                stderr: stderr + '\n' + (err.message || String(err)),
                killReason: 'spawn-error',
                tier: 'node',
                pid: proc.pid,
                durationMs: Date.now() - start,
            });
        });
    });
}
// ---------------------------------------------------------------------------
// Tier 1: ghrun.exe — Rust, surpasses runner.py (deadline + stall + killpg + output cap + error diff)
//
// Wire format: ghrun spawn --json, stdin one-line JSON, stdout one-line JSON.
// ---------------------------------------------------------------------------
function ghrunTier(brief, appRoot, ghrunBin) {
    return new Promise((resolve) => {
        const start = Date.now();
        // A1: cap all timeouts at SYSTEM_MAX_TIMEOUT (10 min hard ceiling)
        const rawTimeout = brief.timeout != null ? brief.timeout : 60000;
        const timeoutMs = rawTimeout > 0 ? Math.min(rawTimeout, SYSTEM_MAX_TIMEOUT) : SYSTEM_MAX_TIMEOUT;
        // A2: guardMs always timeout+10s, never 24h (was: 86400000 when timeout=0)
        const guardMs = timeoutMs + 10000;
        const payload = JSON.stringify({
            cmd: brief.cmd,
            args: brief.args || [],
            cwd: brief.cwd || appRoot,
            env: brief.env || null,
            timeout: timeoutMs,
            stallMs: brief.stallMs || 0,
            memLimitMb: Math.floor(MEM_LIMIT_BYTES / (1024 * 1024)),
            captureOutput: brief.captureOutput !== false,
        });
        let proc;
        try {
            proc = (0, child_process_1.spawn)(ghrunBin, ['spawn', '--json'], {
                cwd: appRoot,
                windowsHide: true,
                env: { ...process.env },
            });
        }
        catch (err) {
            return resolve({
                exitCode: -1, stdout: '', stderr: String(err && err.message || err),
                killReason: 'spawn-error', tier: 'ghrun', durationMs: Date.now() - start,
            });
        }
        let outBuf = '';
        let errBuf = '';
        let done = false;
        // A4: memory guard for ghrun tier — monitor ghrun's process tree
        // Uses PowerShell to sum WorkingSet64 of ghrun + all descendants
        const memGuardInterval = proc.pid ? _startMemGuard(proc.pid, () => {
            if (!done) {
                finish({
                    exitCode: -1, stdout: outBuf, stderr: 'ghrun_mem_guard_killed',
                    killReason: 'mem-guard', tier: 'ghrun',
                    pid: proc.pid, durationMs: Date.now() - start,
                });
            }
        }, MEM_LIMIT_BYTES) : null;
        const finish = (r) => {
            if (done) {
                return;
            }
            done = true;
            clearTimeout(guard);
            if (memGuardInterval) {
                clearInterval(memGuardInterval);
            }
            // Tree-kill ghrun + child on forced termination (mem-guard/deadline)
            if (r.killReason) {
                try {
                    if (process.platform === 'win32') {
                        (0, child_process_1.spawn)('taskkill', ['/F', '/T', '/PID', String(proc.pid)], { windowsHide: true });
                    }
                    else {
                        try {
                            process.kill(-proc.pid, 'SIGKILL');
                        }
                        catch {
                            proc.kill('SIGKILL');
                        }
                    }
                }
                catch { /* ignore */ }
            }
            else {
                try {
                    proc.kill();
                }
                catch { /* ignore */ }
            }
            resolve(r);
        };
        proc.stdout.setEncoding('utf8');
        proc.stderr.setEncoding('utf8');
        proc.stdout.on('data', (d) => { outBuf += d; });
        proc.stderr.on('data', (d) => { errBuf += d; });
        proc.on('exit', (code) => {
            if (done) {
                return;
            }
            const nl = outBuf.indexOf('\n');
            const line = nl >= 0 ? outBuf.slice(0, nl) : outBuf;
            try {
                const r = JSON.parse(line);
                finish({
                    exitCode: typeof r.exitCode === 'number' ? r.exitCode : (code ?? -1),
                    stdout: String(r.stdout || ''),
                    stderr: String(r.stderr || ''),
                    killReason: (r.killReason || ''),
                    tier: 'ghrun', pid: proc.pid, durationMs: Date.now() - start,
                });
            }
            catch {
                finish({
                    exitCode: code ?? -1, stdout: outBuf, stderr: errBuf || 'ghrun_bad_json',
                    killReason: 'spawn-error', tier: 'ghrun',
                    pid: proc.pid, durationMs: Date.now() - start,
                });
            }
        });
        proc.on('error', (err) => finish({
            exitCode: -1, stdout: '', stderr: String(err.message || err),
            killReason: 'spawn-error', tier: 'ghrun',
            pid: proc.pid, durationMs: Date.now() - start,
        }));
        const guard = setTimeout(() => finish({
            exitCode: -1, stdout: '', stderr: 'ghrun_guard_timeout',
            killReason: 'deadline', tier: 'ghrun',
            pid: proc.pid, durationMs: Date.now() - start,
        }), guardMs);
        try {
            proc.stdin.write(payload + '\n');
            proc.stdin.end();
        }
        catch (err) {
            finish({
                exitCode: -1, stdout: '', stderr: String(err.message || err),
                killReason: 'spawn-error', tier: 'ghrun',
                pid: proc.pid, durationMs: Date.now() - start,
            });
        }
    });
}
// ---------------------------------------------------------------------------
// Public entry
// ---------------------------------------------------------------------------
class QzSpawn {
    constructor(appRoot) {
        this.appRoot = appRoot;
    }
    /** Probe ghrun availability (synchronous file check). */
    ghrunAlive() {
        return !!resolveGhrunBin(this.appRoot);
    }
    /**
     * Locate a command in $PATH (synchronous, posix `command -v` equivalent).
     * Returns absolute path or null if not found.
     */
    which(cmd) {
        if (!cmd) {
            return null;
        }
        if (path.isAbsolute(cmd)) {
            return fs.existsSync(cmd) ? cmd : null;
        }
        const dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
        const exts = process.platform === 'win32'
            ? (process.env.PATHEXT || '.EXE;.BAT;.CMD;.COM').split(';').filter(Boolean)
            : [''];
        for (const dir of dirs) {
            for (const ext of exts) {
                const p = path.join(dir, cmd + ext);
                try {
                    if (fs.statSync(p).isFile()) {
                        return p;
                    }
                }
                catch { /* skip */ }
            }
        }
        return null;
    }
    /** Unified spawn entry. Two-tier: ghrun → node child_process. */
    async spawn(brief) {
        if (!brief || !brief.cmd) {
            return {
                exitCode: -1, stdout: '', stderr: 'qz.spawn: missing brief.cmd',
                killReason: 'spawn-error', tier: 'node', durationMs: 0,
            };
        }
        _normalizeBrief(brief);
        // A1: enforce system max timeout — no command runs longer than 10 minutes
        if (brief.timeout == null || brief.timeout <= 0 || brief.timeout > SYSTEM_MAX_TIMEOUT) {
            brief.timeout = SYSTEM_MAX_TIMEOUT;
        }
        // Tier 1: ghrun (Rust, full anti-hang: deadline + stall + tree-kill + process group isolation)
        const ghrun = resolveGhrunBin(this.appRoot);
        if (ghrun) {
            try {
                const r = await ghrunTier(brief, this.appRoot, ghrun);
                if (r.killReason !== 'spawn-error') {
                    if (r.killReason) {
                        console.warn('[qz] ghrun killed:', brief.cmd, 'reason:', r.killReason, r.durationMs + 'ms');
                    }
                    else {
                        console.log('[qz] ghrun OK:', brief.cmd, r.durationMs + 'ms');
                    }
                    return _capOutput(r);
                }
                console.warn('[qz] ghrun spawn-error, falling back to node:', r.stderr.slice(0, 200));
            }
            catch (e) {
                console.warn('[qz] ghrun threw, falling back to node:', e && e.message);
            }
        }
        // Tier 2: node (always available)
        return _capOutput(await nodeTier(brief, this.appRoot));
    }
    /** Spawn a long-lived process with persistent stdin/stdout.
     *  Used by LSP bridge — process stays alive, messages flow bidirectionally. */
    spawnPersist(brief) {
        if (!brief || !brief.cmd) {
            console.error('[qz] spawnPersist: missing brief.cmd');
            return null;
        }
        const args = brief.args || [];
        const cwd = brief.cwd || this.appRoot;
        const inheritEnv = brief.inheritEnv !== false;
        const env = inheritEnv
            ? { ...process.env, ...(brief.env || {}) }
            : { ...(brief.env || {}) };
        const idleTimeout = brief.idleTimeout || 0;
        let proc;
        try {
            proc = (0, child_process_1.spawn)(brief.cmd, args, {
                cwd,
                windowsHide: true,
                env,
                stdio: ['pipe', 'pipe', 'pipe'],
            });
        }
        catch (err) {
            console.error('[qz] spawnPersist error:', err?.message || err);
            return null;
        }
        if (!proc.stdin || !proc.stdout) {
            console.error('[qz] spawnPersist: no stdio pipes');
            try {
                proc.kill();
            }
            catch { /* ignore */ }
            return null;
        }
        const dataHandlers = [];
        const stderrHandlers = [];
        const exitHandlers = [];
        let alive = true;
        let lastDataAt = Date.now();
        let idleTimer = null;
        // --- Idle timeout watchdog ---
        if (idleTimeout > 0) {
            const tick = () => {
                if (!alive)
                    return;
                if (Date.now() - lastDataAt > idleTimeout) {
                    console.warn('[qz] spawnPersist idle timeout, killing:', brief.cmd);
                    try {
                        proc.kill();
                    }
                    catch { /* ignore */ }
                    return;
                }
                idleTimer = setTimeout(tick, Math.max(5000, Math.floor(idleTimeout / 4)));
            };
            idleTimer = setTimeout(tick, Math.max(5000, Math.floor(idleTimeout / 4)));
        }
        // --- stdout: accumulate and emit line-by-line (LSP Content-Length header aware) ---
        let stdoutBuf = '';
        proc.stdout.setEncoding('utf8');
        proc.stdout.on('data', (chunk) => {
            lastDataAt = Date.now();
            stdoutBuf += chunk;
            // Try to extract complete LSP messages (Content-Length: N\r\n\r\n{...})
            // If not LSP, emit raw lines on newline boundaries
            while (stdoutBuf.length > 0) {
                const lspMatch = stdoutBuf.match(/^Content-Length: (\d+)\r\n\r\n/);
                if (lspMatch) {
                    const headerLen = lspMatch[0].length;
                    const bodyLen = parseInt(lspMatch[1], 10);
                    // Reject oversized frames (aligns with lsp_daemon.rs 50MB)
                    if (isNaN(bodyLen) || bodyLen > 50 * 1024 * 1024) {
                        stdoutBuf = ''; // discard corrupted data
                        break;
                    }
                    if (stdoutBuf.length >= headerLen + bodyLen) {
                        const body = stdoutBuf.slice(headerLen, headerLen + bodyLen);
                        stdoutBuf = stdoutBuf.slice(headerLen + bodyLen);
                        for (const h of dataHandlers) {
                            h(body);
                        }
                        continue;
                    }
                    else {
                        break; // incomplete message, wait for more data
                    }
                }
                // Fallback: emit on newline boundaries
                const nl = stdoutBuf.indexOf('\n');
                if (nl >= 0) {
                    const line = stdoutBuf.slice(0, nl);
                    stdoutBuf = stdoutBuf.slice(nl + 1);
                    if (line.trim()) {
                        for (const h of dataHandlers) {
                            h(line);
                        }
                    }
                    continue;
                }
                break; // no complete line found
            }
        });
        // --- stderr ---
        if (proc.stderr) {
            proc.stderr.setEncoding('utf8');
            proc.stderr.on('data', (chunk) => {
                lastDataAt = Date.now();
                for (const h of stderrHandlers) {
                    h(chunk);
                }
            });
        }
        // --- exit ---
        proc.on('exit', (code) => {
            alive = false;
            if (idleTimer) {
                clearTimeout(idleTimer);
            }
            for (const h of exitHandlers) {
                h(code);
            }
        });
        proc.on('error', (err) => {
            console.error('[qz] spawnPersist process error:', err?.message || err);
            alive = false;
            if (idleTimer) {
                clearTimeout(idleTimer);
            }
            for (const h of exitHandlers) {
                h(-1);
            }
        });
        const handle = {
            pid: proc.pid || 0,
            alive: () => alive,
            send: (line) => {
                if (!alive || !proc.stdin)
                    return;
                try {
                    proc.stdin.write(line + '\n');
                }
                catch (e) {
                    console.error('[qz] spawnPersist write error:', e);
                }
            },
            onData: (handler) => { dataHandlers.push(handler); },
            onStderr: (handler) => { stderrHandlers.push(handler); },
            onExit: (handler) => { exitHandlers.push(handler); },
            shutdown: async () => {
                if (!alive)
                    return;
                try {
                    proc.stdin?.end();
                }
                catch { /* ignore */ }
                // Wait up to 5s for graceful exit
                await new Promise((resolve) => {
                    const t = setTimeout(() => { try {
                        proc.kill();
                    }
                    catch { /* */ } resolve(); }, 5000);
                    proc.on('exit', () => { clearTimeout(t); resolve(); });
                });
            },
            kill: () => {
                if (!alive)
                    return;
                alive = false;
                if (idleTimer) {
                    clearTimeout(idleTimer);
                }
                try {
                    proc.kill();
                }
                catch { /* ignore */ }
            },
        };
        return handle;
    }
}
exports.QzSpawn = QzSpawn;
//# sourceMappingURL=qz-spawn.js.map