"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// shell/qz-spawn.ts
var qz_spawn_exports = {};
__export(qz_spawn_exports, {
  QzSpawn: () => QzSpawn,
  registerQzSpawnIpc: () => registerQzSpawnIpc
});
module.exports = __toCommonJS(qz_spawn_exports);
var import_child_process = require("child_process");
var path = __toESM(require("path"));
var fs = __toESM(require("fs"));
var import_electron = require("electron");
var MAX_OUTPUT = 65536;
function _capOutput(r) {
  if (r.stdout.length > MAX_OUTPUT) {
    r.stdout = r.stdout.slice(0, MAX_OUTPUT) + "\n...(truncated)";
  }
  if (r.stderr.length > MAX_OUTPUT) {
    r.stderr = r.stderr.slice(0, MAX_OUTPUT);
  }
  return r;
}
var SYSTEM_MAX_TIMEOUT = 72e5;
var MEM_LIMIT_BYTES = 2 * 1024 * 1024 * 1024;
function _startMemGuard(pid, killFn, limit) {
  if (!pid || limit <= 0)
    return null;
  let stopped = false;
  const isWin = process.platform === "win32";
  const memCmd = isWin ? {
    bin: "powershell",
    args: [
      "-NoProfile",
      "-Command",
      `$sum=0; Get-CimInstance -ClassName Win32_Process -Filter 'ProcessId=${pid} OR ParentProcessId=${pid}' -ErrorAction SilentlyContinue | ForEach-Object { $sum+=$_.WorkingSetSize }; $sum`
    ]
  } : {
    bin: "sh",
    args: [
      "-c",
      `ps -o rss= --pid ${pid} --ppid ${pid} 2>/dev/null | awk '{s+=$1} END {print s*1024}'`
    ]
  };
  const poll = () => {
    if (stopped)
      return;
    (0, import_child_process.execFile)(
      memCmd.bin,
      memCmd.args,
      { windowsHide: isWin, timeout: 5e3, encoding: "utf8" },
      (err, stdout) => {
        if (stopped)
          return;
        try {
          const bytes = parseInt((stdout || "").trim(), 10);
          if (!isNaN(bytes) && bytes > limit) {
            console.warn(`[qz] mem-guard: pid ${pid} tree at ${(bytes / 1024 / 1024).toFixed(0)}MB > ${(limit / 1024 / 1024).toFixed(0)}MB, killing tree`);
            killFn();
            stopped = true;
            return;
          }
        } catch {
        }
        setTimeout(poll, 15e3);
      }
    );
  };
  setTimeout(poll, 5e3);
  return { stop: () => {
    stopped = true;
  } };
}
var IS_WIN = process.platform === "win32";
var WIN_BUILTINS = /* @__PURE__ */ new Set([
  "dir",
  "type",
  "echo",
  "copy",
  "del",
  "erase",
  "set",
  "cd",
  "chdir",
  "md",
  "mkdir",
  "rmdir",
  "rd",
  "ren",
  "rename",
  "move",
  "cls",
  "date",
  "time",
  "ver",
  "vol",
  "path",
  "prompt",
  "title",
  "color",
  "assoc",
  "ftype",
  "pushd",
  "popd",
  "mklink",
  "fc",
  "comp",
  "find",
  "findstr",
  "more",
  "sort",
  "start"
]);
var SHELL_META_RE = /[|&;<>]/;
function _normalizeBrief(brief) {
  if (!brief.cmd) {
    return;
  }
  var cmdLower = brief.cmd.toLowerCase();
  var hasMeta = SHELL_META_RE.test(brief.cmd);
  if (!hasMeta && brief.args) {
    for (var i = 0; i < brief.args.length; i++) {
      if (SHELL_META_RE.test(brief.args[i])) {
        hasMeta = true;
        break;
      }
    }
  }
  if (hasMeta && cmdLower !== "cmd" && cmdLower !== "sh") {
    var fullCmd = brief.cmd;
    if (brief.args && brief.args.length) {
      var quoted = brief.args.map(function(a) {
        if (/\s/.test(a) || SHELL_META_RE.test(a))
          return '"' + a.replace(/"/g, '\\"') + '"';
        return a;
      });
      fullCmd += " " + quoted.join(" ");
    }
    if (IS_WIN) {
      brief.cmd = "cmd";
      brief.args = ["/c", fullCmd];
    } else {
      brief.cmd = "sh";
      brief.args = ["-c", fullCmd];
    }
    brief.shell = false;
    return;
  }
  if (IS_WIN && WIN_BUILTINS.has(cmdLower)) {
    brief.args = ["/c", brief.cmd, ...brief.args || []];
    brief.cmd = "cmd";
    brief.shell = false;
  }
}
var _ghrunBinCache = void 0;
function resolveGhrunBin(appRoot) {
  if (_ghrunBinCache !== void 0) {
    return _ghrunBinCache;
  }
  const env = process.env.QQQIDE_QDIR_GHRUN;
  if (env && fs.existsSync(env)) {
    _ghrunBinCache = env;
    return env;
  }
  const qdir = process.env.QQQIDE_QDIR;
  if (qdir) {
    const ext = process.platform === "win32" ? ".exe" : "";
    const p = path.join(qdir, "ghrun" + ext);
    if (fs.existsSync(p)) {
      _ghrunBinCache = p;
      return p;
    }
  }
  if (appRoot) {
    const ext = process.platform === "win32" ? ".exe" : "";
    const p = path.join(appRoot, "engines", "ghrun" + ext);
    if (fs.existsSync(p)) {
      _ghrunBinCache = p;
      return p;
    }
  }
  _ghrunBinCache = null;
  return null;
}
function nodeTier(brief, appRoot) {
  return new Promise((resolve) => {
    const start = Date.now();
    const args = brief.args || [];
    const rawTimeout = brief.timeout != null ? brief.timeout : 6e4;
    const timeoutMs = rawTimeout > 0 ? Math.min(rawTimeout, SYSTEM_MAX_TIMEOUT) : SYSTEM_MAX_TIMEOUT;
    const stallMs = brief.stallMs != null ? brief.stallMs : 0;
    const capture = brief.captureOutput !== false;
    const inheritEnv = brief.inheritEnv !== false;
    const useShell = brief.shell === true;
    const env = inheritEnv ? { ...process.env, ...brief.env || {} } : { ...brief.env || {} };
    let proc;
    try {
      proc = (0, import_child_process.spawn)(brief.cmd, args, {
        cwd: brief.cwd || appRoot,
        windowsHide: true,
        shell: useShell,
        env,
        detached: process.platform !== "win32"
        // POSIX: own process group
      });
    } catch (err) {
      return resolve({
        exitCode: -1,
        stdout: "",
        stderr: String(err && err.message || err),
        killReason: "spawn-error",
        tier: "node",
        durationMs: Date.now() - start
      });
    }
    let stdout = "";
    let stderr = "";
    let killed = false;
    let killReason = "";
    let lastIOAt = Date.now();
    const killTree = () => {
      if (!proc.pid) {
        return;
      }
      try {
        if (process.platform === "win32") {
          (0, import_child_process.spawn)("taskkill", ["/F", "/T", "/PID", String(proc.pid)], { windowsHide: true });
        } else {
          try {
            process.kill(-proc.pid, "SIGKILL");
          } catch {
            try {
              proc.kill("SIGKILL");
            } catch {
            }
          }
        }
      } catch {
      }
    };
    if (capture && proc.stdout) {
      proc.stdout.setEncoding("utf8");
      proc.stdout.on("data", (d) => {
        stdout += d;
        lastIOAt = Date.now();
      });
    }
    if (capture && proc.stderr) {
      proc.stderr.setEncoding("utf8");
      proc.stderr.on("data", (d) => {
        stderr += d;
        lastIOAt = Date.now();
      });
    }
    const memGuardInterval = proc.pid ? _startMemGuard(proc.pid, () => {
      killed = true;
      killReason = "mem-guard";
      killTree();
    }, MEM_LIMIT_BYTES) : null;
    const deadlineTimer = setTimeout(() => {
      killed = true;
      killReason = "deadline";
      killTree();
    }, timeoutMs);
    let stallTimer = null;
    if (stallMs > 0) {
      const tick = () => {
        if (killed) {
          return;
        }
        if (Date.now() - lastIOAt > stallMs) {
          killed = true;
          killReason = "stall";
          killTree();
          return;
        }
        stallTimer = setTimeout(tick, Math.max(1e3, Math.floor(stallMs / 4)));
      };
      stallTimer = setTimeout(tick, Math.max(1e3, Math.floor(stallMs / 4)));
    }
    const cleanup = () => {
      clearTimeout(deadlineTimer);
      if (stallTimer) {
        clearTimeout(stallTimer);
      }
      if (memGuardInterval) {
        memGuardInterval.stop();
      }
    };
    proc.on("exit", (code) => {
      cleanup();
      const extra = killed ? `
[killed: ${killReason} after ${Date.now() - start}ms]` : "";
      resolve({
        exitCode: killed ? -1 : code ?? -1,
        stdout,
        stderr: stderr + extra,
        killReason,
        tier: "node",
        pid: proc.pid,
        durationMs: Date.now() - start
      });
    });
    proc.on("error", (err) => {
      cleanup();
      resolve({
        exitCode: -1,
        stdout,
        stderr: stderr + "\n" + (err.message || String(err)),
        killReason: "spawn-error",
        tier: "node",
        pid: proc.pid,
        durationMs: Date.now() - start
      });
    });
  });
}
function ghrunTier(brief, appRoot, ghrunBin) {
  return new Promise((resolve) => {
    const start = Date.now();
    const rawTimeout = brief.timeout != null ? brief.timeout : 6e4;
    const timeoutMs = rawTimeout > 0 ? Math.min(rawTimeout, SYSTEM_MAX_TIMEOUT) : SYSTEM_MAX_TIMEOUT;
    const guardMs = timeoutMs + 1e4;
    const payload = JSON.stringify({
      cmd: brief.cmd,
      args: brief.args || [],
      cwd: brief.cwd || appRoot,
      env: brief.env || null,
      timeout: timeoutMs,
      stallMs: brief.stallMs || 0,
      memLimitMb: Math.floor(MEM_LIMIT_BYTES / (1024 * 1024)),
      // B2: native Job Object hint (honored when ghrun supports it)
      captureOutput: brief.captureOutput !== false
    });
    let proc;
    try {
      proc = (0, import_child_process.spawn)(ghrunBin, ["spawn", "--json"], {
        cwd: appRoot,
        windowsHide: true,
        env: { ...process.env }
      });
    } catch (err) {
      return resolve({
        exitCode: -1,
        stdout: "",
        stderr: String(err && err.message || err),
        killReason: "spawn-error",
        tier: "ghrun",
        durationMs: Date.now() - start
      });
    }
    let outBuf = "";
    let errBuf = "";
    let done = false;
    const finish = (r) => {
      if (done) {
        return;
      }
      done = true;
      clearTimeout(guard);
      if (r.killReason) {
        try {
          if (process.platform === "win32") {
            (0, import_child_process.spawn)("taskkill", ["/F", "/T", "/PID", String(proc.pid)], { windowsHide: true });
          } else {
            try {
              process.kill(-proc.pid, "SIGKILL");
            } catch {
              proc.kill("SIGKILL");
            }
          }
        } catch {
        }
      } else {
        try {
          proc.kill();
        } catch {
        }
      }
      resolve(r);
    };
    proc.stdout.setEncoding("utf8");
    proc.stderr.setEncoding("utf8");
    proc.stdout.on("data", (d) => {
      outBuf += d;
    });
    proc.stderr.on("data", (d) => {
      errBuf += d;
    });
    proc.on("exit", (code) => {
      if (done) {
        return;
      }
      const nl = outBuf.indexOf("\n");
      const line = nl >= 0 ? outBuf.slice(0, nl) : outBuf;
      try {
        const r = JSON.parse(line);
        finish({
          exitCode: typeof r.exitCode === "number" ? r.exitCode : code ?? -1,
          stdout: String(r.stdout || ""),
          stderr: String(r.stderr || ""),
          killReason: r.killReason || "",
          tier: "ghrun",
          pid: proc.pid,
          durationMs: Date.now() - start
        });
      } catch {
        finish({
          exitCode: code ?? -1,
          stdout: outBuf,
          stderr: errBuf || "ghrun_bad_json",
          killReason: "spawn-error",
          tier: "ghrun",
          pid: proc.pid,
          durationMs: Date.now() - start
        });
      }
    });
    proc.on("error", (err) => finish({
      exitCode: -1,
      stdout: "",
      stderr: String(err.message || err),
      killReason: "spawn-error",
      tier: "ghrun",
      pid: proc.pid,
      durationMs: Date.now() - start
    }));
    const guard = setTimeout(() => finish({
      exitCode: -1,
      stdout: "",
      stderr: "ghrun_guard_timeout",
      killReason: "deadline",
      tier: "ghrun",
      pid: proc.pid,
      durationMs: Date.now() - start
    }), guardMs);
    try {
      proc.stdin.write(payload + "\n");
      proc.stdin.end();
    } catch (err) {
      finish({
        exitCode: -1,
        stdout: "",
        stderr: String(err.message || err),
        killReason: "spawn-error",
        tier: "ghrun",
        pid: proc.pid,
        durationMs: Date.now() - start
      });
    }
  });
}
var QzSpawn = class {
  constructor(appRoot) {
    this.appRoot = appRoot;
  }
  /** Probe ghrun availability (synchronous file check). */
  ghrunAlive() {
    return !!resolveGhrunBin(this.appRoot);
  }
  /**
   * Locate a command in $PATH (synchronous, posix `command -v` equivalent).
   * Returns absolute path or null if not found.
   */
  which(cmd) {
    if (!cmd) {
      return null;
    }
    if (path.isAbsolute(cmd)) {
      return fs.existsSync(cmd) ? cmd : null;
    }
    const dirs = (process.env.PATH || "").split(path.delimiter).filter(Boolean);
    const exts = process.platform === "win32" ? (process.env.PATHEXT || ".EXE;.BAT;.CMD;.COM").split(";").filter(Boolean) : [""];
    for (const dir of dirs) {
      for (const ext of exts) {
        const p = path.join(dir, cmd + ext);
        try {
          if (fs.statSync(p).isFile()) {
            return p;
          }
        } catch {
        }
      }
    }
    return null;
  }
  /** Unified spawn entry. Two-tier: ghrun → node child_process. */
  async spawn(brief) {
    if (!brief || !brief.cmd) {
      return {
        exitCode: -1,
        stdout: "",
        stderr: "qz.spawn: missing brief.cmd",
        killReason: "spawn-error",
        tier: "node",
        durationMs: 0
      };
    }
    _normalizeBrief(brief);
    if (brief.timeout == null || brief.timeout <= 0 || brief.timeout > SYSTEM_MAX_TIMEOUT) {
      brief.timeout = SYSTEM_MAX_TIMEOUT;
    }
    const ghrun = resolveGhrunBin(this.appRoot);
    if (ghrun) {
      try {
        const r = await ghrunTier(brief, this.appRoot, ghrun);
        if (r.killReason !== "spawn-error") {
          if (r.killReason) {
            try {
              console.warn("[qz] ghrun killed:", brief.cmd, "reason:", r.killReason, r.durationMs + "ms");
            } catch (_) {
            }
          } else {
            try {
              console.log("[qz] ghrun OK:", brief.cmd, r.durationMs + "ms");
            } catch (_) {
            }
          }
          return _capOutput(r);
        }
        try {
          console.warn("[qz] ghrun spawn-error, falling back to node:", r.stderr.slice(0, 200));
        } catch (_) {
        }
      } catch (e) {
        try {
          console.warn("[qz] ghrun threw, falling back to node:", e && e.message);
        } catch (_) {
        }
      }
    }
    return _capOutput(await nodeTier(brief, this.appRoot));
  }
  /** Spawn a long-lived process with persistent stdin/stdout.
   *  Used by LSP bridge — process stays alive, messages flow bidirectionally. */
  spawnPersist(brief) {
    if (!brief || !brief.cmd) {
      console.error("[qz] spawnPersist: missing brief.cmd");
      return null;
    }
    const args = brief.args || [];
    const cwd = brief.cwd || this.appRoot;
    const inheritEnv = brief.inheritEnv !== false;
    const env = inheritEnv ? { ...process.env, ...brief.env || {} } : { ...brief.env || {} };
    const idleTimeout = brief.idleTimeout || 0;
    let proc;
    try {
      proc = (0, import_child_process.spawn)(brief.cmd, args, {
        cwd,
        windowsHide: true,
        env,
        stdio: ["pipe", "pipe", "pipe"]
      });
    } catch (err) {
      console.error("[qz] spawnPersist error:", err?.message || err);
      return null;
    }
    if (!proc.stdin || !proc.stdout) {
      console.error("[qz] spawnPersist: no stdio pipes");
      try {
        proc.kill();
      } catch {
      }
      return null;
    }
    const dataHandlers = [];
    const stderrHandlers = [];
    const exitHandlers = [];
    let alive = true;
    let lastDataAt = Date.now();
    let idleTimer = null;
    if (idleTimeout > 0) {
      const tick = () => {
        if (!alive)
          return;
        if (Date.now() - lastDataAt > idleTimeout) {
          try {
            proc.kill();
          } catch {
          }
          try {
            console.warn("[qz] spawnPersist idle timeout, killing:", brief.cmd);
          } catch (_) {
          }
          return;
        }
        idleTimer = setTimeout(tick, Math.max(5e3, Math.floor(idleTimeout / 4)));
      };
      idleTimer = setTimeout(tick, Math.max(5e3, Math.floor(idleTimeout / 4)));
    }
    let stdoutBuf = "";
    proc.stdout.setEncoding("utf8");
    proc.stdout.on("data", (chunk) => {
      lastDataAt = Date.now();
      stdoutBuf += chunk;
      while (stdoutBuf.length > 0) {
        const lspMatch = stdoutBuf.match(/^Content-Length: (\d+)\r\n\r\n/);
        if (lspMatch) {
          const headerLen = lspMatch[0].length;
          const bodyLen = parseInt(lspMatch[1], 10);
          if (isNaN(bodyLen) || bodyLen > 50 * 1024 * 1024) {
            stdoutBuf = "";
            break;
          }
          if (stdoutBuf.length >= headerLen + bodyLen) {
            const body = stdoutBuf.slice(headerLen, headerLen + bodyLen);
            stdoutBuf = stdoutBuf.slice(headerLen + bodyLen);
            for (const h of dataHandlers) {
              h(body);
            }
            continue;
          } else {
            break;
          }
        }
        const nl = stdoutBuf.indexOf("\n");
        if (nl >= 0) {
          const line = stdoutBuf.slice(0, nl);
          stdoutBuf = stdoutBuf.slice(nl + 1);
          if (line.trim()) {
            for (const h of dataHandlers) {
              h(line);
            }
          }
          continue;
        }
        break;
      }
    });
    if (proc.stderr) {
      proc.stderr.setEncoding("utf8");
      proc.stderr.on("data", (chunk) => {
        lastDataAt = Date.now();
        for (const h of stderrHandlers) {
          h(chunk);
        }
      });
    }
    proc.on("exit", (code) => {
      alive = false;
      if (idleTimer) {
        clearTimeout(idleTimer);
      }
      for (const h of exitHandlers) {
        h(code);
      }
    });
    proc.on("error", (err) => {
      alive = false;
      if (idleTimer) {
        clearTimeout(idleTimer);
      }
      for (const h of exitHandlers) {
        h(-1);
      }
      try {
        console.error("[qz] spawnPersist process error:", err?.message || err);
      } catch (_) {
      }
    });
    const handle = {
      pid: proc.pid || 0,
      alive: () => alive,
      send: (line) => {
        if (!alive || !proc.stdin)
          return;
        try {
          proc.stdin.write(line + "\n");
        } catch (e) {
          console.error("[qz] spawnPersist write error:", e);
        }
      },
      onData: (handler) => {
        dataHandlers.push(handler);
      },
      onStderr: (handler) => {
        stderrHandlers.push(handler);
      },
      onExit: (handler) => {
        exitHandlers.push(handler);
      },
      shutdown: async () => {
        if (!alive)
          return;
        try {
          proc.stdin?.end();
        } catch {
        }
        await new Promise((resolve) => {
          const t = setTimeout(() => {
            try {
              proc.kill();
            } catch {
            }
            resolve();
          }, 5e3);
          proc.on("exit", () => {
            clearTimeout(t);
            resolve();
          });
        });
      },
      kill: () => {
        if (!alive)
          return;
        alive = false;
        if (idleTimer) {
          clearTimeout(idleTimer);
        }
        try {
          proc.kill();
        } catch {
        }
      }
    };
    return handle;
  }
};
function registerQzSpawnIpc(qzSpawn) {
  import_electron.ipcMain.handle("qqqide:qz:spawn", async (_e, brief) => {
    return await qzSpawn.spawn(brief);
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  QzSpawn,
  registerQzSpawnIpc
});
