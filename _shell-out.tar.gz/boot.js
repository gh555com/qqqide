"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// shell/boot.ts
var boot_exports = {};
__export(boot_exports, {
  APP_VERSION: () => APP_VERSION,
  DEFAULT_REMOTE_URL: () => DEFAULT_REMOTE_URL,
  bootSequence: () => bootSequence,
  checkAndDownloadShellUpdate: () => checkAndDownloadShellUpdate,
  extractFlags: () => extractFlags,
  healthCheck: () => healthCheck,
  isBootCompleted: () => isBootCompleted,
  loadBootConfig: () => loadBootConfig,
  loadRemoteWithCacheGuard: () => loadRemoteWithCacheGuard,
  loadStaticFallback: () => loadStaticFallback
});
module.exports = __toCommonJS(boot_exports);
var path = __toESM(require("path"));
var fs = __toESM(require("fs"));
var os = __toESM(require("os"));
var http = __toESM(require("http"));
var https = __toESM(require("https"));
var import_url = require("url");
var import_child_process = require("child_process");
var bootCompleted = false;
function isBootCompleted() {
  return bootCompleted;
}
var _bootLogPath = null;
function bootLog(msg) {
  if (!_bootLogPath) {
    return;
  }
  const ts = (/* @__PURE__ */ new Date()).toISOString();
  try {
    fs.appendFileSync(_bootLogPath, `[${ts}] ${msg}
`);
  } catch (_) {
  }
}
function initBootLog(logsDir) {
  try {
    fs.mkdirSync(logsDir, { recursive: true });
  } catch (_) {
  }
  _bootLogPath = path.join(logsDir, "boot.log");
  bootLog("=== qqqide boot start ===");
  bootLog("version: " + APP_VERSION);
  bootLog("platform: " + os.platform() + " " + os.release());
}
var APP_VERSION = "0.0.2";
var DEFAULT_REMOTE_URL = "http://127.0.0.1:8090/qqq-app/";
function loadBootConfig(portableRoot) {
  const cfgPath = path.join(portableRoot, "config.json");
  let cfg = { url: DEFAULT_REMOTE_URL, healthTimeoutMs: 3e3 };
  if (fs.existsSync(cfgPath)) {
    try {
      const j = JSON.parse(fs.readFileSync(cfgPath, "utf8"));
      if (j.url) {
        cfg.url = j.url;
      }
      if (j.healthTimeoutMs) {
        cfg.healthTimeoutMs = j.healthTimeoutMs;
      }
    } catch (e) {
      console.warn("[main] bad config.json:", e);
    }
  } else {
    try {
      const tpl = {
        url: DEFAULT_REMOTE_URL,
        healthTimeoutMs: 3e3,
        _comment: "qz/VM-snapshot friendly. Edit url to point at your server. NEVER stored in AppData."
      };
      fs.writeFileSync(cfgPath, JSON.stringify(tpl, null, 2), "utf8");
      console.log("[main] wrote default config.json ->", cfgPath);
    } catch (e) {
      console.warn("[main] could not write default config.json:", e);
    }
  }
  if (process.env.QQQIDE_URL) {
    cfg.url = process.env.QQQIDE_URL;
  }
  for (const arg of process.argv.slice(1)) {
    if (arg.startsWith("--url=")) {
      cfg.url = arg.slice(6);
    }
  }
  return cfg;
}
function extractFlags() {
  return {
    isOffline: process.argv.includes("--offline"),
    isDev: process.argv.includes("--dev") || process.env.QQQIDE_DEV === "1"
  };
}
function healthCheck(urlStr, timeoutMs, isOffline) {
  bootLog("health: check " + urlStr);
  return new Promise((resolve) => {
    if (isOffline) {
      bootLog("health: SKIP (offline mode)");
      return resolve(false);
    }
    let healthUrl;
    try {
      const u = new import_url.URL("health", urlStr.endsWith("/") ? urlStr : urlStr + "/");
      healthUrl = u.toString();
    } catch {
      bootLog("health: FAIL \u2014 bad URL");
      return resolve(false);
    }
    const lib = healthUrl.startsWith("https") ? https : http;
    const opts = { timeout: timeoutMs };
    if (healthUrl.startsWith("https")) {
      opts.rejectUnauthorized = false;
    }
    const req = lib.get(healthUrl, opts, (res) => {
      const ok = !!(res.statusCode && res.statusCode >= 200 && res.statusCode < 400);
      res.resume();
      bootLog("health: " + (ok ? "OK " + res.statusCode : "FAIL status=" + res.statusCode));
      resolve(ok);
    });
    req.on("error", (err) => {
      bootLog("health: FAIL \u2014 " + (err && err.message || String(err)));
      resolve(false);
    });
    req.on("timeout", () => {
      bootLog("health: FAIL \u2014 timeout " + timeoutMs + "ms");
      req.destroy();
      resolve(false);
    });
  });
}
var SHELL_UPDATE_URL = "shell-out.tar.gz";
async function checkAndDownloadShellUpdate(bootConfig, portableCache, isDev, isOffline) {
  if (isDev || isOffline)
    return false;
  const stagingDir = path.join(portableCache, "staging", "shell-out-next");
  const tarPath = path.join(portableCache, "staging", "shell-out.tar.gz");
  try {
    const baseUrl = bootConfig.url.endsWith("/") ? bootConfig.url : bootConfig.url + "/";
    const updateUrl = baseUrl + SHELL_UPDATE_URL;
    const lib = updateUrl.startsWith("https") ? https : http;
    let latestVersion = "";
    try {
      const versionUrl = baseUrl + "version.json";
      const vResp = await new Promise((resolve, reject) => {
        const opts2 = { timeout: 5e3 };
        if (versionUrl.startsWith("https")) {
          opts2.rejectUnauthorized = false;
        }
        const req = lib.get(versionUrl, opts2, (res) => {
          let data = "";
          res.setEncoding("utf8");
          res.on("data", (c) => data += c);
          res.on("end", () => resolve({ status: res.statusCode || 0, data }));
        });
        req.on("error", reject);
        req.on("timeout", () => {
          req.destroy();
          reject(new Error("timeout"));
        });
      });
      if (vResp.status === 200) {
        const v = JSON.parse(vResp.data);
        latestVersion = v.shell_version || v.version || "";
      }
    } catch {
    }
    const localVersionPath = path.join(portableCache, "shell-version");
    let localVersion = "";
    try {
      if (fs.existsSync(localVersionPath)) {
        localVersion = fs.readFileSync(localVersionPath, "utf8").trim();
      }
    } catch {
    }
    if (latestVersion && localVersion === latestVersion) {
      return false;
    }
    console.log("[shell-update] downloading", updateUrl);
    try {
      fs.mkdirSync(path.dirname(tarPath), { recursive: true });
    } catch {
    }
    const downloadOk = await new Promise((resolve) => {
      const dlopts = { timeout: 3e4 };
      if (updateUrl.startsWith("https")) {
        dlopts.rejectUnauthorized = false;
      }
      const req = lib.get(updateUrl, dlopts, (res) => {
        if (res.statusCode !== 200) {
          if (res.statusCode === 301 || res.statusCode === 302) {
            const loc = res.headers.location;
            if (loc) {
              const lib2 = loc.startsWith("https") ? https : http;
              const redirOpts = { timeout: 3e4 };
              if (loc.startsWith("https")) {
                redirOpts.rejectUnauthorized = false;
              }
              const req2 = lib2.get(loc, redirOpts, (res2) => {
                if (res2.statusCode !== 200) {
                  resolve(false);
                  return;
                }
                const file2 = fs.createWriteStream(tarPath);
                res2.pipe(file2);
                file2.on("finish", () => resolve(true));
                file2.on("error", () => resolve(false));
              });
              req2.on("error", () => resolve(false));
              req2.on("timeout", () => {
                req2.destroy();
                resolve(false);
              });
              return;
            }
          }
          resolve(false);
          return;
        }
        const file = fs.createWriteStream(tarPath);
        res.pipe(file);
        file.on("finish", () => resolve(true));
        file.on("error", () => resolve(false));
      });
      req.on("error", () => resolve(false));
      req.on("timeout", () => {
        req.destroy();
        resolve(false);
      });
    });
    if (!downloadOk) {
      console.log("[shell-update] download failed or not available");
      return false;
    }
    console.log("[shell-update] extracting to", stagingDir);
    try {
      fs.rmSync(stagingDir, { recursive: true, force: true });
    } catch {
    }
    try {
      fs.mkdirSync(stagingDir, { recursive: true });
    } catch {
    }
    const extractResult = (0, import_child_process.spawnSync)("tar", ["-xzf", tarPath, "-C", stagingDir], {
      stdio: "pipe",
      timeout: 15e3
    });
    if (extractResult.status !== 0) {
      console.log("[shell-update] extract failed, status:", extractResult.status);
      try {
        fs.rmSync(tarPath);
      } catch {
      }
      return false;
    }
    try {
      fs.unlinkSync(tarPath);
    } catch {
    }
    if (latestVersion) {
      try {
        fs.mkdirSync(path.dirname(localVersionPath), { recursive: true });
        fs.writeFileSync(localVersionPath, latestVersion, "utf8");
      } catch {
      }
    }
    console.log("[shell-update] staged for next restart:", stagingDir);
    return true;
  } catch (e) {
    console.log("[shell-update] error:", e.message || e);
    return false;
  }
}
async function loadStaticFallback(mainWindow, bootConfig, portableRoot, reason) {
  if (!mainWindow) {
    return "fallback";
  }
  if (bootCompleted) {
    bootLog("fallback: BLOCKED \u2014 boot already completed, refusing to replace IDE");
    return "fallback";
  }
  bootLog("fallback: reason=" + reason);
  const candidates = [
    path.join(__dirname, "..", "shell", "boot-fallback.html"),
    path.join(__dirname, "boot-fallback.html"),
    path.join(portableRoot, "shell", "boot-fallback.html")
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) {
      try {
        await mainWindow.loadFile(p, { query: { url: bootConfig.url, reason } });
      } catch (e) {
        bootLog("fallback: loadFile crashed \u2014 " + (e && e.message || String(e)));
        try {
          await mainWindow.loadURL("data:text/html,<h1>qqqide offline</h1><p>\u8BF7\u91CD\u542F\u5E94\u7528</p>");
        } catch (_) {
        }
      }
      return "fallback";
    }
  }
  try {
    await mainWindow.loadURL("data:text/html,<h1>qqqide offline</h1><p>\u8BF7\u91CD\u542F\u5E94\u7528</p>");
  } catch (_) {
  }
  return "fallback";
}
async function loadRemoteWithCacheGuard(mainWindow, bootConfig, timeoutMs = 0, isDev = false, portableRoot = "") {
  if (!mainWindow) {
    bootLog("remote: no window");
    return { ok: false, mode: "fallback" };
  }
  bootLog("remote: loading " + bootConfig.url + (timeoutMs > 0 ? " timeout=" + timeoutMs + "ms" : ""));
  const wc = mainWindow.webContents;
  return new Promise((resolve) => {
    let settled = false;
    let timeoutTimer = null;
    let panelTimer = null;
    let progressTickId = null;
    const PANEL_MAX_MS = 3e4;
    const LOADING_STATUS_PATH = portableRoot ? path.join(portableRoot, "loading-status") : "";
    const writeLoadingStatus = (line) => {
      if (!LOADING_STATUS_PATH) {
        return;
      }
      try {
        fs.writeFileSync(LOADING_STATUS_PATH, line, "utf-8");
      } catch (_) {
      }
    };
    let pendingReqs = 0;
    let doneReqs = 0;
    let domReadyFired = false;
    const session = wc.session;
    const reqStartTimes = /* @__PURE__ */ new Map();
    let cooldownTimer = null;
    const COOLDOWN_MS = 4e3;
    const onBeforeReq = (details, cb) => {
      const now = Date.now();
      reqStartTimes.set(details.url, now);
      pendingReqs++;
      if (cooldownTimer) {
        clearTimeout(cooldownTimer);
        cooldownTimer = null;
      }
      const shortUrl = details.url?.slice(0, 100);
      bootLog("webReq: +" + pendingReqs + " " + details.resourceType + " " + shortUrl);
      cb({});
    };
    const onReqDone = (details) => {
      doneReqs++;
      pendingReqs = Math.max(0, pendingReqs - 1);
      const startTime = reqStartTimes.get(details.url);
      const elapsed = startTime ? Date.now() - startTime : -1;
      reqStartTimes.delete(details.url);
      if (elapsed > 1500) {
        bootLog("webReq: SLOW " + elapsed + "ms " + details.resourceType + " " + details.url?.slice(0, 80));
      } else {
        bootLog("webReq: \u2713" + elapsed + "ms " + details.resourceType + " " + details.url?.slice(0, 80));
      }
      tryCooldown();
    };
    const onReqErr = (details) => {
      pendingReqs = Math.max(0, pendingReqs - 1);
      const startTime = reqStartTimes.get(details.url);
      const elapsed = startTime ? Date.now() - startTime : -1;
      reqStartTimes.delete(details.url);
      bootLog("webReq: ERR " + elapsed + "ms " + details.resourceType + " " + details.url?.slice(0, 80));
      tryCooldown();
    };
    const tryCooldown = () => {
      if (pendingReqs === 0 && doneReqs > 0 && !cooldownTimer) {
        bootLog("webReq: cooldown started \u2014 pending=0 done=" + doneReqs + " wait=" + COOLDOWN_MS + "ms");
        cooldownTimer = setTimeout(() => {
          bootLog("webReq: cooldown expired \u2014 truly done (total=" + doneReqs + ")");
          onAllReady();
        }, COOLDOWN_MS);
      }
    };
    const injectLoadingPanel = () => {
      const css = `
                #__qqq_boot_panel{position:fixed;top:0;left:0;right:0;bottom:0;z-index:99999;
                background:#fdf6e3;display:flex;align-items:center;justify-content:center;
                font-family:-apple-system,BlinkMacSystemFont,"Microsoft YaHei",sans-serif}
                #__qqq_boot_panel .wrap{text-align:center;max-width:420px;padding:32px}
                #__qqq_boot_panel .spinner{width:36px;height:36px;margin:0 auto 20px;
                border:3px solid #eee8d5;border-top-color:#268bd2;border-radius:50%;
                animation:__qqq_spin .8s linear infinite}
                #__qqq_boot_panel .stage{color:#586e75;font-size:14px;margin-bottom:20px;min-height:20px}
                #__qqq_boot_panel .bar-bg{background:#eee8d5;border-radius:8px;height:8px;overflow:hidden}
                #__qqq_boot_panel .bar-fg{background:linear-gradient(90deg,#268bd2,#2aa198);height:100%;width:0%;transition:width .3s ease}
                #__qqq_boot_panel .pct{color:#93a1a1;font-size:12px;margin-top:8px}
                @keyframes __qqq_spin{to{transform:rotate(360deg)}}
            `.replace(/\n\s*/g, "");
      const html = '<div id="__qqq_boot_panel"><div class="wrap"><div class="spinner"></div><div class="stage">\u6B63\u5728\u8FDE\u63A5\u670D\u52A1\u5668\u2026</div><div class="bar-bg"><div class="bar-fg" id="__qqq_boot_bar"></div></div><div class="pct" id="__qqq_boot_pct">0%</div></div></div>';
      wc.executeJavaScript(`
                try{
                    // \u2605 \u5F7B\u5E95\u9690\u85CF IDE \u5185\u5BB9 \u2014 \u4E0D\u662F\u906E\u7F69\uFF0C\u662F\u5B8C\u5168\u4E0D\u663E\u793A
                    var hideCSS=document.createElement("style");
                    hideCSS.id="__qqq_boot_hide";
                    hideCSS.textContent="html>body>:not(#__qqq_boot_panel){display:none!important}";
                    document.head.appendChild(hideCSS);
                    // \u6CE8\u5165\u9762\u677F
                    var panelCSS=document.createElement("style");
                    panelCSS.textContent=\`${css}\`;document.head.appendChild(panelCSS);
                    var d=document.createElement("div");
                    d.innerHTML=\`${html}\`;document.body.appendChild(d.firstElementChild);
                }catch(_){}
            `).catch(() => {
      });
    };
    const updateLoadingPanel = (stage, pct) => {
      writeLoadingStatus(pct + "|" + stage);
      wc.executeJavaScript(`
                try{
                    var s=document.getElementById("__qqq_boot_pct");
                    if(s&&s.parentElement){s.textContent="${pct}%"}
                    var b=document.getElementById("__qqq_boot_bar");
                    if(b){b.style.width="${pct}%"}
                    Array.from(document.querySelectorAll("#__qqq_boot_panel .stage")).forEach(function(e){e.textContent="${stage}"})
                }catch(_){}
            `.replace(/\n\s*/g, "")).catch(() => {
      });
    };
    const removeLoadingPanel = () => {
      if (panelTimer) {
        clearTimeout(panelTimer);
        panelTimer = null;
      }
      if (progressTickId) {
        clearInterval(progressTickId);
        progressTickId = null;
      }
      wc.executeJavaScript(`
                try{
                    var p=document.getElementById("__qqq_boot_panel");if(p)p.remove();
                    var h=document.getElementById("__qqq_boot_hide");if(h)h.remove();
                }catch(_){}
            `).catch(() => {
      });
    };
    const updateProgress = () => {
      const total = pendingReqs + doneReqs;
      if (total === 0) {
        return;
      }
      const pct = Math.min(94, Math.round(doneReqs / Math.max(total, 1) * 100));
      const stage = pct < 30 ? "\u6B63\u5728\u52A0\u8F7D\u9875\u9762\u7ED3\u6784\u2026" : pct < 60 ? "\u6B63\u5728\u52A0\u8F7D\u7EC4\u4EF6\u811A\u672C\u2026" : pct < 85 ? "\u6B63\u5728\u52A0\u8F7D\u6837\u5F0F\u8D44\u6E90\u2026" : "\u6B63\u5728\u521D\u59CB\u5316 IDE\u2026";
      updateLoadingPanel(stage, pct);
      if (pendingReqs === 0 && doneReqs > 0) {
        tryCooldown();
      }
    };
    let readyShown = false;
    const onAllReady = () => {
      if (readyShown) {
        return;
      }
      readyShown = true;
      if (progressTickId) {
        clearInterval(progressTickId);
        progressTickId = null;
      }
      if (panelTimer) {
        clearTimeout(panelTimer);
        panelTimer = null;
      }
      if (cooldownTimer) {
        clearTimeout(cooldownTimer);
        cooldownTimer = null;
      }
      wc.removeListener("did-start-navigation", onStartNav);
      wc.removeListener("did-navigate", onNavigate);
      wc.removeListener("dom-ready", onDomReady);
      wc.removeListener("did-finish-load", onFinish);
      wc.removeListener("did-stop-loading", onStopLoading);
      wc.removeListener("did-fail-load", onFail);
      bootLog("remote: all resources loaded + dom-ready \u2192 IDE ready");
      updateLoadingPanel("\u6B63\u5728\u542F\u52A8 IDE\u2026", 100);
      writeLoadingStatus("ready");
      finish(true, "live");
      setTimeout(() => {
        removeLoadingPanel();
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.show();
          mainWindow.focus();
        }
        bootLog("remote: panel removed, IDE shown");
      }, 400);
    };
    const cleanupWebRequest = () => {
      try {
        session.webRequest.onBeforeRequest(null, null);
      } catch (_) {
      }
      try {
        session.webRequest.onCompleted(null, null);
      } catch (_) {
      }
      try {
        session.webRequest.onErrorOccurred(null, null);
      } catch (_) {
      }
    };
    const finish = (ok, mode) => {
      if (settled) {
        return;
      }
      settled = true;
      if (timeoutTimer) {
        clearTimeout(timeoutTimer);
        timeoutTimer = null;
      }
      if (!ok && mode === "fallback") {
        cleanupWebRequest();
        wc.removeListener("did-start-navigation", onStartNav);
        wc.removeListener("did-navigate", onNavigate);
        wc.removeListener("dom-ready", onDomReady);
        wc.removeListener("did-finish-load", onFinish);
        wc.removeListener("did-stop-loading", onStopLoading);
        wc.removeListener("did-fail-load", onFail);
        removeLoadingPanel();
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.show();
          mainWindow.focus();
        }
        try {
          wc.stop();
        } catch (_) {
        }
      }
      bootLog("remote: " + (ok ? "LOADED" : "FAILED") + " mode=" + mode);
      resolve({ ok, mode });
    };
    const onStartNav = (_e, _url, _inFrame, _isMain) => {
      if (!_isMain) {
        return;
      }
      bootLog("remote: did-start-navigation " + _url);
    };
    const onNavigate = (_e, _url, httpCode) => {
      bootLog("remote: did-navigate http=" + httpCode);
      if (httpCode >= 200 && httpCode < 400) {
        if (!isDev) {
          injectLoadingPanel();
          updateLoadingPanel("\u6B63\u5728\u89E3\u6790\u9875\u9762\u2026", 5);
        }
        let lastPct = 5;
        let tickCount = 0;
        progressTickId = setInterval(() => {
          tickCount++;
          if (tickCount % 6 === 0 && !domReadyFired) {
            bootLog("webReq: heartbeat pending=" + pendingReqs + " done=" + doneReqs + " domReadyFired=" + domReadyFired + " tickPct=" + lastPct);
          }
          if (domReadyFired || pendingReqs === 0 && doneReqs > 0) {
            clearInterval(progressTickId);
            progressTickId = null;
            return;
          }
          lastPct = Math.min(88, lastPct + 6);
          const stage = lastPct < 35 ? "\u6B63\u5728\u52A0\u8F7D\u9875\u9762\u7ED3\u6784\u2026" : lastPct < 60 ? "\u6B63\u5728\u52A0\u8F7D\u7EC4\u4EF6\u811A\u672C\u2026" : lastPct < 80 ? "\u6B63\u5728\u52A0\u8F7D\u6837\u5F0F\u8D44\u6E90\u2026" : "\u6B63\u5728\u521D\u59CB\u5316 IDE\u2026";
          updateLoadingPanel(stage, lastPct);
        }, 2500);
        panelTimer = setTimeout(() => {
          bootLog("remote: ultimate fallback after 10min \u2014 force show (pending=" + pendingReqs + " done=" + doneReqs + ")");
          updateLoadingPanel("\u5373\u5C06\u5B8C\u6210\u2026", 95);
          writeLoadingStatus("ready");
          removeLoadingPanel();
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.show();
            mainWindow.focus();
          }
        }, 6e5);
        finish(true, "live");
      } else {
        finish(false, "fallback");
      }
    };
    const onDomReady = () => {
      bootLog("remote: dom-ready");
      domReadyFired = true;
      if (doneReqs === 0) {
        bootLog("remote: dom-ready fallback (no requests tracked) \u2192 90%");
        updateLoadingPanel("\u6B63\u5728\u521D\u59CB\u5316 IDE\u2026", 90);
      }
      if (pendingReqs === 0) {
        onAllReady();
      }
    };
    const onFinish = () => {
      bootLog("remote: did-finish-load (onload)");
    };
    const onStopLoading = () => {
      bootLog("remote: did-stop-loading");
      if (progressTickId) {
        clearInterval(progressTickId);
        progressTickId = null;
      }
      onAllReady();
    };
    const onFail = (_e, code, desc, validatedURL, isMain) => {
      if (!isMain) {
        return;
      }
      bootLog("remote: did-fail-load code=" + code + " desc=" + desc + " url=" + validatedURL);
      finish(false, "fallback");
    };
    if (timeoutMs > 0) {
      timeoutTimer = setTimeout(() => {
        bootLog("remote: TIMEOUT (did-navigate never fired) after " + timeoutMs + "ms");
        finish(false, "fallback");
      }, timeoutMs);
    }
    wc.on("did-start-navigation", onStartNav);
    wc.on("did-navigate", onNavigate);
    wc.on("dom-ready", onDomReady);
    wc.on("did-finish-load", onFinish);
    wc.on("did-stop-loading", onStopLoading);
    wc.on("did-fail-load", onFail);
    session.webRequest.onBeforeRequest(onBeforeReq);
    session.webRequest.onCompleted(onReqDone);
    session.webRequest.onErrorOccurred(onReqErr);
    let loadRetries = 0;
    const doLoad = () => {
      mainWindow.loadURL(bootConfig.url).catch((err) => {
        const msg = err && err.message || String(err);
        bootLog("remote: loadURL error \u2014 " + msg);
        const retryable = /ERR_FAILED|ERR_CONNECTION_REFUSED|ERR_TIMED_OUT|ERR_CONNECTION_RESET/i.test(msg);
        if (retryable && loadRetries < 5) {
          loadRetries++;
          bootLog("remote: retry " + loadRetries + "/5 in 3s\u2026");
          setTimeout(doLoad, 3e3);
          return;
        }
        finish(false, "fallback");
      });
    };
    doLoad();
  });
}
async function bootSequence(mainWindow, bootConfig, portableRoot, portableCache, isDev, isOffline, setLastBootMode, getLastBootMode) {
  const bootT0 = Date.now();
  initBootLog(path.join(portableRoot, "userData", "Logs"));
  try {
    fs.unlinkSync(path.join(portableRoot, "loading-status"));
  } catch (_) {
  }
  const DEV_URL = "http://127.0.0.1:8090/qqq-app/";
  if (isDev) {
    bootConfig.url = DEV_URL;
    bootConfig.healthTimeoutMs = 500;
    bootLog("dev: forced local URL \u2192 " + DEV_URL);
  }
  bootLog("url: " + bootConfig.url);
  try {
    await loadStaticFallback(mainWindow, bootConfig, portableRoot, "connecting");
  } catch (e) {
    bootLog("seq: initial fallback crashed \u2014 " + (e && e.message || String(e)));
  }
  const bootT1 = Date.now();
  bootLog("phase: fallback-shown " + (bootT1 - bootT0) + "ms");
  checkAndDownloadShellUpdate(bootConfig, portableCache, isDev, isOffline).then((updated) => {
    if (updated) {
      console.log("[boot] shell update staged \u2014 will apply on next restart");
    }
  }).catch(() => {
  });
  const healthy = isDev ? true : await healthCheck(bootConfig.url, bootConfig.healthTimeoutMs, isOffline);
  const bootT2 = Date.now();
  if (healthy) {
    bootLog("seq: server OK (" + (bootT2 - bootT1) + "ms)");
  } else {
    bootLog("seq: server unreachable (" + (bootT2 - bootT1) + "ms)");
  }
  const REMOTE_TIMEOUT_MS = 3e4;
  const { ok, mode } = await loadRemoteWithCacheGuard(mainWindow, bootConfig, REMOTE_TIMEOUT_MS, isDev, portableRoot);
  const bootT3 = Date.now();
  if (ok) {
    bootLog("seq: remote OK, boot complete \u2014 total " + (bootT3 - bootT0) + "ms");
    bootCompleted = true;
    setLastBootMode(mode);
  } else {
    const reason = healthy ? "load-failed" : "no-network-no-cache";
    bootLog("seq: FAILED \u2014 staying on fallback, reason=" + reason + " total " + (bootT3 - bootT0) + "ms");
    try {
      await loadStaticFallback(mainWindow, bootConfig, portableRoot, reason);
    } catch (e) {
      bootLog("seq: loadStaticFallback crashed \u2014 " + (e && e.message || String(e)));
    }
    setLastBootMode("fallback");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  APP_VERSION,
  DEFAULT_REMOTE_URL,
  bootSequence,
  checkAndDownloadShellUpdate,
  extractFlags,
  healthCheck,
  isBootCompleted,
  loadBootConfig,
  loadRemoteWithCacheGuard,
  loadStaticFallback
});
