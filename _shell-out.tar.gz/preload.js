"use strict";

// shell/preload.ts
var import_electron = require("electron");
var QQQ = {
  // ---- app info ----
  app: {
    root: () => import_electron.ipcRenderer.invoke("qqqide:app:root"),
    quitAll: () => import_electron.ipcRenderer.invoke("qqqide:app:quitAll")
  },
  // ---- component binaries ----
  components: {
    getBin: (name) => import_electron.ipcRenderer.invoke("qqqide:components:getBin", name)
  },
  // ---- auth push — 浏览器登录成功通过 qqqide:// 协议推 token（2026-06-29） ----
  auth: {
    onAuthPush: (cb) => {
      const handler = (_e, data) => {
        try {
          cb(data);
        } catch (err) {
          console.warn("[auth.onAuthPush]", err);
        }
      };
      import_electron.ipcRenderer.on("qqqide-auth", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide-auth", handler);
    },
    saveAuth: (auth) => import_electron.ipcRenderer.invoke("qqqide:auth:save", auth),
    loadAuth: () => import_electron.ipcRenderer.invoke("qqqide:auth:load"),
    clearAuth: () => import_electron.ipcRenderer.invoke("qqqide:auth:clear"),
    // ★ 轻量：仅同步 phone 到主进程共享内存（不依赖 safeStorage）
    setPhone: (phone) => import_electron.ipcRenderer.invoke("qqqide:auth:set-phone", phone)
  },
  // ---- file system (proxied to engine subprocess) ----
  fs: {
    read: (p) => import_electron.ipcRenderer.invoke("qqqide:fs:read", p),
    readBase64: (p) => import_electron.ipcRenderer.invoke("qqqide:fs:readBase64", p),
    write: (p, content) => import_electron.ipcRenderer.invoke("qqqide:fs:write", p, content),
    writeBase64: (p, base64) => import_electron.ipcRenderer.invoke("qqqide:fs:writeBase64", p, base64),
    append: (p, content) => import_electron.ipcRenderer.invoke("qqqide:fs:append", p, content),
    list: async (p) => {
      var result = await import_electron.ipcRenderer.invoke("qqqide:fs:list", p, new Error("fs.list caller").stack);
      if (Array.isArray(result) && result.length > 0 && typeof result[0] === "object")
        return result;
      if (Array.isArray(result) && result.length > 0 && typeof result[0] === "string") {
        return result.map((s) => ({
          name: s.endsWith("/") ? s.slice(0, -1) : s,
          isDir: s.endsWith("/")
        }));
      }
      return result;
    },
    stat: (p) => import_electron.ipcRenderer.invoke("qqqide:fs:stat", p),
    exists: (p) => import_electron.ipcRenderer.invoke("qqqide:fs:exists", p),
    mkdir: (p) => import_electron.ipcRenderer.invoke("qqqide:fs:mkdir", p),
    remove: (p) => import_electron.ipcRenderer.invoke("qqqide:fs:remove", p),
    rename: (oldP, newP) => import_electron.ipcRenderer.invoke("qqqide:fs:rename", oldP, newP),
    drives: () => import_electron.ipcRenderer.invoke("qqqide:fs:drives"),
    diskFree: (d) => import_electron.ipcRenderer.invoke("qqqide:fs:diskFree", d)
  },
  // ---- dialogs ----
  dialog: {
    open: (opts) => import_electron.ipcRenderer.invoke("qqqide:dialog:open", opts),
    save: (opts) => import_electron.ipcRenderer.invoke("qqqide:dialog:save", opts),
    message: (opts) => import_electron.ipcRenderer.invoke("qqqide:dialog:message", opts)
  },
  // ---- asset-roots: extend the qqqide-asset://file/ whitelist at runtime ----
  assetRoots: {
    add: (absDir) => import_electron.ipcRenderer.invoke("qqqide:assetRoots:add", absDir),
    list: () => import_electron.ipcRenderer.invoke("qqqide:assetRoots:list"),
    remove: (absDir) => import_electron.ipcRenderer.invoke("qqqide:assetRoots:remove", absDir)
  },
  // ---- window controls ----
  window: {
    minimize: () => import_electron.ipcRenderer.invoke("qqqide:window:minimize"),
    maximize: () => import_electron.ipcRenderer.invoke("qqqide:window:maximize"),
    unmaximize: () => import_electron.ipcRenderer.invoke("qqqide:window:unmaximize"),
    close: () => import_electron.ipcRenderer.invoke("qqqide:window:close"),
    closeConfirmed: () => import_electron.ipcRenderer.invoke("qqqide:window:close-confirmed"),
    onCloseConfirm: (cb) => {
      const h = () => {
        try {
          cb();
        } catch (_) {
        }
      };
      import_electron.ipcRenderer.on("qqqide:confirm-close", h);
      return () => import_electron.ipcRenderer.removeListener("qqqide:confirm-close", h);
    },
    isMaximized: () => import_electron.ipcRenderer.invoke("qqqide:window:isMaximized"),
    setTitle: (s) => import_electron.ipcRenderer.invoke("qqqide:window:setTitle", s),
    toggleDevTools: () => import_electron.ipcRenderer.invoke("qqqide:window:toggleDevTools"),
    new: (folderPath) => import_electron.ipcRenderer.invoke("qqqide:window:new", folderPath),
    claimProject: (projectRoot) => import_electron.ipcRenderer.invoke("qqqide:window:claimProject", projectRoot),
    releaseProject: (projectRoot) => import_electron.ipcRenderer.invoke("qqqide:window:releaseProject", projectRoot),
    adjustBounds: (deltaLeft, deltaRight) => import_electron.ipcRenderer.invoke("qqqide:window:adjust-bounds", deltaLeft, deltaRight),
    setWingState: (leftOpen, rightOpen) => import_electron.ipcRenderer.invoke("qqqide:wing:state", leftOpen, rightOpen)
  },
  // ---- devtools bridge (renderer → main process) ----
  devtools: {
    rename: (projectRoot) => import_electron.ipcRenderer.invoke("qqqide:devtools:rename", projectRoot)
  },
  // ---- zoom (UI scale) ----
  zoom: {
    get: () => import_electron.ipcRenderer.invoke("qqqide:zoom:get"),
    set: (factor) => import_electron.ipcRenderer.invoke("qqqide:zoom:set", factor),
    adjust: (delta) => import_electron.ipcRenderer.invoke("qqqide:zoom:adjust", delta),
    onChanged: (cb) => {
      const handler = (_e, factor) => cb(factor);
      import_electron.ipcRenderer.on("qqqide:zoom:changed", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:zoom:changed", handler);
    }
  },
  // ---- native menu (server-pushed JSON schema -> Electron Menu) ----
  menu: {
    set: (schema) => import_electron.ipcRenderer.invoke("qqqide:menu:set", schema),
    onFired: (cb) => {
      const handler = (_e, cmd) => cb(cmd);
      import_electron.ipcRenderer.on("qqqide:menu:fired", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:menu:fired", handler);
    }
  },
  // ---- monaco editor pool (in-shell instances) ----
  monaco: {
    create: (opts) => import_electron.ipcRenderer.invoke("qqqide:monaco:create", opts),
    open: (id, file) => import_electron.ipcRenderer.invoke("qqqide:monaco:open", id, file),
    save: (id) => import_electron.ipcRenderer.invoke("qqqide:monaco:save", id),
    dispose: (id) => import_electron.ipcRenderer.invoke("qqqide:monaco:dispose", id)
  },
  // ---- generic engine RPC (Rust/Python/Node subprocesses) ----
  engine: {
    invoke: (method, params) => import_electron.ipcRenderer.invoke("qqqide:engine:invoke", method, params),
    isAlive: () => import_electron.ipcRenderer.invoke("qqqide:engine:isAlive")
  },
  // ---- audio (will route to miniaudio_v16.py) ----
  audio: {
    play: (file, opts) => import_electron.ipcRenderer.invoke("qqqide:audio:play", file, opts),
    stop: (scope) => import_electron.ipcRenderer.invoke("qqqide:audio:stop", scope),
    invoke: (action, params) => import_electron.ipcRenderer.invoke("qqqide:audio:invoke", action, params),
    isAlive: () => import_electron.ipcRenderer.invoke("qqqide:audio:isAlive")
  },
  // ---- system shell ----
  shell: {
    openExternal: (url) => import_electron.ipcRenderer.invoke("qqqide:shell:openExternal", url),
    openPath: (p) => import_electron.ipcRenderer.invoke("qqqide:shell:openPath", p),
    // ★ 浏览器启动兜底（2026-07-28）：主进程所有层失败后推 URL 给渲染层弹 qoast
    onBrowserFallback: (cb) => {
      const handler = (_e, data) => {
        try {
          cb(data.url);
        } catch (err) {
          console.warn("[shell.onBrowserFallback]", err);
        }
      };
      import_electron.ipcRenderer.on("qqqide:browser-fallback", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:browser-fallback", handler);
    }
  },
  // ---- 跨窗口同步 IPC（替代 BroadcastChannel，终极架构 §C）----
  sync: {
    // 广播消息到所有其他窗口（主进程中转）。静默吞错——广播是 best-effort。
    broadcast: (channel, data) => import_electron.ipcRenderer.invoke("qqqide:sync:broadcast", channel, data).catch(() => {
    }),
    // 订阅来自其他窗口的消息。返回 unsubscribe 函数。
    onMessage: (cb) => {
      const handler = (_e, channel, data) => {
        try {
          cb(channel, data);
        } catch (err) {
          console.warn("[sync.onMessage]", err);
        }
      };
      import_electron.ipcRenderer.on("qqqide:sync:message", handler);
      return () => {
        import_electron.ipcRenderer.removeListener("qqqide:sync:message", handler);
      };
    },
    getProjectPath: () => import_electron.ipcRenderer.invoke("qqqide:sync:get-project-path"),
    setProjectPath: (p) => import_electron.ipcRenderer.invoke("qqqide:sync:set-project-path", p).catch(() => {
    }),
    getTheme: () => import_electron.ipcRenderer.invoke("qqqide:sync:get-theme")
  },
  // ---- clipboard ----
  clipboard: {
    readText: () => import_electron.ipcRenderer.invoke("qqqide:clipboard:readText"),
    writeText: (s) => import_electron.ipcRenderer.invoke("qqqide:clipboard:writeText", s),
    readImage: () => import_electron.ipcRenderer.invoke("qqqide:clipboard:readImage"),
    hasImage: () => import_electron.ipcRenderer.invoke("qqqide:clipboard:hasImage")
  },
  // ---- ghrun (qz process manager) ----
  ghrun: {
    exec: (cmd, args, opts) => import_electron.ipcRenderer.invoke("qqqide:ghrun:exec", cmd, args, opts),
    isAlive: () => import_electron.ipcRenderer.invoke("qqqide:ghrun:isAlive")
  },
  // ---- qz unified spawn (canonical entry; ghrun/runner.py/node fallback) ----
  qz: {
    spawn: (brief) => import_electron.ipcRenderer.invoke("qqqide:qz:spawn", brief),
    // Streaming spawn: real-time stdout/stderr via onChunk(channel, data).
    // Returns Promise<SpawnResult>. Used for long-running commands like git push/pull.
    spawnStream: (brief, onChunk) => {
      const streamId = "qzs-" + Date.now() + "-" + Math.random().toString(36).slice(2, 8);
      return new Promise((resolve, reject) => {
        const handler = (_e, msg) => {
          if (!msg || msg.streamId !== streamId)
            return;
          if (msg.type === "progress") {
            try {
              onChunk(msg.channel || "stdout", msg.data || "");
            } catch {
            }
          } else if (msg.type === "done") {
            import_electron.ipcRenderer.removeListener("qqqide:qz:stream", handler);
            resolve(msg.result);
          } else if (msg.type === "error") {
            import_electron.ipcRenderer.removeListener("qqqide:qz:stream", handler);
            reject(new Error(msg.error || "spawn-stream failed"));
          }
        };
        import_electron.ipcRenderer.on("qqqide:qz:stream", handler);
        import_electron.ipcRenderer.invoke("qqqide:qz:spawn-stream", { ...brief, streamId }).catch((err) => {
          import_electron.ipcRenderer.removeListener("qqqide:qz:stream", handler);
          reject(err);
        });
      });
    },
    which: (cmd) => import_electron.ipcRenderer.invoke("qqqide:qz:which", cmd),
    ghrunAlive: () => import_electron.ipcRenderer.invoke("qqqide:qz:ghrunAlive"),
    runnerAlive: () => import_electron.ipcRenderer.invoke("qqqide:qz:runnerAlive")
  },
  // ---- lsp (language intelligence — spawns language servers for diagnostics) ----
  lsp: {
    startLanguage: (lang, rootUri) => import_electron.ipcRenderer.invoke("qqqide:lsp:startLanguage", lang, rootUri),
    stopLanguage: (lang) => import_electron.ipcRenderer.invoke("qqqide:lsp:stopLanguage", lang),
    openDocument: (filePath, text) => import_electron.ipcRenderer.invoke("qqqide:lsp:openDocument", filePath, text),
    changeDocument: (filePath, changes, version) => import_electron.ipcRenderer.invoke("qqqide:lsp:changeDocument", filePath, changes, version),
    closeDocument: (filePath) => import_electron.ipcRenderer.invoke("qqqide:lsp:closeDocument", filePath),
    hover: (filePath, line, character) => import_electron.ipcRenderer.invoke("qqqide:lsp:hover", filePath, line, character),
    getDiagnostics: (uri) => import_electron.ipcRenderer.invoke("qqqide:lsp:getDiagnostics", uri),
    activeLanguages: () => import_electron.ipcRenderer.invoke("qqqide:lsp:activeLanguages"),
    onDiagnostics: (cb) => {
      const handler = (_e, msg) => {
        try {
          cb(msg);
        } catch (err) {
          console.warn("[lsp.onDiagnostics]", err);
        }
      };
      import_electron.ipcRenderer.on("qqqide:lsp:diagnostics", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:lsp:diagnostics", handler);
    }
  },
  // ---- search (高性能项目搜索引擎) ----
  search: {
    query: (opts) => import_electron.ipcRenderer.invoke("qqqide:search:query", opts),
    replace: (opts) => {
      const { onProgress } = opts;
      let handler = null;
      if (onProgress) {
        handler = (_e, data) => {
          try {
            onProgress(data);
          } catch {
          }
        };
        import_electron.ipcRenderer.on("qqqide:search:replace:progress", handler);
      }
      const invokeArgs = {};
      if (opts.files)
        invokeArgs.files = opts.files;
      if (opts.find)
        invokeArgs.find = opts.find;
      if (opts.replace)
        invokeArgs.replace = opts.replace;
      if (opts.useRegex !== void 0)
        invokeArgs.useRegex = opts.useRegex;
      if (opts.caseSensitive !== void 0)
        invokeArgs.caseSensitive = opts.caseSensitive;
      if (opts.wholeWord !== void 0)
        invokeArgs.wholeWord = opts.wholeWord;
      if (opts.searchPath)
        invokeArgs.searchPath = opts.searchPath;
      if (opts.replacements)
        invokeArgs.replacements = opts.replacements;
      return import_electron.ipcRenderer.invoke("qqqide:search:replace", invokeArgs).then((res) => {
        if (handler)
          import_electron.ipcRenderer.removeListener("qqqide:search:replace:progress", handler);
        return res;
      }).catch((err) => {
        if (handler)
          import_electron.ipcRenderer.removeListener("qqqide:search:replace:progress", handler);
        throw err;
      });
    }
  },
  // ---- ai (one-shot AI calls for hover, inline completions, etc.) ----
  ai: {
    hover: (context) => import_electron.ipcRenderer.invoke("qqqide:ai:hover", context),
    search_text: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:search_text", args),
    find_files: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:find_files", args),
    list_files: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:list_files", args),
    read_file: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:read_file", args),
    edit_file: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:edit_file", args),
    create_file: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:create_file", args),
    delete_file: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:delete_file", args),
    write_file: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:write_file", args),
    search_smart: (args) => import_electron.ipcRenderer.invoke("qqqide:ai:search_smart", args)
  },
  // ---- cache (KV + bucketed file cache rooted at portable.cache) ----
  cache: {
    get: (key) => import_electron.ipcRenderer.invoke("qqqide:cache:get", key),
    put: (key, value, opts) => import_electron.ipcRenderer.invoke("qqqide:cache:put", key, value, opts),
    has: (key) => import_electron.ipcRenderer.invoke("qqqide:cache:has", key),
    delete: (key) => import_electron.ipcRenderer.invoke("qqqide:cache:delete", key),
    path: (key) => import_electron.ipcRenderer.invoke("qqqide:cache:path", key),
    bucketPath: (sig, ext) => import_electron.ipcRenderer.invoke("qqqide:cache:bucketPath", sig, ext)
  },
  // ---- state (唯一真理持久化机器: doc/blob/log via shell/state-sqlite.ts) ----
  state: {
    register: (ns, schema) => import_electron.ipcRenderer.invoke("qqqide:state:register", ns, schema),
    get: (ns, key) => import_electron.ipcRenderer.invoke("qqqide:state:get", ns, key),
    set: (ns, key, value) => import_electron.ipcRenderer.invoke("qqqide:state:set", ns, key, value),
    setNow: (ns, key, value) => import_electron.ipcRenderer.invoke("qqqide:state:setNow", ns, key, value),
    append: (ns, key, event) => import_electron.ipcRenderer.invoke("qqqide:state:append", ns, key, event),
    del: (ns, key) => import_electron.ipcRenderer.invoke("qqqide:state:del", ns, key),
    list: (ns) => import_electron.ipcRenderer.invoke("qqqide:state:list", ns),
    flush: () => import_electron.ipcRenderer.invoke("qqqide:state:flush"),
    flushOne: (ns, key) => import_electron.ipcRenderer.invoke("qqqide:state:flushOne", ns, key),
    stats: () => import_electron.ipcRenderer.invoke("qqqide:state:stats"),
    sql: (query, params) => import_electron.ipcRenderer.invoke("qqqide:state:sql", query, params),
    cloud: {
      pull: () => import_electron.ipcRenderer.invoke("qqqide:state:cloud:pull"),
      push: () => import_electron.ipcRenderer.invoke("qqqide:state:cloud:push"),
      sync: () => import_electron.ipcRenderer.invoke("qqqide:state:cloud:sync"),
      setAuth: (auth) => import_electron.ipcRenderer.invoke("qqqide:state:cloud:setAuth", auth)
    },
    // Subscribe to any (ns,key) change. Returns an unsubscribe fn.
    onChange: (cb) => {
      const handler = (_e, msg) => {
        try {
          cb(msg);
        } catch (err) {
          console.warn("[state.onChange]", err);
        }
      };
      import_electron.ipcRenderer.on("qqqide:state:changed", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:state:changed", handler);
    },
    // Project-level SQLite (quest.sq3) — separate DB per dbPath
    project: {
      register: (dbPath, ns, schema) => import_electron.ipcRenderer.invoke("qqqide:state:project:register", dbPath, ns, schema),
      get: (dbPath, ns, key) => import_electron.ipcRenderer.invoke("qqqide:state:project:get", dbPath, ns, key),
      set: (dbPath, ns, key, value) => import_electron.ipcRenderer.invoke("qqqide:state:project:set", dbPath, ns, key, value),
      setNow: (dbPath, ns, key, value) => import_electron.ipcRenderer.invoke("qqqide:state:project:setNow", dbPath, ns, key, value),
      append: (dbPath, ns, key, event) => import_electron.ipcRenderer.invoke("qqqide:state:project:append", dbPath, ns, key, event),
      del: (dbPath, ns, key) => import_electron.ipcRenderer.invoke("qqqide:state:project:del", dbPath, ns, key),
      list: (dbPath, ns) => import_electron.ipcRenderer.invoke("qqqide:state:project:list", dbPath, ns),
      flush: (dbPath) => import_electron.ipcRenderer.invoke("qqqide:state:project:flush", dbPath),
      flushOne: (dbPath, ns, key) => import_electron.ipcRenderer.invoke("qqqide:state:project:flushOne", dbPath, ns, key),
      stats: (dbPath) => import_electron.ipcRenderer.invoke("qqqide:state:project:stats", dbPath),
      atomicIncr: (dbPath, ns, key) => import_electron.ipcRenderer.invoke("qqqide:state:project:atomicIncr", dbPath, ns, key),
      onChange: (dbPath, cb) => {
        const handler = (_e, msg) => {
          if (msg && msg.dbPath === dbPath) {
            try {
              cb(msg);
            } catch (err) {
              console.warn("[state.project.onChange]", err);
            }
          }
        };
        import_electron.ipcRenderer.on("qqqide:state:project:changed", handler);
        return () => import_electron.ipcRenderer.removeListener("qqqide:state:project:changed", handler);
      }
    }
  },
  // ---- qgf (FS 原子读写真理机) ----
  qgf: {
    register: (rootDir, ns, schema) => import_electron.ipcRenderer.invoke("qqqide:qgf:register", rootDir, ns, schema),
    get: (rootDir, ns, key) => import_electron.ipcRenderer.invoke("qqqide:qgf:get", rootDir, ns, key),
    set: (rootDir, ns, key, value) => import_electron.ipcRenderer.invoke("qqqide:qgf:set", rootDir, ns, key, value),
    setNow: (rootDir, ns, key, value) => import_electron.ipcRenderer.invoke("qqqide:qgf:setNow", rootDir, ns, key, value),
    append: (rootDir, ns, key, event) => import_electron.ipcRenderer.invoke("qqqide:qgf:append", rootDir, ns, key, event),
    del: (rootDir, ns, key) => import_electron.ipcRenderer.invoke("qqqide:qgf:del", rootDir, ns, key),
    list: (rootDir, ns) => import_electron.ipcRenderer.invoke("qqqide:qgf:list", rootDir, ns),
    flush: (rootDir) => import_electron.ipcRenderer.invoke("qqqide:qgf:flush", rootDir),
    stats: (rootDir) => import_electron.ipcRenderer.invoke("qqqide:qgf:stats", rootDir),
    flushOne: (rootDir, ns, key) => import_electron.ipcRenderer.invoke("qqqide:qgf:flushOne", rootDir, ns, key),
    // ★ 任意路径原子读写（突破固定目录限制）
    atomicWrite: (absPath, data) => import_electron.ipcRenderer.invoke("qqqide:qgf:atomicWrite", absPath, data),
    atomicRead: (absPath) => import_electron.ipcRenderer.invoke("qqqide:qgf:atomicRead", absPath),
    onChange: (cb) => {
      const handler = (_e, msg) => {
        try {
          cb(msg);
        } catch (err) {
          console.warn("[qgf.onChange]", err);
        }
      };
      import_electron.ipcRenderer.on("qqqide:qgf:changed", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:qgf:changed", handler);
    }
  },
  // ---- timeline (文件版本时间线，SHA256去重 + gzip + SQLite) ----
  timeline: {
    record: (args) => import_electron.ipcRenderer.invoke("qqqide:timeline:record", args),
    versions: (args) => import_electron.ipcRenderer.invoke("qqqide:timeline:versions", args),
    content: (args) => import_electron.ipcRenderer.invoke("qqqide:timeline:content", args),
    stat: (filePath) => import_electron.ipcRenderer.invoke("qqqide:timeline:stat", filePath),
    readCurrent: (filePath) => import_electron.ipcRenderer.invoke("qqqide:timeline:readCurrent", filePath),
    listTrackedFiles: (args) => import_electron.ipcRenderer.invoke("qqqide:timeline:listTrackedFiles", args),
    captureChanged: (args) => import_electron.ipcRenderer.invoke("qqqide:timeline:captureChanged", args),
    openDiffWindow: (args) => import_electron.ipcRenderer.invoke("qqqide:open-diff-window", args),
    // 用户在 diff 窗口内切换文件时更新主进程映射
    setPath: (newPath) => import_electron.ipcRenderer.send("qqqide:diff:set-path", newPath),
    // op 按钮：在 X 区 editor 打开文件
    openInEditor: (filePath) => import_electron.ipcRenderer.send("qqqide:timeline:open-in-editor", filePath),
    // op 按钮：喂给 AI
    feedToAi: (filePath) => import_electron.ipcRenderer.send("qqqide:timeline:feed-to-ai", filePath),
    // 监听主进程推送的 diff 更新（复用已有窗口时触发）
    onDiffUpdate: (cb) => {
      const handler = (_e, data) => {
        try {
          cb(data);
        } catch (err) {
          console.warn("[timeline.onDiffUpdate]", err);
        }
      };
      import_electron.ipcRenderer.on("qqqide:diff:update", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:diff:update", handler);
    }
  },
  // ---- git diff window (独立 BrowserWindow Monaco diff, read-only) ----
  git: {
    openDiff: (args) => import_electron.ipcRenderer.invoke("qqqide:git:open-diff", args)
  },
  // ---- dirty snapshots (跨窗口脏文件共享，Layer 2: IDE 领域内视觉一致) ----
  dirty: {
    set: (filePath, content) => import_electron.ipcRenderer.invoke("qqqide:dirty:set", filePath, content).catch(() => {
    }),
    get: (filePath) => import_electron.ipcRenderer.invoke("qqqide:dirty:get", filePath),
    remove: (filePath) => import_electron.ipcRenderer.invoke("qqqide:dirty:remove", filePath).catch(() => {
    }),
    list: () => import_electron.ipcRenderer.invoke("qqqide:dirty:list")
  },
  // ---- hash (xxh64 fast + sha256 strong, with mtime cache) ----
  hash: {
    file: (p, mode) => import_electron.ipcRenderer.invoke("qqqide:hash:file", p, mode),
    buffer: (b64, mode) => import_electron.ipcRenderer.invoke("qqqide:hash:buffer", b64, mode)
  },
  // ---- media (ffmpeg-backed thumbnail / transcode / probe via qz) ----
  media: {
    thumb: (opts) => import_electron.ipcRenderer.invoke("qqqide:media:thumb", opts),
    transcode: (opts) => import_electron.ipcRenderer.invoke("qqqide:media:transcode", opts),
    probe: (src) => import_electron.ipcRenderer.invoke("qqqide:media:probe", src),
    ffmpegPath: () => import_electron.ipcRenderer.invoke("qqqide:media:ffmpegPath")
  },
  // ---- key (global shortcut bridge; per-window/iframe handled in renderer) ----
  key: {
    registerGlobal: (accel, id) => import_electron.ipcRenderer.invoke("qqqide:key:registerGlobal", accel, id),
    unregisterGlobal: (accel) => import_electron.ipcRenderer.invoke("qqqide:key:unregisterGlobal", accel),
    unregisterAllGlobal: () => import_electron.ipcRenderer.invoke("qqqide:key:unregisterAllGlobal"),
    onGlobal: (cb) => {
      const handler = (_e, msg) => cb(msg);
      import_electron.ipcRenderer.on("qqqide:key:global", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:key:global", handler);
    }
  },
  // ---- download (SmartHttpDownloader via shell/download-service.ts) ----
  download: {
    start: (opts) => import_electron.ipcRenderer.invoke("qqqide:download:start", opts),
    cancel: (id) => import_electron.ipcRenderer.invoke("qqqide:download:cancel", id),
    list: () => import_electron.ipcRenderer.invoke("qqqide:download:list"),
    onProgress: (cb) => {
      const handler = (_e, entry) => {
        try {
          cb(entry);
        } catch (err) {
          console.warn("[download.onProgress]", err);
        }
      };
      import_electron.ipcRenderer.on("qqqide:download:progress", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:download:progress", handler);
    }
  },
  // ---- update (hot reload: pull server-app.tar.xz from gh555.com) ----
  update: {
    check: () => import_electron.ipcRenderer.invoke("qqqide:update:check"),
    apply: () => import_electron.ipcRenderer.invoke("qqqide:update:apply"),
    state: () => import_electron.ipcRenderer.invoke("qqqide:update:state"),
    abort: () => import_electron.ipcRenderer.invoke("qqqide:update:abort"),
    upgradeShell: () => import_electron.ipcRenderer.invoke("qqqide:update:upgrade-shell")
  },
  // ---- boot info (read once on startup) ----
  boot: {
    getInfo: () => import_electron.ipcRenderer.invoke("qqqide:boot:info"),
    retry: () => import_electron.ipcRenderer.invoke("qqqide:boot:retry"),
    probe: () => import_electron.ipcRenderer.invoke("qqqide:boot:probe")
  },
  // ---- gaeaProcess (通用 gaea process-type goods 进程管理) ----
  // lifecycle: 'attached'=随主窗口生死 / 'independent'=独立程序
  gaeaProcess: {
    start: (goodsId, scriptPath, runtime, lifecycle, allowMultiple) => import_electron.ipcRenderer.invoke("qqqide:gaea-process:start", goodsId, scriptPath, runtime, lifecycle, allowMultiple),
    stop: (goodsId) => import_electron.ipcRenderer.invoke("qqqide:gaea-process:stop", goodsId),
    status: (goodsId) => import_electron.ipcRenderer.invoke("qqqide:gaea-process:status", goodsId),
    getAutoStart: (goodsId) => import_electron.ipcRenderer.invoke("qqqide:gaea-process:get-auto-start", goodsId),
    setAutoStart: (goodsId, v, meta) => import_electron.ipcRenderer.invoke("qqqide:gaea-process:set-auto-start", goodsId, v, meta),
    onStatusChanged: (cb) => {
      const handler = (_e, data) => cb(data.goodsId, data.running, data.pid);
      import_electron.ipcRenderer.on("qqqide:gaea-process:status-changed", handler);
      return () => import_electron.ipcRenderer.removeListener("qqqide:gaea-process:status-changed", handler);
    }
  },
  // ---- desktop shortcut (Windows: PowerShell COM 创建/删除 .lnk) ----
  desktop: {
    syncShortcut: (enabled) => import_electron.ipcRenderer.invoke("qqqide:desktop:sync-shortcut", enabled)
  },
  // ---- kope (剪贴板历史, sql.js 直接读写 kope.sq3) ----
  kope: {
    getHistory: (limit, offset, keyword) => import_electron.ipcRenderer.invoke("qqqide:kope:getHistory", limit, offset, keyword),
    getStats: () => import_electron.ipcRenderer.invoke("qqqide:kope:getStats"),
    togglePin: (id) => import_electron.ipcRenderer.invoke("qqqide:kope:togglePin", id),
    deleteItem: (id) => import_electron.ipcRenderer.invoke("qqqide:kope:deleteItem", id)
  }
};
import_electron.contextBridge.exposeInMainWorld("qqqideBridge", QQQ);
//# sourceMappingURL=preload.js.map
