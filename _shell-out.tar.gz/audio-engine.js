"use strict";
// ============================================================================
// audio-engine.ts
// Spawns engines/miniaudio_bridge.py as a child process and exposes JSON-line
// stdio RPC matching the same protocol as engines.ts (action-based).
// Lazy-started: only spawns when first qqq:audio:* IPC arrives.
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AudioEngine = void 0;
const child_process_1 = require("child_process");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const readline = __importStar(require("readline"));
class AudioEngine {
    constructor(appRoot) {
        this.appRoot = appRoot;
        this.proc = null;
        this.nextId = 1;
        this.pending = new Map();
        this.alive = false;
        this.starting = null;
    }
    resolveScript() {
        const candidates = [
            path.join(this.appRoot, 'engines', 'miniaudio_bridge.py'),
            path.join(this.appRoot, 'resources', 'app', 'engines', 'miniaudio_bridge.py'),
        ];
        for (const p of candidates) {
            if (fs.existsSync(p)) {
                return p;
            }
        }
        return null;
    }
    resolvePython() {
        // Use whatever python is on PATH. Allow override via env.
        if (process.env.QQQ_PYTHON) {
            return process.env.QQQ_PYTHON;
        }
        return process.platform === 'win32' ? 'python' : 'python3';
    }
    /** Start lazily on first call. */
    async ensure() {
        if (this.alive) {
            return true;
        }
        if (this.starting) {
            return this.starting;
        }
        this.starting = this.start();
        const ok = await this.starting;
        this.starting = null;
        return ok;
    }
    async start() {
        const script = this.resolveScript();
        if (!script) {
            console.warn('[audio] miniaudio_bridge.py not found, audio disabled');
            return false;
        }
        const py = this.resolvePython();
        try {
            const proc = (0, child_process_1.spawn)(py, ['-u', script], {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true,
                cwd: path.dirname(script),
                env: { ...process.env, PYTHONUNBUFFERED: '1', PYTHONIOENCODING: 'utf-8' },
            });
            this.proc = proc;
            const rl = readline.createInterface({ input: proc.stdout, crlfDelay: Infinity });
            rl.on('line', line => this.onLine(line));
            proc.stderr.setEncoding('utf8');
            proc.stderr.on('data', d => {
                const s = String(d).trim();
                if (s) {
                    console.error('[audio.stderr]', s);
                }
            });
            proc.on('exit', code => {
                this.alive = false;
                console.warn('[audio] python exited code=' + code);
                for (const { reject, timer } of this.pending.values()) {
                    clearTimeout(timer);
                    reject(new Error('audio_engine_exited'));
                }
                this.pending.clear();
            });
            proc.on('error', err => { console.error('[audio] proc error:', err); this.alive = false; });
            console.log('[audio] spawned:', py, script, '(pid', proc.pid + ')');
            // handshake (5 retries)
            for (let i = 0; i < 5; i++) {
                try {
                    const pong = await this.rawCall('ping', {}, 1500);
                    if (pong && pong.status === 'alive') {
                        this.alive = true;
                        console.log('[audio] handshake OK');
                        return true;
                    }
                }
                catch { /* retry */ }
                await new Promise(r => setTimeout(r, 300));
            }
            console.warn('[audio] handshake failed, killing');
            try {
                proc.kill();
            }
            catch { /* ignore */ }
            this.proc = null;
            return false;
        }
        catch (e) {
            console.error('[audio] failed to start:', e);
            return false;
        }
    }
    onLine(line) {
        if (!line || !line.trim()) {
            return;
        }
        let msg;
        try {
            msg = JSON.parse(line);
        }
        catch {
            return;
        }
        if (msg._id === undefined) {
            return;
        }
        const cb = this.pending.get(msg._id);
        if (!cb) {
            return;
        }
        this.pending.delete(msg._id);
        clearTimeout(cb.timer);
        if (msg.error) {
            cb.reject(new Error(String(msg.error)));
        }
        else {
            cb.resolve(msg);
        }
    }
    rawCall(action, params, timeoutMs) {
        if (!this.proc || this.proc.killed) {
            return Promise.reject(new Error('audio_engine_not_running'));
        }
        const id = ++this.nextId;
        const cmd = JSON.stringify({ _id: id, action, ...(params || {}) }) + '\n';
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error('audio_timeout: ' + action));
            }, timeoutMs);
            this.pending.set(id, { resolve, reject, timer });
            try {
                this.proc.stdin.write(cmd);
            }
            catch (e) {
                clearTimeout(timer);
                this.pending.delete(id);
                reject(e);
            }
        });
    }
    async invoke(action, params = {}, timeoutMs = 10000) {
        const ok = await this.ensure();
        if (!ok) {
            throw new Error('audio_engine_unavailable');
        }
        return this.rawCall(action, params, timeoutMs);
    }
    isAlive() { return this.alive; }
    stop() {
        if (this.proc) {
            try {
                this.proc.kill();
            }
            catch { /* ignore */ }
            this.proc = null;
            this.alive = false;
        }
    }
}
exports.AudioEngine = AudioEngine;
//# sourceMappingURL=audio-engine.js.map