"use strict";
// ============================================================================
// menu-builder.ts
// Receives a JSON menu schema from the renderer, builds a native Electron Menu.
// Click events fire back through IPC channel 'qqqide:menu:fired' with cmd id.
// ============================================================================
Object.defineProperty(exports, "__esModule", { value: true });
exports.applyMenuSchema = void 0;
const electron_1 = require("electron");
function toElectronTemplate(items, win) {
    return items.map(it => {
        if (it.type === 'separator') {
            return { type: 'separator' };
        }
        const out = {
            label: it.label,
            type: it.type,
            enabled: it.enabled !== false,
        };
        if (it.role) {
            out.role = it.role;
        }
        if (it.accel) {
            out.accelerator = it.accel;
        }
        if (it.checked !== undefined) {
            out.checked = it.checked;
        }
        if (it.sub && it.sub.length > 0) {
            out.submenu = toElectronTemplate(it.sub, win);
        }
        else if (it.cmd) {
            const cmd = it.cmd;
            out.click = () => {
                if (win && !win.isDestroyed()) {
                    win.webContents.send('qqqide:menu:fired', cmd);
                }
            };
        }
        return out;
    });
}
function applyMenuSchema(schema, win) {
    if (!schema || !schema.items || schema.items.length === 0) {
        electron_1.Menu.setApplicationMenu(null);
        return;
    }
    const tpl = toElectronTemplate(schema.items, win);
    const menu = electron_1.Menu.buildFromTemplate(tpl);
    electron_1.Menu.setApplicationMenu(menu);
}
exports.applyMenuSchema = applyMenuSchema;
//# sourceMappingURL=menu-builder.js.map