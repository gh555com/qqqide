"use strict";
// ============================================================================
// monaco-host.ts
// Stub for the in-shell monaco editor instance pool (Day 3 deliverable).
// On Day 1 we expose just the contract; renderer can call but gets a stub.
// ============================================================================
Object.defineProperty(exports, "__esModule", { value: true });
exports.MonacoHost = void 0;
const electron_1 = require("electron");
class MonacoHost {
    constructor() {
        this.nextId = 1;
        this.instances = new Map();
    }
    register() {
        electron_1.ipcMain.handle('qqqide:monaco:create', (_e, _opts) => {
            const h = { id: this.nextId++, file: null };
            this.instances.set(h.id, h);
            return h.id;
        });
        electron_1.ipcMain.handle('qqqide:monaco:open', (_e, id, file) => {
            const h = this.instances.get(id);
            if (!h) {
                return false;
            }
            h.file = file;
            // Day 3: actually open file in monaco
            return true;
        });
        electron_1.ipcMain.handle('qqqide:monaco:save', (_e, id) => {
            const h = this.instances.get(id);
            return !!h;
        });
        electron_1.ipcMain.handle('qqqide:monaco:dispose', (_e, id) => {
            return this.instances.delete(id);
        });
    }
}
exports.MonacoHost = MonacoHost;
//# sourceMappingURL=monaco-host.js.map