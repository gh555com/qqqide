"use strict";
// ============================================================================
// lsp-bridge.ts
// LSP (Language Server Protocol) bridge — spawns language servers via qz-spawn
// persist mode and bridges JSON-RPC over stdin/stdout.
//
// Architecture:
//   Renderer (Monaco) ← IPC → lsp-bridge.ts ← stdin/stdout → LSP server
//
// ghrun `which` resolves binary paths; qz-spawn persist manages lifecycle.
// One LSP server instance per language (not per file).
// Diagnostics flow to renderer via webContents.send('qqqide:lsp:diagnostics',...).
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.guessRootUri = exports.LspBridge = void 0;
const qz_spawn_1 = require("./qz-spawn");
const child_process_1 = require("child_process");
const net = __importStar(require("net"));
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const LSP_REGISTRY = {
    python: { component: 'lsp/pyright', args: ['--stdio'], languageId: 'python', fileExtensions: ['.py', '.pyw'] },
    go: { component: 'lsp/gopls', args: [], languageId: 'go', fileExtensions: ['.go'] },
    rust: { component: 'lsp/rust-analyzer', args: [], languageId: 'rust', fileExtensions: ['.rs'] },
    c: { component: 'lsp/clangd', args: [], languageId: 'c', fileExtensions: ['.c', '.h'] },
    cpp: { component: 'lsp/clangd', args: [], languageId: 'cpp', fileExtensions: ['.cpp', '.cc', '.cxx', '.hpp', '.hxx'] },
};
/**
 * Detect language from file extension.
 * Returns null for languages handled by Monaco built-in workers (ts, js, json, html, css).
 */
function detectLanguage(filePath) {
    const ext = path.extname(filePath).toLowerCase();
    // Monaco built-in workers handle these — no LSP needed
    const monacoBuiltins = {
        '.ts': 'typescript', '.tsx': 'typescriptreact',
        '.js': 'javascript', '.jsx': 'javascriptreact',
        '.json': 'json', '.html': 'html', '.htm': 'html',
        '.css': 'css', '.scss': 'scss', '.less': 'less',
    };
    if (ext in monacoBuiltins)
        return null;
    for (const [lang, cfg] of Object.entries(LSP_REGISTRY)) {
        if (cfg.fileExtensions.includes(ext))
            return lang;
    }
    return null;
}
let nextId = 1;
function buildRequest(method, params) {
    const msg = { jsonrpc: '2.0', id: nextId++, method, params };
    const body = JSON.stringify(msg);
    return `Content-Length: ${Buffer.byteLength(body, 'utf8')}\r\n\r\n${body}`;
}
function buildNotification(method, params) {
    const msg = { jsonrpc: '2.0', method, params };
    const body = JSON.stringify(msg);
    return `Content-Length: ${Buffer.byteLength(body, 'utf8')}\r\n\r\n${body}`;
}
// Well-known LSP TCP ports (mirrors ghrun lsp_daemon.rs port_for)
const LSP_PORT_MAP = {
    'go': 9801,
    'python': 9802,
    'c': 9803,
    'cpp': 9803,
    'rust': 9804, // rust-analyzer
};
/** TCP-based LSP transport — connects to ghrun LSP daemon. */
class TcpLspTransport {
    constructor(port, host = '127.0.0.1') {
        this.buffer = '';
        this.dataCbs = [];
        this.exitCbs = [];
        this.stderrCbs = [];
        this.socket = net.createConnection({ port, host });
        this.socket.on('data', (chunk) => {
            this.buffer += chunk.toString('utf8');
            while (true) {
                const m = this.buffer.match(/^Content-Length: (\d+)\r\n\r\n/);
                if (!m)
                    break;
                const len = parseInt(m[1], 10);
                // Reject oversized frames (aligns with ghrun lsp_daemon.rs 50MB limit)
                if (isNaN(len) || len > 50 * 1024 * 1024) {
                    this.buffer = ''; // discard corrupted data
                    return;
                }
                const headerEnd = m[0].length;
                if (this.buffer.length < headerEnd + len)
                    break;
                const body = this.buffer.slice(headerEnd, headerEnd + len);
                this.buffer = this.buffer.slice(headerEnd + len);
                for (const cb of this.dataCbs) {
                    try {
                        cb(body);
                    }
                    catch (e) { /* ignore */ }
                }
            }
        });
        this.socket.on('error', (err) => {
            for (const cb of this.stderrCbs) {
                try {
                    cb('[tcp] ' + err.message);
                }
                catch (e) { /* ignore */ }
            }
        });
        this.socket.on('close', () => {
            for (const cb of this.exitCbs) {
                try {
                    cb(null);
                }
                catch (e) { /* ignore */ }
            }
        });
    }
    send(data) { this.socket.write(data); }
    onData(cb) { this.dataCbs.push(cb); }
    onStderr(cb) { this.stderrCbs.push(cb); }
    onExit(cb) { this.exitCbs.push(cb); }
    async shutdown() { this.socket.destroy(); }
}
class LspInstance {
    constructor(handle, lang, cfg) {
        this.pending = new Map();
        this.openDocs = new Set();
        this.serverCapabilities = null;
        this.initResult = null;
        this.initDone = false;
        this.handle = handle;
        this.lang = lang;
        this.cfg = cfg;
        this.handle.onData((data) => {
            try {
                const msg = JSON.parse(data);
                this._onMessage(msg);
            }
            catch (e) {
                console.warn('[lsp] bad JSON from', lang, ':', String(data).slice(0, 200));
            }
        });
        this.handle.onStderr((data) => {
            console.warn('[lsp]', lang, 'stderr:', data.slice(0, 500));
        });
        this.handle.onExit((code) => {
            console.warn('[lsp]', lang, 'exited with code', code);
            // Reject all pending
            for (const [id, pr] of this.pending) {
                clearTimeout(pr.timer);
                pr.reject(new Error(`LSP server ${lang} exited (code ${code})`));
            }
            this.pending.clear();
        });
    }
    _onMessage(msg) {
        // Response to a request
        if (msg.id !== undefined && this.pending.has(msg.id)) {
            const pr = this.pending.get(msg.id);
            this.pending.delete(msg.id);
            clearTimeout(pr.timer);
            if (msg.error) {
                pr.reject(new Error(msg.error.message || 'LSP error'));
            }
            else {
                pr.resolve(msg.result);
            }
            return;
        }
        // Server→client notification (diagnostics, etc.)
        if (msg.method && this.onNotification) {
            this.onNotification(msg.method, msg.params);
        }
    }
    /** Send a request and wait for response (with 30s timeout). */
    async request(method, params) {
        if (!this.initDone && method !== 'initialize' && method !== 'initialized') {
            throw new Error(`LSP ${this.lang}: not initialized yet`);
        }
        const id = nextId++;
        const msg = { jsonrpc: '2.0', id, method, params };
        const body = JSON.stringify(msg);
        this.handle.send(`Content-Length: ${Buffer.byteLength(body, 'utf8')}\r\n\r\n${body}`);
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error(`LSP ${this.lang} request '${method}' timed out`));
            }, 30000);
            this.pending.set(id, { resolve, reject, timer });
        });
    }
    /** Send a notification (no response expected). */
    notify(method, params) {
        const msg = { jsonrpc: '2.0', method, params };
        const body = JSON.stringify(msg);
        this.handle.send(`Content-Length: ${Buffer.byteLength(body, 'utf8')}\r\n\r\n${body}`);
    }
    /** Initialize the LSP session. Must be called before any document operations. */
    async initialize(rootUri) {
        const result = await this.request('initialize', {
            processId: process.pid,
            rootUri,
            capabilities: {
                textDocument: {
                    synchronization: { didChange: 2 },
                    completion: { completionItem: { snippetSupport: false } },
                    hover: { contentFormat: ['plaintext', 'markdown'] },
                    definition: {},
                    references: {},
                    documentSymbol: {},
                },
            },
            initializationOptions: undefined,
        });
        this.serverCapabilities = result.capabilities;
        this.initResult = result;
        this.notify('initialized', {});
        this.initDone = true;
        console.log('[lsp]', this.lang, 'initialized:', Object.keys(result.capabilities || {}).join(', '));
    }
    async openDocument(filePath, text) {
        if (this.openDocs.has(filePath))
            return;
        this.openDocs.add(filePath);
        const uri = filePathToUri(filePath);
        this.notify('textDocument/didOpen', {
            textDocument: { uri, languageId: this.cfg.languageId, version: 1, text },
        });
    }
    async changeDocument(filePath, changes, version) {
        const uri = filePathToUri(filePath);
        this.notify('textDocument/didChange', {
            textDocument: { uri, version },
            contentChanges: changes,
        });
    }
    async closeDocument(filePath) {
        if (!this.openDocs.has(filePath))
            return;
        this.openDocs.delete(filePath);
        this.notify('textDocument/didClose', {
            textDocument: { uri: filePathToUri(filePath) },
        });
    }
    /** Request hover info at a position (textDocument/hover). */
    async hover(filePath, line, character) {
        const uri = filePathToUri(filePath);
        return this.request('textDocument/hover', {
            textDocument: { uri },
            position: { line, character },
        });
    }
    async shutdown() {
        try {
            await this.request('shutdown');
        }
        catch { /* ignore */ }
        this.notify('exit', {});
        await this.handle.shutdown();
    }
}
// ---------------------------------------------------------------------------
// LspBridge — singleton manager
// ---------------------------------------------------------------------------
class LspBridge {
    /** Resolve TCP port for an LSP language (mirrors ghrun lsp_daemon.rs port_for). */
    resolvePort(lang) {
        return LSP_PORT_MAP[lang] || 0;
    }
    /** Try to connect to ghrun LSP daemon via TCP. Returns transport or null. */
    tryConnectTcp(lang) {
        const port = this.resolvePort(lang);
        if (port <= 0)
            return null;
        try {
            const t = new TcpLspTransport(port);
            console.log('[lsp] TCP connected to', lang, 'on port', port);
            return t;
        }
        catch (e) {
            console.warn('[lsp] TCP connect to', lang, 'port', port, 'failed:', e.message);
            return null;
        }
    }
    constructor(appRoot) {
        this.instances = new Map();
        this.targets = new Set();
        this.diagnosticsCache = new Map(); // uri → diagnostics[]
        /** Resolved binary paths: lang → full path */
        this.binPaths = new Map();
        /** Open document count per language (for idle shutdown). */
        this.docCounts = new Map();
        /** Idle shutdown timers per language. */
        this.idleTimers = new Map();
        this.appRoot = appRoot;
        this.qz = new qz_spawn_1.QzSpawn(appRoot);
    }
    /** Add a renderer target for diagnostics push (one per BrowserWindow). */
    addTarget(wc) {
        this.targets.add(wc);
        // Push cached diagnostics to newly added target
        for (const [uri, diagnostics] of this.diagnosticsCache) {
            if (!wc.isDestroyed()) {
                wc.send('qqqide:lsp:diagnostics', { uri, diagnostics });
            }
        }
    }
    /** Remove a renderer target (window closed). */
    removeTarget(wc) {
        this.targets.delete(wc);
    }
    /**
     * Resolve LSP binary path via ghrun `which` command.
     * Returns null if ghrun is not available or component not found.
     */
    resolveGhrunWhich(component) {
        const ghrunBin = this.findGhrun();
        if (!ghrunBin)
            return null;
        try {
            const result = (0, child_process_1.spawnSync)(ghrunBin, ['which', component], {
                windowsHide: true,
                timeout: 5000,
            });
            if (result.status === 0 && result.stdout) {
                const line = result.stdout.toString('utf8').split('\n')[0];
                const parsed = JSON.parse(line);
                if (parsed.event === 'which' && parsed.path) {
                    return parsed.path;
                }
            }
        }
        catch (e) {
            console.warn('[lsp] ghrun which failed:', e);
        }
        return null;
    }
    /** Auto-start ghrun lsp-daemon in background, then retry TCP connect. */
    async tryAutoStartDaemon() {
        const ghrunBin = this.findGhrun();
        if (!ghrunBin)
            return;
        try {
            const proc = (0, child_process_1.spawn)(ghrunBin, ['lsp-daemon'], {
                detached: true,
                stdio: 'ignore',
                windowsHide: true,
            });
            proc.unref();
            await new Promise(r => setTimeout(r, 500));
            console.log('[lsp] auto-started ghrun lsp-daemon');
        }
        catch (e) {
            console.warn('[lsp] failed to auto-start ghrun daemon:', e.message);
        }
    }
    findGhrun() {
        const env = process.env.QQQIDE_QDIR_GHRUN;
        if (env && fs.existsSync(env))
            return env;
        const qdir = process.env.QQQIDE_QDIR;
        if (qdir) {
            const ext = process.platform === 'win32' ? '.exe' : '';
            const p = path.join(qdir, 'ghrun' + ext);
            if (fs.existsSync(p))
                return p;
        }
        // also probe engines/ghrun.exe under app root
        const ext = process.platform === 'win32' ? '.exe' : '';
        const p = path.join(this.appRoot, 'engines', 'ghrun' + ext);
        if (fs.existsSync(p))
            return p;
        return null;
    }
    /** Start LSP for a language. TCP (ghrun daemon) first, fallback to direct spawn. */
    async startLanguage(lang, rootUri) {
        if (this.instances.has(lang))
            return true;
        const cfg = LSP_REGISTRY[lang];
        if (!cfg) {
            console.warn('[lsp] no LSP config for language:', lang);
            return false;
        }
        // Helper: try TCP init with a given transport
        const tryTcpInit = async (transport) => {
            const instance = new LspInstance(transport, lang, cfg);
            this.instances.set(lang, instance);
            instance.onNotification = (method, params) => {
                if (method === 'textDocument/publishDiagnostics' && params && params.uri) {
                    const filePath = uriToFilePath(params.uri);
                    this.updateDiagnostics(filePath, params.diagnostics || []);
                }
            };
            try {
                await instance.initialize(rootUri);
                return true;
            }
            catch (e) {
                console.warn('[lsp] TCP init failed for', lang, ':', e.message);
                instance.shutdown().catch(() => { });
                this.instances.delete(lang);
                return false;
            }
        };
        // === Phase 1: try TCP via ghrun LSP daemon (already running) ===
        const tcpTransport = this.tryConnectTcp(lang);
        if (tcpTransport && await tryTcpInit(tcpTransport))
            return true;
        // === Phase 1.5: daemon not running → auto-start ghrun lsp-daemon ===
        await this.tryAutoStartDaemon();
        const retryTransport = this.tryConnectTcp(lang);
        if (retryTransport && await tryTcpInit(retryTransport))
            return true;
        // === Phase 2: direct spawn (fallback when ghrun daemon not running) ===
        let binPath = this.binPaths.get(lang);
        if (!binPath) {
            binPath = this.resolveGhrunWhich(cfg.component);
            if (!binPath) {
                const qdir = process.env.QQQIDE_QDIR;
                if (qdir) {
                    const dirName = cfg.component.replace('/', '_');
                    const ext = process.platform === 'win32' ? '.exe' : '';
                    const guessedBin = cfg.component.split('/').pop() + ext;
                    const probePaths = [
                        path.join(qdir, 'f', 'components', dirName, guessedBin),
                        path.join(qdir, 'f', 'components', dirName, cfg.component.split('/').pop() + ext),
                    ];
                    for (const p of probePaths) {
                        if (fs.existsSync(p)) {
                            binPath = p;
                            break;
                        }
                    }
                }
            }
            if (!binPath) {
                const which = this.qz.which(cfg.component.split('/').pop());
                if (which)
                    binPath = which;
            }
            if (binPath) {
                this.binPaths.set(lang, binPath);
            }
        }
        if (!binPath) {
            console.warn('[lsp] cannot find binary for', lang, '(component:', cfg.component, ')');
            return false;
        }
        console.log('[lsp] direct spawn', lang, '→', binPath);
        const handle = this.qz.spawnPersist({
            cmd: binPath,
            args: cfg.args,
            idleTimeout: 300000,
        });
        if (!handle) {
            console.error('[lsp] spawnPersist failed for', lang);
            return false;
        }
        const instance = new LspInstance(handle, lang, cfg);
        this.instances.set(lang, instance);
        instance.onNotification = (method, params) => {
            if (method === 'textDocument/publishDiagnostics' && params && params.uri) {
                const filePath = uriToFilePath(params.uri);
                this.updateDiagnostics(filePath, params.diagnostics || []);
            }
        };
        try {
            await instance.initialize(rootUri);
            return true;
        }
        catch (e) {
            console.error('[lsp] initialize failed for', lang, ':', e.message);
            instance.shutdown().catch(() => { });
            this.instances.delete(lang);
            return false;
        }
    }
    /** Stop LSP for a language. */
    async stopLanguage(lang) {
        const inst = this.instances.get(lang);
        if (!inst)
            return;
        await inst.shutdown();
        this.instances.delete(lang);
        // Clean up idle tracking
        const timer = this.idleTimers.get(lang);
        if (timer) {
            clearTimeout(timer);
            this.idleTimers.delete(lang);
        }
        this.docCounts.delete(lang);
    }
    /** Open a document in the appropriate LSP server. */
    async openDocument(filePath, text) {
        const lang = detectLanguage(filePath);
        if (!lang)
            return null; // Monaco handles this natively
        if (!this.instances.has(lang))
            return lang; // not started yet, no-op
        const inst = this.instances.get(lang);
        await inst.openDocument(filePath, text);
        // Track doc count, cancel idle shutdown if pending
        const count = (this.docCounts.get(lang) || 0) + 1;
        this.docCounts.set(lang, count);
        const timer = this.idleTimers.get(lang);
        if (timer) {
            clearTimeout(timer);
            this.idleTimers.delete(lang);
        }
        return lang;
    }
    /** Notify LSP of document change. */
    async changeDocument(filePath, changes, version) {
        const lang = detectLanguage(filePath);
        if (!lang || !this.instances.has(lang))
            return;
        await this.instances.get(lang).changeDocument(filePath, changes, version);
    }
    /** Close a document. Triggers idle shutdown after 5 min with zero open docs. */
    async closeDocument(filePath) {
        const lang = detectLanguage(filePath);
        if (!lang || !this.instances.has(lang))
            return;
        await this.instances.get(lang).closeDocument(filePath);
        // Decrement doc count; start idle timer when count hits 0
        const count = Math.max(0, (this.docCounts.get(lang) || 1) - 1);
        this.docCounts.set(lang, count);
        if (count <= 0 && this.instances.has(lang)) {
            this.docCounts.delete(lang);
            // Start 5-min idle timer
            const timer = setTimeout(() => {
                this.idleTimers.delete(lang);
                if ((this.docCounts.get(lang) || 0) <= 0 && this.instances.has(lang)) {
                    console.log('[lsp] idle timeout for', lang, '→ shutting down');
                    this.stopLanguage(lang).catch(() => { });
                }
            }, LspBridge.IDLE_SHUTDOWN_MS);
            this.idleTimers.set(lang, timer);
        }
    }
    /** Request hover info via LSP. Returns null if no language server is active. */
    async hover(filePath, line, character) {
        const lang = detectLanguage(filePath);
        if (!lang || !this.instances.has(lang))
            return null;
        try {
            return await this.instances.get(lang).hover(filePath, line, character);
        }
        catch (e) {
            console.warn('[lsp] hover failed for', lang, ':', e.message);
            return null;
        }
    }
    /** Push diagnostics to all target renderers. */
    updateDiagnostics(filePath, diagnostics) {
        const uri = filePathToUri(filePath);
        this.diagnosticsCache.set(uri, diagnostics);
        for (const wc of this.targets) {
            if (!wc.isDestroyed()) {
                wc.send('qqqide:lsp:diagnostics', { uri, diagnostics });
            }
        }
    }
    /** Get cached diagnostics for a URI. */
    getDiagnostics(uri) {
        return this.diagnosticsCache.get(uri) || [];
    }
    /** Get all active language names. */
    activeLanguages() {
        return Array.from(this.instances.keys());
    }
    /** Stop all LSP servers. */
    async shutdownAll() {
        const langs = Array.from(this.instances.keys());
        await Promise.all(langs.map(l => this.stopLanguage(l)));
        this.instances.clear();
        this.diagnosticsCache.clear();
    }
}
/** Kill LSP after 5 minutes with zero open docs. */
LspBridge.IDLE_SHUTDOWN_MS = 300000;
exports.LspBridge = LspBridge;
// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------
function filePathToUri(filePath) {
    // Convert Windows path to file:// URI
    const normalized = filePath.replace(/\\/g, '/');
    if (normalized.match(/^[a-zA-Z]:/)) {
        return 'file:///' + normalized;
    }
    return 'file://' + normalized;
}
function uriToFilePath(uri) {
    // Convert file:// URI back to platform path
    let p = decodeURIComponent(uri.replace(/^file:\/\/\//, '').replace(/^file:\/\//, ''));
    if (process.platform === 'win32') {
        p = p.replace(/\//g, '\\');
    }
    return p;
}
/**
 * Resolve workspace root URI from a file path.
 * For ghrun-managed components, the root is the directory of the file.
 * In the future this can be smarter (e.g. find nearest go.mod, Cargo.toml, etc.).
 */
function guessRootUri(filePath) {
    return filePathToUri(path.dirname(filePath));
}
exports.guessRootUri = guessRootUri;
//# sourceMappingURL=lsp-bridge.js.map