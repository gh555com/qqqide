"use strict";
// ============================================================================
// cache-store.ts
// Two-tier portable cache rooted at $QQQIDE_QDIR/cache (or portable.cache):
//   - KV  : cache/kv/<safekey>.json
//   - file: cache/h/<aa>/<aabbcc...><ext>     (bucketed by content sig)
//
// Designed to be the canonical sink for:
//   - hash-service mtime cache
//   - media-service ffmpeg outputs (thumb/transcode), keyed by input sig
//   - paste-everything dedup'd blobs
//
// Keys are arbitrary user strings; they are hashed to a safe filename internally.
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CacheStore = void 0;
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const crypto = __importStar(require("crypto"));
class CacheStore {
    constructor(root) {
        this.root = root;
        this.kvDir = path.join(root, 'kv');
        this.bucketRoot = path.join(root, 'h'); // file bucket
        this.hashDir = path.join(root, 'hash'); // hash-service mtime db
        for (const d of [root, this.kvDir, this.bucketRoot, this.hashDir]) {
            try {
                fs.mkdirSync(d, { recursive: true });
            }
            catch { /* ignore */ }
        }
    }
    // ----- safe key -> filename ------------------------------------------------
    keyToFile(key) {
        const h = crypto.createHash('sha256').update(String(key)).digest('hex');
        return path.join(this.kvDir, h.slice(0, 2), h + '.json');
    }
    // ----- KV API -------------------------------------------------------------
    async has(key) {
        const p = this.keyToFile(key);
        return fs.existsSync(p);
    }
    async get(key) {
        const p = this.keyToFile(key);
        try {
            const raw = await fs.promises.readFile(p, 'utf8');
            const ent = JSON.parse(raw);
            if (ent.ttl && (Date.now() - ent.t) > ent.ttl) {
                return null;
            }
            return ent.v;
        }
        catch {
            return null;
        }
    }
    async put(key, value, opts) {
        const p = this.keyToFile(key);
        try {
            fs.mkdirSync(path.dirname(p), { recursive: true });
        }
        catch { /* ignore */ }
        const ent = { v: value, t: Date.now() };
        if (opts && opts.ttlMs) {
            ent.ttl = opts.ttlMs;
        }
        try {
            await fs.promises.writeFile(p, JSON.stringify(ent), 'utf8');
            return true;
        }
        catch (e) {
            console.warn('[cache] put failed:', key, e);
            return false;
        }
    }
    async del(key) {
        const p = this.keyToFile(key);
        try {
            await fs.promises.unlink(p);
            return true;
        }
        catch {
            return false;
        }
    }
    /** Absolute filesystem path of the KV entry for a key (may not exist). */
    async path(key) {
        return this.keyToFile(key);
    }
    // ----- File bucket --------------------------------------------------------
    /**
     * Resolve the bucketed path for a content signature (typically a hex hash).
     * `sig` is the full hash; bucket = first 2 chars.
     * Returns absolute path, regardless of whether the file exists.
     */
    bucketPath(sig, ext) {
        const clean = String(sig || '').replace(/[^a-zA-Z0-9]/g, '');
        if (!clean) {
            throw new Error('bucketPath: empty sig');
        }
        const bucket = clean.slice(0, 2).toLowerCase();
        const dir = path.join(this.bucketRoot, bucket);
        try {
            fs.mkdirSync(dir, { recursive: true });
        }
        catch { /* ignore */ }
        const safeExt = ext && /^\.[a-zA-Z0-9]{1,8}$/.test(ext) ? ext : '';
        return path.join(dir, clean + safeExt);
    }
    /** Hash-service mtime db dir (kept separate so we can clean independently). */
    hashDbDir() { return this.hashDir; }
}
exports.CacheStore = CacheStore;
//# sourceMappingURL=cache-store.js.map