"use strict";

// shell/login-preload.ts
var import_electron = require("electron");
import_electron.contextBridge.exposeInMainWorld("__qqqLoginBridge", {
  /** 登录完成 → 传 token 到主进程。主进程关闭此窗口 + 广播所有窗口。 */
  complete: (data) => {
    import_electron.ipcRenderer.send("qqqide:auth:login-complete", data);
  },
  /** 取消登录 → 关闭窗口。 */
  cancel: () => {
    import_electron.ipcRenderer.send("qqqide:auth:login-cancel");
  }
});
//# sourceMappingURL=login-preload.js.map
