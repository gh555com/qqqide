"use strict";
// ============================================================================
// engines.ts
// Spawns the existing Rust IO engine as a child process and exposes a JSON
// line-based RPC over stdio (action-based protocol matching q3 daemon).
//
// Engine binary naming convention (matches q3/assets/):
//   q_win_x64.exe   q_win_arm64.exe
//   q_linux_x64     q_linux_arm64
//   q_mac_x64       q_mac_arm64
//
// Protocol (line-delimited JSON over stdio):
//   request:  {"_id":<int>, "action":"<name>", ...params}\n
//   response: {"_id":<int>, ...result}\n         OR   {"_id":<int>, "error":"..."}
//   event:    {"event":"...", ...}               (no _id)
//   handshake: client sends action="ping" -> server returns {"status":"alive"}
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EngineHost = void 0;
const child_process_1 = require("child_process");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const readline = __importStar(require("readline"));
const events_1 = require("events");
class EngineHost extends events_1.EventEmitter {
    constructor(appRoot) {
        super();
        this.appRoot = appRoot;
        this.proc = null;
        this.nextId = 1;
        this.pending = new Map();
        this.enginePath = '';
        this.alive = false;
        this.starting = null;
    }
    /** Resolve the engine binary path for current platform/arch. */
    resolveEngineBinary() {
        const platMap = { win32: 'win', linux: 'linux', darwin: 'mac' };
        const archMap = { x64: 'x64', arm64: 'arm64' };
        const plat = platMap[process.platform];
        const arch = archMap[process.arch];
        if (!plat || !arch) {
            return null;
        }
        const ext = process.platform === 'win32' ? '.exe' : '';
        // Search roots: appRoot first (extraResources style),
        // then resources/app/ (default electron-builder layout).
        const searchRoots = [
            this.appRoot,
            path.join(this.appRoot, 'resources', 'app'),
        ];
        const tries = [];
        for (const root of searchRoots) {
            tries.push(path.join(root, 'engines', `q_${plat}_${arch}${ext}`));
            // Win arm64 may run x64 via emulation
            if (plat === 'win' && arch === 'arm64') {
                tries.push(path.join(root, 'engines', `q_win_x64${ext}`));
            }
        }
        for (const candidate of tries) {
            if (fs.existsSync(candidate)) {
                return candidate;
            }
        }
        return null;
    }
    /**
     * Start the engine and wait for ping handshake. Returns true if alive.
     * Non-fatal if missing or fails - caller can still operate via fallback.
     */
    async start() {
        if (this.starting) {
            return this.starting;
        }
        if (this.alive) {
            return true;
        }
        this.starting = this.doStart();
        const ok = await this.starting;
        this.starting = null;
        return ok;
    }
    async doStart() {
        const bin = this.resolveEngineBinary();
        if (!bin) {
            console.warn('[engines] no rust engine binary found, fs.* will fall back to node native');
            return false;
        }
        this.enginePath = bin;
        try {
            const proc = (0, child_process_1.spawn)(bin, ['--daemon'], {
                stdio: ['pipe', 'pipe', 'pipe'],
                windowsHide: true,
                env: { ...process.env, QQQ_PARENT_PID: String(process.pid) },
            });
            this.proc = proc;
            // line-delimited reader (handles long lines and partial chunks)
            const rl = readline.createInterface({ input: proc.stdout, crlfDelay: Infinity });
            rl.on('line', line => this.onLine(line));
            proc.stderr.setEncoding('utf8');
            proc.stderr.on('data', d => {
                const text = String(d).trim();
                if (text) {
                    console.error('[engine.stderr]', text);
                }
            });
            proc.on('exit', code => {
                this.alive = false;
                console.warn('[engines] engine exited code=' + code);
                for (const { reject, timer } of this.pending.values()) {
                    clearTimeout(timer);
                    reject(new Error('engine exited'));
                }
                this.pending.clear();
                this.emit('exit', code);
            });
            proc.on('error', err => {
                console.error('[engines] proc error:', err);
                this.alive = false;
                this.emit('error', err);
            });
            console.log('[engines] spawned:', bin, '(pid', proc.pid + ')');
            // Handshake: ping with retries (engine may take ~100-500ms to be ready)
            const ok = await this.handshake();
            this.alive = ok;
            if (ok) {
                console.log('[engines] handshake OK');
                this.emit('ready');
            }
            else {
                console.warn('[engines] handshake failed, killing engine');
                try {
                    proc.kill();
                }
                catch { /* ignore */ }
                this.proc = null;
            }
            return ok;
        }
        catch (e) {
            console.error('[engines] failed to start:', e);
            this.alive = false;
            return false;
        }
    }
    /** Send ping, retry up to 15 times every 200ms. */
    async handshake() {
        for (let i = 0; i < 15; i++) {
            try {
                const pong = await this.rawCall('ping', {}, 1000);
                if (pong && pong.status === 'alive') {
                    return true;
                }
            }
            catch { /* retry */ }
            await new Promise(r => setTimeout(r, 200));
        }
        return false;
    }
    onLine(line) {
        if (!line || !line.trim()) {
            return;
        }
        let msg;
        try {
            msg = JSON.parse(line);
        }
        catch {
            // try base64 decode (q3's PowerShell bridge wraps as base64)
            try {
                msg = JSON.parse(Buffer.from(line, 'base64').toString('utf8'));
            }
            catch {
                console.warn('[engines] bad json:', line.slice(0, 200));
                return;
            }
        }
        // Async event (no _id, or has 'event' field)
        if (msg._id === undefined || msg.event) {
            this.emit('event', msg);
            return;
        }
        const cb = this.pending.get(msg._id);
        if (!cb) {
            return;
        }
        this.pending.delete(msg._id);
        clearTimeout(cb.timer);
        if (msg.error) {
            cb.reject(new Error(String(msg.error)));
        }
        else {
            cb.resolve(msg);
        }
    }
    /** Internal raw call (does not check this.alive; used for handshake). */
    rawCall(action, params, timeoutMs) {
        if (!this.proc || this.proc.killed) {
            return Promise.reject(new Error('engine_not_running'));
        }
        const id = ++this.nextId;
        const cmd = JSON.stringify({ _id: id, action, ...(params || {}) }) + '\n';
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error('engine_timeout: ' + action));
            }, timeoutMs);
            this.pending.set(id, { resolve, reject, timer });
            try {
                this.proc.stdin.write(cmd);
            }
            catch (e) {
                clearTimeout(timer);
                this.pending.delete(id);
                reject(e);
            }
        });
    }
    /**
     * Public RPC: invoke an action on the engine.
     * If engine is not alive, rejects (caller should fall back to native fs).
     */
    invoke(action, params = {}, timeoutMs = 10000) {
        if (!this.alive) {
            return Promise.reject(new Error('engine_not_available'));
        }
        return this.rawCall(action, params, timeoutMs);
    }
    isAlive() { return this.alive; }
    stop() {
        if (this.proc) {
            try {
                this.proc.kill();
            }
            catch { /* ignore */ }
            this.proc = null;
            this.alive = false;
        }
    }
}
exports.EngineHost = EngineHost;
//# sourceMappingURL=engines.js.map