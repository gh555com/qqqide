"use strict";
// ============================================================================
// cdp-sniffer.ts — CDP-based video URL sniffer for qqq-shell-v2
//
// Ported from q3/src/cdp-sniffer.js. Launches Chrome/Edge in debug mode,
// connects via CDP WebSocket, and sniffs Network requests to capture
// real .m3u8 / .mpd / .mp4 URLs for sites like Bilibili, Douyin, Twitch.
//
// Uses a lightweight built-in WebSocket (no ws dependency).
// Browser spawned via Node child_process; cleanup via taskkill on Windows.
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CdpSniffer = void 0;
const child_process_1 = require("child_process");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const os = __importStar(require("os"));
const crypto = __importStar(require("crypto"));
const http = __importStar(require("http"));
const url_1 = require("url");
class SimpleWebSocket {
    constructor(url) {
        this.listeners = { open: [], message: [], error: [] };
        this.socket = null;
        this.url = url;
        this.connect();
    }
    on(event, cb) {
        if (this.listeners[event])
            this.listeners[event].push(cb);
    }
    send(data) {
        if (!this.socket)
            return;
        const payload = Buffer.from(data);
        const length = payload.length;
        let headerLen = 2;
        if (length <= 125) { /* headerLen = 2 */ }
        else if (length <= 65535) {
            headerLen = 4;
        }
        else {
            headerLen = 10;
        }
        const frame = Buffer.alloc(headerLen + 4 + length);
        frame[0] = 0x81; // FIN + Text
        if (length <= 125) {
            frame[1] = 0x80 | length;
        }
        else if (length <= 65535) {
            frame[1] = 0x80 | 126;
            frame.writeUInt16BE(length, 2);
        }
        else {
            frame[1] = 0x80 | 127;
            frame.writeBigUInt64BE(BigInt(length), 2);
        }
        const mask = new Uint8Array(4);
        crypto.randomFillSync(mask);
        for (let i = 0; i < 4; i++)
            frame[headerLen + i] = mask[i];
        for (let i = 0; i < length; i++) {
            frame[headerLen + 4 + i] = payload[i] ^ mask[i % 4];
        }
        this.socket.write(frame);
    }
    close() {
        if (this.socket)
            this.socket.destroy();
        this.socket = null;
    }
    connect() {
        const u = new url_1.URL(this.url);
        const options = {
            host: u.hostname,
            port: u.port ? parseInt(u.port, 10) : 80,
            path: u.pathname + u.search,
            headers: {
                'Connection': 'Upgrade',
                'Upgrade': 'websocket',
                'Sec-WebSocket-Version': '13',
                'Sec-WebSocket-Key': crypto.randomBytes(16).toString('base64'),
            },
        };
        const req = http.request(options);
        req.on('upgrade', (res, socket, _head) => {
            this.socket = socket;
            this.listeners.open.forEach(cb => cb());
            let buffer = Buffer.alloc(0);
            socket.on('data', (chunk) => {
                buffer = Buffer.concat([buffer, chunk]);
                while (true) {
                    if (buffer.length < 2)
                        break;
                    const firstByte = buffer[0];
                    const opCode = firstByte & 0x0f;
                    const secondByte = buffer[1];
                    const isMasked = (secondByte & 0x80) !== 0;
                    let payloadLen = secondByte & 0x7f;
                    let offset = 2;
                    if (payloadLen === 126) {
                        if (buffer.length < offset + 2)
                            break;
                        payloadLen = buffer.readUInt16BE(offset);
                        offset += 2;
                    }
                    else if (payloadLen === 127) {
                        if (buffer.length < offset + 8)
                            break;
                        payloadLen = Number(buffer.readBigUInt64BE(offset));
                        offset += 8;
                    }
                    let maskKey = null;
                    if (isMasked) {
                        if (buffer.length < offset + 4)
                            break;
                        maskKey = buffer.slice(offset, offset + 4);
                        offset += 4;
                    }
                    if (buffer.length < offset + payloadLen)
                        break;
                    const payload = buffer.slice(offset, offset + payloadLen);
                    if (isMasked && maskKey) {
                        for (let i = 0; i < payloadLen; i++)
                            payload[i] ^= maskKey[i % 4];
                    }
                    if (opCode === 0x1) {
                        const str = payload.toString('utf8');
                        this.listeners.message.forEach(cb => cb(str));
                    }
                    buffer = buffer.slice(offset + payloadLen);
                }
            });
        });
        req.on('error', (e) => this.listeners.error.forEach(cb => cb(e)));
        req.end();
    }
}
// ---- Helpers ----
function findBrowserPath() {
    const platform = process.platform;
    const commonPaths = [];
    if (platform === 'win32') {
        const home = os.homedir();
        commonPaths.push('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', path.join(home, 'AppData\\Local\\Google\\Chrome\\Application\\chrome.exe'), path.join(home, 'AppData\\Local\\Microsoft\\Edge\\Application\\msedge.exe'));
    }
    else if (platform === 'darwin') {
        commonPaths.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge');
    }
    else {
        commonPaths.push('/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/microsoft-edge');
    }
    for (const p of commonPaths) {
        if (fs.existsSync(p))
            return p;
    }
    if (process.env.CHROME_PATH && fs.existsSync(process.env.CHROME_PATH))
        return process.env.CHROME_PATH;
    if (process.env.EDGE_PATH && fs.existsSync(process.env.EDGE_PATH))
        return process.env.EDGE_PATH;
    return null;
}
function validateBrowserPath(exePath) {
    if (!exePath || typeof exePath !== 'string')
        return false;
    try {
        const r = (0, child_process_1.spawn)(exePath, ['--version'], { windowsHide: true, timeout: 5000 });
        return true; // spawn succeeded (process started)
    }
    catch {
        return false;
    }
}
async function getDebugUrl(port) {
    const resp = await new Promise((resolve, reject) => {
        http.get(`http://127.0.0.1:${port}/json/version`, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => resolve({ statusCode: res.statusCode || 0, data }));
        }).on('error', reject);
    });
    if (resp.statusCode !== 200)
        throw new Error(`CDP debug endpoint returned ${resp.statusCode}`);
    const parsed = JSON.parse(resp.data);
    if (!parsed.webSocketDebuggerUrl)
        throw new Error('No webSocketDebuggerUrl in CDP response');
    return parsed.webSocketDebuggerUrl;
}
// ---- CdpSniffer ----
class CdpSniffer {
    constructor(appRoot) {
        this.appRoot = appRoot;
        this.browserProcess = null;
        this.ws = null;
        this.tmpDir = '';
        this.nextId = 1000;
        this.capturedVideos = [];
        this.sessions = new Set();
        this.keepAliveTimers = [];
        this.log = () => { };
    }
    /** Set custom browser path globally. */
    static setCustomBrowserPath(p) {
        CdpSniffer.customBrowserPath = p;
    }
    static getCustomBrowserPath() {
        return CdpSniffer.customBrowserPath;
    }
    /** Start sniffing on a target URL. Returns when CDP is connected. */
    async start(targetUrl, onLog, options = {}) {
        this.log = onLog || (() => { });
        const browserPath = CdpSniffer.customBrowserPath || findBrowserPath();
        if (!browserPath)
            throw new Error('未找到 Chrome 或 Edge 浏览器');
        const port = 9222 + Math.floor(Math.random() * 100);
        // User data dir: use provided or create in portable cache
        let userDataDir = options.userDataDir;
        if (!userDataDir) {
            userDataDir = path.join(this.appRoot, 'cache', 'chrome-user-data');
            try {
                fs.mkdirSync(userDataDir, { recursive: true });
            }
            catch { }
        }
        this.tmpDir = userDataDir;
        // Launch browser
        const args = [
            `--remote-debugging-port=${port}`,
            `--user-data-dir=${userDataDir}`,
            '--no-first-run', '--no-default-browser-check',
            '--disable-infobars', '--disable-blink-features=AutomationControlled',
            '--new-window', '--disable-gpu', '--no-sandbox',
            targetUrl,
        ];
        this.log(`[CDP] 启动浏览器: ${browserPath} ${args.join(' ')}`);
        this.browserProcess = (0, child_process_1.spawn)(browserPath, args, { windowsHide: true });
        this.capturedVideos = [];
        this.sessions = new Set();
        const wsUrl = await getDebugUrl(port);
        this.log(`[CDP] 连接 WebSocket: ${wsUrl}`);
        this.ws = new SimpleWebSocket(wsUrl);
        return new Promise((resolve, reject) => {
            if (!this.ws)
                return reject(new Error('WebSocket not created'));
            this.ws.on('open', () => {
                this.sendCommand('Target.setDiscoverTargets', { discover: true });
                this.sendCommand('Target.setAutoAttach', {
                    autoAttach: true, waitForDebuggerOnStart: false, flatten: true,
                });
                resolve();
            });
            this.ws.on('message', (data) => {
                try {
                    const msg = JSON.parse(data);
                    if (msg.error) {
                        this.log(`[CDP Error] ${JSON.stringify(msg)}`);
                        return;
                    }
                    if (msg.id && msg.id >= 100) {
                        const r = msg.result;
                        if (r && Object.keys(r).length === 0) { /* skip keepalive */ }
                        else {
                            const raw = JSON.stringify(msg);
                            if (raw.length > 200) {
                                this.log(`[CDP] Command Response ${msg.id}: ${raw.slice(0, 200)}...`);
                            }
                        }
                    }
                    // Discover new targets
                    if (msg.method === 'Target.targetCreated' || msg.method === 'Target.targetInfoChanged') {
                        const target = msg.params.targetInfo;
                        if (target.type === 'page' && !target.attached) {
                            this.log(`[CDP] 发现 Target: ${target.type} - ${target.url}`);
                            this.sendCommand('Target.attachToTarget', {
                                targetId: target.targetId, flatten: true,
                            });
                        }
                    }
                    // Handle attached session
                    if (msg.method === 'Target.attachedToTarget') {
                        const sessionId = msg.params.sessionId;
                        const targetInfo = msg.params.targetInfo;
                        this.log(`[CDP] 已挂载会话: ${sessionId} (${targetInfo.type})`);
                        this.sessions.add(sessionId);
                        const enableNetwork = () => {
                            this.sendCommand('Network.enable', {}, sessionId);
                        };
                        enableNetwork();
                        const timer = setInterval(enableNetwork, 2000);
                        this.keepAliveTimers.push(timer);
                        this.sendCommand('Runtime.enable', {}, sessionId);
                    }
                    // Sniff requests
                    if (msg.method === 'Network.requestWillBeSent') {
                        const req = msg.params.request;
                        const url = req.url;
                        if (!url.match(/\.(js|css|png|jpg|gif|svg|woff|ttf|ico)(\?|$)/)) {
                            this.log(`[Request] ${req.method} : ${url}`);
                        }
                        if (url.includes('.m3u8') || url.includes('.mpd') ||
                            (url.match(/\.(mp4|webm|flv)(\?|$)/) && !url.includes('.png') && !url.includes('.jpg'))) {
                            this._addCapture(url, req.headers, 'request-url', targetUrl);
                            this.log(`[!!! CAPTURED] ${url}`);
                        }
                    }
                    // Sniff responses
                    if (msg.method === 'Network.responseReceived') {
                        const resp = msg.params.response;
                        const url = resp.url;
                        const mime = resp.mimeType || '';
                        const isMedia = mime.includes('video') || mime.includes('audio') ||
                            mime.includes('mpeg') || mime.includes('stream') ||
                            url.includes('.m3u8') || url.includes('.mpd');
                        if (isMedia) {
                            this.log(`[Response] ${mime} : ${url}`);
                            const lenStr = resp.headers['Content-Length'] || resp.headers['content-length'];
                            const len = lenStr ? parseInt(lenStr, 10) : null;
                            if (url.includes('.m3u8') || url.includes('.mpd')) {
                                this._addCapture(url, null, 'response-mime', targetUrl, len, 100);
                                this.log(`[!!! CAPTURED PRIORITY] ${url}`);
                            }
                            else if (url.match(/\.(mp4|webm|flv|mov|mkv)(\?|$)/) || mime.includes('mp4') || mime.includes('webm')) {
                                this._addCapture(url, null, 'response-mime', targetUrl, len, 80);
                                this.log(`[!!! CAPTURED VIDEO] ${url}`);
                            }
                            else {
                                this._addCapture(url, null, 'response-mime', targetUrl, len, 10);
                                this.log(`[!!! CAPTURED FRAGMENT] ${url}`);
                            }
                        }
                    }
                }
                catch { /* ignore parse errors */ }
            });
            this.ws.on('error', (e) => {
                this.log(`[CDP] WS error: ${e.message}`);
                reject(e);
            });
        });
    }
    /** Get all captured videos so far. */
    getCapturedVideos() {
        return this.capturedVideos || [];
    }
    /** Get the latest capture, optionally trying JS injection as fallback. */
    async getLatestCapture(injectJs = false) {
        if (this.capturedVideos && this.capturedVideos.length > 0) {
            const latest = this.capturedVideos[0];
            if (latest.waitingForCookie) {
                await new Promise(r => setTimeout(r, 500));
            }
            return latest;
        }
        if (injectJs && this.ws && this.sessions.size > 0) {
            return this._injectJsFallback();
        }
        return null;
    }
    /** Stop and cleanup browser + WebSocket. */
    stop() { this.cleanup(); }
    /** Convenience: sniff for a duration, calling onFound when a video is found. */
    async sniff(targetUrl, onFound, timeoutMs = 121000, options) {
        await this.start(targetUrl, undefined, options);
        return new Promise((resolve) => {
            const timer = setInterval(async () => {
                const latest = await this.getLatestCapture(true);
                if (latest) {
                    const found = onFound(latest);
                    if (found) {
                        clearInterval(timer);
                        this.stop();
                        resolve(latest);
                    }
                }
            }, 500);
            setTimeout(() => {
                clearInterval(timer);
                this.stop();
                resolve(null);
            }, timeoutMs);
        });
    }
    // ---- private ----
    sendCommand(method, params = {}, sessionId) {
        if (!this.ws)
            return;
        const id = this.nextId++;
        const msg = { id, method, params };
        if (sessionId)
            msg.sessionId = sessionId;
        this.ws.send(JSON.stringify(msg));
    }
    _addCapture(url, headers, source, targetUrl, contentLength = null, priority = 50) {
        if (this.capturedVideos.length > 0 && this.capturedVideos[0].priority > priority && this.capturedVideos[0].url !== url)
            return;
        if (this.capturedVideos.some(v => v.url === url))
            return;
        const result = {
            url,
            userDataDir: this.tmpDir,
            headers: headers ? {
                'Cookie': headers['Cookie'] || headers['cookie'],
                'Referer': headers['Referer'] || headers['referer'] || targetUrl,
                'User-Agent': headers['User-Agent'] || headers['user-agent'],
                'Origin': headers['Origin'] || headers['origin'],
            } : { 'Referer': targetUrl },
            cookieSource: 'cdp-sniffed',
            timestamp: Date.now(),
            filesize: contentLength,
            resolution: url.includes('1080') ? '1080p' : (url.includes('720') ? '720p' : 'unknown'),
            priority,
        };
        // Active cookie fetch if missing
        if (!result.headers.Cookie && this.ws && this.sessions.size > 0) {
            result.waitingForCookie = true;
            const sessionIds = Array.from(this.sessions);
            sessionIds.forEach(sessionId => {
                const id = this.nextId++;
                const listener = (data) => {
                    try {
                        const msg = JSON.parse(data);
                        if (msg.id === id && msg.result && msg.result.cookies) {
                            const cookies = msg.result.cookies;
                            if (cookies.length > 0) {
                                const cookieStr = cookies.map((c) => `${c.name}=${c.value}`).join('; ');
                                if (!result.headers.Cookie || cookieStr.length > result.headers.Cookie.length) {
                                    result.headers.Cookie = cookieStr;
                                    this.log(`[CDP] 主动获取 Cookie 成功: ${cookieStr.substring(0, 50)}...`);
                                    result.waitingForCookie = false;
                                }
                            }
                            const idx = this.ws.listeners.message.indexOf(listener);
                            if (idx > -1)
                                this.ws.listeners.message.splice(idx, 1);
                        }
                    }
                    catch { }
                };
                this.ws.on('message', listener);
                this.ws.send(JSON.stringify({
                    id, method: 'Network.getCookies',
                    params: { urls: [url, targetUrl] },
                    sessionId,
                }));
            });
            setTimeout(() => { result.waitingForCookie = false; }, 2000);
        }
        // Clean referer
        if (result.headers.Referer) {
            let ref = result.headers.Referer.trim();
            if (ref.includes(','))
                ref = ref.split(',')[0].trim();
            result.headers.Referer = ref;
        }
        if (!result.headers.Origin && result.headers.Referer) {
            try {
                result.headers.Origin = new url_1.URL(result.headers.Referer).origin;
            }
            catch { }
        }
        this.log(`[CDP] !!! 捕获成功 (${source}): ${url} Size:${contentLength}`);
        if (priority >= 90) {
            this.capturedVideos.unshift(result);
        }
        else {
            this.capturedVideos.push(result);
        }
    }
    async _injectJsFallback() {
        if (!this.ws)
            return null;
        this.log(`[CDP] JS 注入兜底... Sessions: ${this.sessions.size}`);
        const script = `(function(){try{var r=performance.getEntriesByType('resource');for(var i=r.length-1;i>=0;i--){var n=r[i].name;if(n.startsWith('blob:')||n.includes('.m3u8')||n.includes('.mpd')||n.match(/\.(mp4|webm|flv)(\?|$)/)){if(!n.includes('.png')&&!n.includes('.ico'))return n}}var v=document.querySelector('video');if(v){if(v.src&&(v.src.startsWith('http')||v.src.startsWith('blob:')))return JSON.stringify({url:v.src,cookie:document.cookie,referer:document.referrer});if(v.currentSrc&&(v.currentSrc.startsWith('http')||v.currentSrc.startsWith('blob:')))return JSON.stringify({url:v.currentSrc,cookie:document.cookie,referer:document.referrer});var s=v.querySelector('source');if(s&&s.src)return JSON.stringify({url:s.src,cookie:document.cookie,referer:document.referrer})}var ifs=document.querySelectorAll('iframe');for(var j=0;j<ifs.length;j++){if(ifs[j].src&&(ifs[j].src.includes('m3u8')||ifs[j].src.includes('mp4')))return JSON.stringify({url:ifs[j].src,cookie:document.cookie,referer:document.referrer})}if(window.hls&&window.hls.url)return JSON.stringify({url:window.hls.url,cookie:document.cookie,referer:document.referrer});var keys=Object.keys(window);for(var k=0;k<keys.length;k++){if(keys[k].includes('Info')||keys[k].includes('Data')||keys[k].includes('Player')||keys[k].includes('Config')){var v2=window[keys[k]];if(v2&&typeof v2==='object'){var m=JSON.stringify(v2).match(/https?:\\/\\/[^"']+\\.(mp4|m3u8|mpd)[^"']*/);if(m)return JSON.stringify({url:m[0].replace(/\\\\\\//g,'/'),cookie:document.cookie,referer:document.referrer})}}}return null}catch(e){return null}})()`;
        const sessions = Array.from(this.sessions);
        const promises = sessions.map(sessionId => {
            return new Promise(resolve => {
                const id = Date.now() + Math.floor(Math.random() * 10000);
                const listener = (data) => {
                    try {
                        const msg = JSON.parse(data);
                        if (msg.id === id && msg.result && msg.result.result) {
                            const val = msg.result.result.value;
                            if (val && typeof val === 'string') {
                                try {
                                    const obj = JSON.parse(val);
                                    if (obj.url) {
                                        let referer = obj.referer ? obj.referer.trim() : 'https://www.google.com/';
                                        if (referer.includes(','))
                                            referer = referer.split(',')[0].trim();
                                        let origin = '';
                                        try {
                                            origin = new url_1.URL(referer).origin;
                                        }
                                        catch { }
                                        resolve({
                                            url: obj.url,
                                            userDataDir: this.tmpDir,
                                            headers: {
                                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                                                'Referer': referer, 'Origin': origin,
                                                'Cookie': obj.cookie || '',
                                            },
                                            cookieSource: 'cdp-injected',
                                            timestamp: Date.now(),
                                            filesize: null, resolution: 'unknown', priority: 90,
                                        });
                                        return;
                                    }
                                }
                                catch { }
                                if (val.startsWith('http')) {
                                    resolve({
                                        url: val,
                                        userDataDir: this.tmpDir,
                                        headers: { 'Referer': 'https://www.google.com/' },
                                        cookieSource: 'cdp-injected',
                                        timestamp: Date.now(),
                                        filesize: null, resolution: 'unknown', priority: 90,
                                    });
                                    return;
                                }
                            }
                            resolve(null);
                        }
                    }
                    catch {
                        resolve(null);
                    }
                };
                this.ws.on('message', listener);
                this.sendCommand('Runtime.evaluate', { expression: script, returnByValue: true }, sessionId);
                setTimeout(() => resolve(null), 1000);
            });
        });
        try {
            const results = await Promise.all(promises);
            const found = results.find(r => r && r.url);
            if (found) {
                this.log(`[CDP] JS 注入成功提取: ${found.url}`);
                this.capturedVideos.unshift(found);
                return found;
            }
        }
        catch (e) {
            this.log(`[CDP] JS 注入失败: ${e.message}`);
        }
        return null;
    }
    cleanup() {
        if (this.ws) {
            try {
                this.ws.close();
            }
            catch { }
            this.ws = null;
        }
        if (this.keepAliveTimers) {
            this.keepAliveTimers.forEach(t => clearInterval(t));
            this.keepAliveTimers = [];
        }
        if (this.browserProcess) {
            const pid = this.browserProcess.pid;
            if (process.platform === 'win32' && pid) {
                try {
                    (0, child_process_1.execSync)(`taskkill /pid ${pid} /T /F`, {
                        stdio: 'ignore',
                        env: { ...process.env, QQQ_NO_TRACK: '1' },
                    });
                }
                catch { }
            }
            try {
                this.browserProcess.kill();
            }
            catch { }
            this.browserProcess = null;
        }
    }
}
CdpSniffer.customBrowserPath = null;
CdpSniffer.validateBrowserPath = validateBrowserPath;
exports.CdpSniffer = CdpSniffer;
//# sourceMappingURL=cdp-sniffer.js.map