"use strict";
// ============================================================================
// media-service.ts
// ffmpeg-backed thumbnail / transcode / probe, driven by the qz subsystem
// and cached by content signature so the same input + params never re-runs.
//
// ffmpeg resolution order:
//   1. process.env.QQQ_FFMPEG  (explicit override)
//   2. $QQQIDE_QDIR/components/ffmpeg/ffmpeg(.exe)
//   3. <appRoot>/engines/ffmpeg/ffmpeg(.exe)
//   4. system PATH (qz.which('ffmpeg'))
//
// ffprobe is resolved analogously; falls back to `ffmpeg -i` parsing if absent.
//
// All spawns go through QzSpawn so they get tree-kill + deadline + stall watchdog.
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaService = void 0;
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
class MediaService {
    constructor(appRoot, qz, cache, hash) {
        this.appRoot = appRoot;
        this.qz = qz;
        this.cache = cache;
        this.hash = hash;
        this._ffmpegPath = null;
        this._ffprobePath = null;
        this._resolved = false;
    }
    // -------------------------------------------------------------------------
    // binary resolution
    // -------------------------------------------------------------------------
    resolveBin(name) {
        const ext = process.platform === 'win32' ? '.exe' : '';
        const envKey = name === 'ffmpeg' ? 'QQQ_FFMPEG' : 'QQQ_FFPROBE';
        const overrideEnv = process.env[envKey];
        if (overrideEnv && fs.existsSync(overrideEnv)) {
            return overrideEnv;
        }
        const qdir = process.env.QQQIDE_QDIR;
        const tries = [];
        if (qdir) {
            tries.push(path.join(qdir, 'components', 'ffmpeg', name + ext));
        }
        tries.push(path.join(this.appRoot, 'engines', 'ffmpeg', name + ext));
        tries.push(path.join(this.appRoot, 'engines', name + ext));
        for (const p of tries) {
            try {
                if (fs.existsSync(p)) {
                    return p;
                }
            }
            catch { /* skip */ }
        }
        return this.qz.which(name);
    }
    ensureResolved() {
        if (this._resolved) {
            return;
        }
        this._ffmpegPath = this.resolveBin('ffmpeg');
        this._ffprobePath = this.resolveBin('ffprobe');
        this._resolved = true;
    }
    ffmpegPath() {
        this.ensureResolved();
        return { ffmpeg: this._ffmpegPath, ffprobe: this._ffprobePath };
    }
    // -------------------------------------------------------------------------
    // thumb
    // -------------------------------------------------------------------------
    async thumb(opts) {
        if (!opts || !opts.src) {
            return { ok: false, error: 'no_src' };
        }
        if (!fs.existsSync(opts.src)) {
            return { ok: false, error: 'src_missing' };
        }
        this.ensureResolved();
        if (!this._ffmpegPath) {
            return { ok: false, error: 'ffmpeg_not_found' };
        }
        const w = Math.max(16, Math.min(2048, opts.w || 256));
        const h = Math.max(16, Math.min(2048, opts.h || 256));
        const ts = Math.max(0, opts.ts != null ? opts.ts : 1.0);
        const format = opts.format || 'jpg';
        const quality = opts.quality != null ? opts.quality : 5;
        const fit = opts.fit || 'contain';
        // Cache key = content-sig + params
        const sig = (await this.hash.hashFile(opts.src, 'fast')).xxh64 || 'no-hash';
        const paramKey = `thumb|${w}x${h}|t=${ts}|f=${format}|q=${quality}|${fit}`;
        const fullKey = `${sig}|${paramKey}`;
        const dst = this.cache.bucketPath('thumb' + this.shortHash(fullKey), '.' + format);
        if (fs.existsSync(dst)) {
            return { ok: true, path: dst, cached: true };
        }
        // Build vf filter
        const vf = fit === 'cover'
            ? `scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h}`
            : `scale=${w}:${h}:force_original_aspect_ratio=decrease`;
        const args = [
            '-y', '-loglevel', 'error',
            '-ss', String(ts),
            '-i', opts.src,
            '-vframes', '1',
            '-vf', vf,
        ];
        if (format === 'jpg') {
            args.push('-q:v', String(quality));
        }
        else if (format === 'webp') {
            args.push('-quality', String(Math.max(1, Math.min(100, 90 - quality * 4))));
        }
        args.push(dst);
        const r = await this.qz.spawn({
            cmd: this._ffmpegPath,
            args,
            timeout: 30000,
            stallMs: 15000,
            captureOutput: true,
        });
        if (r.exitCode !== 0 || !fs.existsSync(dst)) {
            return {
                ok: false, error: 'ffmpeg_failed', stderr: r.stderr.slice(-500),
                path: dst,
            };
        }
        return { ok: true, path: dst, cached: false };
    }
    // -------------------------------------------------------------------------
    // transcode
    // -------------------------------------------------------------------------
    async transcode(opts) {
        if (!opts || !opts.src || !opts.format) {
            return { ok: false, error: 'no_src_or_format' };
        }
        if (!fs.existsSync(opts.src)) {
            return { ok: false, error: 'src_missing' };
        }
        this.ensureResolved();
        if (!this._ffmpegPath) {
            return { ok: false, error: 'ffmpeg_not_found' };
        }
        const sig = (await this.hash.hashFile(opts.src, 'fast')).xxh64 || 'no-hash';
        const paramKey = `tx|${opts.format}|${opts.vbr || ''}|${opts.abr || ''}|${(opts.extraArgs || []).join(',')}`;
        const fullKey = `${sig}|${paramKey}`;
        const dst = opts.dst || this.cache.bucketPath('tx' + this.shortHash(fullKey), '.' + opts.format);
        if (!opts.dst && fs.existsSync(dst)) {
            return { ok: true, path: dst, cached: true };
        }
        const args = ['-y', '-loglevel', 'error', '-i', opts.src];
        if (opts.vbr) {
            args.push('-b:v', opts.vbr);
        }
        if (opts.abr) {
            args.push('-b:a', opts.abr);
        }
        if (opts.extraArgs && opts.extraArgs.length) {
            args.push(...opts.extraArgs);
        }
        args.push(dst);
        const r = await this.qz.spawn({
            cmd: this._ffmpegPath,
            args,
            timeout: 30 * 60000,
            stallMs: 60000,
            captureOutput: true,
        });
        if (r.exitCode !== 0 || !fs.existsSync(dst)) {
            return { ok: false, error: 'ffmpeg_failed', stderr: r.stderr.slice(-500), path: dst };
        }
        return { ok: true, path: dst, cached: false };
    }
    // -------------------------------------------------------------------------
    // probe
    // -------------------------------------------------------------------------
    async probe(src) {
        if (!src || !fs.existsSync(src)) {
            return { ok: false, error: 'src_missing' };
        }
        this.ensureResolved();
        // Cache result keyed by sig
        const sig = (await this.hash.hashFile(src, 'fast')).xxh64 || 'no-hash';
        const cacheKey = `probe:${sig}`;
        const cached = await this.cache.get(cacheKey);
        if (cached) {
            return { ...cached, cached: true };
        }
        if (this._ffprobePath) {
            const args = [
                '-v', 'error',
                '-show_entries', 'stream=width,height,codec_name,duration:format=duration',
                '-of', 'json',
                src,
            ];
            const r = await this.qz.spawn({
                cmd: this._ffprobePath, args, timeout: 20000, stallMs: 10000, captureOutput: true,
            });
            if (r.exitCode === 0 && r.stdout) {
                try {
                    const j = JSON.parse(r.stdout);
                    const stream = (j.streams || [])[0] || {};
                    const duration = Number(stream.duration || (j.format && j.format.duration) || 0);
                    const out = {
                        ok: true,
                        width: Number(stream.width) || undefined,
                        height: Number(stream.height) || undefined,
                        codec: stream.codec_name || undefined,
                        duration: isFinite(duration) ? duration : undefined,
                    };
                    await this.cache.put(cacheKey, out, { ttlMs: 30 * 24 * 3600000 });
                    return out;
                }
                catch { /* fall through */ }
            }
        }
        // Fallback: parse `ffmpeg -i` stderr
        if (this._ffmpegPath) {
            const r = await this.qz.spawn({
                cmd: this._ffmpegPath, args: ['-i', src],
                timeout: 20000, stallMs: 10000, captureOutput: true,
            });
            const txt = r.stderr || '';
            const out = { ok: true };
            const m1 = txt.match(/Duration:\s*(\d+):(\d+):(\d+\.?\d*)/);
            if (m1) {
                out.duration = Number(m1[1]) * 3600 + Number(m1[2]) * 60 + Number(m1[3]);
            }
            const m2 = txt.match(/Video:\s*([^,]+),[^,]*,\s*(\d+)x(\d+)/);
            if (m2) {
                out.codec = m2[1].trim();
                out.width = Number(m2[2]);
                out.height = Number(m2[3]);
            }
            if (out.duration || out.width) {
                await this.cache.put(cacheKey, out, { ttlMs: 30 * 24 * 3600000 });
                return out;
            }
        }
        return { ok: false, error: 'probe_failed' };
    }
    // -------------------------------------------------------------------------
    shortHash(s) {
        // Stable 16-hex from string (sha256 first 16 hex)
        const crypto = require('crypto');
        return crypto.createHash('sha256').update(s).digest('hex').slice(0, 16);
    }
}
exports.MediaService = MediaService;
//# sourceMappingURL=media-service.js.map