"use strict";
// ============================================================================
// hash-service.ts
// File / buffer fingerprinting with mtime cache (h.js algorithm port).
//
//   - fast   : xxh64 (pure JS, branch-light) over up to 4 MB stream
//   - strong : sha256 via node crypto over full stream
//   - both   : compute fast first; then strong; both cached
//
// File-level cache key:  abspath + size + mtimeMs  (so edits invalidate)
// Stored at CacheStore.hashDbDir()/<sha256(key)>.json
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HashService = void 0;
const fs = __importStar(require("fs"));
const crypto = __importStar(require("crypto"));
class HashService {
    constructor(cache) {
        this.cache = cache;
    }
    static rotl64(x, r) {
        return ((x << BigInt(r)) | (x >> BigInt(64 - r))) & HashService.MASK64;
    }
    static round(acc, input) {
        let a = (acc + ((input & HashService.MASK64) * HashService.PRIME64_2)) & HashService.MASK64;
        a = HashService.rotl64(a, 31);
        return (a * HashService.PRIME64_1) & HashService.MASK64;
    }
    static mergeRound(acc, val) {
        const v = HashService.round(0n, val);
        let a = acc ^ v;
        a = (a * HashService.PRIME64_1 + HashService.PRIME64_4) & HashService.MASK64;
        return a;
    }
    /** xxh64 of an entire Buffer (seed = 0). */
    static xxh64(buf, seed = 0n) {
        const len = buf.length;
        let h;
        let p = 0;
        if (len >= 32) {
            let v1 = (seed + HashService.PRIME64_1 + HashService.PRIME64_2) & HashService.MASK64;
            let v2 = (seed + HashService.PRIME64_2) & HashService.MASK64;
            let v3 = seed;
            let v4 = (seed - HashService.PRIME64_1) & HashService.MASK64;
            while (p + 32 <= len) {
                v1 = HashService.round(v1, buf.readBigUInt64LE(p));
                p += 8;
                v2 = HashService.round(v2, buf.readBigUInt64LE(p));
                p += 8;
                v3 = HashService.round(v3, buf.readBigUInt64LE(p));
                p += 8;
                v4 = HashService.round(v4, buf.readBigUInt64LE(p));
                p += 8;
            }
            h = (HashService.rotl64(v1, 1) + HashService.rotl64(v2, 7)
                + HashService.rotl64(v3, 12) + HashService.rotl64(v4, 18)) & HashService.MASK64;
            h = HashService.mergeRound(h, v1);
            h = HashService.mergeRound(h, v2);
            h = HashService.mergeRound(h, v3);
            h = HashService.mergeRound(h, v4);
        }
        else {
            h = (seed + HashService.PRIME64_5) & HashService.MASK64;
        }
        h = (h + BigInt(len)) & HashService.MASK64;
        while (p + 8 <= len) {
            const k1 = HashService.round(0n, buf.readBigUInt64LE(p));
            h ^= k1;
            h = ((HashService.rotl64(h, 27) * HashService.PRIME64_1) + HashService.PRIME64_4) & HashService.MASK64;
            p += 8;
        }
        if (p + 4 <= len) {
            h ^= ((BigInt(buf.readUInt32LE(p))) * HashService.PRIME64_1) & HashService.MASK64;
            h = ((HashService.rotl64(h, 23) * HashService.PRIME64_2) + HashService.PRIME64_3) & HashService.MASK64;
            p += 4;
        }
        while (p < len) {
            h ^= (BigInt(buf[p]) * HashService.PRIME64_5) & HashService.MASK64;
            h = (HashService.rotl64(h, 11) * HashService.PRIME64_1) & HashService.MASK64;
            p += 1;
        }
        h ^= h >> 33n;
        h = (h * HashService.PRIME64_2) & HashService.MASK64;
        h ^= h >> 29n;
        h = (h * HashService.PRIME64_3) & HashService.MASK64;
        h ^= h >> 32n;
        return h.toString(16).padStart(16, '0');
    }
    // -------------------------------------------------------------------------
    // Buffer hashing
    // -------------------------------------------------------------------------
    hashBuffer(buf, mode = 'fast') {
        const r = { size: buf.length };
        if (mode === 'fast' || mode === 'both') {
            r.xxh64 = HashService.xxh64(buf);
        }
        if (mode === 'strong' || mode === 'both') {
            r.sha256 = crypto.createHash('sha256').update(buf).digest('hex');
        }
        return r;
    }
    // -------------------------------------------------------------------------
    // File hashing (with mtime cache)
    // -------------------------------------------------------------------------
    cacheKey(absPath, size, mtimeMs) {
        return `hash:${absPath}|${size}|${Math.floor(mtimeMs)}`;
    }
    async hashFile(absPath, mode = 'fast') {
        const stat = await fs.promises.stat(absPath);
        const key = this.cacheKey(absPath, stat.size, stat.mtimeMs);
        const cached = await this.cache.get(key);
        if (cached) {
            const need = (mode === 'fast' && cached.xxh64)
                || (mode === 'strong' && cached.sha256)
                || (mode === 'both' && cached.xxh64 && cached.sha256);
            if (need) {
                return cached;
            }
        }
        // Stream-compute whichever the cache is missing.
        const want = {
            fast: (mode === 'fast' || mode === 'both') && !(cached && cached.xxh64),
            strong: (mode === 'strong' || mode === 'both') && !(cached && cached.sha256),
        };
        const out = { ...(cached || { size: stat.size }), size: stat.size, mtimeMs: stat.mtimeMs };
        if (want.strong || want.fast) {
            // For strong, use streaming sha256 (no memory cap).
            // For fast (xxh64), our current impl needs a full Buffer; cap at 64 MB.
            // For files larger than 64 MB, use sha256 only as the "fast" stand-in
            // (it's still hardware-accelerated and ~250 MB/s on modern CPUs).
            const FAST_CAP = 64 * 1024 * 1024;
            const useFullBuf = want.fast && stat.size <= FAST_CAP;
            if (useFullBuf) {
                const buf = await fs.promises.readFile(absPath);
                out.xxh64 = HashService.xxh64(buf);
                if (want.strong) {
                    out.sha256 = crypto.createHash('sha256').update(buf).digest('hex');
                }
            }
            else {
                // stream sha256; xxh64 unavailable for huge files
                const h = crypto.createHash('sha256');
                const stream = fs.createReadStream(absPath);
                await new Promise((resolve, reject) => {
                    stream.on('data', d => h.update(d));
                    stream.on('end', () => resolve());
                    stream.on('error', reject);
                });
                if (want.strong) {
                    out.sha256 = h.digest('hex');
                }
                if (want.fast && !out.xxh64) {
                    // Fallback: first 12 hex of sha256 as a non-crypto-grade fast id
                    out.xxh64 = (out.sha256 || h.digest('hex')).slice(0, 16);
                }
            }
        }
        // Write back composite
        try {
            await this.cache.put(key, out);
        }
        catch { /* ignore */ }
        return out;
    }
}
// -------------------------------------------------------------------------
// xxh64 (pure JS, big-int based; matches h.js output)
// -------------------------------------------------------------------------
HashService.PRIME64_1 = 0x9e3779b185ebca87n;
HashService.PRIME64_2 = 0xc2b2ae3d27d4eb4fn;
HashService.PRIME64_3 = 0x165667b19e3779f9n;
HashService.PRIME64_4 = 0x85ebca77c2b2ae63n;
HashService.PRIME64_5 = 0x27d4eb2f165667c5n;
HashService.MASK64 = 0xffffffffffffffffn;
exports.HashService = HashService;
//# sourceMappingURL=hash-service.js.map