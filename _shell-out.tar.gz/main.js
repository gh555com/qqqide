"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// shell/component-checker.ts
function _platformKey() {
  const p = process.platform;
  const a = process.arch === "x64" ? "x64" : "arm64";
  if (p === "win32")
    return "win32-x64";
  if (p === "darwin")
    return a === "arm64" ? "darwin-arm64" : "darwin-x64";
  return "linux-x64";
}
function _readJson(filePath, fallback) {
  try {
    return JSON.parse(fs4.readFileSync(filePath, "utf8"));
  } catch {
    return fallback;
  }
}
function _writeJson(filePath, obj) {
  try {
    fs4.mkdirSync(path4.dirname(filePath), { recursive: true });
  } catch {
  }
  const tmp = filePath + ".tmp";
  try {
    fs4.writeFileSync(tmp, JSON.stringify(obj, null, 2), "utf8");
  } catch {
    return;
  }
  try {
    fs4.renameSync(tmp, filePath);
  } catch {
    try {
      fs4.unlinkSync(tmp);
    } catch {
    }
  }
}
function _cmdOk(binPath, args) {
  try {
    const r = (0, import_child_process2.spawnSync)(binPath, args, {
      encoding: "utf8",
      timeout: 15e3,
      windowsHide: true
    });
    return r.status === 0;
  } catch {
    return false;
  }
}
function _enginesRoot(portableRoot) {
  const resApp = path4.join(portableRoot, "resources", "app");
  return fs4.existsSync(path4.join(resApp, "engines")) ? resApp : portableRoot;
}
function _loadManifest(portableRoot) {
  if (_manifestCache && _manifestRoot === portableRoot)
    return _manifestCache;
  const engRoot = _enginesRoot(portableRoot);
  const p = path4.join(engRoot, "engines", "manifest.json");
  const m = _readJson(p, null);
  if (m && m._version >= 3) {
    _manifestCache = m;
    _manifestRoot = portableRoot;
    return m;
  }
  return null;
}
function _getDef(portableRoot, name) {
  const m = _loadManifest(portableRoot);
  return (m == null ? void 0 : m.components[name]) || null;
}
function _binRel(def) {
  return process.platform === "win32" ? def.bin_win || def.bin_unix || null : def.bin_unix || def.bin_win || null;
}
function _binPath(portableRoot, def) {
  const br = _binRel(def);
  if (!br)
    return null;
  const engRoot = _enginesRoot(portableRoot);
  const dir = def.install_to ? path4.join(engRoot, "engines", def.install_to) : path4.join(engRoot, "engines");
  return path4.join(dir, br);
}
function _dlLogPath(portableRoot) {
  const engRoot = _enginesRoot(portableRoot);
  return path4.join(engRoot, "engines", ".downloads.json");
}
function _isInCooldown(portableRoot, name, manifest) {
  const cooldownMs = manifest.download_cooldown_ms || 3e5;
  const log = _readJson(_dlLogPath(portableRoot), {});
  const entry = log[name];
  if (!entry)
    return false;
  const now = Date.now();
  if (entry.last_success > 0)
    return true;
  if (entry.last_fail > 0 && now - entry.last_fail < cooldownMs)
    return true;
  return false;
}
function _recordDlSuccess(portableRoot, name) {
  const log = _readJson(_dlLogPath(portableRoot), {});
  log[name] = { last_fail: 0, last_success: Date.now() };
  _writeJson(_dlLogPath(portableRoot), log);
}
function _recordDlFail(portableRoot, name) {
  const log = _readJson(_dlLogPath(portableRoot), {});
  if (!log[name])
    log[name] = { last_fail: 0, last_success: 0 };
  log[name].last_fail = Date.now();
  _writeJson(_dlLogPath(portableRoot), log);
}
function checkRank0Components(portableRoot) {
  if (_checked)
    return;
  _checked = true;
  const manifest = _loadManifest(portableRoot);
  if (!manifest) {
    console.log("[components] manifest.json not found or invalid, skipping");
    return;
  }
  const engRoot = _enginesRoot(portableRoot);
  const versPath2 = path4.join(engRoot, "engines", ".versions.json");
  const versions = _readJson(versPath2, {});
  _checkAll(portableRoot, manifest, versions, versPath2).then(() => {
    _verifyAllBundled(portableRoot, manifest, versions, versPath2);
  }).catch((e) => {
    console.log("[components] rank0 check error:", e.message || e);
  });
}
async function _checkAll(portableRoot, manifest, versions, versPath2) {
  const pk = _platformKey();
  for (const name of manifest.rank0) {
    const def = manifest.components[name];
    if (!def) {
      console.log("[components] " + name + ": not in manifest");
      continue;
    }
    if (def.bundled) {
      const bp = _binPath(portableRoot, def);
      if (bp && fs4.existsSync(bp))
        continue;
      console.log("[components] " + name + ": bundled but missing on disk, downloading...");
    }
    try {
      await _ensureOne(portableRoot, name, def, pk, versions, manifest);
    } catch (e) {
      console.log("[components] " + name + ": FAILED \u2014 " + (e.message || e));
    }
  }
  _writeJson(versPath2, versions);
}
function _verifyComponent(portableRoot, name, def) {
  const bp = _binPath(portableRoot, def);
  if (!bp || !fs4.existsSync(bp))
    return { status: "broken", detail: "binary missing" };
  const verify = def.verify;
  const smokeArgs = (verify == null ? void 0 : verify.smoke) || def.verify_args;
  if (!_cmdOk(bp, smokeArgs))
    return { status: "broken", detail: "smoke test failed" };
  const selfHealArgs = verify == null ? void 0 : verify.self_heal;
  if (selfHealArgs && !_cmdOk(bp, selfHealArgs)) {
    return { status: "degraded", detail: "self-heal failed \u2014 binary runs but cannot self-repair" };
  }
  return { status: "ok", detail: "" };
}
async function _verifyAllBundled(portableRoot, manifest, versions, versPath2) {
  const pk = _platformKey();
  for (const name of manifest.rank0) {
    const def = manifest.components[name];
    if (!(def == null ? void 0 : def.bundled))
      continue;
    const r = _verifyComponent(portableRoot, name, def);
    if (r.status === "ok")
      continue;
    console.log(`[components] ${name}: INTEGRITY ${r.status.toUpperCase()} \u2014 ${r.detail}`);
    if (r.status === "degraded") {
      const repaired = await _tryRepairDegraded(portableRoot, name, def);
      if (repaired) {
        console.log(`[components] ${name}: self-healed \u2713`);
        continue;
      }
      console.log(`[components] ${name}: repair failed, falling back to CDN recovery`);
    }
    delete versions[name];
    const dlLog = _readJson(_dlLogPath(portableRoot), {});
    if (dlLog[name])
      dlLog[name].last_success = 0;
    _writeJson(_dlLogPath(portableRoot), dlLog);
    try {
      await _ensureOne(portableRoot, name, def, pk, versions, manifest);
      _writeJson(versPath2, versions);
      console.log(`[components] ${name}: CDN recovery \u2713`);
    } catch (e) {
      console.log(`[components] ${name}: CDN recovery FAILED \u2014 ${e.message || e}`);
    }
  }
}
async function _tryRepairDegraded(portableRoot, name, def) {
  if (name === "python") {
    const bp = _binPath(portableRoot, def);
    if (!bp)
      return false;
    const targetDir = path4.dirname(bp);
    try {
      await _bootstrapPip(targetDir);
      const verify2 = def.verify;
      if ((verify2 == null ? void 0 : verify2.self_heal) && _cmdOk(bp, verify2.self_heal))
        return true;
    } catch {
    }
    try {
      await _ensureCorePyds(targetDir);
      await _bootstrapPip(targetDir);
    } catch {
    }
    const verify = def.verify;
    return !!((verify == null ? void 0 : verify.self_heal) && _cmdOk(bp, verify.self_heal));
  }
  return false;
}
async function _ensureOne(portableRoot, name, def, pk, versions, manifest) {
  const engRoot = _enginesRoot(portableRoot);
  const enginesDir = path4.join(engRoot, "engines");
  const binRel = _binRel(def);
  if (!binRel) {
    console.log("[components] " + name + ": no binary for this platform");
    return;
  }
  const targetDir = def.install_to ? path4.join(enginesDir, def.install_to) : enginesDir;
  const binPath = path4.join(targetDir, binRel);
  const verifyArgs = def.verify_args || ["--version"];
  if (fs4.existsSync(binPath) && _cmdOk(binPath, verifyArgs)) {
    const old = versions[name];
    if (old && old.version !== def.version) {
      console.log("[components] " + name + ": version changed " + old.version + " \u2192 " + def.version + ", reinstalling");
      _safeRmDir(targetDir);
    } else if (old && old.install_to !== def.install_to) {
      console.log("[components] " + name + ": migrating from " + old.install_to + " \u2192 " + def.install_to);
      _migrateDir(enginesDir, old.install_to, def.install_to, name);
      versions[name] = { version: def.version, install_to: def.install_to, verified_at: Date.now() };
      return;
    } else {
      versions[name] = { version: def.version, install_to: def.install_to, verified_at: Date.now() };
      return;
    }
  }
  const oldRec = versions[name];
  if (oldRec && oldRec.install_to !== def.install_to && oldRec.install_to) {
    const oldDir = path4.join(enginesDir, oldRec.install_to);
    const oldBin = path4.join(oldDir, binRel);
    if (fs4.existsSync(oldBin) && _cmdOk(oldBin, verifyArgs)) {
      _migrateDir(enginesDir, oldRec.install_to, def.install_to, name);
      versions[name] = { version: def.version, install_to: def.install_to, verified_at: Date.now() };
      return;
    }
  }
  if (_isInCooldown(portableRoot, name, manifest)) {
    console.log("[components] " + name + ": in cooldown, skipping download");
    return;
  }
  console.log("[components] " + name + ": not found, downloading...");
  const srcs = def.srcs[pk] || [];
  if (srcs.length === 0) {
    console.log("[components] " + name + ": no sources for platform " + pk);
    return;
  }
  let ok = false;
  for (const src of srcs) {
    try {
      await _downloadAndInstall(name, src, targetDir, binPath, verifyArgs, portableRoot);
      ok = true;
      break;
    } catch (e) {
      console.log("[components] " + name + " src failed: " + (e.message || e));
    }
  }
  if (ok) {
    _recordDlSuccess(portableRoot, name);
    versions[name] = { version: def.version, install_to: def.install_to, verified_at: Date.now() };
    _writeJson(versPath, versions);
  } else {
    _recordDlFail(portableRoot, name);
    console.log("[components] " + name + ": all sources exhausted");
  }
}
async function _downloadAndInstall(name, src, targetDir, binPath, verifyArgs, portableRoot) {
  const dlDir = path4.join(portableRoot, "Data");
  const ext = src.kind === "tar.gz" ? ".tar.gz" : ".zip";
  const dlFile = path4.join(dlDir, "_dl_" + name + ext);
  console.log("[components] " + name + ": downloading " + src.url.slice(0, 80) + " ...");
  await _download(src.url, dlFile, 12e4);
  const size = fs4.statSync(dlFile).size;
  if (size < 512)
    throw new Error("Download too small: " + size + " bytes");
  console.log("[components] " + name + ": " + (size / 1024 / 1024).toFixed(1) + "MB");
  _safeRmDir(targetDir);
  fs4.mkdirSync(targetDir, { recursive: true });
  if (src.kind === "binary") {
    const dest = path4.join(targetDir, path4.basename(binPath));
    fs4.copyFileSync(dlFile, dest);
    try {
      fs4.chmodSync(dest, 493);
    } catch {
    }
  } else if (src.kind === "zip") {
    if (process.platform === "win32") {
      (0, import_child_process2.execSync)(
        `powershell -NoProfile -Command "Expand-Archive -Path '${dlFile}' -DestinationPath '${targetDir}' -Force"`,
        { windowsHide: true, timeout: 12e4 }
      );
    } else {
      (0, import_child_process2.execSync)(`unzip -o "${dlFile}" -d "${targetDir}"`, { timeout: 12e4 });
    }
  } else if (src.kind === "tar.gz") {
    (0, import_child_process2.execSync)(`tar -xzf "${dlFile}" -C "${targetDir}" --strip-components=1`, { timeout: 12e4 });
  }
  try {
    fs4.unlinkSync(dlFile);
  } catch {
  }
  if (name === "python" && process.platform === "win32") {
    _patchPythonPth(targetDir);
    _ensureCorePyds(targetDir).catch((e) => {
      console.log("[components] python pyd supplement: " + (e.message || e));
    });
    _bootstrapPip(targetDir).catch((e) => {
      console.log("[components] python pip bootstrap: " + (e.message || e));
    });
  }
  if (!fs4.existsSync(binPath)) {
    const found = _findBinParent(targetDir, path4.basename(binPath));
    if (found) {
      _flattenDir(found, targetDir);
    }
  }
  if (!fs4.existsSync(binPath))
    throw new Error("Binary not found after extract: " + binPath);
  if (!_cmdOk(binPath, verifyArgs))
    throw new Error("Verification failed");
  console.log("[components] " + name + ": installed \u2713");
}
function _patchPythonPth(dir) {
  try {
    for (const f of fs4.readdirSync(dir).filter((x) => x.endsWith("._pth"))) {
      const p = path4.join(dir, f);
      let c = fs4.readFileSync(p, "utf8");
      c = c.replace("#import site", "import site");
      const lines = c.split("\n").filter(Boolean);
      if (!lines.some((l) => l.trim() === "./Lib" || l.trim() === "Lib"))
        lines.unshift("./Lib");
      if (!lines.some((l) => l.includes("site-packages")))
        lines.push("./site-packages");
      fs4.writeFileSync(p, lines.join("\n"), "utf8");
    }
  } catch (e) {
    console.log("[components] python _pth patch warning: " + (e.message || e));
  }
}
async function _ensureCorePyds(targetDir) {
  if (fs4.existsSync(path4.join(targetDir, "pyexpat.pyd")))
    return;
  console.log("[components] python: missing core .pyd files, supplementing from python.org...");
  const https7 = require("https");
  const dlDir = path4.join(targetDir, "..", "_pyd_supplement");
  const zipPath = path4.join(dlDir, "embed.zip");
  try {
    fs4.mkdirSync(dlDir, { recursive: true });
  } catch {
  }
  await new Promise((resolve3, reject) => {
    const u = new URL(PYTHON_EMBED_URL);
    const req = https7.get({
      hostname: u.hostname,
      port: 443,
      path: u.pathname,
      timeout: 6e4,
      headers: { "User-Agent": "Mozilla/5.0 (qqqide)" }
    }, (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error("HTTP " + res.statusCode));
      }
      const file = fs4.createWriteStream(zipPath);
      res.pipe(file);
      file.on("finish", () => {
        file.close();
        resolve3();
      });
      file.on("error", (e) => reject(e));
      res.on("error", (e) => reject(e));
    });
    req.on("error", (e) => reject(e));
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
  });
  const pyBin = path4.join(targetDir, "python.exe");
  const extractScript = `
import zipfile, os
z = zipfile.ZipFile(r'${zipPath.replace(/\\/g, "\\\\")}')
present = set(os.listdir(r'${targetDir.replace(/\\/g, "\\\\")}'))
missing = [n for n in z.namelist() if n.endswith(('.pyd', '.dll')) and n not in present]
for n in missing:
    z.extract(n, r'${targetDir.replace(/\\/g, "\\\\")}')
    print('+', n)
print('done:', len(missing))
`.trim();
  try {
    const r = (0, import_child_process2.execSync)(
      `"${pyBin}" -c "${extractScript.replace(/"/g, '\\"')}"`,
      { encoding: "utf8", timeout: 3e4, windowsHide: true }
    );
    console.log("[components] python pyd supplement: " + r.trim().split("\n").pop());
  } catch (e) {
    console.log("[components] python pyd supplement failed: " + (e.message || e));
  }
  try {
    fs4.unlinkSync(zipPath);
    fs4.rmdirSync(dlDir);
  } catch {
  }
}
async function _bootstrapPip(targetDir) {
  const pyBin = path4.join(targetDir, "python.exe");
  try {
    (0, import_child_process2.execSync)(`"${pyBin}" -m pip --version`, { encoding: "utf8", timeout: 15e3, windowsHide: true });
    return;
  } catch {
  }
  console.log("[components] python: pip not found, bootstrapping...");
  const getPipPath = path4.join(targetDir, "get-pip.py");
  const https7 = require("https");
  await new Promise((resolve3, reject) => {
    const u = new URL("https://bootstrap.pypa.io/pip/3.8/get-pip.py");
    const req = https7.get({
      hostname: u.hostname,
      port: 443,
      path: u.pathname,
      timeout: 3e4,
      headers: { "User-Agent": "Mozilla/5.0 (qqqide)" }
    }, (res) => {
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (d) => {
        data += d;
      });
      res.on("end", () => {
        if (res.statusCode === 200 && data.length > 1e3) {
          try {
            fs4.writeFileSync(getPipPath, data, "utf8");
            resolve3();
          } catch (e) {
            reject(e);
          }
        } else {
          reject(new Error("HTTP " + res.statusCode));
        }
      });
      res.on("error", (e) => reject(e));
    });
    req.on("error", (e) => reject(e));
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
  });
  try {
    (0, import_child_process2.execSync)(
      `"${pyBin}" "${getPipPath}" --no-warn-script-location`,
      { encoding: "utf8", timeout: 12e4, windowsHide: true }
    );
    console.log("[components] python pip bootstrapped \u2713");
  } catch (e) {
    console.log("[components] python pip bootstrap failed: " + (e.message || e));
  } finally {
    try {
      fs4.unlinkSync(getPipPath);
    } catch {
    }
  }
}
function _findBinParent(dir, binName) {
  function _walk(d, depth) {
    if (depth > 4)
      return null;
    try {
      for (const f of fs4.readdirSync(d)) {
        const fp = path4.join(d, f);
        if (f === binName)
          return d;
        try {
          if (fs4.statSync(fp).isDirectory()) {
            const r = _walk(fp, depth + 1);
            if (r)
              return r;
          }
        } catch {
        }
      }
    } catch {
    }
    return null;
  }
  return _walk(dir, 0);
}
function _flattenDir(srcDir, dstDir) {
  const tmpDir = dstDir + "_flatten_tmp";
  fs4.renameSync(srcDir, tmpDir);
  for (const f of fs4.readdirSync(tmpDir)) {
    const sp = path4.join(tmpDir, f);
    const dp = path4.join(dstDir, f);
    try {
      fs4.renameSync(sp, dp);
    } catch {
      try {
        fs4.rmSync(dp, { recursive: true, force: true });
        fs4.renameSync(sp, dp);
      } catch {
      }
    }
  }
  fs4.rmdirSync(tmpDir);
}
function _migrateDir(enginesDir, oldSub, newSub, name) {
  if (!oldSub || oldSub === newSub)
    return;
  const oldDir = path4.join(enginesDir, oldSub);
  const newDir = path4.join(enginesDir, newSub);
  if (!fs4.existsSync(oldDir))
    return;
  try {
    fs4.mkdirSync(path4.dirname(newDir), { recursive: true });
    if (fs4.existsSync(newDir)) {
      for (const f of fs4.readdirSync(oldDir)) {
        const sp = path4.join(oldDir, f);
        const dp = path4.join(newDir, f);
        try {
          fs4.renameSync(sp, dp);
        } catch {
        }
      }
      try {
        if (fs4.readdirSync(oldDir).length === 0)
          fs4.rmdirSync(oldDir);
      } catch {
      }
    } else {
      fs4.renameSync(oldDir, newDir);
    }
    console.log("[components] " + name + ": migrated " + oldSub + " \u2192 " + newSub);
  } catch (e) {
    console.log("[components] " + name + ": migration failed: " + (e.message || e));
  }
}
function _safeRmDir(dir) {
  try {
    fs4.rmSync(dir, { recursive: true, force: true });
  } catch {
  }
}
function _download(url, dest, timeoutMs) {
  const https7 = require("https");
  const http8 = require("http");
  const doReq = (targetUrl, redirects) => {
    if (redirects > 5)
      return Promise.reject(new Error("Too many redirects"));
    return new Promise((resolve3, reject) => {
      const u = new URL(targetUrl);
      const transport = u.protocol === "http:" ? http8 : https7;
      const req = transport.get({
        hostname: u.hostname,
        port: u.port || (u.protocol === "http:" ? 80 : 443),
        path: u.pathname + u.search,
        timeout: timeoutMs,
        headers: { "User-Agent": "Mozilla/5.0 (qqqide)" }
      }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode || 0)) {
          res.resume();
          const loc = res.headers.location || "";
          doReq(new URL(loc, targetUrl).href, redirects + 1).then(resolve3, reject);
          return;
        }
        if (res.statusCode !== 200) {
          res.resume();
          return reject(new Error("HTTP " + res.statusCode));
        }
        const file = fs4.createWriteStream(dest);
        res.pipe(file);
        file.on("finish", () => {
          file.close();
          resolve3();
        });
        file.on("error", (e) => {
          try {
            fs4.unlinkSync(dest);
          } catch {
          }
          reject(e);
        });
        res.on("error", (e) => {
          try {
            fs4.unlinkSync(dest);
          } catch {
          }
          reject(e);
        });
      });
      req.on("error", (e) => reject(new Error(e.message || "network")));
      req.on("timeout", () => {
        req.destroy();
        reject(new Error("timeout"));
      });
    });
  };
  return doReq(url, 0);
}
function getComponentBin(portableRoot, name) {
  const def = _getDef(portableRoot, name);
  if (!def)
    return null;
  const bp = _binPath(portableRoot, def);
  return bp && fs4.existsSync(bp) ? bp : null;
}
function getComponentDir(portableRoot, name) {
  const def = _getDef(portableRoot, name);
  if (!def)
    return null;
  const bp = _binPath(portableRoot, def);
  return bp && fs4.existsSync(bp) ? path4.dirname(bp) : null;
}
var path4, fs4, import_child_process2, _manifestCache, _manifestRoot, _checked, PYTHON_EMBED_URL;
var init_component_checker = __esm({
  "shell/component-checker.ts"() {
    "use strict";
    path4 = __toESM(require("path"));
    fs4 = __toESM(require("fs"));
    import_child_process2 = require("child_process");
    _manifestCache = null;
    _manifestRoot = "";
    _checked = false;
    PYTHON_EMBED_URL = "https://www.python.org/ftp/python/3.8.10/python-3.8.10-embed-amd64.zip";
  }
});

// shell/node-broker.ts
function _tryLoadKoffi() {
  if (_koffiTried)
    return _koffiModule;
  _koffiTried = true;
  try {
    _koffiModule = require("koffi");
    console.log("[node-broker] koffi loaded \u2014 Win32 FFI available");
    return _koffiModule;
  } catch {
    console.log("[node-broker] koffi not installed. Run: npm install koffi");
    return null;
  }
}
function isNodeBrokerAvailable() {
  return process.platform === "win32" && _tryLoadKoffi() !== null;
}
function renameDevToolsViaNodeBroker(mainWin, projName) {
  if (process.platform !== "win32")
    return false;
  const koffi = _tryLoadKoffi();
  if (!koffi)
    return false;
  let mainHwnd = 0;
  try {
    const hbuf = mainWin.getNativeWindowHandle();
    if (hbuf && hbuf.length >= 4) {
      mainHwnd = hbuf.length === 8 ? Number(hbuf.readBigUInt64LE(0)) : hbuf.readUInt32LE(0);
    }
  } catch {
  }
  if (!mainHwnd) {
    console.log("[node-broker] Cannot get main window HWND");
    return false;
  }
  const title = "\u300CU0001f527\u300D" + projName;
  const GW_OWNER = 4;
  try {
    const user32 = koffi.load("user32.dll");
    const EnumWindows = user32.func("int EnumWindows(void *lpEnumFunc, int64 lParam)");
    const GetWindowTextW = user32.func("int GetWindowTextW(void *hwnd, _Out_ char16 *buf, int nMaxCount)");
    const GetWindow = user32.func("void *GetWindow(void *hwnd, int uCmd)");
    const SetWindowTextW = user32.func("int SetWindowTextW(void *hwnd, const char16 *lpString)");
    const foundHwnds = [];
    const cb = koffi.callback("int (void *hwnd, int64 lp)", (hwnd, _lp) => {
      try {
        const buf = Buffer.alloc(1024);
        GetWindowTextW(hwnd, buf, 512);
        const winTitle = buf.toString("utf16le").replace(/\0[\s\S]*$/, "");
        if (!winTitle)
          return 1;
        if (winTitle.startsWith("Developer Tools") || winTitle.startsWith("\u300C\u{1F527}\u300D")) {
          let owner = null;
          try {
            owner = GetWindow(hwnd, GW_OWNER);
          } catch {
          }
          if (owner && Number(owner) !== 0 && Number(owner) === mainHwnd) {
            foundHwnds.push(Number(hwnd));
          } else if (!owner || Number(owner) === 0) {
            foundHwnds.push(Number(hwnd));
          }
        }
      } catch {
      }
      return 1;
    });
    EnumWindows(cb, 0);
    if (foundHwnds.length === 0) {
      console.log("[node-broker] No DevTools window found for HWND=" + mainHwnd);
      return false;
    }
    let renamed = 0;
    for (const hwnd of foundHwnds) {
      const ret = SetWindowTextW(koffi.as(hwnd, "void *"), title);
      if (ret)
        renamed++;
    }
    if (renamed > 0) {
      console.log("[node-broker] OK: renamed=" + renamed + " title=" + title);
      return true;
    }
    console.log("[node-broker] SetWindowTextW failed for all " + foundHwnds.length + " windows");
    return false;
  } catch (e) {
    console.log("[node-broker] ERROR:", e.message || e);
    return false;
  }
}
var _koffiModule, _koffiTried;
var init_node_broker = __esm({
  "shell/node-broker.ts"() {
    "use strict";
    _koffiModule = null;
    _koffiTried = false;
  }
});

// shell/py-broker.ts
var py_broker_exports = {};
__export(py_broker_exports, {
  getPythonDir: () => getPythonDir,
  isPyBrokerReady: () => isPyBrokerReady,
  renameDevToolsViaBroker: () => renameDevToolsViaBroker,
  resolvePythonPath: () => resolvePythonPath,
  startPyBroker: () => startPyBroker,
  stopPyBroker: () => stopPyBroker
});
function startPyBroker(portableRoot) {
  if (_proc)
    return;
  const pyExe = getComponentBin(portableRoot, "python");
  if (!pyExe) {
    console.log("[py-broker] Python not installed. DevTools rename disabled. Python will auto-install as rank0 component on next boot.");
    return;
  }
  const scriptPath = path5.join(__dirname, "py-broker.py");
  console.log("[py-broker] starting: py=" + pyExe);
  if (!fs5.existsSync(scriptPath)) {
    console.log("[py-broker] FATAL: script not found:", scriptPath);
    _readyError = "script not found: " + scriptPath;
    return;
  }
  try {
    const logFile = path5.join(portableRoot, "Data", "Logs", "_py_broker.log");
    _proc = (0, import_child_process3.spawn)(pyExe, ["-u", scriptPath, "--log-file", logFile], {
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, PYTHONUNBUFFERED: "1", PYTHONIOENCODING: "utf-8" },
      windowsHide: true
    });
  } catch (e) {
    console.log("[py-broker] FATAL: spawn failed:", e.message || e);
    _readyError = "spawn failed: " + (e.message || e);
    return;
  }
  console.log("[py-broker] spawned pid=" + _proc.pid);
  _proc.stdout.on("data", (chunk) => {
    _buf += chunk.toString("utf-8");
    let nl;
    while ((nl = _buf.indexOf("\n")) !== -1) {
      const line = _buf.slice(0, nl);
      _buf = _buf.slice(nl + 1);
      try {
        const msg = JSON.parse(line);
        if (msg.type === "ready") {
          _ready = true;
          _readyError = null;
          console.log("[py-broker] ready, platform=" + msg.platform);
        } else if (msg.id && _pending.has(msg.id)) {
          const p = _pending.get(msg.id);
          clearTimeout(p.timer);
          _pending.delete(msg.id);
          p.resolve(msg);
        }
      } catch {
      }
    }
  });
  _proc.stderr.on("data", (chunk) => {
    console.log("[py-broker:stderr]", chunk.toString("utf-8").trim());
  });
  _proc.on("error", (e) => {
    console.log("[py-broker] process error:", e.message || e);
    _readyError = "process error: " + (e.message || e);
  });
  _proc.on("exit", (code, signal) => {
    console.log("[py-broker] exited code=" + code + " signal=" + signal);
    _ready = false;
    _readyError = "exited code=" + code;
    _proc = null;
    for (const [id, p] of _pending) {
      clearTimeout(p.timer);
      p.reject(new Error("py-broker exited"));
    }
    _pending.clear();
  });
}
function _sendCommand(action, params = {}) {
  return new Promise((resolve3, reject) => {
    if (!_ready) {
      reject(new Error("py-broker not ready: " + (_readyError || "unknown")));
      return;
    }
    if (!_proc || _proc.killed) {
      reject(new Error("py-broker not running"));
      return;
    }
    const id = _nextId++;
    const timer = setTimeout(() => {
      _pending.delete(id);
      reject(new Error("py-broker timeout: " + action));
    }, 1e4);
    _pending.set(id, { resolve: resolve3, reject, timer });
    const cmd = JSON.stringify({ action, id, ...params });
    _proc.stdin.write(cmd + "\n", (err) => {
      if (err) {
        clearTimeout(timer);
        _pending.delete(id);
        reject(err);
      }
    });
  });
}
async function renameDevToolsViaBroker(mainWin, projName) {
  if (isNodeBrokerAvailable()) {
    const ok = renameDevToolsViaNodeBroker(mainWin, projName);
    if (ok)
      return;
    console.log("[py-broker] node-broker failed, falling back to Python broker");
  }
  try {
    let mainHwnd = "0";
    try {
      const hbuf = mainWin.getNativeWindowHandle();
      if (hbuf && hbuf.length >= 4) {
        mainHwnd = hbuf.length === 8 ? hbuf.readBigUInt64LE(0).toString() : hbuf.readUInt32LE(0).toString();
      }
    } catch {
    }
    const title = `\u300C\u{1F527}\u300D${projName}`;
    const result = await _sendCommand("rename-devtools", { mainHwnd, title });
    if (result.ok) {
      console.log("[py-broker] renameDevTools (py) OK: renamed=" + (result.renamed || 1) + " title=" + title);
    } else {
      console.log("[py-broker] renameDevTools (py) FAILED:", result.error);
    }
  } catch (e) {
    console.log("[py-broker] renameDevTools (py) ERROR:", e.message || e);
  }
}
function stopPyBroker() {
  if (!_proc)
    return;
  try {
    _proc.stdin.write(JSON.stringify({ action: "exit", id: 0 }) + "\n");
  } catch {
  }
  setTimeout(() => {
    try {
      if (_proc)
        _proc.kill();
    } catch {
    }
    _proc = null;
  }, 2e3);
}
function resolvePythonPath(portableRoot) {
  const own = getComponentBin(portableRoot, "python");
  if (own && fs5.existsSync(own))
    return own;
  if (process.platform === "win32") {
    try {
      const { execSync: execSync6 } = require("child_process");
      const stdout = execSync6(
        "reg query HKCU\\Environment /v QQQIDE_PYTHON_DIR",
        { encoding: "utf8", windowsHide: true, timeout: 5e3 }
      );
      const m = stdout.match(/REG_SZ\s+(.+)/);
      if (m) {
        const qDir = m[1].trim();
        const qPy = path5.join(qDir, "python.exe");
        if (fs5.existsSync(qPy))
          return qPy;
      }
    } catch {
    }
  }
  const candidates = process.platform === "win32" ? ["python", "python3"] : ["python3", "python"];
  for (const cmd of candidates) {
    const dirs = (process.env.PATH || "").split(path5.delimiter).filter(Boolean);
    const exts = process.platform === "win32" ? (process.env.PATHEXT || ".EXE;.BAT;.CMD;.COM").split(";").filter(Boolean) : [""];
    for (const dir of dirs) {
      for (const ext of exts) {
        const p = path5.join(dir, cmd + ext);
        try {
          if (fs5.statSync(p).isFile())
            return p;
        } catch {
        }
      }
    }
  }
  return null;
}
function getPythonDir(portableRoot) {
  return getComponentDir(portableRoot, "python");
}
function isPyBrokerReady() {
  if (isNodeBrokerAvailable())
    return true;
  return _ready;
}
var import_child_process3, path5, fs5, _proc, _pending, _nextId, _ready, _readyError, _buf;
var init_py_broker = __esm({
  "shell/py-broker.ts"() {
    "use strict";
    import_child_process3 = require("child_process");
    path5 = __toESM(require("path"));
    fs5 = __toESM(require("fs"));
    init_component_checker();
    init_node_broker();
    _proc = null;
    _pending = /* @__PURE__ */ new Map();
    _nextId = 1;
    _ready = false;
    _readyError = null;
    _buf = "";
  }
});

// shell/gaea-process.ts
var gaea_process_exports = {};
__export(gaea_process_exports, {
  cleanupAllGaeaProcesses: () => cleanupAllGaeaProcesses,
  getGaeaProcessPid: () => getGaeaProcessPid,
  getOsGaeaAutoStart: () => getOsGaeaAutoStart,
  isGaeaProcessRunning: () => isGaeaProcessRunning,
  onGaeaProcessStatusChange: () => onGaeaProcessStatusChange,
  registerGoodsMeta: () => registerGoodsMeta,
  setGaeaUserDataPath: () => setGaeaUserDataPath,
  startGaeaProcess: () => startGaeaProcess,
  startGaeaWatchdog: () => startGaeaWatchdog,
  stopAllGaeaWatchdogs: () => stopAllGaeaWatchdogs,
  stopGaeaProcess: () => stopGaeaProcess,
  stopGaeaWatchdog: () => stopGaeaWatchdog,
  syncOsGaeaAutoStart: () => syncOsGaeaAutoStart
});
function setGaeaUserDataPath(dir) {
  _userDataPath = dir;
}
function registerGoodsMeta(goodsId, allowMultiple) {
  _goodsMeta.set(goodsId, { allowMultiple });
}
function onGaeaProcessStatusChange(cb) {
  _statusListeners.push(cb);
}
function _notifyStatus(goodsId, running, pid) {
  for (const cb of _statusListeners) {
    try {
      cb(goodsId, running, pid);
    } catch {
    }
  }
}
function _pidFileDir(userData) {
  const dir = path22.join(userData, "alphal", "goods");
  if (!fs21.existsSync(dir))
    fs21.mkdirSync(dir, { recursive: true });
  return dir;
}
function _pidFilePath(userData, goodsId) {
  return path22.join(_pidFileDir(userData), goodsId + ".pid");
}
function _isPidAlive(pid) {
  try {
    if (process.platform === "win32") {
      const result = (0, import_child_process8.execSync)(`tasklist /FI "PID eq ${pid}" /NH`, { windowsHide: true, timeout: 3e3 });
      return result.toString().includes(`${pid}`);
    } else {
      process.kill(pid, 0);
      return true;
    }
  } catch {
    return false;
  }
}
function _checkExistingInstance(userData, goodsId) {
  const pidFile = _pidFilePath(userData, goodsId);
  if (!fs21.existsSync(pidFile))
    return { running: false };
  try {
    const content = fs21.readFileSync(pidFile, "utf-8").trim();
    const pid = parseInt(content.split("\n")[0], 10);
    if (isNaN(pid))
      return { running: false };
    if (_isPidAlive(pid)) {
      return { running: true, pid };
    } else {
      try {
        fs21.unlinkSync(pidFile);
      } catch {
      }
      return { running: false };
    }
  } catch {
    return { running: false };
  }
}
function _writePidFile(userData, goodsId, pid) {
  try {
    fs21.writeFileSync(_pidFilePath(userData, goodsId), `${pid}
${Date.now()}`, "utf-8");
  } catch {
  }
}
function _removePidFile(userData, goodsId) {
  try {
    fs21.unlinkSync(_pidFilePath(userData, goodsId));
  } catch {
  }
}
function _getOsStateDir(goodsId) {
  const dir = path22.join(os5.homedir(), "AppData", "Local", goodsId);
  if (!fs21.existsSync(dir))
    fs21.mkdirSync(dir, { recursive: true });
  return dir;
}
function _getOsStatePath(goodsId) {
  return path22.join(_getOsStateDir(goodsId), ".gaea-state.json");
}
function _readOsState(goodsId) {
  try {
    const p = _getOsStatePath(goodsId);
    if (!fs21.existsSync(p))
      return null;
    const raw = fs21.readFileSync(p, "utf-8");
    const data = JSON.parse(raw);
    if (typeof data.pid === "number" && typeof data.ts === "number") {
      return { pid: data.pid, autoStart: !!data.autoStart, ts: data.ts };
    }
    return null;
  } catch {
    return null;
  }
}
function _writeOsState(goodsId, state) {
  try {
    const dir = _getOsStateDir(goodsId);
    const dest = path22.join(dir, ".gaea-state.json");
    const tmp = dest + ".tmp";
    fs21.writeFileSync(tmp, JSON.stringify(state), "utf-8");
    fs21.renameSync(tmp, dest);
  } catch {
  }
}
function _clearOsState(goodsId) {
  try {
    const p = _getOsStatePath(goodsId);
    if (fs21.existsSync(p))
      fs21.unlinkSync(p);
  } catch {
  }
}
function syncOsGaeaAutoStart(goodsId, autoStart) {
  const state = _readOsState(goodsId);
  if (state) {
    _writeOsState(goodsId, { ...state, autoStart });
  }
}
function getOsGaeaAutoStart(goodsId) {
  const state = _readOsState(goodsId);
  if (!state)
    return null;
  return state.autoStart;
}
function _checkOsState(goodsId) {
  const state = _readOsState(goodsId);
  if (!state)
    return { running: false };
  if (Date.now() - state.ts > 3e4) {
    _clearOsState(goodsId);
    return { running: false };
  }
  if (_isPidAlive(state.pid)) {
    return { running: true, pid: state.pid };
  } else {
    _clearOsState(goodsId);
    return { running: false };
  }
}
function _startOsHeartbeat(goodsId, pid, autoStart) {
  _writeOsState(goodsId, { pid, autoStart, ts: Date.now() });
  const timer = setInterval(() => {
    const current = _readOsState(goodsId);
    if (!current || current.pid !== pid) {
      clearInterval(timer);
      return;
    }
    _writeOsState(goodsId, { pid, autoStart: current.autoStart, ts: Date.now() });
  }, 1e4);
  return timer;
}
function _resolveGoodsScript(portableRoot, scriptPath) {
  const dataWebapp = path22.join(portableRoot, "Data", "webapp");
  const p1 = path22.join(dataWebapp, scriptPath);
  if (fs21.existsSync(p1))
    return p1;
  const oldRel = scriptPath.replace(/^goods\//, "");
  const p2 = path22.join(portableRoot, "resources", "app", "engines", oldRel);
  if (fs21.existsSync(p2))
    return p2;
  const p3 = path22.join(portableRoot, "server-app", scriptPath);
  if (fs21.existsSync(p3))
    return p3;
  return p1;
}
function startGaeaProcess(portableRoot, goodsId, scriptPath, runtime = "python", lifecycle = "attached", allowMultiple = true) {
  var _a;
  const userData = path22.join(portableRoot, "Data");
  _userDataPath = userData;
  _goodsMeta.set(goodsId, { allowMultiple });
  _singletonConflicts.delete(goodsId);
  if (_startingLocks.has(goodsId)) {
    console.log("[" + goodsId + "] start already in progress \u2014 skip");
    return { ok: false, error: "\u542F\u52A8\u8FDB\u884C\u4E2D\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" };
  }
  _startingLocks.add(goodsId);
  try {
    if (!allowMultiple) {
      const existing = _checkExistingInstance(userData, goodsId);
      if (existing.running) {
        console.log("[" + goodsId + "] already running pid=" + existing.pid + " \u2014 skip");
        if (!_registry.has(goodsId)) {
          _registry.set(goodsId, {
            proc: null,
            pid: existing.pid || null,
            scriptPath,
            lifecycle,
            allowMultiple
          });
        }
        return { ok: true, pid: existing.pid, alreadyRunning: true };
      }
    }
    const existingMem = _registry.get(goodsId);
    if (existingMem && existingMem.proc && !existingMem.proc.killed) {
      return { ok: true, pid: existingMem.pid || void 0 };
    }
    let exe = null;
    if (runtime === "python") {
      exe = getComponentBin(portableRoot, "python");
      if (!exe)
        return { ok: false, error: "Python \u672A\u5B89\u88C5\u3002\u91CD\u542F IDE \u540E\u5C06\u81EA\u52A8\u4E0B\u8F7D\u3002" };
    } else {
      const binFromComponent = getComponentBin(portableRoot, runtime);
      if (binFromComponent) {
        exe = binFromComponent;
      } else {
        return { ok: false, error: "\u8FD0\u884C\u65F6\u672A\u627E\u5230: " + runtime };
      }
    }
    const fullPath = _resolveGoodsScript(portableRoot, scriptPath);
    if (!fs21.existsSync(fullPath)) {
      return { ok: false, error: "\u811A\u672C\u672A\u627E\u5230: " + fullPath };
    }
    try {
      const cwd = fullPath.substring(0, fullPath.lastIndexOf("\\"));
      const isDetached = lifecycle === "independent";
      const pidFile = _pidFilePath(userData, goodsId);
      const args = ["-u", fullPath];
      if (!allowMultiple) {
        args.push("--pid-file", pidFile);
      }
      const pyEngineDir = path22.dirname(exe);
      const qtPluginDir = path22.join(pyEngineDir, "site-packages", "PySide2", "plugins");
      const envExt = {
        PYTHONUNBUFFERED: "1",
        PYTHONIOENCODING: "utf-8",
        PYTHONPATH: cwd,
        QT_PLUGIN_PATH: qtPluginDir,
        QT_QPA_PLATFORM_PLUGIN_PATH: qtPluginDir
      };
      envExt.PATH = pyEngineDir + path22.delimiter + (process.env.PATH || "");
      const proc = (0, import_child_process8.spawn)(exe, args, {
        stdio: "ignore",
        windowsHide: false,
        cwd,
        env: { ...process.env, ...envExt },
        detached: isDetached
      });
      const entry = { proc, pid: proc.pid || null, scriptPath: fullPath, lifecycle, allowMultiple };
      _registry.set(goodsId, entry);
      console.log("[" + goodsId + "] spawned pid=" + entry.pid + " lifecycle=" + lifecycle + (allowMultiple ? "" : " [singleton]"));
      if (!allowMultiple && entry.pid) {
        _writePidFile(userData, goodsId, entry.pid);
        const autoStart = ((_a = _readOsState(goodsId)) == null ? void 0 : _a.autoStart) ?? true;
        _osHeartbeats.set(goodsId, _startOsHeartbeat(goodsId, entry.pid, autoStart));
      }
      _notifyStatus(goodsId, true, entry.pid);
      proc.on("exit", (code, signal) => {
        console.log("[" + goodsId + "] exited code=" + code + " signal=" + signal);
        if (!allowMultiple) {
          if (code === 100) {
            _singletonConflicts.add(goodsId);
            console.log("[" + goodsId + "] singleton conflict \u2014 watchdog blocked");
          } else {
            _removePidFile(userData, goodsId);
            _clearOsState(goodsId);
          }
        }
        const hb = _osHeartbeats.get(goodsId);
        if (hb) {
          clearInterval(hb);
          _osHeartbeats.delete(goodsId);
        }
        _registry.delete(goodsId);
        _notifyStatus(goodsId, false, null);
      });
      proc.on("error", (err) => {
        console.error("[" + goodsId + "] proc error:", err);
        if (!allowMultiple) {
          _removePidFile(userData, goodsId);
          _clearOsState(goodsId);
        }
        const hb = _osHeartbeats.get(goodsId);
        if (hb) {
          clearInterval(hb);
          _osHeartbeats.delete(goodsId);
        }
        _registry.delete(goodsId);
        _notifyStatus(goodsId, false, null);
      });
      return { ok: true, pid: entry.pid || void 0 };
    } catch (e) {
      return { ok: false, error: "\u542F\u52A8\u5931\u8D25: " + (e.message || e) };
    }
  } finally {
    _startingLocks.delete(goodsId);
  }
}
function stopGaeaProcess(goodsId) {
  _singletonConflicts.delete(goodsId);
  const entry = _registry.get(goodsId);
  if (entry && entry.proc && !entry.proc.killed) {
    try {
      if (process.platform === "win32" && entry.pid) {
        try {
          (0, import_child_process8.execSync)(`taskkill /F /T /PID ${entry.pid}`, { windowsHide: true });
        } catch {
        }
      } else {
        try {
          process.kill(-entry.pid, "SIGTERM");
        } catch {
          entry.proc.kill("SIGKILL");
        }
      }
      _registry.delete(goodsId);
      console.log("[" + goodsId + "] path A killed pid=" + entry.pid);
    } catch (e) {
      console.warn("[" + goodsId + "] path A failed:", e.message);
    }
  }
  _registry.delete(goodsId);
  if (_userDataPath) {
    const existing = _checkExistingInstance(_userDataPath, goodsId);
    if (existing.running && existing.pid) {
      try {
        if (process.platform === "win32") {
          (0, import_child_process8.execSync)(`taskkill /F /T /PID ${existing.pid}`, { windowsHide: true });
        } else {
          process.kill(existing.pid, "SIGKILL");
        }
        console.log("[" + goodsId + "] path B killed pid=" + existing.pid);
      } catch {
      }
    }
    _removePidFile(_userDataPath, goodsId);
  }
  _clearOsState(goodsId);
  const hb = _osHeartbeats.get(goodsId);
  if (hb) {
    clearInterval(hb);
    _osHeartbeats.delete(goodsId);
  }
  if (process.platform === "win32") {
    try {
      const wmicOut = (0, import_child_process8.execSync)(
        `wmic process where "name like '%python%'" get ProcessId,CommandLine /format:csv`,
        { windowsHide: true, timeout: 5e3 }
      ).toString();
      let killed = 0;
      for (const line of wmicOut.split("\n")) {
        if (line.includes(goodsId + "/q3.py") || line.includes(goodsId + "\\q3.py")) {
          const pidMatch = line.match(/,(\d+)/);
          if (pidMatch) {
            try {
              (0, import_child_process8.execSync)(`taskkill /F /PID ${pidMatch[1]}`, { windowsHide: true });
              killed++;
              console.log("[" + goodsId + "] path C killed pid=" + pidMatch[1]);
            } catch {
            }
          }
        }
      }
      if (killed > 0 || entry) {
        console.log("[" + goodsId + "] brute-force: " + killed + " process(es) killed");
      }
    } catch {
    }
  }
  _notifyStatus(goodsId, false, null);
  return { ok: true };
}
function isGaeaProcessRunning(goodsId) {
  const entry = _registry.get(goodsId);
  if (entry && entry.proc && !entry.proc.killed)
    return true;
  const meta = _goodsMeta.get(goodsId);
  if (meta && !meta.allowMultiple && _userDataPath) {
    const existing = _checkExistingInstance(_userDataPath, goodsId);
    if (existing.running)
      return true;
  }
  if (meta && !meta.allowMultiple) {
    const osCheck = _checkOsState(goodsId);
    if (osCheck.running)
      return true;
  }
  return false;
}
function getGaeaProcessPid(goodsId) {
  const entry = _registry.get(goodsId);
  return entry ? entry.pid : null;
}
function cleanupAllGaeaProcesses() {
  console.log("[gaea-process] cleanupAll \u2014 " + _registry.size + " process(es)");
  stopAllGaeaWatchdogs();
  _osHeartbeats.forEach((timer, goodsId) => {
    clearInterval(timer);
    _clearOsState(goodsId);
  });
  _osHeartbeats.clear();
  _registry.forEach((entry, goodsId) => {
    console.log("[gaea-process] cleaning " + goodsId + " (pid=" + entry.pid + ", lifecycle=" + entry.lifecycle + ")");
    stopGaeaProcess(goodsId);
  });
  const ALL_PROCESS_GOODS = ["kope-a", "window-there"];
  for (const gid of ALL_PROCESS_GOODS) {
    if (!_registry.has(gid)) {
      console.log("[gaea-process] cleanupAll brute-force: " + gid);
      try {
        stopGaeaProcess(gid);
      } catch {
      }
    }
  }
  if (process.platform === "win32") {
    try {
      const wmicOut = require("child_process").execSync(
        `wmic process where "name like '%python%'" get ProcessId,CommandLine /format:csv`,
        { windowsHide: true, timeout: 5e3 }
      ).toString();
      for (const line of wmicOut.split("\n")) {
        const lower = line.toLowerCase();
        if (lower.includes("kope-a") || lower.includes("window-there")) {
          const pidMatch = line.match(/,(\d+)/);
          if (pidMatch) {
            try {
              require("child_process").execSync(`taskkill /F /PID ${pidMatch[1]}`, { windowsHide: true });
              console.log("[gaea-process] cleanupAll final-kill pid=" + pidMatch[1] + " (" + line.trim() + ")");
            } catch {
            }
          }
        }
      }
    } catch {
    }
  }
}
function startGaeaWatchdog(portableRoot, goodsId, scriptPath, runtime = "python", lifecycle = "attached") {
  const userData = path22.join(portableRoot, "Data");
  stopGaeaWatchdog(goodsId);
  const timer = setInterval(() => {
    if (_singletonConflicts.has(goodsId)) {
      return;
    }
    const osCheck = _checkOsState(goodsId);
    const existing = _checkExistingInstance(userData, goodsId);
    if (!existing.running && !osCheck.running) {
      console.log("[watchdog:" + goodsId + "] process not running, restarting...");
      _removePidFile(userData, goodsId);
      _clearOsState(goodsId);
      _registry.delete(goodsId);
      const result = startGaeaProcess(portableRoot, goodsId, scriptPath, runtime, lifecycle, false);
      if (result.ok) {
        console.log("[watchdog:" + goodsId + "] restarted pid=" + result.pid);
      } else {
        console.log("[watchdog:" + goodsId + "] restart failed:", result.error);
      }
    }
  }, 5e3);
  _watchdogs.set(goodsId, timer);
  console.log("[watchdog:" + goodsId + "] started");
}
function stopGaeaWatchdog(goodsId) {
  const timer = _watchdogs.get(goodsId);
  if (timer) {
    clearInterval(timer);
    _watchdogs.delete(goodsId);
    console.log("[watchdog:" + goodsId + "] stopped");
  }
}
function stopAllGaeaWatchdogs() {
  _watchdogs.forEach((timer, goodsId) => {
    clearInterval(timer);
    console.log("[watchdog:" + goodsId + "] stopped (cleanup)");
  });
  _watchdogs.clear();
}
var import_child_process8, path22, fs21, os5, _registry, _watchdogs, _osHeartbeats, _statusListeners, _userDataPath, _goodsMeta, _singletonConflicts, _startingLocks;
var init_gaea_process = __esm({
  "shell/gaea-process.ts"() {
    "use strict";
    import_child_process8 = require("child_process");
    path22 = __toESM(require("path"));
    fs21 = __toESM(require("fs"));
    os5 = __toESM(require("os"));
    init_component_checker();
    _registry = /* @__PURE__ */ new Map();
    _watchdogs = /* @__PURE__ */ new Map();
    _osHeartbeats = /* @__PURE__ */ new Map();
    _statusListeners = [];
    _userDataPath = null;
    _goodsMeta = /* @__PURE__ */ new Map();
    _singletonConflicts = /* @__PURE__ */ new Set();
    _startingLocks = /* @__PURE__ */ new Set();
  }
});

// shell/engines.ts
var engines_exports = {};
__export(engines_exports, {
  EngineHost: () => EngineHost
});
var import_child_process9, path23, fs22, readline, import_events3, EngineHost;
var init_engines = __esm({
  "shell/engines.ts"() {
    "use strict";
    import_child_process9 = require("child_process");
    path23 = __toESM(require("path"));
    fs22 = __toESM(require("fs"));
    readline = __toESM(require("readline"));
    import_events3 = require("events");
    EngineHost = class extends import_events3.EventEmitter {
      constructor(appRoot) {
        super();
        this.appRoot = appRoot;
        this.proc = null;
        this.nextId = 1;
        this.pending = /* @__PURE__ */ new Map();
        this.enginePath = "";
        this.alive = false;
        this.starting = null;
      }
      /** Resolve the engine binary path for current platform/arch. */
      resolveEngineBinary() {
        const platMap = { win32: "win", linux: "linux", darwin: "mac" };
        const archMap = { x64: "x64", arm64: "arm64" };
        const plat = platMap[process.platform];
        const arch2 = archMap[process.arch];
        if (!plat || !arch2) {
          return null;
        }
        const ext = process.platform === "win32" ? ".exe" : "";
        const searchRoots = [
          this.appRoot,
          path23.join(this.appRoot, "resources", "app")
        ];
        const tries = [];
        for (const root of searchRoots) {
          tries.push(path23.join(root, "engines", `q_${plat}_${arch2}${ext}`));
          if (plat === "win" && arch2 === "arm64") {
            tries.push(path23.join(root, "engines", `q_win_x64${ext}`));
          }
        }
        for (const candidate of tries) {
          if (fs22.existsSync(candidate)) {
            return candidate;
          }
        }
        return null;
      }
      /**
       * Start the engine and wait for ping handshake. Returns true if alive.
       * Non-fatal if missing or fails - caller can still operate via fallback.
       */
      async start() {
        if (this.starting) {
          return this.starting;
        }
        if (this.alive) {
          return true;
        }
        this.starting = this.doStart();
        const ok = await this.starting;
        this.starting = null;
        return ok;
      }
      async doStart() {
        const bin = this.resolveEngineBinary();
        if (!bin) {
          console.warn("[engines] no rust engine binary found, fs.* will fall back to node native");
          return false;
        }
        this.enginePath = bin;
        try {
          const proc = (0, import_child_process9.spawn)(bin, ["--daemon"], {
            stdio: ["pipe", "pipe", "pipe"],
            windowsHide: true,
            env: { ...process.env, QQQ_PARENT_PID: String(process.pid) }
          });
          this.proc = proc;
          const rl = readline.createInterface({ input: proc.stdout, crlfDelay: Infinity });
          rl.on("line", (line) => this.onLine(line));
          proc.stderr.setEncoding("utf8");
          proc.stderr.on("data", (d) => {
            const text = String(d).trim();
            if (text) {
              console.error("[engine.stderr]", text);
            }
          });
          proc.on("exit", (code) => {
            this.alive = false;
            console.warn("[engines] engine exited code=" + code);
            for (const { reject, timer } of this.pending.values()) {
              clearTimeout(timer);
              reject(new Error("engine exited"));
            }
            this.pending.clear();
            this.emit("exit", code);
          });
          proc.on("error", (err) => {
            console.error("[engines] proc error:", err);
            this.alive = false;
            this.emit("error", err);
          });
          console.log("[engines] spawned:", bin, "(pid", proc.pid + ")");
          const ok = await this.handshake();
          this.alive = ok;
          if (ok) {
            console.log("[engines] handshake OK");
            this.emit("ready");
          } else {
            console.warn("[engines] handshake failed, killing engine");
            try {
              proc.kill();
            } catch {
            }
            this.proc = null;
          }
          return ok;
        } catch (e) {
          console.error("[engines] failed to start:", e);
          this.alive = false;
          return false;
        }
      }
      /** Send ping, retry up to 15 times every 200ms. */
      async handshake() {
        for (let i = 0; i < 15; i++) {
          try {
            const pong = await this.rawCall("ping", {}, 1e3);
            if (pong && pong.status === "alive") {
              return true;
            }
          } catch {
          }
          await new Promise((r) => setTimeout(r, 200));
        }
        return false;
      }
      onLine(line) {
        if (!line || !line.trim()) {
          return;
        }
        let msg;
        try {
          msg = JSON.parse(line);
        } catch {
          try {
            msg = JSON.parse(Buffer.from(line, "base64").toString("utf8"));
          } catch {
            console.warn("[engines] bad json:", line.slice(0, 200));
            return;
          }
        }
        if (msg._id === void 0 || msg.event) {
          this.emit("event", msg);
          return;
        }
        const cb = this.pending.get(msg._id);
        if (!cb) {
          return;
        }
        this.pending.delete(msg._id);
        clearTimeout(cb.timer);
        if (msg.error) {
          cb.reject(new Error(String(msg.error)));
        } else {
          cb.resolve(msg);
        }
      }
      /** Internal raw call (does not check this.alive; used for handshake). */
      rawCall(action, params, timeoutMs) {
        if (!this.proc || this.proc.killed) {
          return Promise.reject(new Error("engine_not_running"));
        }
        const id = ++this.nextId;
        const cmd = JSON.stringify({ _id: id, action, ...params || {} }) + "\n";
        return new Promise((resolve3, reject) => {
          const timer = setTimeout(() => {
            this.pending.delete(id);
            reject(new Error("engine_timeout: " + action));
          }, timeoutMs);
          this.pending.set(id, { resolve: resolve3, reject, timer });
          try {
            this.proc.stdin.write(cmd);
          } catch (e) {
            clearTimeout(timer);
            this.pending.delete(id);
            reject(e);
          }
        });
      }
      /**
       * Public RPC: invoke an action on the engine.
       * If engine is not alive, rejects (caller should fall back to native fs).
       */
      invoke(action, params = {}, timeoutMs = 1e4) {
        if (!this.alive) {
          return Promise.reject(new Error("engine_not_available"));
        }
        return this.rawCall(action, params, timeoutMs);
      }
      isAlive() {
        return this.alive;
      }
      stop() {
        if (this.proc) {
          try {
            this.proc.kill();
          } catch {
          }
          this.proc = null;
          this.alive = false;
        }
      }
    };
  }
});

// shell/portable-paths.ts
var path = __toESM(require("path"));
var fs = __toESM(require("fs"));
function getAppRoot() {
  const execLower = process.execPath.replace(/\\/g, "/").toLowerCase();
  if (execLower.includes("node_modules") || execLower.includes("electron/dist")) {
    return path.resolve(__dirname, "..");
  }
  return path.dirname(process.execPath);
}
function applyPortablePaths() {
  const root = getAppRoot();
  const userData = path.join(root, "Data");
  const cache = path.join(userData, "Cache");
  const temp = path.join(userData, "Temp");
  const logs = path.join(userData, "Logs");
  const crashDumps = path.join(userData, "CrashDumps");
  process.env.TMP = temp;
  process.env.TEMP = temp;
  if (process.platform === "win32") {
    process.env.LOCALAPPDATA = path.join(userData, "LocalAppData");
  }
  for (const d of [
    userData,
    cache,
    temp,
    logs,
    crashDumps,
    path.join(userData, "LocalAppData")
  ]) {
    try {
      fs.mkdirSync(d, { recursive: true });
    } catch {
    }
  }
  let app6;
  try {
    app6 = require("electron").app;
  } catch {
    console.warn("[portable-paths] electron.app not available, skipping path redirects");
    return { root, userData, cache, logs };
  }
  if (!app6) {
    console.warn("[portable-paths] electron.app is undefined, skipping path redirects");
    return { root, userData, cache, logs };
  }
  app6.setPath("userData", userData);
  app6.setPath("sessionData", userData);
  app6.setPath("cache", cache);
  app6.setPath("temp", temp);
  app6.setPath("logs", logs);
  app6.setPath("crashDumps", crashDumps);
  try {
    app6.setAppLogsPath(logs);
  } catch {
  }
  app6.commandLine.appendSwitch("user-data-dir", userData);
  app6.commandLine.appendSwitch("disk-cache-dir", cache);
  app6.commandLine.appendSwitch(
    "disable-features",
    "DefaultBrowser,MediaRouter,OptimizationHints,PreloadMediaEngagementData,SafeBrowsing,TranslateUI,InterestFeedContentSuggestions,PrivacySandboxSettings4"
  );
  app6.commandLine.appendSwitch("no-default-browser-check");
  app6.commandLine.appendSwitch("disable-background-networking");
  app6.commandLine.appendSwitch("disable-component-update");
  app6.commandLine.appendSwitch("disable-domain-reliability");
  app6.commandLine.appendSwitch("disable-sync");
  app6.commandLine.appendSwitch("metrics-recording-only");
  app6.commandLine.appendSwitch("disable-default-apps");
  try {
    const crashReporter = require("electron").crashReporter;
    if (crashReporter) {
      crashReporter.start({ uploadToServer: false });
    }
  } catch {
  }
  setImmediate(() => cleanupStaleTemp(temp, 24 * 60 * 60 * 1e3));
  setImmediate(() => cleanupStaleTemp(path.join(userData, "LocalAppData"), 24 * 60 * 60 * 1e3));
  return { root, userData, cache, logs };
}
function cleanupStaleTemp(dir, maxAgeMs) {
  const now = Date.now();
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      try {
        const stat = fs.statSync(full);
        if (now - stat.mtimeMs <= maxAgeMs)
          continue;
        if (entry.isDirectory()) {
          fs.rmSync(full, { recursive: true, force: true });
        } else {
          fs.unlinkSync(full);
        }
      } catch {
      }
    }
  } catch {
  }
}

// shell/main.ts
var import_electron21 = require("electron");
var path33 = __toESM(require("path"));
var os8 = __toESM(require("os"));
var fs33 = __toESM(require("fs"));

// shell/boot.ts
var path2 = __toESM(require("path"));
var fs2 = __toESM(require("fs"));
var os = __toESM(require("os"));
var http2 = __toESM(require("http"));
var https2 = __toESM(require("https"));
var import_url = require("url");
var import_child_process = require("child_process");

// shell/version.ts
var import_fs = require("fs");
var import_path = require("path");
var import_fs2 = require("fs");
var import_path2 = require("path");
var APP_VERSION = "0.2.134";
var MIN_VERSION = "0.2.30";
function parseSemver(v) {
  if (!v || typeof v !== "string")
    return null;
  const clean = v.replace(/^v/, "").trim();
  const dashIdx = clean.indexOf("-");
  const numPart = dashIdx >= 0 ? clean.slice(0, dashIdx) : clean;
  const prePart = dashIdx >= 0 ? clean.slice(dashIdx + 1) : void 0;
  const parts = numPart.split(".");
  if (parts.length < 2)
    return null;
  const major = parseInt(parts[0], 10);
  const minor = parseInt(parts[1], 10);
  const patch = parts.length >= 3 ? parseInt(parts[2], 10) : 0;
  if (isNaN(major) || isNaN(minor) || isNaN(patch))
    return null;
  return { major, minor, patch, pre: prePart || void 0 };
}
function compareSemver(a, b) {
  const sa = parseSemver(a);
  const sb = parseSemver(b);
  if (!sa || !sb)
    return null;
  if (sa.major !== sb.major)
    return sa.major - sb.major;
  if (sa.minor !== sb.minor)
    return sa.minor - sb.minor;
  if (sa.patch !== sb.patch)
    return sa.patch - sb.patch;
  if (!sa.pre && !sb.pre)
    return 0;
  if (!sa.pre && sb.pre)
    return 1;
  if (sa.pre && !sb.pre)
    return -1;
  if (sa.pre < sb.pre)
    return -1;
  if (sa.pre > sb.pre)
    return 1;
  return 0;
}
function decideUpdate(localVersion, serverVersion, minVersion) {
  if (minVersion) {
    const cmpMin = compareSemver(localVersion, minVersion);
    if (cmpMin === null)
      return "error";
    if (cmpMin < 0)
      return "force-full-upgrade";
  }
  const cmp = compareSemver(localVersion, serverVersion);
  if (cmp === null)
    return "error";
  if (cmp > 0)
    return "skip-local-newer";
  if (cmp === 0)
    return "skip-up-to-date";
  return "hot-update";
}
var VERSION_DIR = "Data";
var SHELL_VERSION_FILE = "shell-version";
var WEBAPP_VERSION_FILE = "webapp-version";
function readLocalShellVersion(portableRoot) {
  try {
    const p = (0, import_path.join)(portableRoot, VERSION_DIR, SHELL_VERSION_FILE);
    if ((0, import_fs.existsSync)(p))
      return (0, import_fs.readFileSync)(p, "utf8").trim();
  } catch {
  }
  return "";
}
function readLocalWebappVersion(portableRoot) {
  try {
    const p = (0, import_path.join)(portableRoot, VERSION_DIR, WEBAPP_VERSION_FILE);
    if ((0, import_fs.existsSync)(p))
      return (0, import_fs.readFileSync)(p, "utf8").trim();
  } catch {
  }
  return "";
}
function writeLocalWebappVersion(portableRoot, version) {
  try {
    const p = (0, import_path.join)(portableRoot, VERSION_DIR, WEBAPP_VERSION_FILE);
    writeFileSyncRecursive(p, version);
  } catch {
  }
}
function writeFileSyncRecursive(filePath, data) {
  try {
    (0, import_fs2.mkdirSync)((0, import_path2.dirname)(filePath), { recursive: true });
  } catch {
  }
  (0, import_fs2.writeFileSync)(filePath, data, "utf8");
}
var https = require("https");
var http = require("http");
async function _httpGet(url, redirects = 3) {
  const lib = url.startsWith("https") ? https : http;
  return new Promise((resolve3, reject) => {
    const opts = { timeout: 8e3 };
    if (url.startsWith("https")) {
      opts.rejectUnauthorized = false;
    }
    const req = lib.get(url, opts, (res) => {
      if ((res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307 || res.statusCode === 308) && redirects > 0) {
        const loc = res.headers.location;
        res.resume();
        if (loc) {
          _httpGet(loc, redirects - 1).then(resolve3, reject);
        } else {
          resolve3({ status: res.statusCode, data: "" });
        }
        return;
      }
      let data = "";
      res.setEncoding("utf8");
      res.on("data", (c) => data += c);
      res.on("end", () => resolve3({ status: res.statusCode || 0, data }));
    });
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
  });
}
async function fetchServerVersionInfo(baseUrl) {
  try {
    const versionUrl = (baseUrl.endsWith("/") ? baseUrl : baseUrl + "/") + "version.json";
    const vResp = await _httpGet(versionUrl);
    if (vResp.status !== 200)
      return null;
    const v = JSON.parse(vResp.data);
    return {
      shell: v.shell || v.shell_version || v.version || "",
      webapp: v.webapp || v.webapp_version || v.version || "",
      min_shell: v.min_shell || ""
    };
  } catch {
    return null;
  }
}
function checkForcedUpdate() {
  const cmp = compareSemver(APP_VERSION, MIN_VERSION);
  return {
    required: cmp !== null && cmp < 0,
    currentVersion: APP_VERSION,
    minVersion: MIN_VERSION
  };
}
async function fetchServerVersionInfoWithFallback(primaryUrl, fallbackUrl) {
  const primary = await fetchServerVersionInfo(primaryUrl);
  if (primary)
    return primary;
  if (fallbackUrl) {
    return await fetchServerVersionInfo(fallbackUrl);
  }
  return null;
}

// shell/boot.ts
var bootCompleted = false;
function isBootCompleted() {
  return bootCompleted;
}
var _bootLogPath = null;
function bootLog(msg) {
  if (!_bootLogPath) {
    return;
  }
  const ts = (/* @__PURE__ */ new Date()).toISOString();
  try {
    fs2.appendFileSync(_bootLogPath, `[${ts}] ${msg}
`);
  } catch (_) {
  }
}
function initBootLog(logsDir) {
  try {
    fs2.mkdirSync(logsDir, { recursive: true });
  } catch (_) {
  }
  _bootLogPath = path2.join(logsDir, "boot.log");
  bootLog("=== qqqide boot start ===");
  bootLog("version: " + APP_VERSION);
  bootLog("platform: " + os.platform() + " " + os.release());
}
var PRODUCTION_URL = "https://gh555.com/qqqide/";
var UPDATE_BASE_URL = "https://gh555.com/dl/qqqide-up/";
var UPDATE_FALLBACK_URL = "https://gh555-shanghai.oss-cn-shanghai.aliyuncs.com/qqqide-up/";
function loadBootConfig(_portableRoot) {
  let cfg = { url: PRODUCTION_URL, healthTimeoutMs: 3e3 };
  if (process.env.QQQIDE_URL) {
    cfg.url = process.env.QQQIDE_URL;
  }
  for (const arg of process.argv.slice(1)) {
    if (arg.startsWith("--url=")) {
      cfg.url = arg.slice(6);
    }
  }
  return cfg;
}
function extractFlags() {
  return {
    isOffline: process.argv.includes("--offline"),
    isDev: process.argv.includes("--dev") || process.env.QQQIDE_DEV === "1"
  };
}
function healthCheck(urlStr, timeoutMs, isOffline) {
  bootLog("health: check " + urlStr);
  return new Promise((resolve3) => {
    if (isOffline) {
      bootLog("health: SKIP (offline mode)");
      return resolve3(false);
    }
    let healthUrl;
    try {
      const u = new import_url.URL("health", urlStr.endsWith("/") ? urlStr : urlStr + "/");
      healthUrl = u.toString();
    } catch {
      bootLog("health: FAIL \u2014 bad URL");
      return resolve3(false);
    }
    const lib = healthUrl.startsWith("https") ? https2 : http2;
    const opts = { timeout: timeoutMs };
    if (healthUrl.startsWith("https")) {
      opts.rejectUnauthorized = false;
    }
    const req = lib.get(healthUrl, opts, (res) => {
      const ok = !!(res.statusCode && res.statusCode >= 200 && res.statusCode < 400);
      res.resume();
      bootLog("health: " + (ok ? "OK " + res.statusCode : "FAIL status=" + res.statusCode));
      resolve3(ok);
    });
    req.on("error", (err) => {
      bootLog("health: FAIL \u2014 " + (err && err.message || String(err)));
      resolve3(false);
    });
    req.on("timeout", () => {
      bootLog("health: FAIL \u2014 timeout " + timeoutMs + "ms");
      req.destroy();
      resolve3(false);
    });
  });
}
function writeBootStatus(portableRoot, line) {
  if (!portableRoot)
    return;
  try {
    fs2.writeFileSync(path2.join(portableRoot, "loading-status"), line, "utf-8");
  } catch (_) {
  }
}
var SHELL_UPDATE_URL = "shell-out.tar.gz";
async function checkAndDownloadShellUpdate(bootConfig2, portableRoot, portableCache, isDev, isOffline) {
  if (isDev || isOffline)
    return false;
  const stagingDir = path2.join(portableCache, "staging", "shell-out-next");
  const tarPath = path2.join(portableCache, "staging", "shell-out.tar.gz");
  try {
    const updateUrl = UPDATE_BASE_URL + SHELL_UPDATE_URL;
    const lib = updateUrl.startsWith("https") ? https2 : http2;
    const versionInfo = await fetchServerVersionInfoWithFallback(UPDATE_BASE_URL, UPDATE_FALLBACK_URL);
    const latestVersion = (versionInfo == null ? void 0 : versionInfo.shell) || "";
    if (!latestVersion)
      return false;
    const localVersion = readLocalShellVersion(portableRoot) || APP_VERSION;
    const decision = decideUpdate(localVersion, latestVersion, versionInfo == null ? void 0 : versionInfo.min_shell);
    if (decision !== "hot-update" && decision !== "force-full-upgrade") {
      console.log("[shell-update]", decision, "\u2014 local=" + localVersion + " server=" + latestVersion);
      return false;
    }
    console.log("[shell-update]", decision, "\u2014 local=" + localVersion + " server=" + latestVersion);
    console.log("[shell-update] downloading", updateUrl);
    try {
      fs2.mkdirSync(path2.dirname(tarPath), { recursive: true });
    } catch {
    }
    writeBootStatus(portableRoot, "0|\u68C0\u67E5\u58F3\u5C42\u66F4\u65B0\u2026");
    const downloadOk = await new Promise((resolve3) => {
      var _trackDownload = function(resp, label) {
        var total = parseInt(resp.headers["content-length"] || "0", 10);
        var downloaded = 0;
        var lastPct = 0;
        var fstream = fs2.createWriteStream(tarPath);
        resp.on("data", function(chunk) {
          downloaded += chunk.length;
          if (total > 0) {
            var pct = Math.round(downloaded / total * 100);
            if (pct !== lastPct) {
              lastPct = pct;
              writeBootStatus(portableRoot, pct + "|" + label);
            }
          }
        });
        resp.pipe(fstream);
        return fstream;
      };
      const dlopts = { timeout: 6e4 };
      if (updateUrl.startsWith("https")) {
        dlopts.rejectUnauthorized = false;
      }
      const req = lib.get(updateUrl, dlopts, (res) => {
        if (res.statusCode !== 200) {
          if (res.statusCode === 301 || res.statusCode === 302) {
            const loc = res.headers.location;
            if (loc) {
              const lib2 = loc.startsWith("https") ? https2 : http2;
              const redirOpts = { timeout: 6e4 };
              if (loc.startsWith("https")) {
                redirOpts.rejectUnauthorized = false;
              }
              const req2 = lib2.get(loc, redirOpts, (res2) => {
                if (res2.statusCode !== 200) {
                  resolve3(false);
                  return;
                }
                var f2 = _trackDownload(res2, "\u4E0B\u8F7D\u58F3\u5C42\u66F4\u65B0\u2026");
                f2.on("finish", () => resolve3(true));
                f2.on("error", () => resolve3(false));
              });
              req2.on("error", () => resolve3(false));
              req2.on("timeout", () => {
                req2.destroy();
                resolve3(false);
              });
              return;
            }
          }
          resolve3(false);
          return;
        }
        var f1 = _trackDownload(res, "\u4E0B\u8F7D\u58F3\u5C42\u66F4\u65B0\u2026");
        f1.on("finish", () => resolve3(true));
        f1.on("error", () => resolve3(false));
      });
      req.on("error", () => resolve3(false));
      req.on("timeout", () => {
        req.destroy();
        resolve3(false);
      });
    });
    if (!downloadOk) {
      console.log("[shell-update] download failed or not available");
      return false;
    }
    console.log("[shell-update] extracting to", stagingDir);
    try {
      fs2.rmSync(stagingDir, { recursive: true, force: true });
    } catch {
    }
    try {
      fs2.mkdirSync(stagingDir, { recursive: true });
    } catch {
    }
    const extractResult = (0, import_child_process.spawnSync)("tar", ["-xzf", tarPath, "-C", stagingDir], {
      stdio: "pipe",
      timeout: 15e3
    });
    if (extractResult.status !== 0) {
      console.log("[shell-update] extract failed, status:", extractResult.status);
      try {
        fs2.rmSync(tarPath);
      } catch {
      }
      try {
        fs2.rmSync(stagingDir, { recursive: true, force: true });
      } catch {
      }
      return false;
    }
    try {
      fs2.unlinkSync(tarPath);
    } catch {
    }
    const stagingVerFile = path2.join(stagingDir, ".staging-version");
    try {
      fs2.writeFileSync(stagingVerFile, latestVersion, "utf8");
    } catch {
    }
    console.log("[shell-update] staged for next restart:", stagingDir);
    return true;
  } catch (e) {
    console.log("[shell-update] error:", e.message || e);
    return false;
  }
}
var WEBAPP_PROTOCOL = "qqqide-webapp";
var _webappProtocolRegistered = false;
function _copyDirContentsSync(src, dest) {
  try {
    fs2.mkdirSync(dest, { recursive: true });
  } catch {
  }
  const entries = fs2.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path2.join(src, entry.name);
    const destPath = path2.join(dest, entry.name);
    if (entry.isDirectory()) {
      _copyDirContentsSync(srcPath, destPath);
    } else {
      fs2.copyFileSync(srcPath, destPath);
    }
  }
}
function ensureLocalWebapp(portableRoot) {
  const localDir = path2.join(portableRoot, "Data", "webapp");
  const stagingDir = path2.join(portableRoot, "Data", "webapp-staging");
  if (fs2.existsSync(stagingDir)) {
    if (!fs2.existsSync(path2.join(stagingDir, "index.html"))) {
      bootLog("webapp: staging is incomplete (no index.html), discarding");
      try {
        fs2.rmSync(stagingDir, { recursive: true, force: true });
      } catch {
      }
    } else {
      bootLog("webapp: staged update detected, swapping\u2026");
      let swapped = false;
      try {
        const oldDir = localDir + ".old";
        if (fs2.existsSync(localDir)) {
          fs2.renameSync(localDir, oldDir);
        }
        fs2.renameSync(stagingDir, localDir);
        if (fs2.existsSync(oldDir)) {
          fs2.rmSync(oldDir, { recursive: true, force: true });
        }
        swapped = true;
        bootLog("webapp: swap OK (rename) \u2192 " + localDir);
      } catch (e1) {
        bootLog("webapp: rename failed (" + (e1.message || e1) + "), trying copy fallback\u2026");
        try {
          const oldDir = localDir + ".old";
          if (fs2.existsSync(oldDir) && !fs2.existsSync(localDir)) {
            fs2.renameSync(oldDir, localDir);
          }
        } catch (_) {
        }
        try {
          _copyDirContentsSync(stagingDir, localDir);
          if (fs2.existsSync(path2.join(localDir, "index.html"))) {
            swapped = true;
            bootLog("webapp: swap OK (copy-in-place) \u2192 " + localDir);
          }
        } catch (e2) {
          bootLog("webapp: copy-in-place failed \u2014 " + (e2.message || e2));
        }
      }
      if (swapped) {
        const stagingVerPath = path2.join(localDir, ".staging-version");
        try {
          if (fs2.existsSync(stagingVerPath)) {
            const v = fs2.readFileSync(stagingVerPath, "utf8").trim();
            if (v) {
              writeLocalWebappVersion(portableRoot, v);
              bootLog("webapp: version written \u2192 " + v);
            }
            fs2.unlinkSync(stagingVerPath);
          }
        } catch (_) {
        }
        try {
          if (fs2.existsSync(stagingDir))
            fs2.rmSync(stagingDir, { recursive: true, force: true });
        } catch (_) {
        }
      } else {
        bootLog("webapp: swap FAILED \u2014 staging preserved for next retry");
      }
    }
  }
  if (fs2.existsSync(path2.join(localDir, "index.html"))) {
    const verPath = path2.join(portableRoot, "Data", "webapp-version");
    if (!fs2.existsSync(verPath)) {
      try {
        fs2.writeFileSync(verPath, APP_VERSION, "utf8");
      } catch {
      }
    }
    return localDir;
  }
  const candidates = [
    path2.join(portableRoot, "resources", "app", "webapp"),
    path2.join(portableRoot, "resources", "app", "server-app"),
    path2.join(__dirname, "webapp"),
    path2.join(__dirname, "..", "webapp")
  ];
  for (const src of candidates) {
    if (fs2.existsSync(path2.join(src, "index.html"))) {
      try {
        fs2.cpSync(src, localDir, { recursive: true });
        bootLog("webapp: copied from package \u2192 " + localDir);
        try {
          fs2.writeFileSync(path2.join(portableRoot, "Data", "webapp-version"), APP_VERSION, "utf8");
        } catch {
        }
        return localDir;
      } catch (e) {
        bootLog("webapp: copy failed \u2014 " + (e.message || e));
      }
    }
  }
  return null;
}
function registerWebappProtocol(webappDir) {
  if (_webappProtocolRegistered)
    return;
  _webappProtocolRegistered = true;
  const _electron = require("electron");
  _electron.protocol.registerFileProtocol(WEBAPP_PROTOCOL, (request3, callback) => {
    try {
      const u = new import_url.URL(request3.url);
      let rel = decodeURIComponent(u.pathname);
      rel = rel.replace(/^\/qqqide\//, "/");
      if (rel.startsWith("/"))
        rel = rel.slice(1);
      if (!rel)
        rel = "index.html";
      const abs = path2.join(webappDir, rel);
      if (abs.startsWith(webappDir) && fs2.existsSync(abs)) {
        callback({ path: abs });
      } else {
        callback({ error: -6 });
      }
    } catch {
      callback({ error: -2 });
    }
  });
}
async function backgroundCheckWebappUpdate(bootConfig2, portableRoot) {
  try {
    const versionInfo = await fetchServerVersionInfoWithFallback(UPDATE_BASE_URL, UPDATE_FALLBACK_URL);
    if (!versionInfo) {
      bootLog("webapp-update: version check failed");
      return;
    }
    const latestVersion = versionInfo.webapp || "";
    if (!latestVersion) {
      bootLog("webapp-update: no version info on server");
      return;
    }
    const localVersion = readLocalWebappVersion(portableRoot) || "0.0.0";
    const decision = decideUpdate(localVersion, latestVersion);
    if (decision !== "hot-update") {
      bootLog("webapp-update: " + decision + " \u2014 local=" + localVersion + " server=" + latestVersion);
      return;
    }
    bootLog("webapp-update: hot-update \u2014 local=" + localVersion + " server=" + latestVersion);
    const dlUrl = UPDATE_BASE_URL + "server-app.tar.gz";
    bootLog("webapp-update: downloading " + dlUrl);
    const lib = dlUrl.startsWith("https") ? https2 : http2;
    const dlDir = path2.join(portableRoot, "Data", "webapp-dl");
    try {
      fs2.mkdirSync(dlDir, { recursive: true });
    } catch {
    }
    const tarPath = path2.join(dlDir, "server-app.tar.gz");
    const fallbackDlUrl = UPDATE_FALLBACK_URL + "server-app.tar.gz";
    const dlOk = await new Promise((resolve3) => {
      var _trackW = function(resp) {
        var total = parseInt(resp.headers["content-length"] || "0", 10);
        var downloaded = 0;
        var lastPct = 0;
        var fstream = fs2.createWriteStream(tarPath);
        resp.on("data", function(chunk) {
          downloaded += chunk.length;
          if (total > 0) {
            var pct = Math.round(downloaded / total * 100);
            if (pct !== lastPct) {
              lastPct = pct;
            }
          }
        });
        resp.pipe(fstream);
        return fstream;
      };
      var _doW = function(url, isFallback) {
        var lib3 = url.startsWith("https") ? https2 : http2;
        var dopts = { timeout: 12e4 };
        if (url.startsWith("https")) {
          dopts.rejectUnauthorized = false;
        }
        var r = lib3.get(url, dopts, function(res2) {
          if (res2.statusCode !== 200) {
            if (res2.statusCode === 301 || res2.statusCode === 302 || res2.statusCode === 307 || res2.statusCode === 308) {
              var loc = res2.headers.location;
              if (loc) {
                _doW(loc, isFallback);
                return;
              }
            }
            if (!isFallback) {
              bootLog("webapp-update: primary failed (status=" + res2.statusCode + "), trying OSS fallback\u2026");
              _doW(fallbackDlUrl, true);
              return;
            }
            bootLog("webapp-update: download failed (status=" + res2.statusCode + ")");
            resolve3(false);
            return;
          }
          var f2 = _trackW(res2);
          f2.on("finish", function() {
            resolve3(true);
          });
          f2.on("error", function() {
            resolve3(false);
          });
        });
        r.on("error", function(e) {
          if (!isFallback) {
            bootLog("webapp-update: primary error " + (e && e.message || e) + ", trying OSS fallback\u2026");
            _doW(fallbackDlUrl, true);
            return;
          }
          resolve3(false);
        });
        r.on("timeout", function() {
          r.destroy();
          if (!isFallback) {
            _doW(fallbackDlUrl, true);
          } else {
            resolve3(false);
          }
        });
      };
      _doW(dlUrl, false);
    });
    if (!dlOk) {
      bootLog("webapp-update: download failed");
      return;
    }
    const stagingDir = path2.join(portableRoot, "Data", "webapp-staging");
    try {
      fs2.rmSync(stagingDir, { recursive: true, force: true });
    } catch {
    }
    try {
      fs2.mkdirSync(stagingDir, { recursive: true });
    } catch {
    }
    const extractResult = (0, import_child_process.spawnSync)("tar", ["-xzf", tarPath, "-C", stagingDir], {
      stdio: "pipe",
      timeout: 3e4
    });
    if (extractResult.status !== 0) {
      bootLog("webapp-update: extract failed, status=" + extractResult.status);
      try {
        fs2.rmSync(tarPath);
      } catch {
      }
      try {
        fs2.rmSync(stagingDir, { recursive: true, force: true });
      } catch {
      }
      return;
    }
    try {
      fs2.unlinkSync(tarPath);
    } catch {
    }
    try {
      fs2.writeFileSync(path2.join(stagingDir, ".staging-version"), latestVersion, "utf8");
    } catch {
    }
    bootLog("webapp-update: staged for next restart \u2014 " + stagingDir);
  } catch (e) {
    bootLog("webapp-update: error \u2014 " + (e.message || e));
  }
}
async function loadStaticFallback(mainWindow2, bootConfig2, portableRoot, reason) {
  if (!mainWindow2) {
    return "fallback";
  }
  if (bootCompleted) {
    bootLog("fallback: BLOCKED \u2014 boot already completed, refusing to replace IDE");
    return "fallback";
  }
  bootLog("fallback: reason=" + reason);
  const candidates = [
    path2.join(__dirname, "..", "shell", "boot-fallback.html"),
    path2.join(__dirname, "boot-fallback.html"),
    path2.join(portableRoot, "shell", "boot-fallback.html")
  ];
  for (const p of candidates) {
    if (fs2.existsSync(p)) {
      try {
        await mainWindow2.loadFile(p, { query: { url: bootConfig2.url, reason } });
      } catch (e) {
        bootLog("fallback: loadFile crashed \u2014 " + (e && e.message || String(e)));
        try {
          await mainWindow2.loadURL("data:text/html,<h1>qqqide offline</h1><p>\u8BF7\u91CD\u542F\u5E94\u7528</p>");
        } catch (_) {
        }
      }
      return "fallback";
    }
  }
  try {
    await mainWindow2.loadURL("data:text/html,<h1>qqqide offline</h1><p>\u8BF7\u91CD\u542F\u5E94\u7528</p>");
  } catch (_) {
  }
  return "fallback";
}
async function loadRemoteWithCacheGuard(mainWindow2, bootConfig2, timeoutMs = 0, isDev = false, portableRoot = "") {
  if (!mainWindow2) {
    bootLog("remote: no window");
    return { ok: false, mode: "fallback" };
  }
  bootLog("remote: loading " + bootConfig2.url + (timeoutMs > 0 ? " timeout=" + timeoutMs + "ms" : ""));
  const wc = mainWindow2.webContents;
  return new Promise((resolve3) => {
    let settled = false;
    let timeoutTimer = null;
    let panelTimer = null;
    let progressTickId = null;
    const PANEL_MAX_MS = 3e4;
    const writeLoadingStatus = (line) => {
      writeBootStatus(portableRoot, line);
    };
    let pendingReqs = 0;
    let doneReqs = 0;
    let domReadyFired = false;
    const session2 = wc.session;
    const reqStartTimes = /* @__PURE__ */ new Map();
    let cooldownTimer = null;
    const COOLDOWN_MS = 4e3;
    const onBeforeReq = (details, cb) => {
      var _a;
      const now = Date.now();
      reqStartTimes.set(details.url, now);
      pendingReqs++;
      if (cooldownTimer) {
        clearTimeout(cooldownTimer);
        cooldownTimer = null;
      }
      const shortUrl = (_a = details.url) == null ? void 0 : _a.slice(0, 100);
      bootLog("webReq: +" + pendingReqs + " " + details.resourceType + " " + shortUrl);
      cb({});
    };
    const onReqDone = (details) => {
      var _a, _b;
      doneReqs++;
      pendingReqs = Math.max(0, pendingReqs - 1);
      const startTime = reqStartTimes.get(details.url);
      const elapsed = startTime ? Date.now() - startTime : -1;
      reqStartTimes.delete(details.url);
      if (elapsed > 1500) {
        bootLog("webReq: SLOW " + elapsed + "ms " + details.resourceType + " " + ((_a = details.url) == null ? void 0 : _a.slice(0, 80)));
      } else {
        bootLog("webReq: \u2713" + elapsed + "ms " + details.resourceType + " " + ((_b = details.url) == null ? void 0 : _b.slice(0, 80)));
      }
      tryCooldown();
    };
    const onReqErr = (details) => {
      var _a;
      pendingReqs = Math.max(0, pendingReqs - 1);
      const startTime = reqStartTimes.get(details.url);
      const elapsed = startTime ? Date.now() - startTime : -1;
      reqStartTimes.delete(details.url);
      bootLog("webReq: ERR " + elapsed + "ms " + details.resourceType + " " + ((_a = details.url) == null ? void 0 : _a.slice(0, 80)));
      tryCooldown();
    };
    const tryCooldown = () => {
      if (pendingReqs === 0 && doneReqs > 0 && !cooldownTimer) {
        bootLog("webReq: cooldown started \u2014 pending=0 done=" + doneReqs + " wait=" + COOLDOWN_MS + "ms");
        cooldownTimer = setTimeout(() => {
          bootLog("webReq: cooldown expired \u2014 truly done (total=" + doneReqs + ")");
          onAllReady();
        }, COOLDOWN_MS);
      }
    };
    const injectLoadingPanel = () => {
      const css = `
                #__qqq_boot_panel{position:fixed;top:0;left:0;right:0;bottom:0;z-index:99999;
                background:#fdf6e3;display:flex;align-items:center;justify-content:center;
                font-family:-apple-system,BlinkMacSystemFont,"Microsoft YaHei",sans-serif}
                #__qqq_boot_panel .wrap{text-align:center;max-width:420px;padding:32px}
                #__qqq_boot_panel .spinner{width:36px;height:36px;margin:0 auto 20px;
                border:3px solid #eee8d5;border-top-color:#268bd2;border-radius:50%;
                animation:__qqq_spin .8s linear infinite}
                #__qqq_boot_panel .stage{color:#586e75;font-size:14px;margin-bottom:20px;min-height:20px}
                #__qqq_boot_panel .bar-bg{background:#eee8d5;border-radius:8px;height:8px;overflow:hidden}
                #__qqq_boot_panel .bar-fg{background:linear-gradient(90deg,#268bd2,#2aa198);height:100%;width:0%;transition:width .3s ease}
                #__qqq_boot_panel .pct{color:#93a1a1;font-size:12px;margin-top:8px}
                @keyframes __qqq_spin{to{transform:rotate(360deg)}}
            `.replace(/\n\s*/g, "");
      const html = '<div id="__qqq_boot_panel"><div class="wrap"><div class="spinner"></div><div class="stage">\u6B63\u5728\u8FDE\u63A5\u670D\u52A1\u5668\u2026</div><div class="bar-bg"><div class="bar-fg" id="__qqq_boot_bar"></div></div><div class="pct" id="__qqq_boot_pct">0%</div></div></div>';
      wc.executeJavaScript(`
                try{
                    // \u2605 \u5F7B\u5E95\u9690\u85CF IDE \u5185\u5BB9 \u2014 \u4E0D\u662F\u906E\u7F69\uFF0C\u662F\u5B8C\u5168\u4E0D\u663E\u793A
                    var hideCSS=document.createElement("style");
                    hideCSS.id="__qqq_boot_hide";
                    hideCSS.textContent="html>body>:not(#__qqq_boot_panel){display:none!important}";
                    document.head.appendChild(hideCSS);
                    // \u6CE8\u5165\u9762\u677F
                    var panelCSS=document.createElement("style");
                    panelCSS.textContent=\`${css}\`;document.head.appendChild(panelCSS);
                    var d=document.createElement("div");
                    d.innerHTML=\`${html}\`;document.body.appendChild(d.firstElementChild);
                }catch(_){}
            `).catch(() => {
      });
    };
    const updateLoadingPanel = (stage, pct) => {
      writeLoadingStatus(pct + "|" + stage);
      wc.executeJavaScript(`
                try{
                    var s=document.getElementById("__qqq_boot_pct");
                    if(s&&s.parentElement){s.textContent="${pct}%"}
                    var b=document.getElementById("__qqq_boot_bar");
                    if(b){b.style.width="${pct}%"}
                    Array.from(document.querySelectorAll("#__qqq_boot_panel .stage")).forEach(function(e){e.textContent="${stage}"})
                }catch(_){}
            `.replace(/\n\s*/g, "")).catch(() => {
      });
    };
    const removeLoadingPanel = () => {
      if (panelTimer) {
        clearTimeout(panelTimer);
        panelTimer = null;
      }
      if (progressTickId) {
        clearInterval(progressTickId);
        progressTickId = null;
      }
      wc.executeJavaScript(`
                try{
                    var p=document.getElementById("__qqq_boot_panel");if(p)p.remove();
                    var h=document.getElementById("__qqq_boot_hide");if(h)h.remove();
                }catch(_){}
            `).catch(() => {
      });
    };
    const updateProgress = () => {
      const total = pendingReqs + doneReqs;
      if (total === 0) {
        return;
      }
      const pct = Math.min(94, Math.round(doneReqs / Math.max(total, 1) * 100));
      const stage = pct < 30 ? "\u6B63\u5728\u52A0\u8F7D\u9875\u9762\u7ED3\u6784\u2026" : pct < 60 ? "\u6B63\u5728\u52A0\u8F7D\u7EC4\u4EF6\u811A\u672C\u2026" : pct < 85 ? "\u6B63\u5728\u52A0\u8F7D\u6837\u5F0F\u8D44\u6E90\u2026" : "\u6B63\u5728\u521D\u59CB\u5316 IDE\u2026";
      updateLoadingPanel(stage, pct);
      if (pendingReqs === 0 && doneReqs > 0) {
        tryCooldown();
      }
    };
    let readyShown = false;
    const onAllReady = () => {
      if (readyShown) {
        return;
      }
      readyShown = true;
      if (progressTickId) {
        clearInterval(progressTickId);
        progressTickId = null;
      }
      if (panelTimer) {
        clearTimeout(panelTimer);
        panelTimer = null;
      }
      if (cooldownTimer) {
        clearTimeout(cooldownTimer);
        cooldownTimer = null;
      }
      wc.removeListener("did-start-navigation", onStartNav);
      wc.removeListener("did-navigate", onNavigate);
      wc.removeListener("dom-ready", onDomReady);
      wc.removeListener("did-finish-load", onFinish);
      wc.removeListener("did-stop-loading", onStopLoading);
      wc.removeListener("did-fail-load", onFail);
      bootLog("remote: all resources loaded + dom-ready \u2192 IDE ready");
      updateLoadingPanel("\u6B63\u5728\u542F\u52A8 IDE\u2026", 100);
      writeLoadingStatus("ready");
      finish(true, "live");
      setTimeout(() => {
        removeLoadingPanel();
        if (mainWindow2 && !mainWindow2.isDestroyed()) {
          mainWindow2.show();
          mainWindow2.focus();
        }
        bootLog("remote: panel removed, IDE shown");
      }, 400);
    };
    const cleanupWebRequest = () => {
      try {
        session2.webRequest.onBeforeRequest(null, null);
      } catch (_) {
      }
      try {
        session2.webRequest.onCompleted(null, null);
      } catch (_) {
      }
      try {
        session2.webRequest.onErrorOccurred(null, null);
      } catch (_) {
      }
    };
    const finish = (ok, mode) => {
      if (settled) {
        return;
      }
      settled = true;
      if (timeoutTimer) {
        clearTimeout(timeoutTimer);
        timeoutTimer = null;
      }
      if (!ok && mode === "fallback") {
        cleanupWebRequest();
        wc.removeListener("did-start-navigation", onStartNav);
        wc.removeListener("did-navigate", onNavigate);
        wc.removeListener("dom-ready", onDomReady);
        wc.removeListener("did-finish-load", onFinish);
        wc.removeListener("did-stop-loading", onStopLoading);
        wc.removeListener("did-fail-load", onFail);
        removeLoadingPanel();
        if (mainWindow2 && !mainWindow2.isDestroyed()) {
          mainWindow2.show();
          mainWindow2.focus();
        }
        try {
          wc.stop();
        } catch (_) {
        }
      }
      bootLog("remote: " + (ok ? "LOADED" : "FAILED") + " mode=" + mode);
      resolve3({ ok, mode });
    };
    const onStartNav = (_e, _url, _inFrame, _isMain) => {
      if (!_isMain) {
        return;
      }
      bootLog("remote: did-start-navigation " + _url);
    };
    const onNavigate = (_e, _url, httpCode) => {
      bootLog("remote: did-navigate http=" + httpCode);
      if (httpCode >= 200 && httpCode < 400) {
        if (!isDev) {
          injectLoadingPanel();
          updateLoadingPanel("\u6B63\u5728\u89E3\u6790\u9875\u9762\u2026", 5);
        }
        let lastPct = 5;
        let tickCount = 0;
        progressTickId = setInterval(() => {
          tickCount++;
          if (tickCount % 6 === 0 && !domReadyFired) {
            bootLog("webReq: heartbeat pending=" + pendingReqs + " done=" + doneReqs + " domReadyFired=" + domReadyFired + " tickPct=" + lastPct);
          }
          if (domReadyFired || pendingReqs === 0 && doneReqs > 0) {
            clearInterval(progressTickId);
            progressTickId = null;
            return;
          }
          lastPct = Math.min(88, lastPct + 6);
          const stage = lastPct < 35 ? "\u6B63\u5728\u52A0\u8F7D\u9875\u9762\u7ED3\u6784\u2026" : lastPct < 60 ? "\u6B63\u5728\u52A0\u8F7D\u7EC4\u4EF6\u811A\u672C\u2026" : lastPct < 80 ? "\u6B63\u5728\u52A0\u8F7D\u6837\u5F0F\u8D44\u6E90\u2026" : "\u6B63\u5728\u521D\u59CB\u5316 IDE\u2026";
          updateLoadingPanel(stage, lastPct);
        }, 2500);
        panelTimer = setTimeout(() => {
          bootLog("remote: ultimate fallback after 10min \u2014 force show (pending=" + pendingReqs + " done=" + doneReqs + ")");
          updateLoadingPanel("\u5373\u5C06\u5B8C\u6210\u2026", 95);
          writeLoadingStatus("ready");
          removeLoadingPanel();
          if (mainWindow2 && !mainWindow2.isDestroyed()) {
            mainWindow2.show();
            mainWindow2.focus();
          }
        }, 6e5);
        finish(true, "live");
      } else {
        finish(false, "fallback");
      }
    };
    const onDomReady = () => {
      bootLog("remote: dom-ready");
      domReadyFired = true;
      if (doneReqs === 0) {
        bootLog("remote: dom-ready fallback (no requests tracked) \u2192 90%");
        updateLoadingPanel("\u6B63\u5728\u521D\u59CB\u5316 IDE\u2026", 90);
      }
      if (pendingReqs === 0) {
        onAllReady();
      }
    };
    const onFinish = () => {
      bootLog("remote: did-finish-load (onload)");
    };
    const onStopLoading = () => {
      bootLog("remote: did-stop-loading");
      if (progressTickId) {
        clearInterval(progressTickId);
        progressTickId = null;
      }
      onAllReady();
    };
    const onFail = (_e, code, desc, validatedURL, isMain) => {
      if (!isMain) {
        return;
      }
      bootLog("remote: did-fail-load code=" + code + " desc=" + desc + " url=" + validatedURL);
      finish(false, "fallback");
    };
    if (timeoutMs > 0) {
      timeoutTimer = setTimeout(() => {
        bootLog("remote: TIMEOUT (did-navigate never fired) after " + timeoutMs + "ms");
        finish(false, "fallback");
      }, timeoutMs);
    }
    wc.on("did-start-navigation", onStartNav);
    wc.on("did-navigate", onNavigate);
    wc.on("dom-ready", onDomReady);
    wc.on("did-finish-load", onFinish);
    wc.on("did-stop-loading", onStopLoading);
    wc.on("did-fail-load", onFail);
    session2.webRequest.onBeforeRequest(onBeforeReq);
    session2.webRequest.onCompleted(onReqDone);
    session2.webRequest.onErrorOccurred(onReqErr);
    let loadRetries = 0;
    const doLoad = () => {
      mainWindow2.loadURL(bootConfig2.url).catch((err) => {
        const msg = err && err.message || String(err);
        bootLog("remote: loadURL error \u2014 " + msg);
        const retryable = /ERR_FAILED|ERR_CONNECTION_REFUSED|ERR_TIMED_OUT|ERR_CONNECTION_RESET/i.test(msg);
        if (retryable && loadRetries < 5) {
          loadRetries++;
          bootLog("remote: retry " + loadRetries + "/5 in 3s\u2026");
          setTimeout(doLoad, 3e3);
          return;
        }
        finish(false, "fallback");
      });
    };
    doLoad();
  });
}
function getWebappBaseUrl(portableRoot, bootConfig2, isDev) {
  if (isDev) {
    return "http://127.0.0.1:8090/qqqide/";
  }
  const webappDir = ensureLocalWebapp(portableRoot);
  if (webappDir) {
    registerWebappProtocol(webappDir);
    return WEBAPP_PROTOCOL + "://app/qqqide/index.html";
  }
  return bootConfig2.url;
}
async function bootSequence(mainWindow2, bootConfig2, portableRoot, portableCache, isDev, isOffline, setLastBootMode2, getLastBootMode2) {
  const bootT0 = Date.now();
  initBootLog(path2.join(portableRoot, "Data", "Logs"));
  try {
    fs2.unlinkSync(path2.join(portableRoot, "loading-status"));
  } catch (_) {
  }
  writeBootStatus(portableRoot, "0|\u6B63\u5728\u542F\u52A8\u2026");
  const DEV_URL = "http://127.0.0.1:8090/qqqide/";
  if (isDev) {
    bootConfig2.url = DEV_URL;
    bootConfig2.healthTimeoutMs = 500;
    bootLog("dev: forced local URL \u2192 " + DEV_URL);
  }
  bootLog("url: " + bootConfig2.url);
  let effectiveUrl = getWebappBaseUrl(portableRoot, bootConfig2, isDev);
  if (effectiveUrl.startsWith(WEBAPP_PROTOCOL)) {
    bootLog("local: using bundled webapp (no network needed for first boot)");
  } else {
    bootLog("local: no webapp found, will load from remote");
  }
  const isLocal = effectiveUrl.startsWith(WEBAPP_PROTOCOL);
  const bootVersion = readLocalWebappVersion(portableRoot) || readLocalShellVersion(portableRoot) || APP_VERSION;
  const sep2 = effectiveUrl.includes("?") ? "&" : "?";
  effectiveUrl = effectiveUrl + sep2 + "_v=" + encodeURIComponent(bootVersion);
  bootLog("cache-bust: version=" + bootVersion);
  if (!isLocal) {
    try {
      await loadStaticFallback(mainWindow2, bootConfig2, portableRoot, "connecting");
    } catch (e) {
      bootLog("seq: initial fallback crashed \u2014 " + (e && e.message || String(e)));
    }
    bootLog("phase: fallback-shown " + (Date.now() - bootT0) + "ms");
  } else {
    bootLog("local: skipping fallback (instant boot)");
  }
  checkAndDownloadShellUpdate(bootConfig2, portableRoot, portableCache, isDev, isOffline).then((updated) => {
    if (updated) {
      console.log("[boot] shell update staged \u2014 will apply on next restart");
    }
  }).catch(() => {
  });
  const healthy = isLocal ? false : isDev ? true : await healthCheck(bootConfig2.url, bootConfig2.healthTimeoutMs, isOffline);
  if (isLocal) {
    bootLog("seq: local boot, skipping health check");
  } else if (healthy) {
    bootLog("seq: server OK (" + (Date.now() - bootT0) + "ms)");
  } else {
    bootLog("seq: server unreachable (" + (Date.now() - bootT0) + "ms)");
  }
  const REMOTE_TIMEOUT_MS = 3e4;
  const loadConfig = { ...bootConfig2, url: effectiveUrl };
  const { ok, mode } = await loadRemoteWithCacheGuard(mainWindow2, loadConfig, REMOTE_TIMEOUT_MS, isDev, portableRoot);
  const bootT3 = Date.now();
  if (ok) {
    bootLog("seq: remote OK, boot complete \u2014 total " + (bootT3 - bootT0) + "ms");
    bootCompleted = true;
    setLastBootMode2(mode);
    if (!isDev) {
      const _url = bootConfig2.url;
      const _root = portableRoot;
      setTimeout(() => {
        backgroundCheckWebappUpdate({ ...bootConfig2, url: _url }, _root).catch(() => {
        });
      }, 2e4);
    }
  } else {
    const reason = healthy ? "load-failed" : "no-network-no-cache";
    bootLog("seq: FAILED \u2014 staying on fallback, reason=" + reason + " total " + (bootT3 - bootT0) + "ms");
    try {
      await loadStaticFallback(mainWindow2, bootConfig2, portableRoot, reason);
    } catch (e) {
      bootLog("seq: loadStaticFallback crashed \u2014 " + (e && e.message || String(e)));
    }
    setLastBootMode2("fallback");
  }
}

// shell/window-manager.ts
var import_electron2 = require("electron");
var path7 = __toESM(require("path"));
var http4 = __toESM(require("http"));

// shell/devtools-inject.ts
var import_electron = require("electron");
var path3 = __toESM(require("path"));
var fs3 = __toESM(require("fs"));
var _pushTimer = null;
var _saveLock = false;
var _diagLogged = false;
var INJECT_JS = `
(function(){
if(window.__qqq_dt_btns_installed)return;
window.__qqq_dt_btns_installed=true;

window.__QQQ_DIAG = { probes: 0, found: false, path: '', sdkKeys: [], uiKeys: [] };

// \u2500\u2500 \u91CD\u8BD5\u63A2\u9488 \u2500\u2500
var _cm=null,_cmPath='',_probes=0;
function _probeOnce(){
  _probes++; window.__QQQ_DIAG.probes=_probes;
  function _hasMsgs(o){try{var m=o.messages();return Array.isArray(m)&&m.length>0;}catch(e){return false;}}
  if(_probes===1){
    try{window.__QQQ_DIAG.sdkKeys=Object.keys(self.SDK||{});}catch(e){}
    try{window.__QQQ_DIAG.uiKeys=Object.keys(self.UI||{});}catch(e){}
    try{window.__QQQ_DIAG.hasSave=typeof InspectorFrontendHost.save==='function';}catch(e){}
  }
  try{if(self.SDK&&self.SDK.consoleModel&&_hasMsgs(self.SDK.consoleModel)){_cm=self.SDK.consoleModel;_cmPath='SDK.consoleModel';}}catch(e){}
  if(!_cm)try{for(var k in self.SDK){try{if(self.SDK[k]&&self.SDK[k].consoleModel&&_hasMsgs(self.SDK[k].consoleModel)){_cm=self.SDK[k].consoleModel;_cmPath='SDK.'+k+'.consoleModel';break;}}catch(e){}}}catch(e){}
  if(!_cm)try{
    var _seen=new Set();
    function _walk(o,d,p){
      if(d>3||!o||typeof o!=='object'||_seen.has(o))return false;_seen.add(o);
      if(_hasMsgs(o)){_cm=o;_cmPath=p;return true;}
      for(var kk in o){try{if(o[kk]&&typeof o[kk]==='object'&&_walk(o[kk],d+1,p+'.'+kk))return true;}catch(e){}}
      return false;
    }
    if(self.SDK&&_walk(self.SDK,0,'SDK')){}
    else if(self.UI&&_walk(self.UI,0,'UI')){}
    else _walk(self,0,'self');
  }catch(e){}

  if(_cm){
    window.__QQQ_DIAG.found=true; window.__QQQ_DIAG.path=_cmPath;
    window.__QQQ_CM_FOUND=true; window.__QQQ_CM_PATH=_cmPath;
    _dumpMsgStructs(); _dumpNetMsg(); _dumpPanelStruct();
    return;
  }
  window.__QQQ_CM_FOUND=false;
  if(_probes<60) setTimeout(_probeOnce, 500);
}

function _dumpMsgStructs(){
  try{
    var ms=_cm.messages(); var structs=[];
    for(var i=0;i<Math.min(ms.length,10);i++){
      var m=ms[i],keys=[],vals={};
      try{for(var k in m){try{keys.push(k);var v=m[k];vals[k]=typeof v==='string'?v.slice(0,120):typeof v==='number'?v:typeof v==='boolean'?v:typeof v==='object'?(Array.isArray(v)?'Array['+v.length+']':'Object{'+Object.keys(v||{}).join(',')+'}'):typeof v;}catch(e){}}}catch(e){}
      structs.push({i:i,source:m.source,level:m.level,keys:keys.slice(0,25),vals:vals,rawText:(m.messageText||'').slice(0,150)});
    }
    window.__QQQ_MSG_STRUCTS=structs;
  }catch(e){window.__QQQ_MSG_STRUCTS=['err: '+(e.message||e)];}
}

function _dumpPanelStruct(){
  try{
    var info={};
    if(self.UI&&self.UI.inspectorView){try{info._panels=Object.keys(self.UI.inspectorView._panels||{}).join(',');}catch(e){}}
    try{var cp=self.UI.panels&&self.UI.panels.console;if(cp){info.consolePanel=true;}}catch(e){}
    window.__QQQ_PANEL_INFO=info;
  }catch(e){window.__QQQ_PANEL_INFO=['err: '+(e.message||e)];}
}

function _dumpNetMsg(){
  try{
    var ms=_cm.messages(),nets=[];
    for(var i=0;i<ms.length;i++){
      var m=ms[i]; if(m.source!=='network')continue;
      var p=[];
      try{var params=m.parameters||[];for(var j=0;j<params.length;j++)p.push({t:typeof params[j].value,v:(params[j].value||'').slice(0,80)});}catch(e){}
      nets.push({i:i,text:(m.messageText||'').slice(0,200),url:(m.url||'').slice(0,200),line:m.line,params:p,hasCfs:!!(m.stackTrace&&m.stackTrace.callFrames&&m.stackTrace.callFrames.length)});
      if(nets.length>=10)break;
    }
    window.__QQQ_NET_MSGS=nets;
  }catch(e){window.__QQQ_NET_MSGS=['err: '+(e.message||e)];}
}

_probeOnce();

// \u2500\u2500 Hijack save \u2500\u2500
(function(){
  try{
    if(!InspectorFrontendHost||!InspectorFrontendHost.save) return;
    var _os=InspectorFrontendHost.save;
    InspectorFrontendHost.save=function(url,content,forceSaveAs){
      if(typeof content==='string'&&content.length>10){window.__QQQ_HIJACK_CONTENT=content;window.__QQQ_HIJACK_TS=Date.now();}
      try{return _os.apply(this,arguments);}catch(e){}
    };
    window.__QQQ_DIAG.hijackInstalled=true;
  }catch(e){window.__QQQ_DIAG.hijackError=e&&e.message;}
})();

// \u2500\u2500 _fmtMsg \u2014 \u6838\u5FC3\u683C\u5F0F\u5316 \u2500\u2500
function _fmtMsg(m){
  if(!m)return'';
  if(m.level==='verbose')return'';
  if(m.source==='violation'||m.source==='deprecation'||m.source==='recommendation'||m.source==='intervention')return'';
  var txt=m.messageText||'';
  // \u2605 \u63D0\u53D6\u72B6\u6001\u7801\uFF08\u5728\u53C2\u6570\u62FC\u63A5\u4E4B\u524D\uFF0C\u539F\u59CB txt \u6700\u53EF\u9760\uFF09
  var _statusCode='';
  var _cms=txt.match(/status ofs+(d+)/i);if(_cms)_statusCode=_cms[1];
  // \u62FC\u63A5\u6240\u6709\u53C2\u6570
  try{var pm=m.parameters||[];for(var pi=1;pi<pm.length;pi++){var pv=pm[pi];var pvs=typeof pv.value==='string'?pv.value:typeof pv==='string'?pv:'';if(pvs)txt+=' '+pvs;}}catch(e){}
  // \u9012\u5F52\u5C55\u5F00\u6808\u5E27\uFF08parent \u94FE\u542B\u5F02\u6B65\u5E27\uFF09
  function _flat(st){var a=[];if(!st)return a;a=(st.callFrames||[]).slice();if(st.parent){var pa=_flat(st.parent);for(var x=0;x<pa.length;x++)a.push(pa[x]);}return a;}
  var cfs=_flat(m.stackTrace);
  var lines=[];

  if(m.source==='network'){
    var nUrl=(m.url||'').replace(/\\\\/g,'/');
    // \u2605 HTTP \u65B9\u6CD5: \u4E09\u8DEF\u63A2\u6D4B
    var method='';
    // A: cfs[0].functionName\uFF08XHR \u573A\u666F\uFF0C\u9996\u5E27\u5373 'GET'/'POST'\uFF09
    if(!method&&cfs.length>0){var fn0=(cfs[0].functionName||'').toUpperCase();if(/^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)$/.test(fn0))method=fn0+' ';}
    // B: m.parameters \u2014 fetch(url, {method:'POST'}) \u573A\u666F
    if(!method){try{var _pm=m.parameters||[];for(var _pi=0;_pi<_pm.length;_pi++){var _v=_pm[_pi],_vs=typeof _v.value==='string'?_v.value:typeof _v==='string'?_v:'';
      if(/^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)$/i.test(_vs)){method=_vs.toUpperCase()+' ';break;}
      // \u53C2\u6570\u5BF9\u8C61\u4E2D\u5305\u542B "method":"POST"
      try{if(_vs.indexOf('method')!==-1){var _mm=_vs.match(/"method"\\s*:\\s*"(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)"/i);if(_mm){method=_mm[1].toUpperCase()+' ';break;}}}catch(e){}
    }}catch(e){}}
    // C: messageText \u5F00\u5934
    if(!method){var _mt=txt.match(/^(GET|POST|PUT|DELETE|PATCH)\\s/);if(_mt)method=_mt[1]+' ';}
    // D: \u515C\u5E95\u63A8\u65AD\uFF08/api/ \u8DEF\u5F84\u591A\u4E3A POST\uFF09
    if(!method)method='GET ';

    // \u6E90\u6587\u4EF6\u5E27: \u8DF3\u8FC7\u5E27\u540D\u4E3A HTTP \u65B9\u6CD5\u7684\u5E27
    var srcFile='',srcLine=0;
    for(var _fi=0;_fi<cfs.length;_fi++){
      var _ffn=(cfs[_fi].functionName||'').toUpperCase();
      var _furl=((cfs[_fi].url||'').replace(/\\\\/g,'/').split('/').pop())||cfs[_fi].url||'';
      if(!/^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)$/.test(_ffn)&&_furl&&!_furl.startsWith('VM')){srcFile=_furl;srcLine=cfs[_fi].lineNumber||0;break;}
    }
    if(!srcFile&&cfs.length>0){var _fz=cfs[cfs.length-1];srcFile=((_fz.url||'').replace(/\\\\/g,'/').split('/').pop())||_fz.url||'';srcLine=_fz.lineNumber||0;}

    // \u6E05\u6D17\u6587\u672C: \u4E0D\u540C\u9519\u8BEF\u7C7B\u578B\u4E0D\u540C\u683C\u5F0F
    var cleanTxt=txt;
    if(/^Failed to load resource:s*/i.test(txt)){cleanTxt=txt.replace(/^Failed to load resource:s*/i,'');}
    else if(_statusCode){cleanTxt=_statusCode;}

    lines.push((srcFile&&srcLine?srcFile+':'+srcLine+'          ':'')+method+nUrl+' '+cleanTxt);
    for(var ni=0;ni<cfs.length;ni++){
      var nc=cfs[ni];
      lines.push('    '+(nc.functionName||'(anonymous)')+' @ '+(((nc.url||'').replace(/\\\\/g,'/').split('/').pop())||nc.url)+':'+(nc.lineNumber||0));
    }
    return lines.join('\\n');
  }

  if(cfs.length>0){
    var f0=cfs[0];
    var fu=((f0.url||'').replace(/\\\\/g,'/').split('/').pop())||f0.url;
    lines.push((fu?fu+':'+(f0.lineNumber||0)+' ':'')+txt);
    // \u4EC5 warning/error \u8F93\u51FA\u5B8C\u6574\u6808\u5E27\uFF08\u4E0E\u53C2\u8003\u5BF9\u9F50\uFF1Alog/info \u4E0D\u8F93\u51FA\u6808\uFF09
    var _lv=(m.level||'').toLowerCase();
    if(_lv==='warning'||_lv==='error'||_lv==='warn'){
      for(var i=1;i<cfs.length;i++){
        var cf=cfs[i];
        lines.push('    '+(cf.functionName||'(anonymous)')+' @ '+(((cf.url||'').replace(/\\\\/g,'/').split('/').pop())||cf.url)+':'+(cf.lineNumber||0));
      }
    }
  }else{
    var uu=(m.url||'').replace(/\\\\/g,'/'),file=uu.split('/').pop()||uu,ln=m.line||0;
    lines.push((file&&ln?file+':'+ln+' ':'')+txt);
  }
  return lines.join('\\n');
}

// \u2500\u2500 \u5168\u91CF\u5BFC\u51FA \u2500\u2500
window._qqqGetConsoleText=function(){
  if(_cm){try{var ms=_cm.messages();if(ms&&ms.length){
    var out=[],pass=0,skipV=0,skipS=0;
    for(var i=0;i<ms.length;i++){
      var r=_fmtMsg(ms[i]);
      if(r){out.push(r);pass++;}else{if(ms[i].level==='verbose')skipV++;else skipS++;}
    }
    window.__QQQ_CM_STATS={total:ms.length,pass:pass,skipVerbose:skipV,skipSource:skipS};
    if(pass<3&&ms.length>0){var raw=[];for(var ri=0;ri<Math.min(ms.length,20);ri++){var rm=ms[ri];raw.push(ri+':'+rm.source+'/'+rm.level+' t='+(rm.messageText||'').slice(0,60));}window.__QQQ_CM_RAW=raw;}
    return out.join('\\n\\n');
  }}catch(e){return'// CM err: '+(e.message||e);}}
  if(window.__QQQ_HIJACK_CONTENT) return window.__QQQ_HIJACK_CONTENT;
  if(window.__QQQ_CONSOLE_READY&&window.__QQQ_CONSOLE_B64){
    try{var b=atob(window.__QQQ_CONSOLE_B64),u=new Uint8Array(b.length);for(var j=0;j<b.length;j++)u[j]=b.charCodeAt(j);return new TextDecoder('utf-8').decode(u);}catch(e){return window.__QQQ_CONSOLE_B64;}
  }
  return'';
};

// \u2500\u2500 UI \u2500\u2500
function _toast(m){
  var el=document.getElementById('qqq-dt-toast');if(!el)return;
  el.textContent=m;el.style.opacity='1';
  clearTimeout(_toast._tid);_toast._tid=setTimeout(function(){el.style.opacity='0'},1800);
}
var s=document.createElement('style');
s.textContent=[
  '#qqq-dt-btns{position:fixed;bottom:8px;right:8px;display:flex;gap:4px;z-index:999999;opacity:0.25;transition:opacity 0.15s}',
  '#qqq-dt-btns:hover{opacity:1}',
  '#qqq-dt-btns button{padding:3px 9px;border:1px solid #666;border-radius:3px;background:#1e1e1e;color:#ccc;font-size:11px;cursor:pointer;font-family:system-ui,sans-serif}',
  '#qqq-dt-btns button:hover{background:#333;border-color:#aaa;color:#fff}',
  '#qqq-dt-toast{position:fixed;bottom:36px;right:8px;padding:3px 8px;border-radius:3px;background:rgba(0,0,0,0.85);color:#fff;font-size:10px;z-index:999999;pointer-events:none;opacity:0;transition:opacity 0.2s;font-family:system-ui,sans-serif}'
].join('\\n');
document.head.appendChild(s);
var b=document.createElement('div');b.id='qqq-dt-btns';
b.innerHTML='<button id="qqq-dt-copy">\\u{1F4CB}\\u590D\\u5236</button><button id="qqq-dt-save">\\u{1F4BE}\\u53E6\\u5B58\\u4E3A</button>';
var e=document.createElement('div');e.id='qqq-dt-toast';
document.body.appendChild(b);document.body.appendChild(e);
document.getElementById('qqq-dt-copy').onclick=function(){
  var t=window._qqqGetConsoleText().replace(/\\n+$/,'').replace(/^\\n+/,'');if(!t){_toast('\\u65E0\\u5185\\u5BB9');return;}
  var ta=document.createElement('textarea');ta.value=t;ta.style.cssText='position:fixed;left:-9999px;top:0';
  document.body.appendChild(ta);ta.select();
  try{document.execCommand('copy');_toast('\\u5DF2\\u590D\\u5236 '+t.split('\\n').length+'\\u884C');}catch(ex){_toast('\\u5931\\u8D25');}
  document.body.removeChild(ta);
};
document.getElementById('qqq-dt-save').onclick=function(){
  window.__QQQ_CONSOLE_REQUEST_SAVE=true;_toast('\\u6B63\\u5728\\u4FDD\\u5B58...');
};
})();`;
async function _mergedText(wc, dwc, getText) {
  try {
    if (!dwc.isDestroyed()) {
      const cmFound = await dwc.executeJavaScript("!!window.__QQQ_CM_FOUND");
      const dtText = await dwc.executeJavaScript("window._qqqGetConsoleText&&window._qqqGetConsoleText()");
      if (dtText && typeof dtText === "string" && (cmFound || dtText.split("\n").filter(Boolean).length >= 3)) {
        return dtText;
      }
    }
  } catch {
  }
  const cdp = getText();
  if (cdp) {
    const cdpLines = cdp.split("\n").filter(Boolean);
    if (cdpLines.length >= 5)
      return cdp;
  }
  const parts = [];
  try {
    const r = await wc.executeJavaScript('((window.top||window).__qqq_console_lines||[]).join("\\n")');
    if (r)
      parts.push(r);
  } catch {
  }
  if (cdp)
    parts.push(cdp);
  return parts.join("\n");
}
function injectDevToolsConsoleButtons(dwc, wc, getText, mw) {
  if (dwc.isDestroyed())
    return;
  console.log("[devtools-inject] injecting v14.5 buttons...");
  dwc.executeJavaScript(INJECT_JS).then(() => {
    _startPushLoop(wc, dwc, getText, mw);
  }).catch((err) => {
    console.log("[devtools-inject] inject failed:", (err == null ? void 0 : err.message) || err);
  });
}
function _startPushLoop(wc, dwc, getText, mw) {
  if (_pushTimer)
    clearInterval(_pushTimer);
  _pushTimer = setInterval(async () => {
    if (dwc.isDestroyed() || wc.isDestroyed()) {
      if (_pushTimer) {
        clearInterval(_pushTimer);
        _pushTimer = null;
      }
      return;
    }
    try {
      const ws = await dwc.executeJavaScript("!!window.__QQQ_CONSOLE_REQUEST_SAVE");
      if (ws && !_saveLock) {
        _saveLock = true;
        dwc.executeJavaScript("window.__QQQ_CONSOLE_REQUEST_SAVE=false").catch(() => {
        });
        try {
          const text = await _mergedText(wc, dwc, getText);
          if (!text) {
            _saveLock = false;
            return;
          }
          let pr = "";
          try {
            pr = await wc.executeJavaScript('(window._workspaceRoot||"")');
          } catch {
          }
          const now = /* @__PURE__ */ new Date();
          const p = (n) => n < 10 ? "0" + n : "" + n;
          const ts = now.getFullYear() + "-" + p(now.getMonth() + 1) + "-" + p(now.getDate()) + "_" + p(now.getHours()) + "-" + p(now.getMinutes()) + "-" + p(now.getSeconds());
          const defPath = pr ? path3.join(pr, "logs", "console_" + ts + ".log") : "console_" + ts + ".log";
          const result = await import_electron.dialog.showSaveDialog(mw, { title: "\u4FDD\u5B58\u63A7\u5236\u53F0\u65E5\u5FD7", defaultPath: defPath, filters: [{ name: "\u65E5\u5FD7\u6587\u4EF6", extensions: ["log"] }] });
          if (!result.canceled && result.filePath) {
            fs3.mkdirSync(path3.dirname(result.filePath), { recursive: true });
            fs3.writeFileSync(result.filePath, text, "utf-8");
          }
        } catch {
        }
        _saveLock = false;
      }
    } catch {
    }
    if (!_diagLogged) {
      _diagLogged = true;
      try {
        const diag2 = await dwc.executeJavaScript("window.__QQQ_DIAG&&JSON.stringify(window.__QQQ_DIAG)");
        if (diag2) {
          const d = JSON.parse(diag2);
          try {
            const outPath = path3.join("E:/s/wol/py/qqq-shell-v2/qqq/logs", "devtools-diag.json");
            fs3.mkdirSync(path3.dirname(outPath), { recursive: true });
            fs3.writeFileSync(outPath, JSON.stringify(d, null, 2), "utf-8");
            const keys = ["MSG_STRUCTS", "PANEL_INFO", "NET_MSGS", "CM_STATS", "CM_RAW"];
            for (const k of keys) {
              try {
                const v = await dwc.executeJavaScript("window.__QQQ_" + k + "&&JSON.stringify(window.__QQQ_" + k + ")");
                if (v)
                  fs3.writeFileSync(path3.join("E:/s/wol/py/qqq-shell-v2/qqq/logs", "devtools-" + k.toLowerCase().replace(/_/g, "-") + ".json"), v, "utf-8");
              } catch {
              }
            }
          } catch {
          }
        }
      } catch {
      }
    }
    try {
      let text = await _mergedText(wc, dwc, getText);
      if (!text)
        text = "";
      if (text.length > 2 * 1024 * 1024) {
        text = "...(truncated from start)\\n" + text.slice(-2 * 1024 * 1024);
      }
      const b64 = Buffer.from(text, "utf-8").toString("base64");
      if (b64.length < 50 * 1024 * 1024) {
        dwc.executeJavaScript('window.__QQQ_CONSOLE_B64="' + b64 + '";window.__QQQ_CONSOLE_READY=true').catch(() => {
        });
      }
    } catch {
    }
  }, 2e3);
  if (_pushTimer && typeof _pushTimer === "object" && "unref" in _pushTimer)
    _pushTimer.unref();
}

// shell/window-manager.ts
init_py_broker();

// shell/cdp-sniffer.ts
var import_child_process4 = require("child_process");
var fs6 = __toESM(require("fs"));
var path6 = __toESM(require("path"));
var os2 = __toESM(require("os"));
var crypto = __toESM(require("crypto"));
var http3 = __toESM(require("http"));
var import_url2 = require("url");
var SimpleWebSocket = class {
  constructor(url) {
    this.listeners = { open: [], message: [], error: [] };
    this.socket = null;
    this.url = url;
    this.connect();
  }
  on(event, cb) {
    if (this.listeners[event])
      this.listeners[event].push(cb);
  }
  send(data) {
    if (!this.socket)
      return;
    const payload = Buffer.from(data);
    const length = payload.length;
    let headerLen = 2;
    if (length <= 125) {
    } else if (length <= 65535) {
      headerLen = 4;
    } else {
      headerLen = 10;
    }
    const frame = Buffer.alloc(headerLen + 4 + length);
    frame[0] = 129;
    if (length <= 125) {
      frame[1] = 128 | length;
    } else if (length <= 65535) {
      frame[1] = 128 | 126;
      frame.writeUInt16BE(length, 2);
    } else {
      frame[1] = 128 | 127;
      frame.writeBigUInt64BE(BigInt(length), 2);
    }
    const mask = new Uint8Array(4);
    crypto.randomFillSync(mask);
    for (let i = 0; i < 4; i++)
      frame[headerLen + i] = mask[i];
    for (let i = 0; i < length; i++) {
      frame[headerLen + 4 + i] = payload[i] ^ mask[i % 4];
    }
    this.socket.write(frame);
  }
  close() {
    if (this.socket)
      this.socket.destroy();
    this.socket = null;
  }
  connect() {
    const u = new import_url2.URL(this.url);
    const options = {
      host: u.hostname,
      port: u.port ? parseInt(u.port, 10) : 80,
      path: u.pathname + u.search,
      headers: {
        "Connection": "Upgrade",
        "Upgrade": "websocket",
        "Sec-WebSocket-Version": "13",
        "Sec-WebSocket-Key": crypto.randomBytes(16).toString("base64")
      }
    };
    const req = http3.request(options);
    req.on("upgrade", (res, socket, _head) => {
      this.socket = socket;
      this.listeners.open.forEach((cb) => cb());
      let buffer = Buffer.alloc(0);
      socket.on("data", (chunk) => {
        buffer = Buffer.concat([buffer, chunk]);
        while (true) {
          if (buffer.length < 2)
            break;
          const firstByte = buffer[0];
          const opCode = firstByte & 15;
          const secondByte = buffer[1];
          const isMasked = (secondByte & 128) !== 0;
          let payloadLen = secondByte & 127;
          let offset = 2;
          if (payloadLen === 126) {
            if (buffer.length < offset + 2)
              break;
            payloadLen = buffer.readUInt16BE(offset);
            offset += 2;
          } else if (payloadLen === 127) {
            if (buffer.length < offset + 8)
              break;
            payloadLen = Number(buffer.readBigUInt64BE(offset));
            offset += 8;
          }
          let maskKey = null;
          if (isMasked) {
            if (buffer.length < offset + 4)
              break;
            maskKey = buffer.slice(offset, offset + 4);
            offset += 4;
          }
          if (buffer.length < offset + payloadLen)
            break;
          const payload = buffer.slice(offset, offset + payloadLen);
          if (isMasked && maskKey) {
            for (let i = 0; i < payloadLen; i++)
              payload[i] ^= maskKey[i % 4];
          }
          if (opCode === 1) {
            const str = payload.toString("utf8");
            this.listeners.message.forEach((cb) => cb(str));
          }
          buffer = buffer.slice(offset + payloadLen);
        }
      });
    });
    req.on("error", (e) => this.listeners.error.forEach((cb) => cb(e)));
    req.end();
  }
};
function findBrowserPath() {
  const platform3 = process.platform;
  const commonPaths = [];
  if (platform3 === "win32") {
    const home = os2.homedir();
    commonPaths.push(
      "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
      "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
      "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
      "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
      path6.join(home, "AppData\\Local\\Google\\Chrome\\Application\\chrome.exe"),
      path6.join(home, "AppData\\Local\\Microsoft\\Edge\\Application\\msedge.exe")
    );
  } else if (platform3 === "darwin") {
    commonPaths.push(
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
    );
  } else {
    commonPaths.push(
      "/usr/bin/google-chrome",
      "/usr/bin/chromium",
      "/usr/bin/microsoft-edge"
    );
  }
  for (const p of commonPaths) {
    if (fs6.existsSync(p))
      return p;
  }
  if (process.env.CHROME_PATH && fs6.existsSync(process.env.CHROME_PATH))
    return process.env.CHROME_PATH;
  if (process.env.EDGE_PATH && fs6.existsSync(process.env.EDGE_PATH))
    return process.env.EDGE_PATH;
  return null;
}
function validateBrowserPath(exePath) {
  if (!exePath || typeof exePath !== "string")
    return false;
  try {
    const r = (0, import_child_process4.spawn)(exePath, ["--version"], { windowsHide: true, timeout: 5e3 });
    return true;
  } catch {
    return false;
  }
}
async function getDebugUrl(port) {
  const resp = await new Promise((resolve3, reject) => {
    http3.get(`http://127.0.0.1:${port}/json/version`, (res) => {
      let data = "";
      res.on("data", (chunk) => data += chunk);
      res.on("end", () => resolve3({ statusCode: res.statusCode || 0, data }));
    }).on("error", reject);
  });
  if (resp.statusCode !== 200)
    throw new Error(`CDP debug endpoint returned ${resp.statusCode}`);
  const parsed = JSON.parse(resp.data);
  if (!parsed.webSocketDebuggerUrl)
    throw new Error("No webSocketDebuggerUrl in CDP response");
  return parsed.webSocketDebuggerUrl;
}
var _CdpSniffer = class _CdpSniffer {
  constructor(appRoot) {
    this.appRoot = appRoot;
    this.browserProcess = null;
    this.ws = null;
    this.tmpDir = "";
    this.nextId = 1e3;
    this.capturedVideos = [];
    this.sessions = /* @__PURE__ */ new Set();
    this.keepAliveTimers = [];
    this.log = () => {
    };
  }
  /** Set custom browser path globally. */
  static setCustomBrowserPath(p) {
    _CdpSniffer.customBrowserPath = p;
  }
  static getCustomBrowserPath() {
    return _CdpSniffer.customBrowserPath;
  }
  /** Start sniffing on a target URL. Returns when CDP is connected. */
  async start(targetUrl, onLog, options = {}) {
    this.log = onLog || (() => {
    });
    const browserPath = _CdpSniffer.customBrowserPath || findBrowserPath();
    if (!browserPath)
      throw new Error("\u672A\u627E\u5230 Chrome \u6216 Edge \u6D4F\u89C8\u5668");
    const port = 9222 + Math.floor(Math.random() * 100);
    let userDataDir = options.userDataDir;
    if (!userDataDir) {
      userDataDir = path6.join(this.appRoot, "Data", "chrome-user-data");
      try {
        fs6.mkdirSync(userDataDir, { recursive: true });
      } catch {
      }
    }
    this.tmpDir = userDataDir;
    const args = [
      `--remote-debugging-port=${port}`,
      `--user-data-dir=${userDataDir}`,
      "--no-first-run",
      "--no-default-browser-check",
      "--disable-infobars",
      "--disable-blink-features=AutomationControlled",
      "--new-window",
      "--disable-gpu",
      "--no-sandbox",
      targetUrl
    ];
    this.log(`[CDP] \u542F\u52A8\u6D4F\u89C8\u5668: ${browserPath} ${args.join(" ")}`);
    this.browserProcess = (0, import_child_process4.spawn)(browserPath, args, { windowsHide: true });
    this.capturedVideos = [];
    this.sessions = /* @__PURE__ */ new Set();
    const wsUrl = await getDebugUrl(port);
    this.log(`[CDP] \u8FDE\u63A5 WebSocket: ${wsUrl}`);
    this.ws = new SimpleWebSocket(wsUrl);
    return new Promise((resolve3, reject) => {
      if (!this.ws)
        return reject(new Error("WebSocket not created"));
      this.ws.on("open", () => {
        this.sendCommand("Target.setDiscoverTargets", { discover: true });
        this.sendCommand("Target.setAutoAttach", {
          autoAttach: true,
          waitForDebuggerOnStart: false,
          flatten: true
        });
        resolve3();
      });
      this.ws.on("message", (data) => {
        try {
          const msg = JSON.parse(data);
          if (msg.error) {
            this.log(`[CDP Error] ${JSON.stringify(msg)}`);
            return;
          }
          if (msg.id && msg.id >= 100) {
            const r = msg.result;
            if (r && Object.keys(r).length === 0) {
            } else {
              const raw = JSON.stringify(msg);
              if (raw.length > 200) {
                this.log(`[CDP] Command Response ${msg.id}: ${raw.slice(0, 200)}...`);
              }
            }
          }
          if (msg.method === "Target.targetCreated" || msg.method === "Target.targetInfoChanged") {
            const target = msg.params.targetInfo;
            if (target.type === "page" && !target.attached) {
              this.log(`[CDP] \u53D1\u73B0 Target: ${target.type} - ${target.url}`);
              this.sendCommand("Target.attachToTarget", {
                targetId: target.targetId,
                flatten: true
              });
            }
          }
          if (msg.method === "Target.attachedToTarget") {
            const sessionId = msg.params.sessionId;
            const targetInfo = msg.params.targetInfo;
            this.log(`[CDP] \u5DF2\u6302\u8F7D\u4F1A\u8BDD: ${sessionId} (${targetInfo.type})`);
            this.sessions.add(sessionId);
            const enableNetwork = () => {
              this.sendCommand("Network.enable", {}, sessionId);
            };
            enableNetwork();
            const timer = setInterval(enableNetwork, 2e3);
            this.keepAliveTimers.push(timer);
            this.sendCommand("Runtime.enable", {}, sessionId);
          }
          if (msg.method === "Network.requestWillBeSent") {
            const req = msg.params.request;
            const url = req.url;
            if (!url.match(/\.(js|css|png|jpg|gif|svg|woff|ttf|ico)(\?|$)/)) {
              this.log(`[Request] ${req.method} : ${url}`);
            }
            if (url.includes(".m3u8") || url.includes(".mpd") || url.match(/\.(mp4|webm|flv)(\?|$)/) && !url.includes(".png") && !url.includes(".jpg")) {
              this._addCapture(url, req.headers, "request-url", targetUrl);
              this.log(`[!!! CAPTURED] ${url}`);
            }
          }
          if (msg.method === "Network.responseReceived") {
            const resp = msg.params.response;
            const url = resp.url;
            const mime = resp.mimeType || "";
            const isMedia = mime.includes("video") || mime.includes("audio") || mime.includes("mpeg") || mime.includes("stream") || url.includes(".m3u8") || url.includes(".mpd");
            if (isMedia) {
              this.log(`[Response] ${mime} : ${url}`);
              const lenStr = resp.headers["Content-Length"] || resp.headers["content-length"];
              const len = lenStr ? parseInt(lenStr, 10) : null;
              if (url.includes(".m3u8") || url.includes(".mpd")) {
                this._addCapture(url, null, "response-mime", targetUrl, len, 100);
                this.log(`[!!! CAPTURED PRIORITY] ${url}`);
              } else if (url.match(/\.(mp4|webm|flv|mov|mkv)(\?|$)/) || mime.includes("mp4") || mime.includes("webm")) {
                this._addCapture(url, null, "response-mime", targetUrl, len, 80);
                this.log(`[!!! CAPTURED VIDEO] ${url}`);
              } else {
                this._addCapture(url, null, "response-mime", targetUrl, len, 10);
                this.log(`[!!! CAPTURED FRAGMENT] ${url}`);
              }
            }
          }
        } catch {
        }
      });
      this.ws.on("error", (e) => {
        this.log(`[CDP] WS error: ${e.message}`);
        reject(e);
      });
    });
  }
  /** Get all captured videos so far. */
  getCapturedVideos() {
    return this.capturedVideos || [];
  }
  /** Get the latest capture, optionally trying JS injection as fallback. */
  async getLatestCapture(injectJs = false) {
    if (this.capturedVideos && this.capturedVideos.length > 0) {
      const latest = this.capturedVideos[0];
      if (latest.waitingForCookie) {
        await new Promise((r) => setTimeout(r, 500));
      }
      return latest;
    }
    if (injectJs && this.ws && this.sessions.size > 0) {
      return this._injectJsFallback();
    }
    return null;
  }
  /** Stop and cleanup browser + WebSocket. */
  stop() {
    this.cleanup();
  }
  /** Convenience: sniff for a duration, calling onFound when a video is found. */
  async sniff(targetUrl, onFound, timeoutMs = 121e3, options) {
    await this.start(targetUrl, void 0, options);
    return new Promise((resolve3) => {
      const timer = setInterval(async () => {
        const latest = await this.getLatestCapture(true);
        if (latest) {
          const found = onFound(latest);
          if (found) {
            clearInterval(timer);
            this.stop();
            resolve3(latest);
          }
        }
      }, 500);
      setTimeout(() => {
        clearInterval(timer);
        this.stop();
        resolve3(null);
      }, timeoutMs);
    });
  }
  // ---- private ----
  sendCommand(method, params = {}, sessionId) {
    if (!this.ws)
      return;
    const id = this.nextId++;
    const msg = { id, method, params };
    if (sessionId)
      msg.sessionId = sessionId;
    this.ws.send(JSON.stringify(msg));
  }
  _addCapture(url, headers, source, targetUrl, contentLength = null, priority = 50) {
    if (this.capturedVideos.length > 0 && this.capturedVideos[0].priority > priority && this.capturedVideos[0].url !== url)
      return;
    if (this.capturedVideos.some((v) => v.url === url))
      return;
    const result = {
      url,
      userDataDir: this.tmpDir,
      headers: headers ? {
        "Cookie": headers["Cookie"] || headers["cookie"],
        "Referer": headers["Referer"] || headers["referer"] || targetUrl,
        "User-Agent": headers["User-Agent"] || headers["user-agent"],
        "Origin": headers["Origin"] || headers["origin"]
      } : { "Referer": targetUrl },
      cookieSource: "cdp-sniffed",
      timestamp: Date.now(),
      filesize: contentLength,
      resolution: url.includes("1080") ? "1080p" : url.includes("720") ? "720p" : "unknown",
      priority
    };
    if (!result.headers.Cookie && this.ws && this.sessions.size > 0) {
      result.waitingForCookie = true;
      const sessionIds = Array.from(this.sessions);
      sessionIds.forEach((sessionId) => {
        const id = this.nextId++;
        const listener = (data) => {
          try {
            const msg = JSON.parse(data);
            if (msg.id === id && msg.result && msg.result.cookies) {
              const cookies = msg.result.cookies;
              if (cookies.length > 0) {
                const cookieStr = cookies.map((c) => `${c.name}=${c.value}`).join("; ");
                if (!result.headers.Cookie || cookieStr.length > result.headers.Cookie.length) {
                  result.headers.Cookie = cookieStr;
                  this.log(`[CDP] \u4E3B\u52A8\u83B7\u53D6 Cookie \u6210\u529F: ${cookieStr.substring(0, 50)}...`);
                  result.waitingForCookie = false;
                }
              }
              const idx = this.ws.listeners.message.indexOf(listener);
              if (idx > -1)
                this.ws.listeners.message.splice(idx, 1);
            }
          } catch {
          }
        };
        this.ws.on("message", listener);
        this.ws.send(JSON.stringify({
          id,
          method: "Network.getCookies",
          params: { urls: [url, targetUrl] },
          sessionId
        }));
      });
      setTimeout(() => {
        result.waitingForCookie = false;
      }, 2e3);
    }
    if (result.headers.Referer) {
      let ref = result.headers.Referer.trim();
      if (ref.includes(","))
        ref = ref.split(",")[0].trim();
      result.headers.Referer = ref;
    }
    if (!result.headers.Origin && result.headers.Referer) {
      try {
        result.headers.Origin = new import_url2.URL(result.headers.Referer).origin;
      } catch {
      }
    }
    this.log(`[CDP] !!! \u6355\u83B7\u6210\u529F (${source}): ${url} Size:${contentLength}`);
    if (priority >= 90) {
      this.capturedVideos.unshift(result);
    } else {
      this.capturedVideos.push(result);
    }
  }
  async _injectJsFallback() {
    if (!this.ws)
      return null;
    this.log(`[CDP] JS \u6CE8\u5165\u515C\u5E95... Sessions: ${this.sessions.size}`);
    const script = `(function(){try{var r=performance.getEntriesByType('resource');for(var i=r.length-1;i>=0;i--){var n=r[i].name;if(n.startsWith('blob:')||n.includes('.m3u8')||n.includes('.mpd')||n.match(/.(mp4|webm|flv)(?|$)/)){if(!n.includes('.png')&&!n.includes('.ico'))return n}}var v=document.querySelector('video');if(v){if(v.src&&(v.src.startsWith('http')||v.src.startsWith('blob:')))return JSON.stringify({url:v.src,cookie:document.cookie,referer:document.referrer});if(v.currentSrc&&(v.currentSrc.startsWith('http')||v.currentSrc.startsWith('blob:')))return JSON.stringify({url:v.currentSrc,cookie:document.cookie,referer:document.referrer});var s=v.querySelector('source');if(s&&s.src)return JSON.stringify({url:s.src,cookie:document.cookie,referer:document.referrer})}var ifs=document.querySelectorAll('iframe');for(var j=0;j<ifs.length;j++){if(ifs[j].src&&(ifs[j].src.includes('m3u8')||ifs[j].src.includes('mp4')))return JSON.stringify({url:ifs[j].src,cookie:document.cookie,referer:document.referrer})}if(window.hls&&window.hls.url)return JSON.stringify({url:window.hls.url,cookie:document.cookie,referer:document.referrer});var keys=Object.keys(window);for(var k=0;k<keys.length;k++){if(keys[k].includes('Info')||keys[k].includes('Data')||keys[k].includes('Player')||keys[k].includes('Config')){var v2=window[keys[k]];if(v2&&typeof v2==='object'){var m=JSON.stringify(v2).match(/https?:\\/\\/[^"']+\\.(mp4|m3u8|mpd)[^"']*/);if(m)return JSON.stringify({url:m[0].replace(/\\\\\\//g,'/'),cookie:document.cookie,referer:document.referrer})}}}return null}catch(e){return null}})()`;
    const sessions = Array.from(this.sessions);
    const promises11 = sessions.map((sessionId) => {
      return new Promise((resolve3) => {
        const id = Date.now() + Math.floor(Math.random() * 1e4);
        const listener = (data) => {
          try {
            const msg = JSON.parse(data);
            if (msg.id === id && msg.result && msg.result.result) {
              const val = msg.result.result.value;
              if (val && typeof val === "string") {
                try {
                  const obj = JSON.parse(val);
                  if (obj.url) {
                    let referer = obj.referer ? obj.referer.trim() : "https://www.google.com/";
                    if (referer.includes(","))
                      referer = referer.split(",")[0].trim();
                    let origin = "";
                    try {
                      origin = new import_url2.URL(referer).origin;
                    } catch {
                    }
                    resolve3({
                      url: obj.url,
                      userDataDir: this.tmpDir,
                      headers: {
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                        "Referer": referer,
                        "Origin": origin,
                        "Cookie": obj.cookie || ""
                      },
                      cookieSource: "cdp-injected",
                      timestamp: Date.now(),
                      filesize: null,
                      resolution: "unknown",
                      priority: 90
                    });
                    return;
                  }
                } catch {
                }
                if (val.startsWith("http")) {
                  resolve3({
                    url: val,
                    userDataDir: this.tmpDir,
                    headers: { "Referer": "https://www.google.com/" },
                    cookieSource: "cdp-injected",
                    timestamp: Date.now(),
                    filesize: null,
                    resolution: "unknown",
                    priority: 90
                  });
                  return;
                }
              }
              resolve3(null);
            }
          } catch {
            resolve3(null);
          }
        };
        this.ws.on("message", listener);
        this.sendCommand("Runtime.evaluate", { expression: script, returnByValue: true }, sessionId);
        setTimeout(() => resolve3(null), 1e3);
      });
    });
    try {
      const results = await Promise.all(promises11);
      const found = results.find((r) => r && r.url);
      if (found) {
        this.log(`[CDP] JS \u6CE8\u5165\u6210\u529F\u63D0\u53D6: ${found.url}`);
        this.capturedVideos.unshift(found);
        return found;
      }
    } catch (e) {
      this.log(`[CDP] JS \u6CE8\u5165\u5931\u8D25: ${e.message}`);
    }
    return null;
  }
  cleanup() {
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
      }
      this.ws = null;
    }
    if (this.keepAliveTimers) {
      this.keepAliveTimers.forEach((t) => clearInterval(t));
      this.keepAliveTimers = [];
    }
    if (this.browserProcess) {
      const pid = this.browserProcess.pid;
      if (process.platform === "win32" && pid) {
        try {
          (0, import_child_process4.execSync)(`taskkill /pid ${pid} /T /F`, {
            stdio: "ignore",
            env: { ...process.env, QQQ_NO_TRACK: "1" }
          });
        } catch {
        }
      }
      try {
        this.browserProcess.kill();
      } catch {
      }
      this.browserProcess = null;
    }
  }
};
_CdpSniffer.customBrowserPath = null;
_CdpSniffer.validateBrowserPath = validateBrowserPath;
var CdpSniffer = _CdpSniffer;

// shell/window-manager.ts
var _consoleBuffer = [];
var _consoleMaxLines = 2e4;
var editorFontSize = 13;
function setEditorFontSize(size) {
  editorFontSize = size;
}
function saveEditorFontSize(stateStore2) {
  try {
    stateStore2.set("qqqide", "editorFontSize", { size: editorFontSize });
  } catch {
  }
}
function broadcastEditorFontSize(size) {
  const allWindows = import_electron2.BrowserWindow.getAllWindows();
  for (const win of allWindows) {
    if (!win.isDestroyed() && !win.webContents.isDestroyed()) {
      try {
        win.webContents.send("qqqide:zoom:changed", size);
      } catch {
      }
    }
  }
}
var WING_WIDTH = 389;
var CENTER_MIN_W = 1100;
var CENTER_MIN_H = 800;
function updateWingMinSize(win, leftOpen, rightOpen) {
  if (!win || win.isDestroyed())
    return;
  const wingW = (leftOpen ? WING_WIDTH : 0) + (rightOpen ? WING_WIDTH : 0);
  win.setMinimumSize(CENTER_MIN_W + wingW, CENTER_MIN_H);
}
async function restoreWindowBounds(win, stateStore2) {
  try {
    const v = await stateStore2.get("qqqide", "window_bounds");
    if (!v) {
      return;
    }
    if (v.maximized) {
      win.maximize();
      return;
    }
    if (typeof v.w === "number" && typeof v.h === "number" && v.w > 0 && v.h > 0) {
      const displays = import_electron2.screen.getAllDisplays();
      const anyOverlap = displays.some((d) => {
        const dx = d.bounds.x, dy = d.bounds.y, dw = d.bounds.width, dh = d.bounds.height;
        return v.x < dx + dw && v.x + v.w > dx && v.y < dy + dh && v.y + v.h > dy;
      });
      if (anyOverlap) {
        win.setBounds({ x: v.x || 0, y: v.y || 0, width: v.w, height: v.h });
      }
    }
  } catch (e) {
  }
}
var _windowProjectMap = /* @__PURE__ */ new Map();
var _projectWindowMap = /* @__PURE__ */ new Map();
function bypassCloseConfirm(win) {
  win.__qqqCloseBypass = true;
}
function createWindow(portableRoot, portableCache, appVersion, lspBridge2, downloadService2, stateStore2) {
  const preloadPath = path7.join(__dirname, "preload.js");
  const win = new import_electron2.BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: CENTER_MIN_W,
    minHeight: CENTER_MIN_H,
    show: false,
    frame: false,
    backgroundColor: "#fdf6e3",
    title: "qqqide",
    webPreferences: {
      preload: preloadPath,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      webSecurity: false,
      additionalArguments: [
        `--qqqide-root=${portableRoot}`,
        `--qqqide-version=${appVersion}`
      ]
    }
  });
  const _cmHandler = (_e, _level, message, _line, _sourceId) => {
    if (_level === 0)
      return;
    const src = (_sourceId || "").replace(/\\/g, "/");
    const file = src.split("/").pop() || "";
    const prefix = file && !file.startsWith("(") && _line ? file + ":" + _line + " " : "";
    _consoleBuffer.push(prefix + message);
    if (_consoleBuffer.length > _consoleMaxLines)
      _consoleBuffer.shift();
  };
  win.webContents.on("console-message", _cmHandler);
  _setupCdpConsoleCapture(win).catch(() => {
  });
  win.removeMenu();
  win.once("ready-to-show", async () => {
    await restoreWindowBounds(win, stateStore2);
  });
  win.on("close", (e) => {
    if (win.__qqqCloseBypass) {
      return;
    }
    e.preventDefault();
    if (!win.isDestroyed() && !win.webContents.isDestroyed()) {
      try {
        win.webContents.send("qqqide:confirm-close");
      } catch (_) {
      }
    }
  });
  win.on("closed", () => {
    try {
      if (_boundsSaveTimer) {
        clearTimeout(_boundsSaveTimer);
        _boundsSaveTimer = null;
      }
    } catch (_) {
    }
    try {
      const ownedProject = _windowProjectMap.get(win.id);
      if (ownedProject) {
        _windowProjectMap.delete(win.id);
        _projectWindowMap.delete(ownedProject);
      }
    } catch (_) {
    }
  });
  win.on("blur", () => {
    if (!win.isDestroyed() && !win.webContents.isDestroyed()) {
      win.webContents.executeJavaScript(
        "if(window.qqqideViewport&&window.qqqideViewport.closeDropdown)window.qqqideViewport.closeDropdown()"
      ).catch((e) => {
        try {
          console.warn("[main] blur dismiss failed:", e && e.message);
        } catch (_) {
        }
      });
    }
  });
  let _boundsSaveTimer = null;
  const saveBounds = () => {
    try {
      if (win.isDestroyed() || win.isMinimized() || win.isMaximized()) {
        return;
      }
      const b = win.getBounds();
      stateStore2.set("qqqide", "window_bounds", {
        x: b.x,
        y: b.y,
        w: b.width,
        h: b.height,
        maximized: false
      }).catch(() => {
      });
    } catch {
    }
  };
  const debouncedSaveBounds = () => {
    if (_boundsSaveTimer) {
      clearTimeout(_boundsSaveTimer);
    }
    _boundsSaveTimer = setTimeout(saveBounds, 500);
  };
  win.on("resize", debouncedSaveBounds);
  win.on("move", debouncedSaveBounds);
  win.on("maximize", () => {
    try {
      stateStore2.set("qqqide", "window_bounds", { maximized: true }).catch(() => {
      });
    } catch {
    }
  });
  win.on("unmaximize", () => {
    try {
      saveBounds();
    } catch {
    }
  });
  downloadService2.setProgressSender((entry) => {
    if (win && !win.isDestroyed()) {
      try {
        win.webContents.send("qqqide:download:progress", entry);
      } catch {
      }
    }
  });
  win.webContents.on("did-finish-load", () => {
    win.webContents.setZoomFactor(1);
  });
  win.webContents.on("before-input-event", (ev, input) => {
    if (input.type !== "keyDown") {
      return;
    }
    const ctrl = input.control || input.meta;
    if (!ctrl) {
      return;
    }
    const k = input.key;
    if (k === "=" || k === "+") {
      ev.preventDefault();
      editorFontSize = Math.min(128, editorFontSize + 1);
      saveEditorFontSize(stateStore2);
      broadcastEditorFontSize(editorFontSize);
    } else if (k === "-" || k === "_") {
      ev.preventDefault();
      editorFontSize = Math.max(1, editorFontSize - 1);
      saveEditorFontSize(stateStore2);
      broadcastEditorFontSize(editorFontSize);
    } else if (k === "0") {
      ev.preventDefault();
      editorFontSize = 13;
      saveEditorFontSize(stateStore2);
      broadcastEditorFontSize(editorFontSize);
    }
  });
  win.webContents.on("devtools-opened", () => {
    const dwc = win.webContents.devToolsWebContents;
    if (dwc && !dwc.isDestroyed()) {
      injectDevToolsConsoleButtons(dwc, win.webContents, () => _consoleBuffer.join("\n"), win);
    }
  });
  if (extractFlags().isDev) {
    win.webContents.on("devtools-opened", () => {
      const _doRename = (attempt) => {
        const p = _windowProjectMap.get(win.id);
        const n = p ? path7.basename(p) : "qqqide";
        console.log("[devtools] rename attempt=" + attempt + " winId=" + win.id + " projPath=" + (p || "(none)") + " name=" + n);
        renameDevToolsViaBroker(win, n);
      };
      for (let _ri = 1; _ri <= 8; _ri++) {
        setTimeout(() => _doRename(_ri), 1500 * _ri);
      }
    });
    win.webContents.openDevTools({ mode: "detach" });
    win.webContents.on("before-input-event", (ev, input) => {
      if (input.type !== "keyDown") {
        return;
      }
      if (input.key === "F5" || input.control && input.key.toLowerCase() === "r") {
        ev.preventDefault();
        win.webContents.reloadIgnoringCache();
      }
      if (input.control && input.shift && input.key.toLowerCase() === "i") {
        ev.preventDefault();
        if (win.webContents.isDevToolsOpened()) {
          win.webContents.closeDevTools();
        } else {
          win.webContents.openDevTools({ mode: "detach" });
        }
      }
      if (input.key === "F12") {
        ev.preventDefault();
      }
    });
  }
  return win;
}
async function _setupCdpConsoleCapture(win) {
  const PORT = 8315;
  const allSockets = [];
  let _started = false;
  const _NOISE_SOURCES = /* @__PURE__ */ new Set(["intervention", "rendering", "violation", "deprecation", "recommendation"]);
  const _handleEntry = (entry) => {
    var _a, _b;
    if (!entry || !entry.text)
      return;
    if (entry.level === "verbose")
      return;
    if (entry.source && _NOISE_SOURCES.has(entry.source))
      return;
    if (entry.source === "network") {
      const nUrl = (entry.url || "").replace(/\\/g, "/");
      const nFile = nUrl.split("/").pop() || nUrl;
      const nText = entry.text || "";
      const nCallFrames = ((_a = entry.stackTrace) == null ? void 0 : _a.callFrames) || [];
      const nLines = [];
      if (nCallFrames.length > 0) {
        const f0 = nCallFrames[0];
        const fUrl = (f0.url || "").replace(/\\/g, "/").split("/").pop() || f0.url;
        const fLine = f0.lineNumber || 0;
        nLines.push((fUrl && fLine ? fUrl + ":" + fLine + " " : "") + nUrl + " " + nText);
        for (let i = 1; i < nCallFrames.length; i++) {
          const cf = nCallFrames[i];
          const fn = cf.functionName || "<anonymous>";
          const fu = (cf.url || "").replace(/\\/g, "/").split("/").pop() || cf.url;
          nLines.push("    " + fn + " @ " + fu + ":" + (cf.lineNumber || 0));
        }
      } else {
        nLines.push(nUrl + " " + nText);
      }
      for (const l of nLines) {
        _consoleBuffer.push(l);
        if (_consoleBuffer.length > _consoleMaxLines)
          _consoleBuffer.shift();
      }
      return;
    }
    const url = (entry.url || "").replace(/\\/g, "/");
    const file = url.split("/").pop() || url;
    const line = entry.lineNumber || 0;
    const text = entry.text || "";
    const callFrames = ((_b = entry.stackTrace) == null ? void 0 : _b.callFrames) || [];
    const lines = [];
    if (callFrames.length > 0) {
      const f0 = callFrames[0];
      const fUrl = (f0.url || "").replace(/\\/g, "/").split("/").pop() || f0.url;
      const fLine = f0.lineNumber || 0;
      lines.push((fUrl && fLine ? fUrl + ":" + fLine + " " : "") + text);
      for (let i = 1; i < callFrames.length; i++) {
        const cf = callFrames[i];
        const fn = cf.functionName || "<anonymous>";
        const fu = (cf.url || "").replace(/\\/g, "/").split("/").pop() || cf.url;
        lines.push("    " + fn + " @ " + fu + ":" + (cf.lineNumber || 0));
      }
    } else if (file && line) {
      lines.push(file + ":" + line + " " + text);
    } else {
      lines.push(text);
    }
    for (const l of lines) {
      _consoleBuffer.push(l);
      if (_consoleBuffer.length > _consoleMaxLines)
        _consoleBuffer.shift();
    }
  };
  const _consoleDedup = /* @__PURE__ */ new Set();
  const _handleConsoleMsg = (msg) => {
    var _a;
    if (!msg || !msg.text)
      return;
    if (msg.level === "verbose")
      return;
    if (msg.source && _NOISE_SOURCES.has(msg.source))
      return;
    if (msg.source === "network")
      return;
    const url = (msg.url || "").replace(/\\/g, "/");
    const file = url.split("/").pop() || url;
    const line = msg.line || 0;
    const text = msg.text || "";
    const callFrames = ((_a = msg.stackTrace) == null ? void 0 : _a.callFrames) || [];
    const dedupKey = file + ":" + line + ":" + text.slice(0, 80);
    if (_consoleDedup.has(dedupKey))
      return;
    _consoleDedup.add(dedupKey);
    setTimeout(() => _consoleDedup.delete(dedupKey), 1e3);
    const lines = [];
    if (callFrames.length > 0) {
      const f0 = callFrames[0];
      const fUrl = (f0.url || "").replace(/\\/g, "/").split("/").pop() || f0.url;
      const fLine = f0.lineNumber || 0;
      lines.push((fUrl && fLine ? fUrl + ":" + fLine + " " : "") + text);
      for (let i = 1; i < callFrames.length; i++) {
        const cf = callFrames[i];
        const fn = cf.functionName || "<anonymous>";
        const fu = (cf.url || "").replace(/\\/g, "/").split("/").pop() || cf.url;
        lines.push("    " + fn + " @ " + fu + ":" + (cf.lineNumber || 0));
      }
    } else if (file && line) {
      lines.push(file + ":" + line + " " + text);
    } else {
      lines.push(text);
    }
    for (const l of lines) {
      _consoleBuffer.push(l);
      if (_consoleBuffer.length > _consoleMaxLines)
        _consoleBuffer.shift();
    }
  };
  const _connectTarget = (wsUrl, label) => {
    try {
      const ws = new SimpleWebSocket(wsUrl);
      allSockets.push(ws);
      ws.on("open", () => {
        ws.send(JSON.stringify({ id: 1, method: "Console.enable", params: {} }));
        ws.send(JSON.stringify({ id: 2, method: "Log.enable", params: {} }));
        console.log("[main] CDP Console+Log enabled for " + label);
      });
      ws.on("message", (data) => {
        var _a, _b;
        try {
          const msg = JSON.parse(data);
          if (msg.method === "Console.messageAdded" && ((_a = msg.params) == null ? void 0 : _a.message)) {
            _handleConsoleMsg(msg.params.message);
          } else if (msg.method === "Log.entryAdded" && ((_b = msg.params) == null ? void 0 : _b.entry)) {
            _handleEntry(msg.params.entry);
          }
        } catch {
        }
      });
      ws.on("error", (err) => {
        console.log("[main] CDP WS error (" + label + "):", err.message);
        try {
          ws.close();
        } catch {
        }
      });
    } catch (e) {
      console.log("[main] CDP connect failed (" + label + "):", e.message);
    }
  };
  const _doCapture = async () => {
    if (_started)
      return;
    try {
      const targetsJson = await new Promise((resolve3, reject) => {
        const req = http4.get(`http://127.0.0.1:${PORT}/json/list`, (res) => {
          let data = "";
          res.on("data", (chunk) => data += chunk);
          res.on("end", () => resolve3(data));
        });
        req.on("error", reject);
        req.setTimeout(3e3, () => {
          req.destroy();
          reject(new Error("timeout"));
        });
      });
      const targets = JSON.parse(targetsJson);
      let pageCount = 0;
      for (const t of targets) {
        if (t.type === "page" && t.webSocketDebuggerUrl) {
          _connectTarget(t.webSocketDebuggerUrl, "page:" + (t.url || "").slice(0, 60));
          pageCount++;
        }
      }
      try {
        const versionJson = await new Promise((resolve3, reject) => {
          const req = http4.get(`http://127.0.0.1:${PORT}/json/version`, (res) => {
            let data = "";
            res.on("data", (chunk) => data += chunk);
            res.on("end", () => resolve3(data));
          });
          req.on("error", reject);
          req.setTimeout(2e3, () => {
            req.destroy();
            reject(new Error("timeout"));
          });
        });
        const vi = JSON.parse(versionJson);
        if (vi.webSocketDebuggerUrl) {
          _connectTarget(vi.webSocketDebuggerUrl, "browser");
        }
      } catch {
      }
      console.log("[main] CDP capture started: " + pageCount + " page(s) + browser");
      _started = true;
      const _poll = setInterval(async () => {
        try {
          const resp = await new Promise((resolve3, reject) => {
            const req = http4.get(`http://127.0.0.1:${PORT}/json/list`, (res) => {
              let data = "";
              res.on("data", (chunk) => data += chunk);
              res.on("end", () => resolve3(data));
            });
            req.on("error", reject);
            req.setTimeout(2e3, () => {
              req.destroy();
            });
          });
          const list = JSON.parse(resp);
          const known = new Set(allSockets.map((s) => s.url));
          for (const t of list) {
            if (t.type === "page" && t.webSocketDebuggerUrl && !known.has(t.webSocketDebuggerUrl)) {
              _connectTarget(t.webSocketDebuggerUrl, "new:" + (t.url || "").slice(0, 60));
            }
          }
        } catch {
        }
      }, 8e3);
      win.on("closed", () => {
        clearInterval(_poll);
        for (const s of allSockets) {
          try {
            s.close();
          } catch {
          }
        }
        allSockets.length = 0;
      });
    } catch (err) {
      console.log("[main] CDP capture init failed (retry in 2s):", err.message);
      setTimeout(_doCapture, 2e3);
    }
  };
  setTimeout(_doCapture, 2e3);
  setTimeout(() => {
    if (!_started)
      _doCapture();
  }, 5e3);
}

// shell/asset-protocol.ts
var import_electron3 = require("electron");
var path8 = __toESM(require("path"));
var fs7 = __toESM(require("fs"));
var os3 = __toESM(require("os"));
var import_url3 = require("url");
var import_child_process5 = require("child_process");
var _assetFileBuiltinRoots = [];
var _assetFileWorkspaceRoots = /* @__PURE__ */ new Set();
var _assetRootsStorePath = "";
function initBuiltinRoots(portableCache) {
  _assetFileBuiltinRoots.length = 0;
  _assetFileBuiltinRoots.push(path8.normalize(portableCache), path8.normalize(os3.homedir()));
}
function loadAssetRoots(portableUserData) {
  _assetRootsStorePath = path8.join(portableUserData, "asset-roots.json");
  try {
    if (!fs7.existsSync(_assetRootsStorePath)) {
      return;
    }
    const raw = fs7.readFileSync(_assetRootsStorePath, "utf8");
    const arr = JSON.parse(raw);
    if (Array.isArray(arr)) {
      for (const r of arr) {
        if (typeof r === "string" && r) {
          _assetFileWorkspaceRoots.add(path8.normalize(r));
        }
      }
      console.log("[asset-roots] loaded", _assetFileWorkspaceRoots.size, "workspace root(s)");
    }
  } catch (e) {
    console.warn("[asset-roots] load failed:", e);
  }
}
async function hydrateAssetRootsFromState(stateStore2) {
  try {
    const v = await stateStore2.get("qqqide", "asset_roots");
    if (Array.isArray(v) && v.length > 0) {
      for (const r of v) {
        if (typeof r === "string" && r) {
          _assetFileWorkspaceRoots.add(path8.normalize(r));
        }
      }
      console.log("[asset-roots] hydrated", _assetFileWorkspaceRoots.size, "from state");
    } else {
      const arr = Array.from(_assetFileWorkspaceRoots);
      await stateStore2.setNow("qqqide", "asset_roots", arr);
      try {
        if (_assetRootsStorePath && fs7.existsSync(_assetRootsStorePath)) {
          fs7.renameSync(_assetRootsStorePath, _assetRootsStorePath + ".migrated");
        }
      } catch {
      }
    }
  } catch (e) {
    console.warn("[state] _hydrateAssetRootsFromState failed:", e);
  }
}
function persistAssetRoots(stateStore2) {
  try {
    const arr = Array.from(_assetFileWorkspaceRoots);
    stateStore2.set("qqqide", "asset_roots", arr);
  } catch (e) {
    console.warn("[asset-roots] persist failed:", e);
  }
}
function addAssetRoot(absDir, stateStore2) {
  if (!absDir || typeof absDir !== "string") {
    return false;
  }
  if (!path8.isAbsolute(absDir)) {
    return false;
  }
  let norm;
  try {
    norm = path8.normalize(absDir);
  } catch {
    return false;
  }
  try {
    const st = fs7.statSync(norm);
    if (!st.isDirectory()) {
      return false;
    }
  } catch {
    return false;
  }
  if (_assetFileWorkspaceRoots.has(norm)) {
    return false;
  }
  _assetFileWorkspaceRoots.add(norm);
  persistAssetRoots(stateStore2);
  console.log("[asset-roots] added", norm);
  return true;
}
function isPathAllowed(abs) {
  const norm = path8.normalize(abs);
  for (const root of _assetFileBuiltinRoots) {
    if (norm === root || norm.startsWith(root + path8.sep)) {
      return true;
    }
  }
  for (const root of _assetFileWorkspaceRoots) {
    if (norm === root || norm.startsWith(root + path8.sep)) {
      return true;
    }
  }
  return false;
}
function registerAssetProtocol(portableRoot) {
  const resApp = path8.join(portableRoot, "resources", "app");
  const appAssetsRoot = fs7.existsSync(resApp) ? resApp : portableRoot;
  const roots = {
    monaco: path8.join(appAssetsRoot, "node_modules", "monaco-editor", "min"),
    "monaco-maps": path8.join(appAssetsRoot, "node_modules", "monaco-editor", "min-maps"),
    "monaco-esm": path8.join(appAssetsRoot, "node_modules", "monaco-editor", "esm"),
    monaco_deps: path8.join(portableRoot, "Data", "monaco-deps"),
    ts: path8.join(appAssetsRoot, "node_modules", "typescript", "lib"),
    shell: path8.join(appAssetsRoot, "shell-out")
  };
  import_electron3.protocol.registerFileProtocol("qqqide-asset", (request3, callback) => {
    try {
      const url = new import_url3.URL(request3.url);
      const resource = url.hostname;
      const subPath = decodeURIComponent(url.pathname);
      if (resource === "file") {
        let abs = subPath.startsWith("/") ? subPath.slice(1) : subPath;
        abs = path8.normalize(abs);
        if (!path8.isAbsolute(abs) || !isPathAllowed(abs)) {
          console.warn("[qqqide-asset/file] denied:", abs);
          return callback({ error: -10 });
        }
        if (!fs7.existsSync(abs)) {
          return callback({ error: -6 });
        }
        return callback({ path: abs });
      }
      const root = roots[resource];
      if (!root) {
        return callback({ error: -6 });
      }
      const resolved = path8.normalize(path8.join(root, subPath));
      if (!resolved.startsWith(root)) {
        return callback({ error: -10 });
      }
      if (resource === "monaco" && !fs7.existsSync(resolved) && roots["monaco_deps"]) {
        const fallback = path8.normalize(path8.join(roots["monaco_deps"], subPath));
        if (fallback.startsWith(roots["monaco_deps"]) && fs7.existsSync(fallback)) {
          return callback({ path: fallback });
        }
      }
      if (resource === "monaco" && !fs7.existsSync(resolved) && roots["monaco-maps"] && subPath.startsWith("/min-maps/")) {
        const realSubPath = subPath.slice("/min-maps".length);
        const mapsFallback = path8.normalize(path8.join(roots["monaco-maps"], realSubPath));
        if (mapsFallback.startsWith(roots["monaco-maps"]) && fs7.existsSync(mapsFallback)) {
          return callback({ path: mapsFallback });
        }
      }
      callback({ path: resolved });
    } catch (e) {
      console.warn("[qqqide-asset] bad url:", request3.url, e);
      callback({ error: -2 });
    }
  });
}
var _diskFreeCache = null;
var _DISK_FREE_TTL_MS = 30 * 1e3;
function resolveKpBridge(portableRoot) {
  const candidates = [
    path8.join(portableRoot, "engines", "kp_bridge.py"),
    path8.join(portableRoot, "resources", "app", "engines", "kp_bridge.py")
  ];
  for (const p of candidates) {
    if (fs7.existsSync(p)) {
      const py = process.env.QQQ_PYTHON || (process.platform === "win32" ? "python" : "python3");
      return { script: p, python: py };
    }
  }
  return null;
}
function diskFreeNodeFallback(drives) {
  const result = {};
  for (const d of drives || []) {
    try {
      const stats = fs7.statfsSync(d);
      const bsize = stats.bsize;
      const letter = (d.charAt(0) || "X").toUpperCase();
      result[letter] = {
        free: stats.bfree * bsize,
        total: stats.blocks * bsize
      };
    } catch {
    }
  }
  try {
    const desktop = path8.join(os3.homedir(), "Desktop");
    let used = 0;
    const entries = fs7.readdirSync(desktop);
    for (const e of entries) {
      try {
        used += fs7.statSync(path8.join(desktop, e)).size;
      } catch {
      }
    }
    result["DESKTOP"] = { used, path: desktop };
  } catch {
    result["DESKTOP"] = { used: 0 };
  }
  result["RECYCLE"] = { used: 0 };
  return result;
}
async function diskFreeViaKpBridge(portableRoot, drives) {
  const kp = resolveKpBridge(portableRoot);
  if (!kp) {
    return null;
  }
  return await new Promise((resolve3) => {
    let proc;
    try {
      proc = (0, import_child_process5.spawn)(kp.python, ["-u", kp.script], {
        cwd: portableRoot,
        stdio: ["pipe", "pipe", "pipe"],
        windowsHide: true
      });
    } catch {
      return resolve3(null);
    }
    let stdout = "";
    proc.stdout.on("data", (d) => {
      stdout += d.toString();
    });
    proc.on("error", () => resolve3(null));
    proc.on("close", () => {
      try {
        const result = JSON.parse(stdout);
        resolve3(result || null);
      } catch {
        resolve3(null);
      }
    });
    const input = JSON.stringify(drives || []);
    try {
      proc.stdin.write(input);
      proc.stdin.end();
    } catch (e) {
      console.warn("[diskFree] kp_bridge stdin failed:", e);
      resolve3(null);
    }
  });
}
async function diskFreeBatch(portableRoot, drives) {
  const key = JSON.stringify(drives || []);
  const now = Date.now();
  if (_diskFreeCache && _diskFreeCache.key === key && now - _diskFreeCache.t < _DISK_FREE_TTL_MS) {
    return _diskFreeCache.data;
  }
  let data = await diskFreeViaKpBridge(portableRoot, drives);
  if (!data) {
    data = diskFreeNodeFallback(drives);
  }
  _diskFreeCache = { t: now, key, data };
  return data;
}
function initAssetProtocol(portableRoot, portableCache, portableUserData) {
  initBuiltinRoots(portableCache);
  loadAssetRoots(portableUserData);
  registerAssetProtocol(portableRoot);
}

// shell/ipc-fs.ts
var import_electron4 = require("electron");
var path10 = __toESM(require("path"));
var fs9 = __toESM(require("fs"));

// shell/ipc-state.ts
var _sn = {};
var _qw = /* @__PURE__ */ new Map();
var _co = Promise.resolve();
var _ac = Promise.resolve();
function _qe(filePath, fn) {
  const prev = _qw.get(filePath) || Promise.resolve();
  const p = prev.then(async () => {
    await _ac;
    return fn();
  });
  _qw.set(filePath, p);
  p.finally(() => {
    if (_qw.get(filePath) === p) {
      _qw.delete(filePath);
    }
  });
  return p;
}
var AI_SKIP_DIRS = ["node_modules", ".git", "dist", "backup", "__pycache__", ".venv", "vendor", "build", "out", ".next", ".nuxt", ".cache", "coverage", "target", "logs", "cache", "temp", "crashDumps"];
var AI_SKIP_EXTS = [".exe", ".dll", ".so", ".dylib", ".bin", ".png", ".jpg", ".jpeg", ".gif", ".mp3", ".mp4", ".zip", ".tar", ".gz", ".xz", ".woff", ".woff2", ".ttf", ".eot", ".ico", ".vsix", ".lock", ".wasm"];
var AI_MAX_FILE_SIZE = 10 * 1024 * 1024;
function aiGlobToRegex(pattern) {
  const esc = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
  return new RegExp("^" + esc + "$", "i");
}
function aiTimeout(ms, partial) {
  return new Promise((resolve3) => {
    setTimeout(() => resolve3((partial || "") + "\n[TIMEOUT]"), ms);
  });
}
function aiNormalizeWhitespace(s) {
  return s.replace(/[ \t]+/g, " ").replace(/[\r\n]+/g, "\n").trim();
}
function aiNormalizeCRLF(s) {
  return s.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
}

// shell/timeline-store.ts
var path9 = __toESM(require("path"));
var fs8 = __toESM(require("fs"));
var crypto2 = __toESM(require("crypto"));
var zlib = __toESM(require("zlib"));
var _timelineDbs = /* @__PURE__ */ new Map();
var _diffWindows = /* @__PURE__ */ new Map();
var _tlInitLocks = /* @__PURE__ */ new Map();
var WAL_MAX_LINES = 100;
var _tlWalCounts = /* @__PURE__ */ new Map();
function _tlDir(projectRoot) {
  return path9.join(projectRoot, "qqq", "timeline");
}
function _tlBlobPath(projectRoot, sha256) {
  return path9.join(_tlDir(projectRoot), "blobs", sha256.slice(0, 2), sha256 + ".gz");
}
function _tlDbPath(projectRoot) {
  return path9.join(_tlDir(projectRoot), "timeline.db");
}
function _tlBakPath(projectRoot) {
  return path9.join(_tlDir(projectRoot), "timeline.db.bak");
}
function _tlWalPath(projectRoot) {
  return path9.join(_tlDir(projectRoot), "timeline.wal");
}
function _tlTmpDir(projectRoot) {
  return path9.join(_tlDir(projectRoot), ".tmp");
}
function _tlReplayWal(db, projectRoot) {
  const walPath = _tlWalPath(projectRoot);
  if (!fs8.existsSync(walPath))
    return 0;
  let count = 0;
  try {
    const content = fs8.readFileSync(walPath, "utf8");
    const lines = content.split("\n").filter((l) => l.trim());
    if (lines.length === 0)
      return 0;
    var seqMap = /* @__PURE__ */ new Map();
    var seqInitStmt = db.prepare("SELECT file_path, COALESCE(MAX(file_seq), 0) as mx FROM versions GROUP BY file_path");
    while (seqInitStmt.step()) {
      var sr = seqInitStmt.getAsObject();
      seqMap.set(sr.file_path, sr.mx);
    }
    seqInitStmt.free();
    const stmt = db.prepare(
      "INSERT INTO versions (file_path, file_seq, ts, blob_hash, source, floor_id, added_lines, deleted_lines) VALUES (?,?,?,?,?,?,?,?)"
    );
    for (const line of lines) {
      try {
        const row = JSON.parse(line);
        var fp = row.p || "";
        var seq = (seqMap.get(fp) || 0) + 1;
        seqMap.set(fp, seq);
        stmt.run([fp, seq, row.t || 0, row.h || "", row.s || "q", row.f || null, row.a || null, row.d || null]);
        count++;
      } catch (_) {
      }
    }
    stmt.free();
  } catch (e) {
    console.warn("[timeline] wal replay failed:", e && e.message);
  }
  return count;
}
async function _tlOpenDb(projectRoot) {
  const dbPath = _tlDbPath(projectRoot);
  let db = _timelineDbs.get(dbPath);
  if (db)
    return db;
  const existingInit = _tlInitLocks.get(dbPath);
  if (existingInit)
    return existingInit;
  const initPromise = (async () => {
    try {
      fs8.mkdirSync(path9.dirname(dbPath), { recursive: true });
    } catch (_) {
    }
    const initSqlJs3 = require("sql.js");
    const SQL = await initSqlJs3();
    let dbLoaded = false;
    for (const tryPath of [dbPath, _tlBakPath(projectRoot)]) {
      if (!fs8.existsSync(tryPath))
        continue;
      try {
        const buf = fs8.readFileSync(tryPath);
        db = new SQL.Database(buf);
        db.exec("SELECT 1");
        dbLoaded = true;
        if (tryPath !== dbPath) {
          console.warn("[timeline] main db corrupt, recovered from .bak");
          try {
            fs8.writeFileSync(dbPath, buf);
          } catch (_) {
          }
        }
        break;
      } catch (e) {
        console.warn("[timeline] db load failed:", tryPath, e && e.message);
        try {
          fs8.renameSync(tryPath, tryPath + ".corrupt." + Date.now());
        } catch (_) {
        }
        db = null;
      }
    }
    if (!dbLoaded || !db)
      db = new SQL.Database();
    db.run(`CREATE TABLE IF NOT EXISTS versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT NOT NULL, ts INTEGER NOT NULL, blob_hash TEXT NOT NULL,
            source TEXT NOT NULL, floor_id TEXT, added_lines INTEGER, deleted_lines INTEGER,
            file_seq INTEGER
        )`);
    try {
      db.run("ALTER TABLE versions ADD COLUMN file_seq INTEGER");
    } catch (_) {
    }
    try {
      db.run("ALTER TABLE versions ADD COLUMN added_lines INTEGER");
    } catch (_) {
    }
    try {
      db.run("ALTER TABLE versions ADD COLUMN deleted_lines INTEGER");
    } catch (_) {
    }
    db.run("CREATE INDEX IF NOT EXISTS idx_versions_path_ts ON versions(file_path, ts)");
    db.run("CREATE INDEX IF NOT EXISTS idx_versions_path_seq ON versions(file_path, file_seq)");
    db.run("PRAGMA journal_mode=WAL");
    db.run("PRAGMA synchronous=FULL");
    db.run("PRAGMA busy_timeout=30000");
    const replayed = _tlReplayWal(db, projectRoot);
    if (replayed > 0) {
      console.log("[timeline] replayed " + replayed + " wal entries");
    }
    _timelineDbs.set(dbPath, db);
    _tlWalCounts.set(dbPath, replayed);
    _tlCleanStaleTmp(projectRoot);
    if (replayed > 0) {
      try {
        _tlCompactSync(db, dbPath, projectRoot);
      } catch (_) {
      }
    }
    return db;
  })();
  _tlInitLocks.set(dbPath, initPromise);
  try {
    return await initPromise;
  } finally {
    _tlInitLocks.delete(dbPath);
  }
}
function _tlRecord(db, dbPath, projectRoot, row) {
  var fileSeq = 1;
  try {
    var seqStmt = db.prepare("SELECT COALESCE(MAX(file_seq), 0) + 1 as ns FROM versions WHERE file_path = ?");
    seqStmt.bind([row.file_path]);
    if (seqStmt.step()) {
      fileSeq = seqStmt.getAsObject().ns;
    }
    seqStmt.free();
  } catch (_) {
  }
  db.run(
    "INSERT INTO versions (file_path, file_seq, ts, blob_hash, source, floor_id, added_lines, deleted_lines) VALUES (?,?,?,?,?,?,?,?)",
    [row.file_path, fileSeq, row.ts, row.blob_hash, row.source, row.floor_id || null, row.added_lines || null, row.deleted_lines || null]
  );
  const walLine = JSON.stringify({
    p: row.file_path,
    q: fileSeq,
    t: row.ts,
    h: row.blob_hash,
    s: row.source,
    f: row.floor_id || void 0,
    a: row.added_lines ?? void 0,
    d: row.deleted_lines ?? void 0
  }) + "\n";
  const walPath = _tlWalPath(projectRoot);
  try {
    fs8.mkdirSync(path9.dirname(walPath), { recursive: true });
  } catch (_) {
  }
  fs8.appendFileSync(walPath, walLine, "utf8");
  const count = (_tlWalCounts.get(dbPath) || 0) + 1;
  _tlWalCounts.set(dbPath, count);
  if (count >= WAL_MAX_LINES) {
    _tlCompactSync(db, dbPath, projectRoot);
  }
}
function _tlFlushNow(db, dbPath, projectRoot) {
  try {
    _tlCompactSync(db, dbPath, projectRoot);
  } catch (e) {
    console.warn("[timeline] flushNow failed:", e && e.message);
  }
}
function _tlCompactSync(db, dbPath, projectRoot) {
  const walPath = _tlWalPath(projectRoot);
  const tmpDir = _tlTmpDir(projectRoot);
  try {
    fs8.mkdirSync(tmpDir, { recursive: true });
  } catch (_) {
  }
  let walSize = 0;
  try {
    walSize = fs8.statSync(walPath).size;
  } catch (_) {
  }
  if (walSize === 0)
    return;
  const data = db.export();
  const tmp = path9.join(tmpDir, "timeline.db.tmp." + Date.now());
  fs8.writeFileSync(tmp, Buffer.from(data));
  fs8.renameSync(tmp, dbPath);
  const bakPath = _tlBakPath(projectRoot);
  const bakTmp = path9.join(tmpDir, "timeline.db.bak.tmp." + Date.now());
  fs8.writeFileSync(bakTmp, Buffer.from(data));
  try {
    fs8.renameSync(bakTmp, bakPath);
  } catch (_) {
    try {
      fs8.writeFileSync(bakPath, Buffer.from(data));
    } catch (_2) {
    }
    try {
      fs8.unlinkSync(bakTmp);
    } catch (_2) {
    }
  }
  try {
    fs8.writeFileSync(walPath, "", "utf8");
  } catch (_) {
  }
  _tlWalCounts.set(dbPath, 0);
}
function _sha256(content) {
  const normalized = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  return crypto2.createHash("sha256").update(normalized, "utf8").digest("hex");
}
function _gzipSync(content) {
  return zlib.gzipSync(Buffer.from(content, "utf8"), { level: 6 });
}
function _gunzipSync(buf) {
  return zlib.gunzipSync(buf).toString("utf8");
}
function _tlWriteBlob(projectRoot, sha256, gzBuf) {
  const blobPath = _tlBlobPath(projectRoot, sha256);
  const dir = path9.dirname(blobPath);
  try {
    fs8.mkdirSync(dir, { recursive: true });
  } catch (_) {
  }
  if (fs8.existsSync(blobPath))
    return;
  const tmpDir = _tlTmpDir(projectRoot);
  try {
    fs8.mkdirSync(tmpDir, { recursive: true });
  } catch (_) {
  }
  const tmp = path9.join(tmpDir, sha256 + ".tmp." + Date.now());
  fs8.writeFileSync(tmp, gzBuf);
  fs8.renameSync(tmp, blobPath);
}
function _tlCleanStaleTmp(projectRoot) {
  const tmpDir = _tlTmpDir(projectRoot);
  try {
    if (!fs8.existsSync(tmpDir))
      return;
    const files = fs8.readdirSync(tmpDir);
    for (const f of files) {
      try {
        fs8.unlinkSync(path9.join(tmpDir, f));
      } catch (_) {
      }
    }
  } catch (_) {
  }
}

// shell/ipc-fs.ts
var READ_FILE_MAX = 50 * 1024 * 1024;
async function _atomicWrite(absPath, data) {
  const dir = path10.dirname(absPath);
  await fs9.promises.mkdir(dir, { recursive: true });
  const tmp = absPath + ".tmp." + process.pid + "." + Math.random().toString(36).slice(2, 8);
  await fs9.promises.writeFile(tmp, data);
  try {
    await fs9.promises.rename(tmp, absPath);
  } catch (e) {
    if (e && (e.code === "EEXIST" || e.code === "EPERM" || e.code === "EACCES")) {
      try {
        const data2 = await fs9.promises.readFile(tmp);
        await fs9.promises.writeFile(absPath, data2);
        try {
          await fs9.promises.unlink(tmp);
        } catch {
        }
      } catch (e2) {
        try {
          await fs9.promises.unlink(tmp);
        } catch {
        }
        throw e2;
      }
    } else {
      try {
        await fs9.promises.unlink(tmp);
      } catch {
      }
      throw e;
    }
  }
}
function registerFsIpc() {
  import_electron4.ipcMain.handle("qqqide:fs:exists", async (_e, p) => fs9.existsSync(p));
  import_electron4.ipcMain.handle("qqqide:fs:read", async (_e, p) => {
    try {
      return await fs9.promises.readFile(p, "utf8");
    } catch (e) {
      if (e.code === "ENOENT")
        return null;
      throw e;
    }
  });
  import_electron4.ipcMain.handle("qqqide:fs:readBase64", async (_e, p) => {
    try {
      const buf = await fs9.promises.readFile(p);
      return buf.toString("base64");
    } catch (e) {
      if (e.code === "ENOENT")
        return null;
      throw e;
    }
  });
  import_electron4.ipcMain.handle("qqqide:fs:writeBase64", async (_e, p, base64) => {
    try {
      await fs9.promises.mkdir(path10.dirname(p), { recursive: true });
    } catch {
    }
    const buf = Buffer.from(base64 || "", "base64");
    await _atomicWrite(p, buf);
    return true;
  });
  import_electron4.ipcMain.handle("qqqide:fs:write", async (_e, p, content) => {
    try {
      await fs9.promises.mkdir(path10.dirname(p), { recursive: true });
    } catch {
    }
    const buf = Buffer.isBuffer(content) ? content : Buffer.from(content, "utf8");
    await _atomicWrite(p, buf);
    return true;
  });
  import_electron4.ipcMain.handle("qqqide:fs:append", async (_e, p, content) => {
    try {
      await fs9.promises.mkdir(path10.dirname(p), { recursive: true });
    } catch {
    }
    await fs9.promises.appendFile(p, content, "utf8");
    return true;
  });
  import_electron4.ipcMain.handle("qqqide:fs:list", async (_e, p, callerStack) => {
    console.log("[fs:list]", p);
    const MAX = 3e3;
    try {
      const names = await fs9.promises.readdir(p, { withFileTypes: true });
      const entries = names.slice(0, MAX);
      const stats = await Promise.all(entries.map(function(e) {
        return fs9.promises.stat(path10.join(p, e.name)).catch(function() {
          return null;
        });
      }));
      const result = entries.map(function(e, i) {
        var st = stats[i];
        return {
          name: e.name,
          isDir: e.isDirectory(),
          mtimeMs: st ? st.mtimeMs : 0,
          ctimeMs: st ? st.ctimeMs : 0,
          size: st ? st.size : 0
        };
      });
      if (names.length > MAX) {
        console.warn("[fs:list] TRUNCATED:", p, "returned " + MAX + "/" + names.length + " entries");
      }
      return result;
    } catch (e) {
      if ((e == null ? void 0 : e.code) !== "ENOENT" && callerStack) {
        console.warn("[fs:list] FAILED:", p, "\n" + callerStack, e == null ? void 0 : e.message);
      }
      return [];
    }
  });
  import_electron4.ipcMain.handle("qqqide:fs:stat", async (_e, p) => {
    try {
      const s = await fs9.promises.stat(p);
      return { size: s.size, mtimeMs: s.mtimeMs, isDir: s.isDirectory(), isFile: s.isFile() };
    } catch {
      return null;
    }
  });
  import_electron4.ipcMain.handle("qqqide:fs:mkdir", async (_e, p) => {
    await fs9.promises.mkdir(p, { recursive: true });
    return true;
  });
  import_electron4.ipcMain.handle("qqqide:fs:remove", async (_e, p) => {
    try {
      const s = await fs9.promises.stat(p);
      if (s.isDirectory())
        await fs9.promises.rm(p, { recursive: true, force: true });
      else
        await fs9.promises.unlink(p);
    } catch (e) {
      if (e && e.code !== "ENOENT")
        throw e;
    }
    return true;
  });
  import_electron4.ipcMain.handle("qqqide:fs:rename", async (_e, oldP, newP) => {
    await fs9.promises.rename(oldP, newP);
    return true;
  });
  import_electron4.ipcMain.handle("qqqide:ai:read_file", async (_e, args) => {
    try {
      if (args.sha256) {
        let root = path10.dirname(args.path);
        while (root && root !== path10.dirname(root)) {
          if (fs9.existsSync(path10.join(root, "qqq", "timeline", "blobs")))
            break;
          root = path10.dirname(root);
        }
        if (!root || root === path10.dirname(root)) {
          return "Error: cannot find project root (no qqq/timeline/blobs/) from " + args.path;
        }
        const blobPath = _tlBlobPath(root, args.sha256);
        if (!fs9.existsSync(blobPath)) {
          return "Error: blob not found for sha256 " + args.sha256.slice(0, 12) + "... in " + root;
        }
        const gzBuf = fs9.readFileSync(blobPath);
        let content2 = _gunzipSync(gzBuf);
        if (args.start_line != null || args.end_line != null) {
          const lines = content2.split("\n");
          const start = Math.max(0, (args.start_line || 1) - 1);
          const end = args.end_line != null ? Math.min(args.end_line, lines.length) : lines.length;
          const header = "[paginated " + (start + 1) + "-" + end + " of " + lines.length + " lines]\n";
          return header + lines.slice(start, end).join("\n");
        }
        return content2;
      }
      const st = await fs9.promises.stat(args.path);
      if (st.size > READ_FILE_MAX) {
        return "Error: file " + path10.basename(args.path) + " is " + (st.size / 1024 / 1024).toFixed(1) + "MB. Use start_line/end_line to paginate.";
      }
      let content = await fs9.promises.readFile(args.path, "utf8");
      try {
        _sn[args.path] = { mtimeMs: st.mtimeMs, size: st.size };
      } catch {
      }
      if (args.start_line != null || args.end_line != null) {
        const lines = content.split("\n");
        const start = Math.max(0, (args.start_line || 1) - 1);
        const end = args.end_line != null ? Math.min(args.end_line, lines.length) : lines.length;
        const header = "[paginated " + (start + 1) + "-" + end + " of " + lines.length + " lines]\n";
        return header + lines.slice(start, end).join("\n");
      }
      return content;
    } catch (e) {
      if (e.code === "ENOENT")
        return "Error: file not found: " + args.path;
      if (e.code === "EACCES")
        return "Error: permission denied: " + args.path;
      return "Error reading file: " + (e.message || e);
    }
  });
}

// shell/ipc-boot.ts
var import_electron5 = require("electron");
init_component_checker();
function registerBootIpc(portableRoot, portableUserData, portableCache, portableLogs, appVersion, bootConfig2, getEngineAlive, getLastBootMode2, getMainWindow) {
  import_electron5.ipcMain.handle("qqqide:app:root", () => portableRoot);
  import_electron5.ipcMain.handle("qqqide:components:getBin", (_e, name) => {
    return getComponentBin(portableRoot, name);
  });
  import_electron5.ipcMain.handle("qqqide:boot:info", () => ({
    url: bootConfig2.url,
    version: appVersion,
    platform: process.platform,
    arch: process.arch,
    appRoot: portableRoot,
    userData: portableUserData,
    cacheDir: portableCache,
    logsDir: portableLogs,
    cwd: process.cwd(),
    homedir: require("os").homedir(),
    engineAlive: getEngineAlive(),
    bootMode: getLastBootMode2()
  }));
  import_electron5.ipcMain.handle("qqqide:boot:retry", async () => {
    if (isBootCompleted()) {
      console.log("[boot.retry] boot already completed \u2014 ignoring retry from stale fallback");
      return true;
    }
    const mw = getMainWindow();
    if (!mw) {
      return false;
    }
    const healthy = await healthCheck(bootConfig2.url, bootConfig2.healthTimeoutMs, false);
    if (healthy) {
      console.log("[boot.retry] server OK -> reload");
      await mw.loadURL(bootConfig2.url);
      return true;
    }
    const { ok } = await loadRemoteWithCacheGuard(mw, bootConfig2);
    if (!ok) {
      await loadStaticFallback(mw, bootConfig2, portableRoot, "retry-failed");
      return false;
    }
    return true;
  });
  import_electron5.ipcMain.handle("qqqide:boot:probe", async () => {
    return healthCheck(bootConfig2.url, Math.min(bootConfig2.healthTimeoutMs, 2e3), false);
  });
}

// shell/ipc-ai-tools.ts
var import_electron6 = require("electron");
var path11 = __toESM(require("path"));
var fs10 = __toESM(require("fs"));
function registerAiToolsIpc() {
  import_electron6.ipcMain.handle("qqqide:ai:search_text", async (_e, args) => {
    const query = args.query;
    const searchPaths = args.paths || (args.path ? [args.path] : []);
    const maxResults = args.maxResults || 30;
    const timeoutMs = args.timeoutMs || 3e4;
    if (searchPaths.length === 0)
      return "Error: no search paths";
    let regex;
    try {
      regex = new RegExp(query, "i");
    } catch {
      regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
    }
    const matches = [];
    const doSearch = async () => {
      async function walk(dir, depth) {
        if (depth > 8 || matches.length >= maxResults)
          return;
        let entries;
        try {
          entries = await fs10.promises.readdir(dir, { withFileTypes: true });
        } catch {
          return;
        }
        entries.sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true, sensitivity: "base" }));
        for (const ent of entries) {
          if (matches.length >= maxResults)
            break;
          if (ent.name.startsWith(".") && ent.isDirectory())
            continue;
          if (ent.isDirectory() && AI_SKIP_DIRS.includes(ent.name))
            continue;
          const full = path11.join(dir, ent.name);
          if (ent.isDirectory()) {
            await walk(full, depth + 1);
          } else {
            const extMatch = ent.name.match(/\.([a-z0-9]+)$/i);
            const ext = extMatch ? "." + extMatch[1].toLowerCase() : "";
            if (AI_SKIP_EXTS.includes(ext))
              continue;
            try {
              const st = await fs10.promises.stat(full);
              if (!st || st.size > AI_MAX_FILE_SIZE)
                continue;
              const content = await fs10.promises.readFile(full, "utf8");
              const lines = content.split("\n");
              for (let li = 0; li < lines.length && matches.length < maxResults; li++) {
                if (regex.test(lines[li])) {
                  matches.push(full + ":" + (li + 1) + ":" + lines[li].trim().slice(0, 200));
                }
              }
            } catch {
            }
          }
        }
      }
      for (const d of searchPaths) {
        if (matches.length >= maxResults)
          break;
        await walk(d, 0);
      }
      return matches.length > 0 ? matches.join("\n") : "No matches found.";
    };
    return Promise.race([doSearch(), aiTimeout(timeoutMs, matches.length > 0 ? matches.join("\n") : "")]);
  });
  import_electron6.ipcMain.handle("qqqide:ai:find_files", async (_e, args) => {
    const pattern = args.pattern;
    const searchPaths = args.paths || (args.path ? [args.path] : []);
    const maxResults = args.maxResults || 50;
    const timeoutMs = args.timeoutMs || 15e3;
    if (!pattern || searchPaths.length === 0)
      return "Error: missing pattern or paths";
    const regex = aiGlobToRegex(pattern);
    const baseDirs = searchPaths.map((p) => p.replace(/\\/g, "/").replace(/\/$/, ""));
    const matches = [];
    const doSearch = async () => {
      async function walk(dir, depth, baseDir) {
        if (depth > 8 || matches.length >= maxResults)
          return;
        let entries;
        try {
          entries = await fs10.promises.readdir(dir, { withFileTypes: true });
        } catch {
          return;
        }
        entries.sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true, sensitivity: "base" }));
        for (const ent of entries) {
          if (matches.length >= maxResults)
            break;
          if (ent.name.startsWith("."))
            continue;
          if (ent.isDirectory() && AI_SKIP_DIRS.includes(ent.name))
            continue;
          const full = path11.join(dir, ent.name);
          const rel = baseDir ? full.replace(/\\/g, "/").slice(baseDir.length + 1) : full;
          if (regex.test(ent.name) || regex.test(rel)) {
            matches.push(full + (ent.isDirectory() ? "/" : ""));
          }
          if (ent.isDirectory())
            await walk(full, depth + 1, baseDir);
        }
      }
      for (let d = 0; d < searchPaths.length && matches.length < maxResults; d++) {
        await walk(searchPaths[d], 0, baseDirs[d]);
      }
      return matches.length > 0 ? matches.join("\n") : "No files found.";
    };
    return Promise.race([doSearch(), aiTimeout(timeoutMs, matches.length > 0 ? matches.join("\n") : "")]);
  });
  import_electron6.ipcMain.handle("qqqide:ai:list_files", async (_e, args) => {
    const searchPath = args.path;
    const maxResults = args.maxResults || 200;
    const timeoutMs = args.timeoutMs || 15e3;
    if (!searchPath)
      return "Error: missing path";
    const matches = [];
    const doSearch = async () => {
      async function walk(dir, depth) {
        if (depth > 8 || matches.length >= maxResults)
          return;
        let entries;
        try {
          entries = await fs10.promises.readdir(dir, { withFileTypes: true });
        } catch {
          return;
        }
        entries.sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true, sensitivity: "base" }));
        for (const ent of entries) {
          if (matches.length >= maxResults)
            break;
          if (ent.name.startsWith("."))
            continue;
          if (ent.isDirectory() && AI_SKIP_DIRS.includes(ent.name))
            continue;
          const full = path11.join(dir, ent.name);
          matches.push(full + (ent.isDirectory() ? "/" : ""));
          if (ent.isDirectory())
            await walk(full, depth + 1);
        }
      }
      await walk(searchPath, 0);
      return matches.length > 0 ? matches.join("\n") : "No files found.";
    };
    return Promise.race([doSearch(), aiTimeout(timeoutMs, matches.length > 0 ? matches.join("\n") : "")]);
  });
}

// shell/ipc-search.ts
var import_electron7 = require("electron");
var path12 = __toESM(require("path"));
var fs11 = __toESM(require("fs"));
var import_child_process6 = require("child_process");
var SEARCH_MAX_DEPTH = 20;
var SEARCH_MAX_FILE_MB = 5;
function _findRipgrep() {
  const rgName = process.platform === "win32" ? "rg.exe" : "rg";
  const tries = [];
  try {
    tries.push(path12.join(import_electron7.app.getPath("userData"), "components", "ripgrep", rgName));
  } catch {
  }
  tries.push(path12.join(__dirname, "..", "engines", "ripgrep", rgName));
  tries.push(path12.join(__dirname, "..", "..", "engines", "ripgrep", rgName));
  const platSuffix = { win32: "win-x64", linux: "linux-x64", darwin: "darwin-" + (process.arch === "arm64" ? "arm64" : "x64") };
  const suffix = platSuffix[process.platform];
  if (suffix) {
    const baseName = rgName.endsWith(".exe") ? rgName.slice(0, -4) : rgName;
    const suffixed = baseName + "-" + suffix + (process.platform === "win32" ? ".exe" : "");
    tries.push(path12.join(__dirname, "..", "engines", "ripgrep", suffixed));
    tries.push(path12.join(__dirname, "..", "..", "engines", "ripgrep", suffixed));
  }
  for (const p of tries) {
    try {
      if (fs11.existsSync(p)) {
        console.log("[search] ripgrep found:", p);
        return p;
      }
    } catch {
    }
  }
  console.log("[search] ripgrep not found in known paths, trying PATH:", rgName);
  return rgName;
}
async function _ripgrepSearch(searchPath, query, isRegex, caseSensitive, wholeWord, includePattern, excludePattern, contextLines, maxResults, timeoutMs, respectGitignore, matchFilenames) {
  const rgPath = _findRipgrep();
  if (!rgPath) {
    return { error: "ripgrep \u672A\u5B89\u88C5\u3002\u8FD0\u884C: python op/components.py ensure ripgrep", results: [], total: 0, elapsed: 0, filesScanned: 0, truncated: false, fileStats: {} };
  }
  const startTime = Date.now();
  console.log("[search] spawning ripgrep:", rgPath, "query:", query.slice(0, 80));
  const args = [
    "--json",
    "--no-heading",
    "--with-filename",
    "--line-number",
    "--column",
    "--only-matching",
    "--color",
    "never",
    "--max-depth",
    String(SEARCH_MAX_DEPTH),
    "--max-filesize",
    String(SEARCH_MAX_FILE_MB) + "M"
  ];
  let actualQuery = query;
  let forceRegex = false;
  const hasNewline = query.indexOf("\\n") !== -1 || query.indexOf("\n") !== -1;
  if (hasNewline) {
    args.push("--multiline");
    args.push("--crlf");
    actualQuery = query.replace(/\\n/g, "\n");
    if (!isRegex) {
      forceRegex = true;
      actualQuery = actualQuery.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      if (wholeWord)
        actualQuery = "\\b" + actualQuery + "\\b";
    }
  }
  if (!caseSensitive)
    args.push("--ignore-case");
  if (wholeWord && !forceRegex)
    args.push("--word-regexp");
  if (!isRegex && !forceRegex)
    args.push("--fixed-strings");
  if (!respectGitignore)
    args.push("--no-ignore");
  args.push("--glob", "!.git");
  args.push("--glob", "!node_modules");
  if (includePattern) {
    for (const p of includePattern.split(",").map((s) => s.trim()).filter(Boolean)) {
      args.push("--glob", p);
    }
  }
  if (excludePattern) {
    for (const p of excludePattern.split(",").map((s) => s.trim()).filter(Boolean)) {
      args.push("--glob", "!" + p);
    }
  }
  if (contextLines > 0) {
    args.push("--context", String(contextLines));
  }
  args.push("--regexp", actualQuery);
  args.push(searchPath);
  return new Promise((resolve3) => {
    let rg;
    try {
      rg = (0, import_child_process6.spawn)(rgPath, args, {
        cwd: searchPath,
        stdio: ["ignore", "pipe", "pipe"],
        windowsHide: true
      });
    } catch (e) {
      return resolve3({ error: "\u65E0\u6CD5\u542F\u52A8 ripgrep: " + (e.message || e), results: [], total: 0, elapsed: 0, filesScanned: 0, truncated: false, fileStats: {} });
    }
    let stdout = "";
    let killed = false;
    const timer = setTimeout(() => {
      killed = true;
      try {
        rg.kill("SIGTERM");
      } catch {
      }
      setTimeout(() => {
        try {
          rg.kill("SIGKILL");
        } catch {
        }
      }, 2e3);
    }, timeoutMs);
    rg.stdout.on("data", (chunk) => {
      stdout += chunk.toString("utf8");
    });
    let stderr = "";
    rg.stderr.on("data", (chunk) => {
      stderr += chunk.toString("utf8");
    });
    rg.on("error", (err) => {
      clearTimeout(timer);
      resolve3({ error: "ripgrep \u8FDB\u7A0B\u9519\u8BEF: " + err.message, results: [], total: 0, elapsed: 0, filesScanned: 0, truncated: false, fileStats: {} });
    });
    rg.on("close", async (code) => {
      clearTimeout(timer);
      if (killed || code === null && stdout.length === 0) {
        if (stdout.length > 0) {
          const parsed2 = _parseRgJson(stdout, maxResults, contextLines, searchPath);
          parsed2.elapsed = Date.now() - startTime;
          parsed2.truncated = true;
          return resolve3(parsed2);
        }
        return resolve3({ error: "\u641C\u7D22\u8D85\u65F6", results: [], total: 0, elapsed: Date.now() - startTime, filesScanned: 0, truncated: true, fileStats: {} });
      }
      if (code === 2 && stdout.length === 0) {
        const errMsg = stderr.split("\n").filter(Boolean).slice(-2).join("; ") || "ripgrep \u9000\u51FA\u7801 2";
        return resolve3({ error: errMsg, results: [], total: 0, elapsed: Date.now() - startTime, filesScanned: 0, truncated: false, fileStats: {} });
      }
      const parsed = _parseRgJson(stdout, maxResults, contextLines, searchPath);
      parsed.elapsed = Date.now() - startTime;
      const fileSet = /* @__PURE__ */ new Set();
      for (const line of stdout.split("\n")) {
        try {
          const obj = JSON.parse(line);
          if (obj.data && obj.data.path && obj.data.path.text) {
            fileSet.add(obj.data.path.text);
          }
        } catch {
        }
      }
      parsed.filesScanned = fileSet.size;
      if (matchFilenames && parsed.results.length < maxResults && !parsed.error) {
        try {
          const fnameMatches = await _rgFilenameSearch(
            searchPath,
            query,
            isRegex,
            caseSensitive,
            wholeWord,
            includePattern,
            excludePattern,
            respectGitignore,
            maxResults - parsed.results.length
          );
          const existingFiles = new Set(parsed.results.map((r) => r.file));
          for (const m of fnameMatches.matches) {
            if (!existingFiles.has(m.file)) {
              parsed.results.push(m);
              existingFiles.add(m.file);
            }
          }
          parsed.total = parsed.results.length;
          Object.assign(parsed.fileStats, fnameMatches.fileStats);
        } catch {
        }
      }
      resolve3(parsed);
    });
  });
}
async function _rgFilenameSearch(searchPath, query, isRegex, caseSensitive, wholeWord, includePattern, excludePattern, respectGitignore, maxResults) {
  const rgPath = _findRipgrep();
  if (!rgPath)
    return { matches: [], fileStats: {} };
  const args = ["--files", "--no-heading", "--max-depth", String(SEARCH_MAX_DEPTH)];
  if (!respectGitignore)
    args.push("--no-ignore");
  args.push("--glob", "!.git");
  args.push("--glob", "!node_modules");
  if (includePattern) {
    for (const p of includePattern.split(",").map((s) => s.trim()).filter(Boolean)) {
      args.push("--glob", p);
    }
  }
  if (excludePattern) {
    for (const p of excludePattern.split(",").map((s) => s.trim()).filter(Boolean)) {
      args.push("--glob", "!" + p);
    }
  }
  args.push(searchPath);
  return new Promise((resolve3) => {
    let stdout = "";
    try {
      const child = (0, import_child_process6.spawn)(rgPath, args, { cwd: searchPath, stdio: ["ignore", "pipe", "pipe"], windowsHide: true });
      const timer = setTimeout(() => {
        try {
          child.kill();
        } catch {
        }
      }, 15e3);
      child.stdout.on("data", (chunk) => {
        stdout += chunk.toString("utf8");
      });
      child.on("close", () => {
        clearTimeout(timer);
        const lines = stdout.split("\n").map((s) => s.trim()).filter(Boolean);
        const matches = [];
        const fileStats = {};
        let fnameMatcher;
        if (isRegex) {
          try {
            const re = new RegExp(query, caseSensitive ? "" : "i");
            fnameMatcher = (n) => re.test(n);
          } catch {
            fnameMatcher = () => false;
          }
        } else if (wholeWord) {
          const esc = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          const re = new RegExp("\\b" + esc + "\\b", caseSensitive ? "" : "i");
          fnameMatcher = (n) => re.test(n);
        } else {
          const q = caseSensitive ? query : query.toLowerCase();
          fnameMatcher = (n) => (caseSensitive ? n : n.toLowerCase()).indexOf(q) !== -1;
        }
        const searchNorm = searchPath.replace(/\\/g, "/").replace(/\/$/, "");
        for (const rawPath of lines) {
          if (matches.length >= maxResults)
            break;
          const relPath = rawPath.replace(/\\/g, "/");
          const displayPath = relPath.startsWith(searchNorm + "/") ? relPath.slice(searchNorm.length + 1) : relPath;
          const fname = path12.basename(displayPath);
          if (fnameMatcher(fname)) {
            const absFp = path12.join(searchPath, displayPath);
            matches.push({ file: displayPath, line: 1, col: 1, matchText: fname, text: fname });
            try {
              const st = fs11.statSync(absFp);
              fileStats[displayPath] = { mtime: st.mtimeMs, birthtime: st.birthtimeMs, size: st.size };
            } catch {
            }
          }
        }
        resolve3({ matches, fileStats });
      });
      child.on("error", () => resolve3({ matches: [], fileStats: {} }));
    } catch {
      resolve3({ matches: [], fileStats: {} });
    }
  });
}
function _parseRgJson(raw, maxResults, contextLines, _searchPath) {
  const fileEntries = /* @__PURE__ */ new Map();
  const seenFiles = /* @__PURE__ */ new Set();
  for (const line of raw.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed)
      continue;
    try {
      const obj = JSON.parse(trimmed);
      if (!obj || !obj.type)
        continue;
      if (obj.type === "summary" || obj.type === "end")
        continue;
      const fpath = obj.data && obj.data.path && obj.data.path.text || "";
      if (!fpath)
        continue;
      seenFiles.add(fpath);
      const relPath = fpath.replace(/\\/g, "/");
      const searchNorm = _searchPath.replace(/\\/g, "/").replace(/\/$/, "");
      const displayPath = relPath.startsWith(searchNorm + "/") ? relPath.slice(searchNorm.length + 1) : relPath;
      if (obj.type === "match") {
        const lineNum = obj.data.line_number || 0;
        const text = obj.data.lines && obj.data.lines.text || "";
        const submatch = obj.data.submatches && obj.data.submatches[0];
        const matchText = submatch && submatch.match && submatch.match.text || "";
        const cleanText = text.replace(/\r?\n$/, "");
        let col = 1, matchLen = matchText.length;
        if (submatch && cleanText && (submatch.start || 0) > 0) {
          const lineBuf = Buffer.from(cleanText, "utf8");
          const byteStart = submatch.start || 0;
          if (byteStart < lineBuf.length) {
            col = lineBuf.slice(0, byteStart).toString("utf8").length + 1;
          } else if (matchText) {
            const ci = cleanText.indexOf(matchText);
            if (ci !== -1)
              col = ci + 1;
          }
        }
        const displayText = cleanText.slice(0, 300);
        if (!fileEntries.has(displayPath))
          fileEntries.set(displayPath, []);
        fileEntries.get(displayPath).push({ type: "match", file: displayPath, line: lineNum, col, matchText, matchLen, text: displayText });
      } else if (obj.type === "context" && contextLines > 0) {
        const lineNum = obj.data.line_number || 0;
        const text = obj.data.lines && obj.data.lines.text || "";
        const cleanText = text.replace(/\r?\n$/, "").slice(0, 200);
        if (!fileEntries.has(displayPath))
          fileEntries.set(displayPath, []);
        fileEntries.get(displayPath).push({ type: "context", file: displayPath, line: lineNum, text: cleanText });
      }
    } catch {
    }
  }
  const results = [];
  for (const [filePath, entries] of fileEntries) {
    const matches = entries.filter((e) => e.type === "match");
    const contexts = entries.filter((e) => e.type === "context");
    for (const m of matches) {
      if (results.length >= maxResults)
        break;
      if (results.some((r) => r.file === filePath && r.line === m.line))
        continue;
      const match = { file: filePath, line: m.line, col: m.col || 1, matchLen: m.matchLen, matchText: m.matchText, text: m.text };
      if (contextLines > 0) {
        const before = contexts.filter((c) => c.line < m.line && m.line - c.line <= contextLines).sort((a, b) => a.line - b.line).map((c) => c.text);
        const after = contexts.filter((c) => c.line > m.line && c.line - m.line <= contextLines).sort((a, b) => a.line - b.line).map((c) => c.text);
        if (before.length > 0)
          match.before = before;
        if (after.length > 0)
          match.after = after;
      }
      results.push(match);
    }
  }
  const fileStats = {};
  const uniqueFiles = new Set(results.map((r) => r.file));
  for (const fp of uniqueFiles) {
    try {
      const absFp = path12.join(_searchPath, fp);
      const st = fs11.statSync(absFp);
      fileStats[fp] = { mtime: st.mtimeMs, birthtime: st.birthtimeMs, size: st.size };
    } catch {
    }
  }
  return {
    results,
    total: results.length,
    elapsed: 0,
    // filled by caller
    filesScanned: seenFiles.size,
    truncated: results.length >= maxResults,
    fileStats
  };
}
function registerSearchIpc() {
  import_electron7.ipcMain.handle("qqqide:search:query", async (_e, args) => {
    const searchPath = args.searchPath || args.rootDir || "";
    const {
      query,
      isRegex = false,
      caseSensitive = false,
      wholeWord = false,
      contextLines = 1,
      maxResults = 5e3,
      timeoutMs = 6e4,
      respectGitignore = false
    } = args;
    if (!searchPath || !query) {
      return { error: "\u7F3A\u5C11\u641C\u7D22\u5173\u952E\u8BCD\u6216\u641C\u7D22\u8DEF\u5F84", results: [], total: 0, elapsed: 0, filesScanned: 0, truncated: false, fileStats: {} };
    }
    return await _ripgrepSearch(
      searchPath,
      query,
      isRegex,
      caseSensitive,
      wholeWord,
      args.includePattern,
      args.excludePattern,
      contextLines,
      maxResults,
      timeoutMs,
      respectGitignore,
      args.matchFilenames !== false
    );
  });
  import_electron7.ipcMain.handle("qqqide:search:replace", async (_e, args) => {
    if (args.find && args.files && args.files.length > 0) {
      const { find: find2, replace: replaceText2 = "", searchPath: sp = "", useRegex: useRegex2 = false, caseSensitive: caseSensitive2 = false, wholeWord: wholeWord2 = false } = args;
      let pattern2;
      if (useRegex2) {
        pattern2 = find2;
      } else {
        pattern2 = find2.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      }
      if (wholeWord2)
        pattern2 = "\\b" + pattern2 + "\\b";
      let flags = "g";
      if (!caseSensitive2)
        flags += "i";
      let re;
      try {
        re = new RegExp(pattern2, flags);
      } catch (e) {
        return { replaced: 0, files: 0, errors: ["Invalid regex: " + (e.message || e)] };
      }
      let totalReplaced2 = 0, filesChanged2 = 0, processed = 0;
      const totalFiles = args.files.length;
      const errors2 = [];
      for (const fpath of args.files) {
        const absFp = path12.isAbsolute(fpath) ? fpath : path12.join(sp, fpath);
        try {
          const content = await fs11.promises.readFile(absFp, "utf8");
          const matches = content.match(re);
          if (!matches || matches.length === 0) {
            processed++;
            continue;
          }
          const newContent = content.replace(re, replaceText2);
          const hasCRLF = content.indexOf("\r\n") !== -1;
          const finalContent = hasCRLF ? newContent.replace(/\n/g, "\r\n") : newContent;
          await fs11.promises.writeFile(absFp, finalContent, "utf8");
          totalReplaced2 += matches.length;
          filesChanged2++;
        } catch (e) {
          errors2.push(fpath + ": " + (e.message || e));
        }
        processed++;
        if (_e.sender && !_e.sender.isDestroyed()) {
          _e.sender.send("qqqide:search:replace:progress", {
            current: processed,
            total: totalFiles,
            file: fpath,
            replaced: totalReplaced2,
            errors: errors2.slice()
          });
        }
      }
      return { replaced: totalReplaced2, files: filesChanged2, errors: errors2 };
    }
    if (args.replacements && Array.isArray(args.replacements) && args.replacements.length > 0) {
      const searchPath = args.searchPath || "";
      const byFile = /* @__PURE__ */ new Map();
      for (const r of args.replacements) {
        if (!byFile.has(r.file))
          byFile.set(r.file, []);
        byFile.get(r.file).push(r);
      }
      let totalReplaced2 = 0, filesChanged2 = 0, processed = 0;
      const totalFiles = byFile.size;
      const errors2 = [];
      for (const [fpath, reps] of byFile) {
        try {
          const absFp = path12.isAbsolute(fpath) ? fpath : path12.join(searchPath, fpath);
          reps.sort((a, b) => b.line - a.line || b.col - a.col);
          const content = await fs11.promises.readFile(absFp, "utf8");
          const lines = content.split("\n");
          let changed = false;
          for (const rep of reps) {
            const li = rep.line - 1;
            if (li < 0 || li >= lines.length)
              continue;
            const line = lines[li];
            const mt = rep.matchText || "";
            let idx = -1, len = rep.matchLen;
            if (mt) {
              len = mt.length;
              const approxCol = Math.max(0, (rep.col || 1) - 11);
              idx = line.indexOf(mt, approxCol);
              if (idx === -1)
                idx = line.indexOf(mt);
            }
            if (idx === -1) {
              const col0 = rep.col - 1;
              if (col0 + rep.matchLen > line.length)
                continue;
              idx = col0;
            }
            if (idx + len > line.length)
              continue;
            lines[li] = line.slice(0, idx) + rep.replacement + line.slice(idx + len);
            changed = true;
            totalReplaced2++;
          }
          if (changed) {
            await fs11.promises.writeFile(absFp, lines.join("\n"), "utf8");
            filesChanged2++;
          }
        } catch (e) {
          errors2.push(fpath + ": " + (e.message || e));
        }
        processed++;
        if (_e.sender && !_e.sender.isDestroyed()) {
          _e.sender.send("qqqide:search:replace:progress", {
            current: processed,
            total: totalFiles,
            file: fpath,
            replaced: totalReplaced2,
            errors: errors2.slice()
          });
        }
      }
      return { replaced: totalReplaced2, files: filesChanged2, errors: errors2 };
    }
    const { files, find, replace: replaceText, useRegex = false, caseSensitive = false, wholeWord = false } = args;
    if (!files || !find)
      return { replaced: 0, files: 0, errors: [] };
    let pattern;
    try {
      let flags = "g";
      if (!caseSensitive)
        flags += "i";
      if (useRegex) {
        pattern = new RegExp(find, flags);
      } else {
        let esc = find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        if (wholeWord)
          esc = "\\b" + esc + "\\b";
        pattern = new RegExp(esc, flags);
      }
    } catch (e) {
      return { replaced: 0, files: 0, errors: [e.message] };
    }
    let totalReplaced = 0, filesChanged = 0;
    const errors = [];
    for (const fp of files) {
      try {
        const content = await fs11.promises.readFile(fp, "utf8");
        const newContent = content.replace(pattern, replaceText);
        if (newContent !== content) {
          await fs11.promises.writeFile(fp, newContent, "utf8");
          totalReplaced += (content.match(pattern) || []).length;
          filesChanged++;
        }
      } catch (e) {
        errors.push(fp + ": " + (e.message || e));
      }
    }
    return { replaced: totalReplaced, files: filesChanged, errors };
  });
}

// shell/ipc-edit.ts
var import_electron8 = require("electron");
var path13 = __toESM(require("path"));
var fs12 = __toESM(require("fs"));
var vm = __toESM(require("vm"));
function measureMatchSpan(orig, start, findText, normFn) {
  const normFind = normFn(findText);
  for (let end = start + 1; end <= orig.length; end++) {
    if (normFn(orig.slice(start, end)) === normFind) {
      return end - start;
    }
  }
  return findText.length;
}
function checkSyntaxSync(filePath, originalContent, matchCtx) {
  const ext = path13.extname(filePath).toLowerCase();
  if (ext === ".js") {
    try {
      const content = fs12.readFileSync(filePath, "utf8");
      new vm.Script(content, { filename: filePath });
    } catch (syntaxErr) {
      const msg = (syntaxErr.message || String(syntaxErr)).replace(/\n/g, " ").substring(0, 250);
      if (originalContent !== null) {
        try {
          fs12.writeFileSync(filePath, originalContent);
        } catch (_) {
        }
      } else {
        try {
          fs12.unlinkSync(filePath);
        } catch (_) {
        }
      }
      let hint = matchCtx ? " (" + matchCtx + ")" : "";
      return "Error: your edit produced invalid JS syntax \u2014 " + msg + hint + ". File reverted unchanged. \u26A0 Your find string likely matched at the WRONG location. Re-read the file, then use a LONGER / more unique find string (add surrounding context lines).";
    }
  } else if (ext === ".mjs" || ext === ".cjs") {
    try {
      const content = fs12.readFileSync(filePath, "utf8");
      new Function(content);
    } catch (syntaxErr) {
      const msg = (syntaxErr.message || String(syntaxErr)).replace(/\n/g, " ").substring(0, 250);
      if (originalContent !== null) {
        try {
          fs12.writeFileSync(filePath, originalContent);
        } catch (_) {
        }
      } else {
        try {
          fs12.unlinkSync(filePath);
        } catch (_) {
        }
      }
      return "Error: your edit produced invalid ES module syntax \u2014 " + msg + ". File reverted unchanged. Re-read the file and use a more precise find string.";
    }
  } else if (ext === ".json") {
    try {
      const jsonContent = fs12.readFileSync(filePath, "utf8");
      JSON.parse(jsonContent);
    } catch (jsonErr) {
      const msg = (jsonErr.message || String(jsonErr)).replace(/\n/g, " ").substring(0, 250);
      if (originalContent !== null) {
        try {
          fs12.writeFileSync(filePath, originalContent);
        } catch (_) {
        }
      } else {
        try {
          fs12.unlinkSync(filePath);
        } catch (_) {
        }
      }
      return "Error: your edit produced invalid JSON \u2014 " + msg + ". File reverted unchanged. Check bracket/brace balance in your replace text.";
    }
  }
  return null;
}
function registerEditIpc() {
  import_electron8.ipcMain.handle("qqqide:ai:edit_file", async (_e, args) => {
    return _qe(args.path, async () => {
      try {
        const snap = _sn[args.path];
        if (snap) {
          try {
            const st = await fs12.promises.stat(args.path);
            if (st.mtimeMs !== snap.mtimeMs || st.size !== snap.size) {
              return "Error: file has been modified externally since last read. Please re-read the file and try again.";
            }
          } catch (_) {
          }
        }
        const originalContent = await fs12.promises.readFile(args.path, "utf8");
        let content = originalContent;
        const matchPlan = [];
        const results = [];
        let totalApplied = 0;
        for (let i = 0; i < args.edits.length; i++) {
          const ed = args.edits[i];
          if (ed.replace_all) {
            let count = content.split(ed.find).length - 1;
            if (count === 0 && ed.find.indexOf("\n") !== -1) {
              const escaped = ed.find.replace(/\n/g, "\\n");
              const count2 = content.split(escaped).length - 1;
              if (count2 > 0) {
                ed.find = escaped;
                count = count2;
              }
            }
            if (count === 0) {
              return `Error: edit #${i + 1} match failed \u2014 text not found in ${args.path.split(/[\\/]/).pop()}. (checked exact match)`;
            }
            matchPlan.push({ edit: ed, match: { start: 0, end: 0, matchLevel: 1 }, index: i });
            continue;
          }
          let matchStart = -1;
          let matchSpan = ed.find.length;
          let matchLevel = 1;
          let idx = content.indexOf(ed.find);
          if (idx !== -1) {
            matchStart = idx;
            matchLevel = 1;
          }
          if (matchStart === -1) {
            const findNorm = aiNormalizeCRLF(ed.find);
            const contentNorm = aiNormalizeCRLF(content);
            const normIdx = contentNorm.indexOf(findNorm);
            if (normIdx !== -1) {
              let oi = 0, ni = 0;
              while (ni < normIdx && oi < content.length) {
                if (content[oi] === "\r" && content[oi + 1] === "\n") {
                  oi += 2;
                  ni++;
                } else if (content[oi] === "\r") {
                  oi++;
                  ni++;
                } else {
                  oi++;
                  ni++;
                }
              }
              matchStart = oi;
              matchSpan = measureMatchSpan(content, oi, ed.find, aiNormalizeCRLF);
              matchLevel = 2;
            }
          }
          if (matchStart === -1 && ed.find.indexOf("\n") !== -1) {
            const escaped = ed.find.replace(/\n/g, "\\n");
            idx = content.indexOf(escaped);
            if (idx !== -1) {
              matchStart = idx;
              matchLevel = 1;
            }
          }
          if (matchStart === -1) {
            const nf = aiNormalizeWhitespace(ed.find);
            const nc = aiNormalizeWhitespace(content);
            let normIdx = -1;
            let searchFrom = 0;
            while ((normIdx = nc.indexOf(nf, searchFrom)) !== -1) {
              let oi = 0, ni = 0;
              while (ni < normIdx && oi < content.length) {
                const c = content[oi];
                if (c === " " || c === "	" || c === "\r" || c === "\n") {
                  const ncChar = nc[ni];
                  if (ncChar === " " || ncChar === "\n") {
                    oi++;
                    ni++;
                  } else
                    oi++;
                } else {
                  oi++;
                  ni++;
                }
              }
              if (nf.length >= 30)
                break;
              if (oi === 0 || content[oi - 1] === "\n")
                break;
              const firstChar = nf[0];
              if (firstChar !== "}" && firstChar !== ")" && firstChar !== ";" && firstChar !== "]")
                break;
              searchFrom = normIdx + 1;
            }
            if (normIdx !== -1) {
              let oi2 = 0, ni2 = 0;
              while (ni2 < normIdx && oi2 < content.length) {
                const c = content[oi2];
                if (c === " " || c === "	" || c === "\r" || c === "\n") {
                  const ncChar = nc[ni2];
                  if (ncChar === " " || ncChar === "\n") {
                    oi2++;
                    ni2++;
                  } else
                    oi2++;
                } else {
                  oi2++;
                  ni2++;
                }
              }
              matchStart = oi2;
              matchSpan = measureMatchSpan(content, oi2, ed.find, aiNormalizeWhitespace);
              matchLevel = 3;
            }
          }
          if (matchStart === -1) {
            const fl = ed.find.split("\n").map((l) => l.trim()).filter((l) => l.length > 0);
            if (fl.length >= 2) {
              const cl2 = content.split("\n");
              for (let li = 0; li <= cl2.length - fl.length; li++) {
                let ok = true;
                for (let lj = 0; lj < fl.length; lj++) {
                  if (cl2[li + lj].trim() !== fl[lj]) {
                    ok = false;
                    break;
                  }
                }
                if (ok) {
                  matchStart = cl2.slice(0, li).join("\n").length + (li > 0 ? 1 : 0);
                  matchSpan = cl2.slice(0, li + fl.length).join("\n").length - matchStart;
                  matchLevel = 4;
                  break;
                }
              }
            }
          }
          if (matchStart === -1) {
            const findBuf = Buffer.from(ed.find, "utf8");
            const contentBuf = Buffer.from(content, "utf8");
            const bufIdx = contentBuf.indexOf(findBuf);
            if (bufIdx !== -1) {
              matchStart = contentBuf.subarray(0, bufIdx).toString("utf8").length;
              matchSpan = ed.find.length;
              matchLevel = 5;
            }
          }
          if (matchStart === -1) {
            let _h = "";
            if (ed.find.length > 80)
              _h = " (long text \u2014 try shorter match)";
            const _f20 = ed.find.slice(0, 40);
            const _pos = content.indexOf(_f20);
            if (_pos !== -1) {
              const _ln = (content.slice(0, _pos).match(/\n/g) || []).length + 1;
              _h += `
\u{1F4A1} Find starts: "${_f20.replace(/\n/g, "\\n")}"... Occurs at line ${_ln}. Check whitespace/escaping difference.`;
            }
            return `Error: edit #${i + 1} match failed \u2014 text not found in ${args.path.split(/[\\/]/).pop()}.${_h}`;
          }
          matchPlan.push({
            edit: ed,
            match: { start: matchStart, end: matchStart + matchSpan, matchLevel },
            index: i
          });
        }
        const editLines = [];
        for (let pi = 0; pi < matchPlan.length; pi++) {
          const plan = matchPlan[pi];
          const ed = plan.edit;
          if (ed.replace_all) {
            const count = content.split(ed.find).length - 1;
            const allLines = [];
            let pos = 0;
            while (pos < content.length) {
              const idx2 = content.indexOf(ed.find, pos);
              if (idx2 === -1)
                break;
              allLines.push((content.slice(0, idx2).match(/\n/g) || []).length + 1);
              pos = idx2 + 1;
            }
            content = content.split(ed.find).join(ed.replace);
            results.push(`#${pi + 1}: all (${count}x, L${plan.match.matchLevel}, lines ${allLines.join(",")})`);
            editLines.push(`#${pi + 1}: lines ${allLines.join(",")} (${count}x replace_all)`);
            totalApplied += count;
          } else {
            const preContent = content.slice(0, plan.match.start);
            const lineNum = (preContent.match(/\n/g) || []).length + 1;
            content = content.slice(0, plan.match.start) + ed.replace + content.slice(plan.match.end);
            results.push(`L${plan.match.matchLevel} @L${lineNum}`);
            editLines.push(`#${pi + 1}: L${lineNum} (L${plan.match.matchLevel})`);
            totalApplied++;
          }
        }
        let multiWarn = "";
        for (let pi = 0; pi < matchPlan.length; pi++) {
          const plan = matchPlan[pi];
          if (plan.match.matchLevel >= 2 && !plan.edit.replace_all) {
            const nf = aiNormalizeWhitespace(plan.edit.find);
            const nc = aiNormalizeWhitespace(originalContent);
            let count = 0;
            let pos = 0;
            while ((pos = nc.indexOf(nf, pos)) !== -1) {
              count++;
              pos++;
            }
            if (count > 1) {
              multiWarn += ` \u26A0\uFE0F edit #${plan.match.index + 1}: ${count} candidates found, applied to first (L${plan.match.matchLevel})`;
            }
          }
        }
        try {
          await fs12.promises.mkdir(path13.dirname(args.path), { recursive: true });
        } catch {
        }
        await fs12.promises.writeFile(args.path, content);
        const syntaxCtx = multiWarn || (results.some((r) => r.indexOf("L2") !== -1 || r.indexOf("L3") !== -1 || r.indexOf("L4") !== -1 || r.indexOf("L5") !== -1) ? "whitespace-tolerant matching used \u2014 higher mismatch risk" : "");
        const syntaxErr = checkSyntaxSync(args.path, originalContent, syntaxCtx || void 0);
        if (syntaxErr)
          return syntaxErr;
        try {
          const st2 = await fs12.promises.stat(args.path);
          _sn[args.path] = { mtimeMs: st2.mtimeMs, size: st2.size };
        } catch {
        }
        const matchInfo = results.some((r) => r.indexOf("L2") !== -1 || r.indexOf("L3") !== -1 || r.indexOf("L4") !== -1 || r.indexOf("L5") !== -1) ? " (whitespace-tolerant match used)" : "";
        const lineInfo = editLines.length > 0 ? " [" + editLines.join(", ") + "]" : "";
        return `\u2713 ${totalApplied} edit(s) applied to ${args.path.split(/[\\/]/).pop()}${lineInfo}${matchInfo}${multiWarn}`;
      } catch (err) {
        return "Error editing file: " + (err.message || err);
      }
    });
  });
  import_electron8.ipcMain.handle("qqqide:ai:create_file", async (_e, args) => {
    return _qe(args.path, async () => {
      try {
        try {
          await fs12.promises.access(args.path);
          return `Error: file already exists: ${args.path}. Use edit_file to modify existing files.`;
        } catch {
        }
        try {
          await fs12.promises.mkdir(path13.dirname(args.path), { recursive: true });
        } catch {
        }
        await fs12.promises.writeFile(args.path, args.content);
        const syntaxErr2 = checkSyntaxSync(args.path, null, void 0);
        if (syntaxErr2)
          return syntaxErr2;
        try {
          const st2 = await fs12.promises.stat(args.path);
          _sn[args.path] = { mtimeMs: st2.mtimeMs, size: st2.size };
        } catch {
        }
        return `File created: ${args.path} (${args.content.length} chars)`;
      } catch (err) {
        return "Error creating file: " + (err.message || err);
      }
    });
  });
  import_electron8.ipcMain.handle("qqqide:ai:delete_file", async (_e, args) => {
    return _qe(args.path, async () => {
      try {
        try {
          await fs12.promises.access(args.path);
        } catch {
          return `Error: file not found: ${args.path}`;
        }
        await fs12.promises.unlink(args.path);
        delete _sn[args.path];
        return `Deleted: ${args.path}`;
      } catch (err) {
        return "Error deleting file: " + (err.message || err);
      }
    });
  });
  import_electron8.ipcMain.handle("qqqide:ai:write_file", async (_e, args) => {
    return _qe(args.path, async () => {
      try {
        const snap = _sn[args.path];
        if (snap) {
          try {
            const st = await fs12.promises.stat(args.path);
            if (st.mtimeMs !== snap.mtimeMs || st.size !== snap.size) {
              return "Error: file has been modified externally since last read. Please re-read the file and try again.";
            }
          } catch (_) {
          }
        }
        let origContent = null;
        try {
          origContent = await fs12.promises.readFile(args.path, "utf8");
        } catch (_) {
        }
        try {
          await fs12.promises.mkdir(path13.dirname(args.path), { recursive: true });
        } catch {
        }
        await fs12.promises.writeFile(args.path, args.content);
        const syntaxErr3 = checkSyntaxSync(args.path, origContent, void 0);
        if (syntaxErr3)
          return syntaxErr3;
        try {
          const st2 = await fs12.promises.stat(args.path);
          _sn[args.path] = { mtimeMs: st2.mtimeMs, size: st2.size };
        } catch {
        }
        return `File written: ${args.path} (${args.content.length} chars)`;
      } catch (err) {
        return "Error writing file: " + (err.message || err);
      }
    });
  });
}

// shell/ipc-misc.ts
var import_electron11 = require("electron");

// shell/browser-launcher.ts
var import_electron9 = require("electron");
var import_child_process7 = require("child_process");
var fs13 = __toESM(require("fs"));
var path14 = __toESM(require("path"));
var os4 = __toESM(require("os"));
var _logPath = null;
function getLogPath() {
  if (_logPath)
    return _logPath;
  try {
    const dataDir = import_electron9.app.getPath("userData");
    const dir = path14.join(dataDir, "alphal");
    if (!fs13.existsSync(dir))
      fs13.mkdirSync(dir, { recursive: true });
    _logPath = path14.join(dir, "browser-launch.log");
  } catch {
    _logPath = path14.join(os4.tmpdir(), "qqqide-browser-launch.log");
  }
  try {
    fs13.writeFileSync(_logPath, "", "utf8");
  } catch {
  }
  return _logPath;
}
function diag(msg) {
  const ts = (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").slice(0, 23);
  const line = `[${ts}] ${msg}`;
  console.log("[browser-launcher]", msg);
  try {
    fs13.appendFileSync(getLogPath(), line + "\n", "utf8");
  } catch {
  }
}
function openUrl(url, sender) {
  if (process.platform === "win32") {
    openUrlWindows(url, sender);
  } else {
    diag(`macOS/Linux: shell.openExternal url=${url}`);
    import_electron9.shell.openExternal(url).catch(
      (err) => diag(`shell.openExternal failed: ${err}`)
    );
  }
}
function openUrlWindows(url, sender) {
  diag(`=== openUrlWindows === url=${url}`);
  diag(`platform=${process.platform} arch=${process.arch} node=${process.version}`);
  const exe = findDefaultBrowserExe();
  diag(`default browser exe: ${exe || "NOT FOUND"}`);
  if (exe) {
    const bn = path14.basename(exe).toLowerCase();
    const isEdge = bn === "msedge.exe";
    const isChromium = ["msedge.exe", "chrome.exe", "brave.exe", "opera.exe", "chromium.exe"].indexOf(bn) !== -1;
    diag(`isEdge=${isEdge} isChromium=${isChromium}`);
  }
  let l1Rejected = false;
  diag("L1: shell.openExternal");
  import_electron9.shell.openExternal(url).then(() => {
    diag("L1: resolved (ShellExecuteW returned success)");
  }).catch((err) => {
    l1Rejected = true;
    diag(`L1: REJECTED \u2014 ${(err == null ? void 0 : err.message) || err}`);
    diag("L2: explorer.exe (fallback after L1 rejection)");
    try {
      const child = (0, import_child_process7.spawn)("explorer.exe", [url], {
        detached: true,
        stdio: "ignore",
        windowsHide: true
      });
      child.unref();
      child.on("error", (e) => diag(`L2 spawn error: ${e.message}`));
      diag("L2: spawn OK");
    } catch (e) {
      diag(`L2: exception \u2014 ${e.message}`);
    }
  });
  setTimeout(() => {
    diag(`3s fallback \u2014 l1Rejected=${l1Rejected}`);
    showFallbackViaIpc(url, sender);
    if (l1Rejected) {
      showNativeFallbackDialog(url);
    }
  }, 3e3);
}
function showFallbackViaIpc(url, sender) {
  if (!sender || sender.isDestroyed()) {
    diag("IPC fallback skipped: no sender or destroyed");
    return;
  }
  try {
    sender.send("qqqide:browser-fallback", { url });
    diag("IPC qqide:browser-fallback sent to renderer");
  } catch (e) {
    diag(`IPC fallback failed: ${e.message}`);
  }
}
function showNativeFallbackDialog(url) {
  diag("Showing native fallback dialog");
  import_electron9.dialog.showMessageBox({
    type: "warning",
    title: "\u65E0\u6CD5\u81EA\u52A8\u6253\u5F00\u6D4F\u89C8\u5668 \u2014 qqqide",
    message: "\u81EA\u52A8\u6253\u5F00\u6D4F\u89C8\u5668\u5931\u8D25\u3002\u8BF7\u590D\u5236\u4EE5\u4E0B\u94FE\u63A5\u5230\u6D4F\u89C8\u5668\u5730\u5740\u680F\uFF1A",
    detail: url,
    buttons: ["\u590D\u5236\u94FE\u63A5", "\u5173\u95ED"],
    defaultId: 0,
    cancelId: 1,
    noLink: true
  }).then((result) => {
    if (result.response === 0) {
      import_electron9.clipboard.writeText(url);
      diag('User clicked "\u590D\u5236\u94FE\u63A5"');
    } else {
      diag('User clicked "\u5173\u95ED"');
    }
  }).catch((err) => {
    diag(`Native dialog failed: ${err}`);
  });
}
function findDefaultBrowserExe() {
  try {
    const progId = regQuery(
      "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\Shell\\Associations\\UrlAssociations\\http\\UserChoice",
      "ProgId"
    );
    if (!progId) {
      diag("findDefaultBrowserExe: no ProgId for http");
      return null;
    }
    diag(`findDefaultBrowserExe: ProgId=${progId}`);
    const cmdLine = regQueryDefault(
      `HKEY_CLASSES_ROOT\\${progId}\\shell\\open\\command`
    );
    if (!cmdLine) {
      diag(`findDefaultBrowserExe: no command for ProgId=${progId}`);
      return null;
    }
    diag(`findDefaultBrowserExe: cmdLine=${cmdLine}`);
    const exe = parseExeFromCmdLine(cmdLine);
    if (!exe) {
      diag(`findDefaultBrowserExe: cannot parse exe from: ${cmdLine}`);
      return null;
    }
    if (!fs13.existsSync(exe)) {
      diag(`findDefaultBrowserExe: exe not found: ${exe}`);
      return null;
    }
    diag(`findDefaultBrowserExe: found ${exe}`);
    return exe;
  } catch (e) {
    diag(`findDefaultBrowserExe error: ${e.message}`);
    return null;
  }
}
function regQuery(key, value) {
  try {
    const output = (0, import_child_process7.execSync)(
      `reg query "${key}" /v "${value}"`,
      { encoding: "utf8", timeout: 3e3, windowsHide: true }
    );
    const lines = output.split("\n");
    for (const line of lines) {
      const m = line.match(/^\s*(?:\S+\s+)?REG_SZ\s+(.+)/);
      if (m)
        return m[1].trim();
    }
  } catch {
  }
  return null;
}
function regQueryDefault(key) {
  try {
    const output = (0, import_child_process7.execSync)(
      `reg query "${key}" /ve`,
      { encoding: "utf8", timeout: 3e3, windowsHide: true }
    );
    const lines = output.split("\n");
    for (const line of lines) {
      const m = line.match(/^\s*(?:\S+\s+)?REG_(?:SZ|EXPAND_SZ)\s+(.+)/);
      if (m)
        return m[1].trim();
    }
  } catch {
  }
  return null;
}
function parseExeFromCmdLine(cmdLine) {
  const quoted = cmdLine.match(/^\s*"([^"]+)"/);
  if (quoted) {
    const exe = quoted[1];
    if (fs13.existsSync(exe))
      return exe;
  }
  const parts = cmdLine.trim().split(/\s+/);
  if (parts.length > 0) {
    const exe = parts[0];
    if (fs13.existsSync(exe))
      return exe;
  }
  return null;
}

// shell/ipc-misc.ts
var path15 = __toESM(require("path"));
var fs14 = __toESM(require("fs"));
init_py_broker();

// shell/menu-builder.ts
var import_electron10 = require("electron");
function toElectronTemplate(items, win) {
  return items.map((it) => {
    if (it.type === "separator") {
      return { type: "separator" };
    }
    const out = {
      label: it.label,
      type: it.type,
      enabled: it.enabled !== false
    };
    if (it.role) {
      out.role = it.role;
    }
    if (it.accel) {
      out.accelerator = it.accel;
    }
    if (it.checked !== void 0) {
      out.checked = it.checked;
    }
    if (it.sub && it.sub.length > 0) {
      out.submenu = toElectronTemplate(it.sub, win);
    } else if (it.cmd) {
      const cmd = it.cmd;
      out.click = () => {
        if (win && !win.isDestroyed()) {
          win.webContents.send("qqqide:menu:fired", cmd);
        }
      };
    }
    return out;
  });
}
function applyMenuSchema(schema, win) {
  if (!schema || !schema.items || schema.items.length === 0) {
    import_electron10.Menu.setApplicationMenu(null);
    return;
  }
  const tpl = toElectronTemplate(schema.items, win);
  const menu = import_electron10.Menu.buildFromTemplate(tpl);
  import_electron10.Menu.setApplicationMenu(menu);
}

// shell/ipc-misc.ts
var _dirtySnapshots = /* @__PURE__ */ new Map();
function registerMiscIpc(portableRoot, portableCache, appVersion, isDevFlag2, lspBridge2, downloadService2, stateStore2, updateService2, getMainWindow, bootConfig2) {
  import_electron11.ipcMain.handle("qqqide:clipboard:writeText", async (_e, s) => import_electron11.clipboard.writeText(String(s)));
  import_electron11.ipcMain.handle("qqqide:clipboard:readText", async () => import_electron11.clipboard.readText());
  import_electron11.ipcMain.handle("qqqide:clipboard:readImage", async () => {
    var img = import_electron11.clipboard.readImage();
    return img.isEmpty() ? null : img.toDataURL();
  });
  import_electron11.ipcMain.handle("qqqide:clipboard:hasImage", async () => !import_electron11.clipboard.readImage().isEmpty());
  import_electron11.ipcMain.handle("qqqide:shell:openPath", async (_e, p) => {
    try {
      return await import_electron11.shell.openPath(p);
    } catch (e) {
      console.warn("[shell:openPath]", e);
      return "";
    }
  });
  import_electron11.ipcMain.handle("qqqide:shell:openExternal", async (_e, url) => {
    openUrl(url, _e.sender);
  });
  import_electron11.ipcMain.handle("qqqide:fs:drives", async () => {
    const drives = [];
    if (process.platform === "win32") {
      for (let i = 65; i <= 90; i++) {
        const d = String.fromCharCode(i) + ":\\";
        try {
          if (fs14.existsSync(d))
            drives.push(d);
        } catch {
        }
      }
      if (drives.length === 0)
        drives.push("C:\\");
    } else {
      drives.push("/");
    }
    return drives;
  });
  import_electron11.ipcMain.handle("qqqide:fs:diskFree", async (_e, drives) => {
    return await diskFreeBatch(portableRoot, drives);
  });
  import_electron11.ipcMain.handle("qqqide:dialog:open", async (_e, opts) => {
    const mainWindow2 = import_electron11.BrowserWindow.getAllWindows()[0] || null;
    if (!mainWindow2) {
      return null;
    }
    const result = await import_electron11.dialog.showOpenDialog(mainWindow2, opts || {});
    try {
      const wantsDir = !!(opts && Array.isArray(opts.properties) && opts.properties.indexOf("openDirectory") !== -1);
      if (result && Array.isArray(result.filePaths)) {
        for (const p of result.filePaths) {
          if (!p) {
            continue;
          }
          if (wantsDir) {
            addAssetRoot(p, stateStore2);
          } else {
            const dir = path15.dirname(p);
            if (dir) {
              addAssetRoot(dir, stateStore2);
            }
          }
        }
      }
    } catch (e) {
      console.warn("[qqqide:dialog:open] asset-root auto-extend failed:", e);
    }
    return result;
  });
  import_electron11.ipcMain.handle("qqqide:dialog:save", async (_e, opts) => {
    const mainWindow2 = import_electron11.BrowserWindow.getAllWindows()[0] || null;
    if (!mainWindow2) {
      return null;
    }
    return import_electron11.dialog.showSaveDialog(mainWindow2, opts || {});
  });
  import_electron11.ipcMain.handle("qqqide:dialog:message", async (_e, opts) => {
    const mainWindow2 = import_electron11.BrowserWindow.getAllWindows()[0] || null;
    if (!mainWindow2) {
      return null;
    }
    return import_electron11.dialog.showMessageBox(mainWindow2, opts || {});
  });
  import_electron11.ipcMain.handle("qqqide:assetRoots:add", async (_e, absDir) => addAssetRoot(absDir, stateStore2));
  import_electron11.ipcMain.handle("qqqide:assetRoots:list", async () => Array.from(_assetFileWorkspaceRoots));
  import_electron11.ipcMain.handle("qqqide:assetRoots:remove", async (_e, absDir) => {
    if (!absDir) {
      return false;
    }
    const ok = _assetFileWorkspaceRoots.delete(path15.normalize(absDir));
    if (ok) {
      const arr = Array.from(_assetFileWorkspaceRoots);
      try {
        stateStore2.set("qqqide", "asset_roots", arr);
      } catch {
      }
    }
    return ok;
  });
  import_electron11.ipcMain.handle("qqqide:app:quitAll", async () => {
    import_electron11.BrowserWindow.getAllWindows().forEach(function(w) {
      if (!w.isDestroyed())
        bypassCloseConfirm(w);
    });
    import_electron11.app.quit();
  });
  import_electron11.ipcMain.handle("qqqide:window:minimize", (e) => {
    var _a;
    (_a = import_electron11.BrowserWindow.fromWebContents(e.sender)) == null ? void 0 : _a.minimize();
  });
  import_electron11.ipcMain.handle("qqqide:window:maximize", (e) => {
    var _a;
    (_a = import_electron11.BrowserWindow.fromWebContents(e.sender)) == null ? void 0 : _a.maximize();
  });
  import_electron11.ipcMain.handle("qqqide:window:unmaximize", (e) => {
    var _a;
    (_a = import_electron11.BrowserWindow.fromWebContents(e.sender)) == null ? void 0 : _a.unmaximize();
  });
  import_electron11.ipcMain.handle("qqqide:window:close", (e) => {
    const win = import_electron11.BrowserWindow.fromWebContents(e.sender);
    if (win && !win.isDestroyed()) {
      win.close();
    }
  });
  import_electron11.ipcMain.handle("qqqide:window:close-confirmed", (e) => {
    const win = import_electron11.BrowserWindow.fromWebContents(e.sender);
    if (win && !win.isDestroyed()) {
      bypassCloseConfirm(win);
      win.destroy();
    }
  });
  import_electron11.ipcMain.handle("qqqide:window:isMaximized", (e) => {
    var _a;
    return ((_a = import_electron11.BrowserWindow.fromWebContents(e.sender)) == null ? void 0 : _a.isMaximized()) ?? false;
  });
  import_electron11.ipcMain.handle("qqqide:window:setTitle", (e, s) => {
    const win = import_electron11.BrowserWindow.fromWebContents(e.sender);
    if (!win)
      return;
    win.setTitle(String(s));
  });
  import_electron11.ipcMain.handle("qqqide:window:toggleDevTools", (e) => {
    const win = import_electron11.BrowserWindow.fromWebContents(e.sender);
    if (!win || win.isDestroyed()) {
      return;
    }
    const wc = win.webContents;
    if (wc.isDevToolsOpened()) {
      wc.closeDevTools();
    } else {
      wc.openDevTools({ mode: "detach" });
    }
  });
  import_electron11.ipcMain.handle("qqqide:window:new", async (_e, folderPath) => {
    if (folderPath && typeof folderPath === "string") {
      const normalized = folderPath.replace(/\\/g, "/").replace(/\/$/, "");
      const existingWinId = _projectWindowMap.get(normalized);
      if (existingWinId != null) {
        const existingWin = import_electron11.BrowserWindow.fromId(existingWinId);
        if (existingWin && !existingWin.isDestroyed()) {
          if (existingWin.isMinimized())
            existingWin.restore();
          existingWin.focus();
          return { ok: false, locked: true, existingWindowId: existingWinId };
        }
        _projectWindowMap.delete(normalized);
        _windowProjectMap.delete(existingWinId);
      }
      const lockPath = normalized + "/qqq/alphal/.lock";
      try {
        const lockRaw = fs14.readFileSync(lockPath, "utf-8");
        const lockData = JSON.parse(lockRaw);
        const age = Date.now() - (lockData.atime || 0);
        if (age < 6e4) {
          return { ok: false, locked: true, existingWindowId: null };
        }
        try {
          fs14.unlinkSync(lockPath);
        } catch (_) {
        }
      } catch (_) {
      }
    }
    const newWin = createWindow(portableRoot, portableCache, appVersion, lspBridge2, downloadService2, stateStore2);
    if (folderPath && typeof folderPath === "string") {
      const normalized = folderPath.replace(/\\/g, "/").replace(/\/$/, "");
      _windowProjectMap.set(newWin.id, normalized);
      _projectWindowMap.set(normalized, newWin.id);
    }
    const baseUrl = getWebappBaseUrl(portableRoot, bootConfig2, isDevFlag2);
    const cacheBust = "&_v=" + encodeURIComponent(appVersion);
    let url;
    if (folderPath && typeof folderPath === "string") {
      url = baseUrl + "?restore=1&folder=" + encodeURIComponent(folderPath) + cacheBust;
    } else {
      url = baseUrl + "?fresh=1" + cacheBust;
    }
    newWin.loadURL(url).then(() => {
      newWin.show();
    }).catch((err) => {
      console.error("[window:new] loadURL FAILED:", err);
    });
    return { ok: true, windowId: newWin.id };
  });
  import_electron11.ipcMain.handle("qqqide:sync:broadcast", (e, channel, data) => {
    for (const win of import_electron11.BrowserWindow.getAllWindows()) {
      if (win.isDestroyed() || win.webContents.isDestroyed())
        continue;
      try {
        win.webContents.send("qqqide:sync:message", channel, data);
      } catch {
      }
    }
  });
  let _currentProjectPath = null;
  import_electron11.ipcMain.handle("qqqide:sync:get-project-path", () => _currentProjectPath);
  import_electron11.ipcMain.handle("qqqide:sync:set-project-path", (e, p) => {
    const senderWin = import_electron11.BrowserWindow.fromWebContents(e.sender);
    const mainWindow2 = getMainWindow();
    if (senderWin !== mainWindow2)
      return;
    _currentProjectPath = p;
  });
  import_electron11.ipcMain.handle("qqqide:sync:get-theme", () => {
    try {
      const mainWindow2 = getMainWindow();
      if (mainWindow2 && !mainWindow2.isDestroyed()) {
        return mainWindow2.webContents.executeJavaScript(
          'document.documentElement.getAttribute("data-theme") === "dark"'
        );
      }
    } catch (_) {
    }
    return false;
  });
  import_electron11.ipcMain.handle("qqqide:window:claimProject", (_e, projectRoot) => {
    const win = import_electron11.BrowserWindow.fromWebContents(_e.sender);
    if (!win)
      return false;
    const normalized = projectRoot.replace(/\\/g, "/").replace(/\/$/, "");
    const oldProject = _windowProjectMap.get(win.id);
    if (oldProject && oldProject !== normalized) {
      _projectWindowMap.delete(oldProject);
    }
    _windowProjectMap.set(win.id, normalized);
    _projectWindowMap.set(normalized, win.id);
    const projName = path15.basename(normalized);
    console.log("[devtools] claimProject: winId=" + win.id + " normalized=" + normalized + " projName=" + projName);
    setTimeout(() => renameDevToolsViaBroker(win, projName), 1500);
    return true;
  });
  import_electron11.ipcMain.handle("qqqide:window:releaseProject", (_e, projectRoot) => {
    const win = import_electron11.BrowserWindow.fromWebContents(_e.sender);
    if (!win)
      return false;
    const normalized = projectRoot.replace(/\\/g, "/").replace(/\/$/, "");
    const currentProject = _windowProjectMap.get(win.id);
    if (currentProject === normalized) {
      _windowProjectMap.delete(win.id);
      _projectWindowMap.delete(normalized);
    }
    return true;
  });
  import_electron11.ipcMain.handle("qqqide:devtools:rename", (_e, projectRoot) => {
    const win = import_electron11.BrowserWindow.fromWebContents(_e.sender);
    if (!win)
      return false;
    const normalized = projectRoot.replace(/\\/g, "/").replace(/\/$/, "");
    const projName = path15.basename(normalized);
    console.log("[devtools] direct-rename: winId=" + win.id + " projName=" + projName + " brokerReady=" + isPyBrokerReady());
    renameDevToolsViaBroker(win, projName);
    return true;
  });
  import_electron11.ipcMain.handle("qqqide:window:adjust-bounds", async (e, deltaLeft, deltaRight) => {
    const win = import_electron11.BrowserWindow.fromWebContents(e.sender);
    if (!win || win.isDestroyed())
      return;
    const b = win.getBounds();
    const newX = b.x - deltaLeft;
    const newW = b.width + deltaLeft + deltaRight;
    win.setBounds({ x: newX, y: b.y, width: newW, height: b.height });
  });
  import_electron11.ipcMain.handle("qqqide:wing:state", async (e, leftOpen, rightOpen) => {
    const win = import_electron11.BrowserWindow.fromWebContents(e.sender);
    updateWingMinSize(win, leftOpen, rightOpen);
  });
  import_electron11.ipcMain.handle("qqqide:zoom:get", () => editorFontSize);
  import_electron11.ipcMain.handle("qqqide:zoom:set", (_e, size) => {
    const s = Math.max(1, Math.min(128, Math.round(Number(size))));
    setEditorFontSize(s);
    saveEditorFontSize(stateStore2);
    broadcastEditorFontSize(s);
    return s;
  });
  import_electron11.ipcMain.handle("qqqide:zoom:adjust", (_e, delta) => {
    const next = Math.max(1, Math.min(128, Math.round(editorFontSize + Number(delta))));
    setEditorFontSize(next);
    broadcastEditorFontSize(next);
    return next;
  });
  import_electron11.ipcMain.handle("qqqide:menu:set", (_e, schema) => {
    applyMenuSchema(schema, getMainWindow());
    return true;
  });
  import_electron11.ipcMain.handle("qqqide:update:check", async () => updateService2.check());
  import_electron11.ipcMain.handle("qqqide:update:apply", async () => updateService2.apply());
  import_electron11.ipcMain.handle("qqqide:update:state", async () => updateService2.getState());
  import_electron11.ipcMain.handle("qqqide:update:upgrade-shell", async () => updateService2.upgradeShell());
  import_electron11.ipcMain.handle("qqqide:dirty:set", (_e, filePath, content) => {
    _dirtySnapshots.set(filePath.replace(/\\/g, "/"), content);
  });
  import_electron11.ipcMain.handle("qqqide:dirty:get", (_e, filePath) => {
    return _dirtySnapshots.get(filePath.replace(/\\/g, "/")) || null;
  });
  import_electron11.ipcMain.handle("qqqide:dirty:remove", (_e, filePath) => {
    _dirtySnapshots.delete(filePath.replace(/\\/g, "/"));
  });
  import_electron11.ipcMain.handle("qqqide:dirty:list", () => {
    return [..._dirtySnapshots.keys()];
  });
}

// shell/ipc-timeline.ts
var import_electron12 = require("electron");
var path16 = __toESM(require("path"));
var fs15 = __toESM(require("fs"));
function registerTimelineIpc(portableRoot, bootConfig2) {
  const COOLING_MS = 1e5;
  const COOLING_SOURCES = /* @__PURE__ */ new Set(["editx"]);
  const _lastRecordTs = /* @__PURE__ */ new Map();
  const _lastRecordHash = /* @__PURE__ */ new Map();
  import_electron12.ipcMain.handle("qqqide:timeline:record", async (_e, args) => {
    try {
      const { projectRoot, filePath, content, source, floorId, addedLines, deletedLines } = args;
      if (!projectRoot || !filePath || content === void 0 || content === null)
        return { ok: false, error: "missing args" };
      const normalizedPath = filePath.replace(/\\/g, "/");
      const sha = _sha256(content);
      if (COOLING_SOURCES.has(source)) {
        const coolKey = normalizedPath + "|" + source;
        const prevHash = _lastRecordHash.get(coolKey);
        if (prevHash === sha)
          return { ok: true, blob_hash: sha, recorded: false, reason: "same-content" };
        const prevTs = _lastRecordTs.get(coolKey) || 0;
        const now = Date.now();
        if (now - prevTs < COOLING_MS)
          return { ok: true, blob_hash: sha, recorded: false, reason: "cooling" };
        _lastRecordTs.set(coolKey, now);
        _lastRecordHash.set(coolKey, sha);
      }
      const db = await _tlOpenDb(projectRoot);
      const dbPath = path16.join(_tlDir(projectRoot), "timeline.db");
      const blobPath = _tlBlobPath(projectRoot, sha);
      if (!fs15.existsSync(blobPath)) {
        const gzBuf = _gzipSync(content);
        _tlWriteBlob(projectRoot, sha, gzBuf);
      }
      const ts = Date.now();
      _tlRecord(db, dbPath, projectRoot, {
        file_path: normalizedPath,
        ts,
        blob_hash: sha,
        source,
        floor_id: floorId || null,
        added_lines: addedLines || null,
        deleted_lines: deletedLines || null
      });
      return { ok: true, blob_hash: sha, ts, recorded: true };
    } catch (err) {
      console.error("[timeline:record]", err);
      return { ok: false, error: err.message };
    }
  });
  import_electron12.ipcMain.handle("qqqide:timeline:versions", async (_e, args) => {
    try {
      const { projectRoot, filePath } = args;
      if (!projectRoot || !filePath)
        return [];
      const normalizedPath = filePath.replace(/\\/g, "/");
      const db = await _tlOpenDb(projectRoot);
      const stmt = db.prepare("SELECT id, ts, blob_hash, source, floor_id, added_lines, deleted_lines, file_seq FROM versions WHERE file_path = ? ORDER BY id ASC");
      stmt.bind([normalizedPath]);
      const versionRows = [];
      while (stmt.step()) {
        const row = stmt.getAsObject();
        versionRows.push({
          id: row.id,
          ts: row.ts,
          blob_hash: row.blob_hash,
          source: row.source,
          floor_id: row.floor_id,
          added_lines: row.added_lines,
          deleted_lines: row.deleted_lines,
          file_seq: row.file_seq
        });
      }
      stmt.free();
      return versionRows;
    } catch (err) {
      console.error("[timeline:versions]", err);
      return [];
    }
  });
  import_electron12.ipcMain.handle("qqqide:timeline:content", async (_e, args) => {
    try {
      const { projectRoot, blobHash } = args;
      if (!projectRoot || !blobHash)
        return null;
      const blobPath = _tlBlobPath(projectRoot, blobHash);
      if (!fs15.existsSync(blobPath))
        return null;
      const gzBuf = fs15.readFileSync(blobPath);
      return _gunzipSync(gzBuf);
    } catch (err) {
      console.error("[timeline:content]", err);
      return null;
    }
  });
  import_electron12.ipcMain.handle("qqqide:timeline:stat", async (_e, filePath) => {
    try {
      const st = fs15.statSync(filePath);
      return { mtimeMs: st.mtimeMs, size: st.size };
    } catch (_) {
      return null;
    }
  });
  import_electron12.ipcMain.handle("qqqide:timeline:readCurrent", async (_e, filePath) => {
    try {
      return fs15.readFileSync(filePath, "utf8");
    } catch (_) {
      return null;
    }
  });
  import_electron12.ipcMain.handle("qqqide:timeline:listTrackedFiles", async (_e, args) => {
    try {
      const { projectRoot } = args;
      if (!projectRoot)
        return [];
      const db = await _tlOpenDb(projectRoot);
      const stmt = db.prepare("SELECT DISTINCT file_path, MAX(ts) as latest_ts FROM versions GROUP BY file_path ORDER BY file_path ASC");
      const files = [];
      while (stmt.step()) {
        const row = stmt.getAsObject();
        let exists = false;
        try {
          exists = fs15.existsSync(row.file_path);
        } catch (_) {
        }
        files.push({
          file_path: row.file_path,
          latest_ts: row.latest_ts,
          exists
        });
      }
      stmt.free();
      return files;
    } catch (err) {
      console.error("[timeline:listTrackedFiles]", err);
      return [];
    }
  });
  import_electron12.ipcMain.handle("qqqide:timeline:captureChanged", async (_e, args) => {
    const { projectRoot, sinceMs } = args;
    const scanRoot = args.cwd && args.cwd.startsWith(projectRoot) ? args.cwd : projectRoot;
    if (!projectRoot || !sinceMs)
      return [];
    const MAX_SIZE = 512 * 1024;
    function isBinary(content) {
      return content.indexOf("\0") !== -1;
    }
    function tryRead(fp) {
      try {
        const st = fs15.statSync(fp);
        if (st.mtimeMs <= sinceMs || st.size > MAX_SIZE)
          return null;
        const content = fs15.readFileSync(fp, "utf8");
        if (isBinary(content))
          return null;
        return { filePath: fp.replace(/\\/g, "/"), content, size: st.size, mtimeMs: st.mtimeMs };
      } catch (_) {
        return null;
      }
    }
    const changed = [];
    let gitOk = false;
    try {
      const { execSync: execSync6 } = require("child_process");
      const gitFiles = /* @__PURE__ */ new Set();
      for (const gitArgs of [["diff", "--name-only", "--diff-filter=ACMR"], ["diff", "--cached", "--name-only", "--diff-filter=ACMR"]]) {
        try {
          const out = execSync6("git", gitArgs, { cwd: scanRoot, timeout: 5e3, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
          for (const line of out.split("\n")) {
            const t = line.trim();
            if (t)
              gitFiles.add(path16.resolve(scanRoot, t));
          }
        } catch (_) {
        }
      }
      if (gitFiles.size > 0) {
        gitOk = true;
        for (const fp of gitFiles) {
          const f = tryRead(fp);
          if (f)
            changed.push(f);
        }
      }
    } catch (_) {
    }
    if (!gitOk) {
      let walkNew2 = function(dir) {
        if (scanned >= MAX_FILES2)
          return;
        let entries;
        try {
          entries = fs15.readdirSync(dir, { withFileTypes: true });
        } catch (_) {
          return;
        }
        for (const ent of entries) {
          if (scanned >= MAX_FILES2)
            return;
          const fp = path16.join(dir, ent.name);
          if (ent.isDirectory()) {
            if (ent.name === "node_modules" || ent.name === ".git" || ent.name === ".tmp")
              continue;
            walkNew2(fp);
          } else if ((ent.isFile() || ent.isSymbolicLink()) && !indexedSet.has(fp)) {
            if (ent.name.endsWith("~") || ent.name.indexOf(".tmp.") !== -1)
              continue;
            if (ent.name === ".DS_Store" || ent.name === "Thumbs.db" || ent.name === "desktop.ini")
              continue;
            scanned++;
            const f = tryRead(fp);
            if (f)
              changed.push(f);
          }
        }
      };
      var walkNew = walkNew2;
      const indexPath = path16.join(_tlDir(projectRoot), "file-index.json");
      let indexed = [];
      try {
        if (fs15.existsSync(indexPath))
          indexed = JSON.parse(fs15.readFileSync(indexPath, "utf8"));
      } catch (_) {
      }
      const indexedSet = new Set(indexed);
      for (const fp of indexed) {
        const f = tryRead(fp);
        if (f)
          changed.push(f);
      }
      const MAX_FILES2 = 500;
      let scanned = 0;
      walkNew2(scanRoot);
    }
    const results = [];
    for (const f of changed) {
      try {
        const sha = _sha256(f.content);
        const blobPath = _tlBlobPath(projectRoot, sha);
        if (!fs15.existsSync(blobPath)) {
          const gzBuf = _gzipSync(f.content);
          _tlWriteBlob(projectRoot, sha, gzBuf);
        }
        const db = await _tlOpenDb(projectRoot);
        const dbPath2 = path16.join(_tlDir(projectRoot), "timeline.db");
        const ts = Date.now();
        _tlRecord(db, dbPath2, projectRoot, {
          file_path: f.filePath,
          ts,
          blob_hash: sha,
          source: "run-command"
        });
        results.push({ filePath: f.filePath, blob_hash: sha });
      } catch (_) {
      }
    }
    return results;
  });
  import_electron12.ipcMain.handle("qqqide:open-diff-window", async (e, args) => {
    const { filePath, beforeBlobHash, afterBlobHash, projectRoot } = args;
    const normalizedPath = filePath.replace(/\\/g, "/");
    const existingWin = _diffWindows.get(normalizedPath);
    if (existingWin && !existingWin.isDestroyed()) {
      try {
        existingWin.webContents.send("qqqide:diff:update", { filePath: normalizedPath, beforeBlobHash, afterBlobHash });
        if (existingWin.isMinimized())
          existingWin.restore();
        existingWin.focus();
      } catch (_) {
      }
      return { ok: true, windowId: existingWin.id, reused: true };
    }
    const _parentWin = import_electron12.BrowserWindow.fromWebContents(e.sender);
    const mainWindow2 = import_electron12.BrowserWindow.getAllWindows()[0] || null;
    let mainRect = { x: 0, y: 0, width: 1200, height: 700 };
    if (mainWindow2 && !mainWindow2.isDestroyed()) {
      try {
        const jsRect = await mainWindow2.webContents.executeJavaScript(
          `(function(){var m=document.getElementById('qqq-main');if(!m)return null;var r=m.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height};})()`
        );
        if (jsRect && jsRect.w > 0) {
          const wb = mainWindow2.getBounds();
          mainRect = { x: wb.x + (jsRect.x || 0), y: wb.y + (jsRect.y || 0), width: jsRect.w, height: jsRect.h };
        } else {
          const wb = mainWindow2.getBounds();
          mainRect = { x: wb.x, y: wb.y, width: wb.width, height: wb.height };
        }
      } catch (_) {
        const wb = mainWindow2.getBounds();
        mainRect = { x: wb.x, y: wb.y, width: wb.width, height: wb.height };
      }
    }
    const diffWin = new import_electron12.BrowserWindow({
      x: mainRect.x,
      y: mainRect.y,
      width: Math.max(1100, mainRect.width),
      height: Math.max(800, mainRect.height),
      minWidth: 1100,
      minHeight: 800,
      frame: false,
      title: "Timeline Diff \u2014 " + (filePath.split(/[\\/]/).pop() || filePath),
      backgroundColor: "#1e1e1e",
      parent: _parentWin || void 0,
      modal: false,
      resizable: true,
      webPreferences: {
        preload: path16.join(__dirname, "preload.js"),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
        webSecurity: false,
        additionalArguments: [
          `--qqqide-root=${portableRoot}`,
          `--qqqide-version=${APP_VERSION}`
        ]
      }
    });
    diffWin.removeMenu();
    diffWin.on("closed", () => {
      _diffWindows.delete(normalizedPath);
      for (const [k, v] of _diffWindows) {
        if (v === diffWin)
          _diffWindows.delete(k);
      }
    });
    _diffWindows.set(normalizedPath, diffWin);
    diffWin.webContents.on("ipc-message", (_ev, ch, ...args2) => {
      if (ch === "qqqide:diff:set-path") {
        const newPath = args2 && args2[0] ? String(args2[0]).replace(/\\/g, "/") : "";
        if (newPath && newPath !== normalizedPath) {
          _diffWindows.delete(normalizedPath);
          _diffWindows.set(newPath, diffWin);
        }
      }
    });
    var diffBaseUrl = bootConfig2.url.replace(/\/*$/, "/");
    try {
      var webappIndex = path16.join(portableRoot, "Data", "webapp", "index.html");
      if (fs15.existsSync(webappIndex)) {
        diffBaseUrl = "qqqide-webapp://app/qqqide/";
      }
    } catch (_) {
    }
    let _isDark = true;
    try {
      if (mainWindow2 && !mainWindow2.isDestroyed()) {
        _isDark = await mainWindow2.webContents.executeJavaScript(
          'document.documentElement.getAttribute("data-theme") === "dark"'
        );
      }
    } catch (_) {
    }
    const diffUrl = diffBaseUrl + "timeline/diff-window.html?path=" + encodeURIComponent(filePath) + "&projectRoot=" + encodeURIComponent(projectRoot) + "&theme=" + (_isDark ? "dark" : "light") + (beforeBlobHash ? "&before=" + encodeURIComponent(beforeBlobHash) : "") + (afterBlobHash ? "&after=" + encodeURIComponent(afterBlobHash) : "");
    diffWin.loadURL(diffUrl).catch((err) => {
      console.warn("[diff-window] loadURL failed:", err && err.message);
      _diffWindows.delete(normalizedPath);
    });
    return { ok: true, windowId: diffWin.id };
  });
  import_electron12.ipcMain.on("qqqide:timeline:open-in-editor", (_e, filePath) => {
    if (!filePath)
      return;
    const mw = import_electron12.BrowserWindow.getAllWindows()[0];
    if (!mw || mw.isDestroyed())
      return;
    mw.webContents.executeJavaScript(
      `(function(){ if(window.qqqTabs&&window.qqqTabs.openFile) window.qqqTabs.openFile(${JSON.stringify(filePath)}); })()`
    ).catch(() => {
    });
  });
  import_electron12.ipcMain.on("qqqide:timeline:feed-to-ai", (_e, filePath) => {
    if (!filePath)
      return;
    const mw = import_electron12.BrowserWindow.getAllWindows()[0];
    if (!mw || mw.isDestroyed())
      return;
    mw.webContents.executeJavaScript(
      `(function(){ if(window.__qqq_aiFeedFile) window.__qqq_aiFeedFile(${JSON.stringify(filePath)},false,null); })()`
    ).catch(() => {
    });
  });
}

// shell/ipc-git-diff.ts
var import_electron13 = require("electron");
var path17 = __toESM(require("path"));
init_component_checker();
var _gitDiffWindows = /* @__PURE__ */ new Map();
function registerGitDiffIpc(portableRoot, bootConfig2) {
  import_electron13.ipcMain.handle("qqqide:git:open-diff", async (e, args) => {
    const { filePath, projectRoot, commitHash, mode, staged } = args;
    const winKey = filePath.replace(/\\/g, "/") + "|" + (commitHash || "working");
    const normalizedPath = filePath.replace(/\\/g, "/");
    const existingWin = _gitDiffWindows.get(winKey);
    if (existingWin && !existingWin.isDestroyed()) {
      try {
        existingWin.webContents.send("qqqide:git-diff:update", { filePath: normalizedPath, commitHash, mode, staged });
        if (existingWin.isMinimized())
          existingWin.restore();
        existingWin.focus();
      } catch (_) {
      }
      return { ok: true, windowId: existingWin.id, reused: true };
    }
    const mainWin = import_electron13.BrowserWindow.fromWebContents(e.sender);
    let mainRect = { x: 0, y: 0, width: 1200, height: 700 };
    if (mainWin && !mainWin.isDestroyed()) {
      try {
        const wb = mainWin.getBounds();
        mainRect = { x: wb.x, y: wb.y, width: wb.width, height: wb.height };
      } catch (_) {
      }
    }
    let menuBarH = 0, statusBarH = 0;
    try {
      if (mainWin && !mainWin.isDestroyed()) {
        menuBarH = await mainWin.webContents.executeJavaScript(
          '(document.getElementById("qqq-menu-row")?.offsetHeight || 28)'
        );
        statusBarH = await mainWin.webContents.executeJavaScript(
          '(document.getElementById("qqq-status-bar")?.offsetHeight || 24)'
        );
      }
    } catch (_) {
    }
    const diffW = Math.floor(mainRect.width * 2 / 3);
    const diffH = mainRect.height - menuBarH - statusBarH;
    const diffX = mainRect.x + (mainRect.width - diffW);
    const diffY = mainRect.y + menuBarH;
    const diffWin = new import_electron13.BrowserWindow({
      x: diffX,
      y: diffY,
      width: Math.max(800, diffW),
      height: Math.max(600, diffH),
      minWidth: 800,
      minHeight: 600,
      frame: false,
      title: "Git Diff \u2014 " + (filePath.split(/[\\/]/).pop() || filePath),
      backgroundColor: "#1e1e1e",
      parent: mainWin || void 0,
      modal: false,
      resizable: true,
      webPreferences: {
        preload: path17.join(__dirname, "preload.js"),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: false,
        webSecurity: false,
        additionalArguments: [
          `--qqqide-root=${portableRoot}`,
          `--qqqide-version=${APP_VERSION}`
        ]
      }
    });
    diffWin.removeMenu();
    diffWin.on("closed", () => {
      _gitDiffWindows.delete(winKey);
    });
    _gitDiffWindows.set(winKey, diffWin);
    const diffBaseUrl = bootConfig2.url.replace(/\/*$/, "/");
    let _isDark = true;
    try {
      if (mainWin && !mainWin.isDestroyed()) {
        _isDark = await mainWin.webContents.executeJavaScript(
          'document.documentElement.getAttribute("data-theme") === "dark"'
        );
      }
    } catch (_) {
    }
    const _gitBin = getComponentBin(portableRoot, "git") || "git";
    const diffUrl = diffBaseUrl + "goods/git/git-diff-window.html?filePath=" + encodeURIComponent(filePath) + "&projectRoot=" + encodeURIComponent(projectRoot) + "&gitBin=" + encodeURIComponent(_gitBin) + "&theme=" + (_isDark ? "dark" : "light") + "&mode=" + (mode || "working") + (commitHash ? "&commitHash=" + encodeURIComponent(commitHash) : "") + (staged ? "&staged=1" : "");
    console.log("[git-diff-window] loading:", diffUrl);
    diffWin.loadURL(diffUrl).catch((err) => {
      console.warn("[git-diff-window] loadURL failed:", err && err.message);
      _gitDiffWindows.delete(winKey);
      try {
        diffWin.close();
      } catch (_) {
      }
    });
    return { ok: true, windowId: diffWin.id };
  });
}

// shell/ipc-smart-search.ts
var import_electron14 = require("electron");
var path19 = __toESM(require("path"));
var fs17 = __toESM(require("fs"));

// shell/index-service.ts
var path18 = __toESM(require("path"));
var fs16 = __toESM(require("fs"));
var BM25_K1 = 1.5;
var BM25_B = 0.75;
var SKIP_DIRS = /* @__PURE__ */ new Set([
  "node_modules",
  ".git",
  "dist",
  "backup",
  "__pycache__",
  ".venv",
  "vendor",
  "build",
  "out",
  ".next",
  ".nuxt",
  ".cache",
  "coverage",
  "target",
  "logs",
  ".hg",
  ".svn",
  "bower_components",
  ".idea",
  ".vs",
  "cache",
  "temp",
  "crashDumps",
  "dist-pack",
  "shell-out",
  "shell-build",
  ".qoder",
  "Data",
  "logs",
  "new_log",
  "tmp",
  "op"
]);
var SKIP_EXTS = /* @__PURE__ */ new Set([
  ".exe",
  ".dll",
  ".so",
  ".dylib",
  ".bin",
  ".png",
  ".jpg",
  ".jpeg",
  ".gif",
  ".bmp",
  ".webp",
  ".ico",
  ".mp3",
  ".mp4",
  ".avi",
  ".mkv",
  ".mov",
  ".wav",
  ".flac",
  ".ogg",
  ".zip",
  ".tar",
  ".gz",
  ".xz",
  ".bz2",
  ".7z",
  ".rar",
  ".woff",
  ".woff2",
  ".ttf",
  ".eot",
  ".pdf",
  ".vsix",
  ".wasm",
  ".class",
  ".o",
  ".obj",
  ".pyc",
  ".pyo",
  ".sqlite",
  ".db",
  ".lock",
  ".otf"
]);
var MAX_FILE_SIZE = 500 * 1024;
var CHUNK_MIN = 100;
var CHUNK_MAX = 4e3;
var MAX_FILES = 5e4;
var FUNC_RE = /(?:^|\n)\s*(?:export\s+)?(?:async\s+)?(?:function|def|fn|func)\s+(\w+)/g;
var CLASS_RE = /(?:^|\n)\s*(?:export\s+)?(?:class|interface|struct|enum|type)\s+(\w+)/g;
var IMPORT_RE = /(?:import|require|from)\s+.*?['"](\S+?)['"]/g;
var EXPORT_RE = /export\s+(?:default\s+)?(?:function|class|const|let|var)\s+(\w+)/g;
var TOKEN_RE = /[a-zA-Z_]\w{1,}/g;
var STOP_WORDS = /* @__PURE__ */ new Set([
  "the",
  "is",
  "at",
  "which",
  "on",
  "a",
  "an",
  "and",
  "or",
  "not",
  "but",
  "in",
  "with",
  "to",
  "for",
  "of",
  "by",
  "from",
  "as",
  "be",
  "this",
  "that",
  "it",
  "are",
  "was",
  "were",
  "been",
  "has",
  "had",
  "do",
  "does",
  "did",
  "will",
  "would",
  "could",
  "should",
  "may",
  "might",
  "can",
  "shall",
  "you",
  "he",
  "she",
  "they",
  "we",
  "me",
  "him",
  "her",
  "us",
  "them",
  "my",
  "your",
  "his",
  "its",
  "our",
  "their",
  "if",
  "else",
  "then",
  "than",
  "so",
  "no",
  "yes",
  "just",
  "very",
  "too",
  "also",
  "now",
  "here",
  "there",
  "when",
  "where",
  "why",
  "how",
  "all",
  "each",
  "every",
  "both",
  "few",
  "more",
  "most",
  "some",
  "any",
  "one",
  "two",
  "get",
  "set",
  "let",
  "var",
  "const",
  "new",
  "return",
  "true",
  "false",
  "null",
  "undefined",
  "typeof",
  "instanceof",
  "void",
  "delete",
  "type",
  "interface"
]);
function tokenize(text) {
  const tokens = [];
  const lower = text.toLowerCase();
  let m;
  const re = new RegExp(TOKEN_RE.source, "g");
  while ((m = re.exec(lower)) !== null) {
    const t = m[0];
    if (t.length < 2 || STOP_WORDS.has(t))
      continue;
    tokens.push(t);
  }
  return tokens;
}
function chunkFile(content, ext) {
  const chunks = [];
  const isCode = [
    ".ts",
    ".js",
    ".py",
    ".go",
    ".rs",
    ".java",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".tsx",
    ".jsx",
    ".vue",
    ".svelte",
    ".rb",
    ".php",
    ".swift",
    ".kt",
    ".scala"
  ].includes(ext);
  if (isCode) {
    const lines = content.split("\n");
    let chunkStart = 0;
    let chunkLines = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      chunkLines.push(line);
      const isBoundary = /^(export\s+)?(async\s+)?(function|def|fn|func|class|interface|struct|enum|type|impl|pub\s+fn|public\s+class)\s/.test(line.trim()) && (i === 0 || lines[i - 1].trim() === "");
      const chunkLen = chunkLines.join("\n").length;
      if (isBoundary && chunkLen > CHUNK_MIN || chunkLen >= CHUNK_MAX) {
        const text = chunkLines.join("\n");
        chunks.push({
          start: chunkStart,
          end: chunkStart + text.length,
          tokens: tokenize(text),
          type: "code"
        });
        chunkStart += text.length + 1;
        chunkLines = [];
      }
    }
    if (chunkLines.length > 0) {
      const text = chunkLines.join("\n");
      if (text.trim().length >= CHUNK_MIN) {
        chunks.push({
          start: chunkStart,
          end: chunkStart + text.length,
          tokens: tokenize(text),
          type: "code"
        });
      }
    }
  } else {
    const paragraphs = content.split(/\n\n+/);
    let pos = 0;
    for (const para of paragraphs) {
      if (para.trim().length < CHUNK_MIN) {
        pos += para.length + 2;
        continue;
      }
      const combined = para;
      chunks.push({
        start: pos,
        end: pos + combined.length,
        tokens: tokenize(combined),
        type: "text"
      });
      pos += combined.length + 2;
    }
  }
  return chunks;
}
function extractSymbols(content, ext) {
  const entry = { functions: [], classes: [], imports: [], exports: [] };
  if (![".ts", ".js", ".py", ".go", ".rs", ".java", ".tsx", ".jsx"].includes(ext)) {
    return entry;
  }
  let m;
  const funcRe = new RegExp(FUNC_RE.source, "g");
  while ((m = funcRe.exec(content)) !== null) {
    if (!entry.functions.includes(m[1]))
      entry.functions.push(m[1]);
  }
  const classRe = new RegExp(CLASS_RE.source, "g");
  while ((m = classRe.exec(content)) !== null) {
    if (!entry.classes.includes(m[1]))
      entry.classes.push(m[1]);
  }
  const importRe = new RegExp(IMPORT_RE.source, "g");
  while ((m = importRe.exec(content)) !== null) {
    const imp = m[1];
    if (!imp.startsWith(".") && !entry.imports.includes(imp))
      entry.imports.push(imp);
  }
  const exportRe = new RegExp(EXPORT_RE.source, "g");
  while ((m = exportRe.exec(content)) !== null) {
    if (!entry.exports.includes(m[1]))
      entry.exports.push(m[1]);
  }
  return entry;
}
function createEmptyIndex() {
  return {
    inverted: {},
    chunks: [],
    fileContents: {},
    df: {},
    stats: { N: 0, avgdl: 0, lastBuildAt: 0 }
  };
}
function addToIndex(idx, filePath, content, ext) {
  const chunks = chunkFile(content, ext);
  idx.fileContents[filePath] = content;
  for (const chunk of chunks) {
    const chunkId = idx.chunks.length;
    idx.chunks.push({
      file: filePath,
      start: chunk.start,
      end: chunk.end,
      tokens: chunk.tokens.length,
      type: chunk.type
    });
    const tf = {};
    for (const t of chunk.tokens) {
      tf[t] = (tf[t] || 0) + 1;
    }
    for (const [term, count] of Object.entries(tf)) {
      if (!idx.inverted[term])
        idx.inverted[term] = {};
      idx.inverted[term][chunkId] = count;
    }
    for (const term of Object.keys(tf)) {
      idx.df[term] = (idx.df[term] || 0) + 1;
    }
    idx.stats.N++;
  }
}
function finalizeIndex(idx) {
  let totalTokens = 0;
  for (const c of idx.chunks) {
    totalTokens += c.tokens;
  }
  idx.stats.avgdl = idx.stats.N > 0 ? totalTokens / idx.stats.N : 1;
  idx.stats.lastBuildAt = Date.now();
}
function removeFromIndex(idx, filePath) {
  const chunkIds = [];
  for (let i = 0; i < idx.chunks.length; i++) {
    if (idx.chunks[i].file === filePath)
      chunkIds.push(i);
  }
  for (const term of Object.keys(idx.inverted)) {
    for (const cid of chunkIds) {
      if (idx.inverted[term][cid] !== void 0) {
        delete idx.inverted[term][cid];
        idx.df[term]--;
      }
    }
    if (Object.keys(idx.inverted[term]).length === 0) {
      delete idx.inverted[term];
      delete idx.df[term];
    }
  }
  for (const cid of chunkIds) {
    idx.chunks[cid].file = "";
  }
  delete idx.fileContents[filePath];
}
function bm25Idf(idx, term) {
  const n = idx.df[term] || 0;
  if (n === 0)
    return 0;
  return Math.log((idx.stats.N - n + 0.5) / (n + 0.5) + 1);
}
function bm25Search(idx, query, topK) {
  const queryTokens = tokenize(query);
  const idfs = {};
  for (const t of queryTokens) {
    idfs[t] = bm25Idf(idx, t);
  }
  const scores = {};
  const avgdl = idx.stats.avgdl;
  for (const term of queryTokens) {
    const idf = idfs[term];
    if (idf === 0)
      continue;
    const postings = idx.inverted[term];
    if (!postings)
      continue;
    for (const [chunkIdStr, tf] of Object.entries(postings)) {
      const chunkId = parseInt(chunkIdStr, 10);
      const chunk = idx.chunks[chunkId];
      if (!chunk || !chunk.file)
        continue;
      const dl = chunk.tokens || 1;
      const numerator = tf * (BM25_K1 + 1);
      const denominator = tf + BM25_K1 * (1 - BM25_B + BM25_B * dl / avgdl);
      const score = idf * numerator / denominator;
      scores[chunkId] = (scores[chunkId] || 0) + score;
    }
  }
  const results = [];
  for (const [chunkIdStr, score] of Object.entries(scores)) {
    const chunkId = parseInt(chunkIdStr, 10);
    const chunk = idx.chunks[chunkId];
    if (!chunk || !chunk.file)
      continue;
    const fileContent = idx.fileContents[chunk.file] || "";
    const snippet = fileContent.slice(chunk.start, chunk.end).slice(0, 300).replace(/\n/g, " ");
    results.push({
      filePath: chunk.file,
      score,
      matchType: "bm25",
      snippet,
      line: (fileContent.slice(0, chunk.start).match(/\n/g) || []).length + 1
    });
  }
  results.sort((a, b) => b.score - a.score);
  const seen = /* @__PURE__ */ new Set();
  const deduped = [];
  for (const r of results) {
    if (!seen.has(r.filePath)) {
      seen.add(r.filePath);
      deduped.push(r);
      if (deduped.length >= topK)
        break;
    }
  }
  return deduped;
}
function symbolSearch(symbols, query, topK) {
  const queryLower = query.toLowerCase();
  const queryTokens = tokenize(query);
  const results = [];
  for (const [filePath, entry] of Object.entries(symbols)) {
    let score = 0;
    let matched = "";
    let matchKind = "";
    for (const fn of entry.functions) {
      for (const qt of queryTokens) {
        if (fn.toLowerCase().includes(qt)) {
          score += 3;
          if (!matched) {
            matched = fn;
            matchKind = "fn";
          }
        }
      }
      if (fn.toLowerCase() === queryLower) {
        score += 10;
        matched = fn;
        matchKind = "fn";
      }
    }
    for (const cls of entry.classes) {
      for (const qt of queryTokens) {
        if (cls.toLowerCase().includes(qt)) {
          score += 3;
          if (!matched) {
            matched = cls;
            matchKind = "class";
          }
        }
      }
      if (cls.toLowerCase() === queryLower) {
        score += 10;
        matched = cls;
        matchKind = "class";
      }
    }
    for (const imp of entry.imports) {
      for (const qt of queryTokens) {
        if (imp.toLowerCase().includes(qt)) {
          score += 1;
          if (!matched) {
            matched = imp;
            matchKind = "import";
          }
        }
      }
      if (imp.toLowerCase() === queryLower) {
        score += 5;
        matched = imp;
        matchKind = "import";
      }
    }
    for (const exp of entry.exports) {
      for (const qt of queryTokens) {
        if (exp.toLowerCase().includes(qt)) {
          score += 4;
          if (!matched || matchKind === "import") {
            matched = exp;
            matchKind = "export";
          }
        }
      }
      if (exp.toLowerCase() === queryLower) {
        score += 12;
        matched = exp;
        matchKind = "export";
      }
    }
    if (score > 0) {
      results.push({ filePath, score, matched, matchKind });
    }
  }
  results.sort((a, b) => b.score - a.score);
  return results.slice(0, topK).map((r) => ({
    filePath: r.filePath,
    score: r.score,
    matchType: "symbol",
    snippet: `symbol: ${r.matched} [${r.matchKind}]`,
    line: void 0
  }));
}
function indexDir(rootDir) {
  return path18.join(rootDir, "Data", "index");
}
function ensureIndexDir(rootDir) {
  const dir = indexDir(rootDir);
  fs16.mkdirSync(dir, { recursive: true });
  return dir;
}
async function saveIndex(rootDir, idx, manifest, symbols) {
  const dir = ensureIndexDir(rootDir);
  await fs16.promises.writeFile(path18.join(dir, "manifest.json"), JSON.stringify(manifest, null, 2), "utf8");
  await fs16.promises.writeFile(path18.join(dir, "symbols.json"), JSON.stringify(symbols, null, 2), "utf8");
  const bm25Data = {
    stats: idx.stats,
    chunks: idx.chunks,
    df: idx.df,
    inverted: idx.inverted
    // fileContents NOT persisted (re-read on load)
  };
  await fs16.promises.writeFile(path18.join(dir, "bm25.json"), JSON.stringify(bm25Data), "utf8");
}
async function loadIndex(rootDir) {
  const dir = indexDir(rootDir);
  try {
    const [manifestRaw, bm25Raw, symbolsRaw] = await Promise.all([
      fs16.promises.readFile(path18.join(dir, "manifest.json"), "utf8"),
      fs16.promises.readFile(path18.join(dir, "bm25.json"), "utf8"),
      fs16.promises.readFile(path18.join(dir, "symbols.json"), "utf8")
    ]);
    const manifest = JSON.parse(manifestRaw);
    const bm25Data = JSON.parse(bm25Raw);
    const symbols = JSON.parse(symbolsRaw);
    const idx = createEmptyIndex();
    idx.stats = bm25Data.stats;
    idx.chunks = bm25Data.chunks;
    idx.df = bm25Data.df;
    idx.inverted = bm25Data.inverted;
    return { idx, manifest, symbols };
  } catch {
    return null;
  }
}
var IndexService = class {
  // ★ P3: lazy-built, invalidated on rebuild
  constructor(rootDir) {
    this.idx = null;
    this.manifest = null;
    this.symbols = null;
    this.building = false;
    this.ready = false;
    this._symbolGraphCache = null;
    this.rootDir = rootDir;
  }
  /** Initialize: load existing index or build from scratch */
  async init() {
    if (this.ready || this.building)
      return;
    const loaded = await loadIndex(this.rootDir);
    if (loaded) {
      this.idx = loaded.idx;
      this.manifest = loaded.manifest;
      this.symbols = loaded.symbols;
      this.ready = true;
      this._symbolGraphCache = null;
      console.log("[index] loaded existing index:", loaded.idx.stats.N, "chunks,", Object.keys(loaded.manifest.files).length, "files");
    } else {
      this.buildAsync();
    }
  }
  get isReady() {
    return this.ready;
  }
  get isBuilding() {
    return this.building;
  }
  get chunkCount() {
    return this.idx ? this.idx.stats.N : 0;
  }
  get fileCount() {
    return this.manifest ? Object.keys(this.manifest.files).length : 0;
  }
  get symbolCount() {
    return this.symbols ? Object.keys(this.symbols).length : 0;
  }
  // ★ P3
  /** Expose file paths from manifest (for regex phase reuse — skip directory walk) */
  getFilePaths() {
    return this.manifest ? Object.keys(this.manifest.files) : [];
  }
  // ═══ P3: Symbol Graph Interface ═══
  /** Expose raw symbol table for external consumers */
  getSymbols() {
    return this.symbols || {};
  }
  /**
   * Build and return a reverse symbol graph:
   * symbolName → { definingFiles: string[], importingFiles: string[], exportingFiles: string[] }
   * Lazily computed — cached once per build cycle, invalidated on index rebuild.
   */
  getSymbolGraph() {
    if (this._symbolGraphCache)
      return this._symbolGraphCache;
    const graph = {};
    const syms = this.symbols || {};
    for (const [filePath, entry] of Object.entries(syms)) {
      for (const fn of entry.functions) {
        if (!graph[fn])
          graph[fn] = { definingFiles: [], importingFiles: [], exportingFiles: [] };
        if (!graph[fn].definingFiles.includes(filePath))
          graph[fn].definingFiles.push(filePath);
      }
      for (const cls of entry.classes) {
        if (!graph[cls])
          graph[cls] = { definingFiles: [], importingFiles: [], exportingFiles: [] };
        if (!graph[cls].definingFiles.includes(filePath))
          graph[cls].definingFiles.push(filePath);
      }
      for (const exp of entry.exports) {
        if (!graph[exp])
          graph[exp] = { definingFiles: [], importingFiles: [], exportingFiles: [] };
        if (!graph[exp].exportingFiles.includes(filePath))
          graph[exp].exportingFiles.push(filePath);
      }
      for (const imp of entry.imports) {
        if (!graph[imp])
          graph[imp] = { definingFiles: [], importingFiles: [], exportingFiles: [] };
        if (!graph[imp].importingFiles.includes(filePath))
          graph[imp].importingFiles.push(filePath);
      }
    }
    this._symbolGraphCache = graph;
    return graph;
  }
  /**
   * Find all files that reference a given symbol (define, export, or import it).
   * @returns {{ filePath: string; role: 'defines'|'exports'|'imports' }[]}
   */
  findSymbolReferences(symbolName) {
    const graph = this.getSymbolGraph();
    const entry = graph[symbolName];
    if (!entry)
      return [];
    const refs = [];
    for (const f of entry.definingFiles)
      refs.push({ filePath: f, role: "defines" });
    for (const f of entry.exportingFiles)
      refs.push({ filePath: f, role: "exports" });
    for (const f of entry.importingFiles)
      refs.push({ filePath: f, role: "imports" });
    return refs;
  }
  /** Build index asynchronously (does not block caller) */
  async buildAsync() {
    if (this.building)
      return;
    this.building = true;
    console.log("[index] building index for:", this.rootDir);
    try {
      const files = await this.collectFiles(this.rootDir);
      console.log("[index] collected", files.length, "files for indexing");
      const idx = createEmptyIndex();
      const manifest = { files: {} };
      const symbols = {};
      let processed = 0;
      for (const filePath of files) {
        try {
          const st = await fs16.promises.stat(filePath);
          if (st.size > MAX_FILE_SIZE)
            continue;
          const content = await fs16.promises.readFile(filePath, "utf8");
          if (content.length === 0)
            continue;
          if (content.includes("\0"))
            continue;
          const ext = path18.extname(filePath).toLowerCase();
          const relPath = path18.relative(this.rootDir, filePath).replace(/\\/g, "/");
          const indexableExts = [
            ".ts",
            ".js",
            ".py",
            ".go",
            ".rs",
            ".java",
            ".c",
            ".cpp",
            ".h",
            ".hpp",
            ".tsx",
            ".jsx",
            ".vue",
            ".svelte",
            ".rb",
            ".php",
            ".swift",
            ".kt",
            ".scala",
            ".json",
            ".txt",
            ".md",
            ".yml",
            ".yaml",
            ".toml",
            ".cfg",
            ".ini",
            ".sh",
            ".bat",
            ".html",
            ".css",
            ".scss",
            ".less",
            ".svg",
            ".xml",
            ".sql",
            ".graphql",
            ".proto"
          ];
          if (!indexableExts.includes(ext))
            continue;
          addToIndex(idx, relPath, content, ext);
          manifest.files[relPath] = { mtime: st.mtimeMs, size: st.size, chunkCount: 0 };
          const symEntry = extractSymbols(content, ext);
          if (symEntry.functions.length > 0 || symEntry.classes.length > 0) {
            symbols[relPath] = symEntry;
          }
          processed++;
          if (processed % 500 === 0) {
            console.log("[index] processed", processed, "files...");
          }
        } catch {
        }
      }
      for (const c of idx.chunks) {
        if (c.file && manifest.files[c.file]) {
          manifest.files[c.file].chunkCount++;
        }
      }
      finalizeIndex(idx);
      this.idx = idx;
      this.manifest = manifest;
      this.symbols = symbols;
      this.ready = true;
      this._symbolGraphCache = null;
      await saveIndex(this.rootDir, idx, manifest, symbols);
      console.log("[index] build complete:", idx.stats.N, "chunks,", processed, "files");
    } catch (e) {
      console.error("[index] build failed:", e);
    } finally {
      this.building = false;
    }
  }
  /** Update a single file in the index (called on file save) */
  async updateFile(filePath) {
    if (!this.idx || !this.manifest || !this.symbols)
      return;
    const relPath = path18.relative(this.rootDir, filePath).replace(/\\/g, "/");
    if (this.manifest.files[relPath]) {
      removeFromIndex(this.idx, relPath);
      delete this.symbols[relPath];
    }
    try {
      const st = await fs16.promises.stat(filePath);
      if (st.size > MAX_FILE_SIZE || st.size === 0)
        return;
      const content = await fs16.promises.readFile(filePath, "utf8");
      if (content.includes("\0"))
        return;
      const ext = path18.extname(filePath).toLowerCase();
      const indexableExts = [
        ".ts",
        ".js",
        ".py",
        ".go",
        ".rs",
        ".java",
        ".c",
        ".cpp",
        ".h",
        ".hpp",
        ".tsx",
        ".jsx",
        ".vue",
        ".svelte",
        ".rb",
        ".php",
        ".swift",
        ".kt",
        ".scala",
        ".json",
        ".txt",
        ".md",
        ".yml",
        ".yaml",
        ".toml",
        ".cfg",
        ".ini",
        ".sh",
        ".bat",
        ".html",
        ".css",
        ".scss",
        ".less",
        ".svg",
        ".xml",
        ".sql",
        ".graphql",
        ".proto"
      ];
      if (!indexableExts.includes(ext))
        return;
      addToIndex(this.idx, relPath, content, ext);
      this.manifest.files[relPath] = { mtime: st.mtimeMs, size: st.size, chunkCount: 0 };
      const symEntry = extractSymbols(content, ext);
      if (symEntry.functions.length > 0 || symEntry.classes.length > 0) {
        this.symbols[relPath] = symEntry;
      }
      for (const c of this.idx.chunks) {
        if (c.file === relPath) {
          const mf = this.manifest.files[relPath];
          if (mf)
            mf.chunkCount++;
        }
      }
      finalizeIndex(this.idx);
      this._symbolGraphCache = null;
      await saveIndex(this.rootDir, this.idx, this.manifest, this.symbols);
    } catch {
    }
  }
  /** Remove a file from the index */
  async removeFile(filePath) {
    if (!this.idx || !this.manifest || !this.symbols)
      return;
    const relPath = path18.relative(this.rootDir, filePath).replace(/\\/g, "/");
    removeFromIndex(this.idx, relPath);
    delete this.manifest.files[relPath];
    delete this.symbols[relPath];
    this._symbolGraphCache = null;
    await saveIndex(this.rootDir, this.idx, this.manifest, this.symbols);
  }
  /** Main search: BM25 + symbol matching */
  search(query, topK = 10) {
    if (!this.idx || !this.symbols) {
      return { results: [], indexReady: false };
    }
    const bm25Results = bm25Search(this.idx, query, topK * 2);
    const symResults = symbolSearch(this.symbols, query, topK);
    const merged = [];
    const seen = /* @__PURE__ */ new Set();
    let bi = 0, si = 0;
    while (merged.length < topK && (bi < bm25Results.length || si < symResults.length)) {
      const bScore = bi < bm25Results.length ? bm25Results[bi].score : -1;
      const sScore = si < symResults.length ? symResults[si].score : -1;
      if (bScore >= sScore && bi < bm25Results.length) {
        const r = bm25Results[bi++];
        if (!seen.has(r.filePath)) {
          seen.add(r.filePath);
          merged.push(r);
        }
      } else if (si < symResults.length) {
        const r = symResults[si++];
        if (!seen.has(r.filePath)) {
          seen.add(r.filePath);
          merged.push(r);
        }
      } else {
        break;
      }
    }
    return { results: merged, indexReady: true };
  }
  // -----------------------------------------------------------------------
  // File collection (respects .gitignore)
  // -----------------------------------------------------------------------
  async collectFiles(rootDir) {
    const files = [];
    const ignoreMatchers = [];
    for (const ignName of [".gitignore", ".qqqignore"]) {
      const ignPath = path18.join(rootDir, ignName);
      try {
        if (fs16.existsSync(ignPath)) {
          ignoreMatchers.push(this.parseIgnoreFile(fs16.readFileSync(ignPath, "utf8")));
        }
      } catch {
      }
    }
    const isIgnored = (rel, isDir) => {
      for (const m of ignoreMatchers) {
        if (m(rel, isDir))
          return true;
      }
      return false;
    };
    const walk = async (dir, relBase) => {
      if (files.length >= MAX_FILES)
        return;
      let entries;
      try {
        entries = await fs16.promises.readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const ent of entries) {
        if (files.length >= MAX_FILES)
          return;
        const rel = relBase ? relBase + "/" + ent.name : ent.name;
        if (ent.isDirectory()) {
          if (SKIP_DIRS.has(ent.name))
            continue;
          if (ent.name.startsWith("."))
            continue;
          if (isIgnored(rel + "/", true))
            continue;
          await walk(path18.join(dir, ent.name), rel);
        } else if (ent.isFile() || ent.isSymbolicLink()) {
          const ext = path18.extname(ent.name).toLowerCase();
          if (SKIP_EXTS.has(ext))
            continue;
          if (isIgnored(rel, false))
            continue;
          files.push(path18.join(dir, ent.name));
        }
      }
    };
    await walk(rootDir, "");
    return files;
  }
  parseIgnoreFile(content) {
    const rules = [];
    for (const raw of content.split("\n")) {
      let line = raw.trim();
      if (!line || line.startsWith("#"))
        continue;
      let negate = false;
      if (line.startsWith("!")) {
        negate = true;
        line = line.slice(1);
      }
      const dirOnly = line.endsWith("/");
      if (dirOnly)
        line = line.slice(0, -1);
      let pattern = line.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*\*/g, "[[GLOBSTAR]]").replace(/\*/g, "[^/]*").replace(/\[\[GLOBSTAR\]\]/g, ".*").replace(/\?/g, "[^/]");
      if (!pattern.startsWith("/"))
        pattern = "(^|/)" + pattern;
      rules.push({ pattern: new RegExp(pattern), negate, dirOnly });
    }
    return (rel, isDir) => {
      let ignored = false;
      for (const r of rules) {
        if (r.dirOnly && !isDir)
          continue;
        if (r.pattern.test("/" + rel)) {
          ignored = !r.negate;
        }
      }
      return ignored;
    };
  }
};

// shell/ipc-smart-search.ts
var REGEX_SKIP_DIRS = /* @__PURE__ */ new Set([
  "node_modules",
  ".git",
  "dist",
  "backup",
  "__pycache__",
  ".venv",
  "vendor",
  "build",
  "out",
  ".next",
  ".nuxt",
  ".cache",
  "coverage",
  "target",
  "logs",
  ".hg",
  ".svn",
  "bower_components",
  ".idea",
  ".vs",
  "cache",
  "temp",
  "crashDumps",
  "dist-pack",
  "shell-out",
  "shell-build",
  ".qoder",
  "Data",
  "logs",
  "new_log",
  "tmp",
  "op"
]);
var REGEX_SKIP_EXTS = /* @__PURE__ */ new Set([
  ".exe",
  ".dll",
  ".so",
  ".dylib",
  ".bin",
  ".png",
  ".jpg",
  ".jpeg",
  ".gif",
  ".bmp",
  ".webp",
  ".ico",
  ".mp3",
  ".mp4",
  ".avi",
  ".mkv",
  ".mov",
  ".wav",
  ".flac",
  ".ogg",
  ".zip",
  ".tar",
  ".gz",
  ".xz",
  ".bz2",
  ".7z",
  ".rar",
  ".woff",
  ".woff2",
  ".ttf",
  ".eot",
  ".pdf",
  ".vsix",
  ".wasm",
  ".class",
  ".o",
  ".obj",
  ".pyc",
  ".pyo",
  ".sqlite",
  ".db",
  ".lock",
  ".otf"
]);
var REGEX_MAX_FILE = 5 * 1024 * 1024;
var REGEX_MAX_RESULTS = 20;
var REGEX_TIMEOUT = 2500;
function registerSmartSearchIpc(indexService2) {
  import_electron14.ipcMain.handle("qqqide:ai:search_smart", async (_e, args) => {
    const query = args.query;
    const topK = args.topK || 10;
    const includeRegex = args.includeRegex !== false;
    const returnStructured = args.returnStructured === true;
    const searchPaths = args.paths || (args.path ? [args.path] : []);
    const explicitRegex = args.regex || null;
    const looksLikePath = /[\/\\]/.test(query) || /\.[a-z]{1,6}$/i.test(query);
    const identifiers = query.match(/[a-zA-Z_]\w{2,}/g) || [];
    const regexQuery = explicitRegex || (identifiers.length > 0 ? identifiers.slice(0, 3).join("|") : query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    const semanticResults = [];
    const bm25Structured = [];
    let bm25Ran = false;
    if (indexService2.isReady) {
      const { results, indexReady } = indexService2.search(query, topK);
      if (indexReady) {
        const lines = [];
        for (const r of results) {
          const projectRoot = indexService2.rootDir || "";
          const absPath = path19.join(projectRoot, r.filePath);
          const snippet = r.snippet.length > 200 ? r.snippet.slice(0, 200) + "..." : r.snippet;
          lines.push(`[${r.matchType.toUpperCase()}] ${r.filePath}${r.line ? ":" + r.line : ""} (score:${r.score.toFixed(1)})
  ${snippet}`);
          bm25Structured.push({
            filePath: r.filePath,
            line: r.line,
            snippet: r.snippet,
            score: r.score,
            matchType: r.matchType
          });
        }
        semanticResults.push(lines.length > 0 ? lines : []);
        bm25Ran = true;
      }
    }
    const regexResults = [];
    if (includeRegex && !looksLikePath) {
      let regex;
      try {
        regex = new RegExp(regexQuery, "i");
      } catch {
        regex = new RegExp(regexQuery.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      }
      const matches = [];
      const startTime = Date.now();
      const rootDir = indexService2.rootDir || process.cwd();
      if (indexService2.isReady) {
        const filePaths = indexService2.getFilePaths();
        for (const relPath of filePaths) {
          if (matches.length >= REGEX_MAX_RESULTS)
            break;
          if (Date.now() - startTime > REGEX_TIMEOUT)
            break;
          const full = path19.join(rootDir, relPath);
          try {
            const st = await fs17.promises.stat(full);
            if (!st || st.size > REGEX_MAX_FILE)
              continue;
            const content = await fs17.promises.readFile(full, "utf8");
            const lines = content.split("\n");
            for (let li = 0; li < lines.length && matches.length < REGEX_MAX_RESULTS; li++) {
              if (regex.test(lines[li])) {
                matches.push(relPath + ":" + (li + 1) + ":" + lines[li].trim().slice(0, 150));
              }
            }
          } catch {
          }
        }
      } else {
        const searchDirs = searchPaths.length > 0 ? searchPaths : [rootDir];
        const walk = async (dir, depth) => {
          if (depth > 6 || matches.length >= REGEX_MAX_RESULTS)
            return;
          if (Date.now() - startTime > REGEX_TIMEOUT)
            return;
          let entries;
          try {
            entries = await fs17.promises.readdir(dir, { withFileTypes: true });
          } catch {
            return;
          }
          for (const ent of entries) {
            if (matches.length >= REGEX_MAX_RESULTS)
              break;
            if (Date.now() - startTime > REGEX_TIMEOUT)
              return;
            if (ent.name.startsWith(".") && ent.isDirectory())
              continue;
            if (ent.isDirectory() && REGEX_SKIP_DIRS.has(ent.name))
              continue;
            const full = path19.join(dir, ent.name);
            if (ent.isDirectory()) {
              await walk(full, depth + 1);
            } else {
              const ext = path19.extname(ent.name).toLowerCase();
              if (REGEX_SKIP_EXTS.has(ext))
                continue;
              try {
                const st = await fs17.promises.stat(full);
                if (!st || st.size > REGEX_MAX_FILE)
                  continue;
                const content = await fs17.promises.readFile(full, "utf8");
                const lines = content.split("\n");
                for (let li = 0; li < lines.length && matches.length < REGEX_MAX_RESULTS; li++) {
                  if (regex.test(lines[li])) {
                    const relPath = full.replace(/\\/g, "/");
                    matches.push(relPath + ":" + (li + 1) + ":" + lines[li].trim().slice(0, 150));
                  }
                }
              } catch {
              }
            }
          }
        };
        for (const d of searchDirs) {
          if (Date.now() - startTime > REGEX_TIMEOUT)
            break;
          if (matches.length >= REGEX_MAX_RESULTS)
            break;
          await walk(d, 0);
        }
      }
      for (const m of matches) {
        regexResults.push("[REGEX] " + m);
      }
      if (regexResults.length === 0) {
        regexResults.push("[REGEX] No matches for pattern: " + regexQuery);
      }
    } else if (looksLikePath) {
      regexResults.push("[REGEX] Skipped (query looks like a path)");
    }
    const output = [];
    output.push('\u2550\u2550\u2550\u2550\u2550\u2550 SEARCH SMART: "' + query + '" \u2550\u2550\u2550\u2550\u2550\u2550');
    output.push("");
    if (bm25Ran && semanticResults.length > 0 && semanticResults[0].length > 0) {
      output.push("\u2500\u2500 Semantic (BM25) \u2500\u2500");
      output.push(...semanticResults[0]);
      output.push("");
    }
    if (regexResults.length > 0 && includeRegex) {
      const hasRealMatches = !regexResults[0].startsWith("[REGEX] No match") && !regexResults[0].startsWith("[REGEX] Skipped");
      if (hasRealMatches) {
        output.push("\u2500\u2500 Regex \u2500\u2500");
        output.push(...regexResults);
      }
    }
    if (output.length <= 2) {
      output.push('No results found for "' + query + '"');
      if (!indexService2.isReady) {
        output.push("Tip: index is warming up. Use search_text for exact pattern matching in the meantime.");
      } else {
        output.push("Try: different keywords, check spelling, or use search_text for exact regex");
      }
    }
    output.push("");
    output.push("\u2500\u2500 Stats \u2500\u2500");
    if (indexService2.isReady) {
      output.push("Index: " + indexService2.fileCount + " files, " + indexService2.symbolCount + " symbols, " + indexService2.chunkCount + " chunks");
    }
    if (bm25Ran) {
      output.push("BM25: " + (semanticResults[0] ? semanticResults[0].length : 0) + " results");
    }
    if (includeRegex && regexResults.length > 0 && !regexResults[0].startsWith("[REGEX] No match") && !regexResults[0].startsWith("[REGEX] Skipped")) {
      output.push("Regex: " + regexResults.length + " matches (pattern: " + regexQuery + ")");
    }
    const textOutput = output.join("\n");
    if (returnStructured) {
      const symbolGraph = [];
      if (indexService2.isReady) {
        const fullGraph = indexService2.getSymbolGraph();
        const seenSyms = /* @__PURE__ */ new Set();
        for (const r of bm25Structured) {
          if (r.matchType !== "symbol")
            continue;
          const symMatch = r.snippet.match(/^symbol:\s*(\S+)/);
          if (!symMatch)
            continue;
          const symName = symMatch[1];
          if (seenSyms.has(symName))
            continue;
          seenSyms.add(symName);
          const ge = fullGraph[symName];
          if (ge) {
            const kindMatch = r.snippet.match(/\[(\w+)\]/);
            symbolGraph.push({
              symbol: symName,
              kind: kindMatch ? kindMatch[1] : "?",
              definingFiles: ge.definingFiles.slice(0, 5),
              importingFiles: ge.importingFiles.slice(0, 10),
              exportingFiles: ge.exportingFiles.slice(0, 5)
            });
          }
        }
      }
      return {
        text: textOutput,
        bm25: bm25Structured,
        bm25Ran,
        symbolGraph,
        indexReady: indexService2.isReady,
        fileCount: indexService2.isReady ? indexService2.fileCount : 0,
        chunkCount: indexService2.isReady ? indexService2.chunkCount : 0
      };
    }
    return textOutput;
  });
}

// shell/ipc-state-handlers.ts
var import_electron15 = require("electron");

// shell/state-sqlite.ts
var path20 = __toESM(require("path"));
var fs18 = __toESM(require("fs"));
var crypto3 = __toESM(require("crypto"));
var import_events = require("events");
var initSqlJs = require("sql.js");
var DEFAULT_DEBOUNCE_MS = 250;
var StateStore = class extends import_events.EventEmitter {
  // ----- constructor --------------------------------------------------------
  /**
   * @param userDataDir  Electron userData path (for global Data/alphal/global.sq3).
   *                      When dbPath is provided, userDataDir is only used for deviceId fallback.
   * @param dbPath       Optional explicit SQLite file path. When set, the DB is created
   *                      at this exact path (e.g. project-level quest.sq3).
   */
  constructor(userDataDir, dbPath) {
    super();
    this._db = null;
    // sql.js Database (null until WASM loaded)
    this._SQL = null;
    // sql.js module
    this._ready = null;
    this._readyOk = false;
    this.outboxSeq = 0;
    this.schemas = /* @__PURE__ */ new Map();
    // debounce timers (key = ns\u0000key)
    this._debouncers = /* @__PURE__ */ new Map();
    // dirty tracking for stats
    this._dirtySet = /* @__PURE__ */ new Set();
    // ★ batched DB export (avoids per-key db.export() → one export per ~50ms window)
    this._saveDbPending = false;
    this._saveDbTimer = null;
    // ★ in-memory read cache (avoids append() re-reading from DB each time)
    this._memCache = /* @__PURE__ */ new Map();
    // ★ 全局数据库标记：用于阻止 quest 相关 namespace 误写入全局 global.sq3
    this._isGlobal = false;
    /** Hook for state-cloud.ts */
    this.onCloudDirty = null;
    this.setMaxListeners(0);
    if (dbPath) {
      const dbDir = path20.dirname(dbPath);
      try {
        fs18.mkdirSync(dbDir, { recursive: true });
      } catch {
      }
      this.dbPath = dbPath;
      this.outboxDir = path20.join(dbDir, "outbox");
      this._isGlobal = false;
    } else {
      const alphalDir2 = path20.join(userDataDir, "alphal");
      try {
        fs18.mkdirSync(alphalDir2, { recursive: true });
      } catch {
      }
      this.dbPath = path20.join(alphalDir2, "global.sq3");
      this.outboxDir = path20.join(alphalDir2, "outbox");
      this._isGlobal = true;
    }
    try {
      fs18.mkdirSync(this.outboxDir, { recursive: true });
    } catch {
    }
    this.deviceId = this._loadOrCreateDeviceId(path20.dirname(this.outboxDir));
    this._restoreOutboxSeq();
    console.log("[state-sqlite] db=", this.dbPath, "device=", this.deviceId);
  }
  // ----- init (lazy, triggered on first use) --------------------------------
  _init() {
    if (this._ready)
      return this._ready;
    this._ready = this._doInit();
    return this._ready;
  }
  async _doInit() {
    try {
      this._SQL = await initSqlJs();
      if (fs18.existsSync(this.dbPath)) {
        try {
          const buf = fs18.readFileSync(this.dbPath);
          this._db = new this._SQL.Database(buf);
        } catch (e) {
          console.warn("[state-sqlite]failed to load global.sq33, starting fresh:", e);
          const bak = this.dbPath + ".corrupt." + Date.now();
          try {
            fs18.renameSync(this.dbPath, bak);
          } catch {
          }
          if (!this._tryRestoreFromBak()) {
            this._db = new this._SQL.Database();
          }
        }
      } else {
        if (!this._tryRestoreFromBak()) {
          this._db = new this._SQL.Database();
        }
      }
      this._cleanStaleTmp();
      try {
        this._initSchema();
      } catch (sqlError) {
        console.warn("[state-sqlite] schema init failed (internal corruption?), quarantine & start fresh:", sqlError);
        const bak = this.dbPath + ".corrupt." + Date.now();
        try {
          fs18.renameSync(this.dbPath, bak);
        } catch {
        }
        this._db = new this._SQL.Database();
        this._initSchema();
      }
      this._readyOk = true;
      console.log("[state-sqlite] ready, schemas:", this.schemas.size);
    } catch (e) {
      console.error("[state-sqlite] init FAILED:", e);
      this._ready = null;
      throw e;
    }
  }
  _ensureReady() {
    return this._init();
  }
  _assertReady() {
    if (!this._readyOk || !this._db) {
      this._init().catch(() => {
      });
    }
  }
  /** Create/reset schema on current DB instance */
  _initSchema() {
    this._db.run(`CREATE TABLE IF NOT EXISTS state (
            ns TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT,
            meta TEXT,
            updated_at INTEGER DEFAULT 0,
            PRIMARY KEY (ns, key)
        )`);
    this._db.run("CREATE INDEX IF NOT EXISTS idx_state_ns ON state(ns)");
    this._db.run("PRAGMA journal_mode=WAL");
    this._db.run("PRAGMA synchronous=FULL");
    this._db.run("PRAGMA busy_timeout=30000");
    this._loadSchemas();
  }
  // ★ 启动时恢复/清理残留 .tmp 文件（进程崩溃遗孤 → 恢复而非丢弃）
  _cleanStaleTmp() {
    const dir = path20.dirname(this.dbPath);
    const mainDb = this.dbPath;
    const mainExists = fs18.existsSync(mainDb);
    const mainMtime = mainExists ? fs18.statSync(mainDb).mtimeMs : 0;
    try {
      const files = fs18.readdirSync(dir);
      const prefix = path20.basename(mainDb);
      for (const f of files) {
        if (!f.includes(".tmp."))
          continue;
        if (!f.startsWith(prefix))
          continue;
        const fullPath = path20.join(dir, f);
        const tmpMtime = fs18.statSync(fullPath).mtimeMs;
        if (!mainExists || tmpMtime > mainMtime) {
          console.log("[state-sqlite] recovering from tmp:", fullPath, "\u2192", mainDb);
          try {
            fs18.renameSync(fullPath, mainDb);
          } catch {
            try {
              fs18.copyFileSync(fullPath, mainDb);
              fs18.unlinkSync(fullPath);
            } catch {
            }
          }
        } else {
          try {
            fs18.unlinkSync(fullPath);
          } catch {
          }
        }
      }
    } catch {
    }
    try {
      const outboxFiles = fs18.readdirSync(this.outboxDir);
      for (const f of outboxFiles) {
        if (!f.includes(".tmp."))
          continue;
        const fullPath = path20.join(this.outboxDir, f);
        const targetName = f.replace(/\.tmp\.\d+$/, "");
        const targetPath = path20.join(this.outboxDir, targetName);
        if (!fs18.existsSync(targetPath)) {
          try {
            fs18.renameSync(fullPath, targetPath);
          } catch {
          }
        } else {
          try {
            fs18.unlinkSync(fullPath);
          } catch {
          }
        }
      }
    } catch {
    }
  }
  // ----- device id ----------------------------------------------------------
  _loadOrCreateDeviceId(stateDir) {
    const f = path20.join(stateDir, "device.id");
    try {
      if (fs18.existsSync(f)) {
        const s = fs18.readFileSync(f, "utf8").trim();
        if (s && s.length >= 8)
          return s;
      }
    } catch {
    }
    const id = "dev_" + crypto3.randomBytes(8).toString("hex");
    try {
      fs18.writeFileSync(f, id, "utf8");
    } catch {
    }
    return id;
  }
  _restoreOutboxSeq() {
    try {
      const files = fs18.readdirSync(this.outboxDir);
      for (const f of files) {
        const m = f.match(/^(\d+)\.json$/);
        if (m) {
          const n = parseInt(m[1], 10);
          if (n > this.outboxSeq)
            this.outboxSeq = n;
        }
      }
    } catch {
    }
  }
  // ----- sql.js helpers (compatible with all versions) --------------------
  /** Execute SELECT via step()+getAsObject(), compatible with sql.js >=1.4 */
  _stmtAll(sql, params) {
    if (!this._db)
      return [];
    const stmt = this._db.prepare(sql);
    try {
      if (params && params.length) {
        stmt.bind(params);
      }
      const rows = [];
      while (stmt.step()) {
        rows.push(stmt.getAsObject());
      }
      return rows;
    } finally {
      stmt.free();
    }
  }
  /** Get single row via step()+getAsObject(), compatible with sql.js >=1.4 */
  _stmtGet(sql, params) {
    if (!this._db)
      return null;
    try {
      const stmt = this._db.prepare(sql);
      try {
        stmt.bind(params);
        if (stmt.step()) {
          return stmt.getAsObject();
        }
        return null;
      } finally {
        stmt.free();
      }
    } catch (e) {
      if (e && e.message && /disk image is malformed/i.test(e.message)) {
        console.warn("[state-sqlite] \u26A0 runtime corruption detected in _stmtGet \u2014 quarantining & rebuilding");
        this._quarantineAndRebuild();
      }
      throw e;
    }
  }
  /** Run DML via step()+getRowsModified(), compatible with sql.js >=1.4 */
  _stmtRun(sql, params) {
    if (!this._db)
      return { changes: 0 };
    try {
      const stmt = this._db.prepare(sql);
      try {
        stmt.bind(params);
        stmt.step();
        return { changes: this._db.getRowsModified() };
      } finally {
        stmt.free();
      }
    } catch (e) {
      if (e && e.message && /disk image is malformed/i.test(e.message)) {
        console.warn("[state-sqlite] \u26A0 runtime corruption detected in _stmtRun \u2014 quarantining & rebuilding");
        this._quarantineAndRebuild();
      }
      throw e;
    }
  }
  /** ★ 运行时腐败隔离： rename 坏库 → 创建空库 → 重建 schema → 标记脏数据全部重写 */
  _quarantineAndRebuild() {
    try {
      const bak = this.dbPath + ".corrupt." + Date.now();
      try {
        fs18.renameSync(this.dbPath, bak);
      } catch {
      }
      this._db = new this._SQL.Database();
      this._initSchema();
      this._memCache.clear();
      for (const [id] of this._debouncers) {
        this._dirtySet.add(id);
      }
      console.warn("[state-sqlite] \u26A0 quarantined corrupt db \u2192 " + bak + ", fresh db ready (data loss may have occurred)");
    } catch (e2) {
      console.error("[state-sqlite] CRITICAL: quarantine failed:", e2);
    }
  }
  /** ★ 验证导出的 SQLite 数据是否有效：打开 → SELECT 1 → true/false */
  _tryValidateDb(data) {
    try {
      const testDb = new this._SQL.Database(data);
      try {
        testDb.exec("SELECT 1");
        return true;
      } finally {
        testDb.close();
      }
    } catch {
      return false;
    }
  }
  /** ★ 尝试从最近的 .bak 文件恢复数据库。成功返回 true。 */
  _tryRestoreFromBak() {
    try {
      const dir = path20.dirname(this.dbPath);
      const base = path20.basename(this.dbPath);
      const bakFiles = fs18.readdirSync(dir).filter((f) => f.startsWith(base + ".bak.")).sort().reverse();
      for (const bakFile of bakFiles) {
        const bakPath = path20.join(dir, bakFile);
        try {
          const buf = fs18.readFileSync(bakPath);
          this._db = new this._SQL.Database(buf);
          this._db.exec("SELECT 1");
          console.warn("[state-sqlite] \u26A0 restored from backup: " + bakPath);
          return true;
        } catch {
        }
      }
    } catch {
    }
    return false;
  }
  // ----- schema registry ----------------------------------------------------
  _loadSchemas() {
    try {
      this._db.run(`CREATE TABLE IF NOT EXISTS registry (
                ns TEXT PRIMARY KEY,
                v INTEGER NOT NULL,
                form TEXT NOT NULL,
                cloud INTEGER DEFAULT 0,
                quota_bytes INTEGER
            )`);
      const rows = this._stmtAll("SELECT * FROM registry");
      for (const r of rows) {
        this.schemas.set(r.ns, {
          v: r.v,
          form: r.form,
          cloud: !!r.cloud,
          quotaBytes: r.quota_bytes || void 0
        });
      }
    } catch (e) {
      console.warn("[state-sqlite] _loadSchemas failed:", e);
    }
  }
  _persistSchema(ns, sc) {
    if (!this._readyOk || !this._db)
      return;
    try {
      this._db.run(
        `INSERT OR REPLACE INTO registry (ns, v, form, cloud, quota_bytes) VALUES (?,?,?,?,?)`,
        [ns, sc.v, sc.form, sc.cloud ? 1 : 0, sc.quotaBytes || null]
      );
    } catch (e) {
      console.warn("[state-sqlite] _persistSchema failed:", e);
    }
  }
  // ----- public introspection -----------------------------------------------
  getDeviceId() {
    return this.deviceId;
  }
  getRootDir() {
    return path20.dirname(this.dbPath);
  }
  getOutboxDir() {
    return this.outboxDir;
  }
  getRegisteredNs() {
    return Array.from(this.schemas.keys());
  }
  getSchema(ns) {
    return this.schemas.get(ns);
  }
  sql(query, params) {
    try {
      if (params && params.length) {
        if (query.trim().toUpperCase().startsWith("SELECT")) {
          return this._stmtAll(query, params);
        }
        this._db.run(query, params);
        this._scheduleSaveDb();
        return { changes: this._db.getRowsModified() };
      }
      if (query.trim().toUpperCase().startsWith("SELECT")) {
        return this._stmtAll(query);
      }
      this._db.run(query);
      this._scheduleSaveDb();
      return { changes: this._db.getRowsModified() };
    } catch (e) {
      console.warn("[state-sqlite] sql error:", query, e);
      throw e;
    }
  }
  stats() {
    let outbox = 0;
    try {
      outbox = fs18.readdirSync(this.outboxDir).filter((f) => f.endsWith(".json")).length;
    } catch {
    }
    return {
      dirtyKeys: this._dirtySet.size,
      queuedOutbox: outbox,
      lastSyncAt: this.lastSyncAt,
      namespaces: this.schemas.size
    };
  }
  markSyncedAt(t) {
    this.lastSyncAt = t;
  }
  // ----- registration -------------------------------------------------------
  register(ns, schema) {
    if (!ns || typeof ns !== "string")
      throw new Error("state.register: bad ns");
    if (!schema || !schema.form || !["doc", "blob", "log"].includes(schema.form)) {
      throw new Error("state.register: bad schema.form, must be doc/blob/log");
    }
    if (typeof schema.v !== "number" || schema.v < 1) {
      throw new Error("state.register: schema.v must be >=1");
    }
    if (this._isGlobal) {
      const FORBIDDEN_NS = ["qqq.ai", "qqq.only", "qqq.quest"];
      if (FORBIDDEN_NS.includes(ns) || ns.startsWith("qqq.ai.") || ns.startsWith("qqq.quest.")) {
        throw new Error(
          `state.register: ns "${ns}" is FORBIDDEN in global global.sq3. Quest/AI data MUST use project-level SQLite (quest.sq3/only.sq3). Refusing to register.`
        );
      }
    }
    const existing = this.schemas.get(ns);
    if (existing) {
      if (existing.form !== schema.form) {
        throw new Error(`state.register: ns "${ns}" form mismatch (existing=${existing.form}, new=${schema.form})`);
      }
      return;
    }
    this.schemas.set(ns, schema);
    this._persistSchema(ns, schema);
    console.log("[state-sqlite] register ns=", ns, "v=", schema.v, "form=", schema.form, "cloud=", !!schema.cloud);
  }
  // ----- encode / decode ----------------------------------------------------
  _encode(form, value) {
    if (form === "doc") {
      return JSON.stringify(value);
    }
    if (form === "blob") {
      return JSON.stringify(value);
    }
    if (!Array.isArray(value))
      value = [];
    return JSON.stringify(value);
  }
  _decode(form, raw) {
    if (!raw)
      return form === "log" ? [] : null;
    try {
      return JSON.parse(raw);
    } catch {
      return form === "log" ? [] : null;
    }
  }
  // ----- public API: get / set / setNow / append / del / list ----------------
  async get(ns, key) {
    await this._ensureReady();
    this._requireSchema(ns);
    const cid = ns + "\0" + key;
    const cached = this._memCache.get(cid);
    if (cached !== void 0)
      return cached;
    try {
      const row = this._stmtGet("SELECT value FROM state WHERE ns=? AND key=?", [ns, key]);
      if (!row || row.value === null || row.value === void 0) {
        const sc2 = this.schemas.get(ns);
        return sc2.form === "log" ? [] : null;
      }
      const sc = this.schemas.get(ns);
      const val = this._decode(sc.form, row.value);
      this._memCache.set(cid, val);
      return val;
    } catch (e) {
      console.warn("[state-sqlite] get error", ns, key, e);
      const sc = this.schemas.get(ns);
      return sc && sc.form === "log" ? [] : null;
    }
  }
  async set(ns, key, value) {
    await this._ensureReady();
    const sc = this._requireSchema(ns);
    if (sc.form === "log" && !Array.isArray(value)) {
      throw new Error(`state.set on log form requires an array; ns=${ns} key=${key}`);
    }
    this._markDirty(ns, key, sc, value);
    if (sc.cloud && this.onCloudDirty) {
      try {
        this.onCloudDirty(ns, key);
      } catch {
      }
    }
  }
  async setNow(ns, key, value) {
    await this._ensureReady();
    const sc = this._requireSchema(ns);
    if (sc.form === "log" && !Array.isArray(value)) {
      throw new Error(`state.setNow on log form requires an array; ns=${ns} key=${key}`);
    }
    const ids = Array.from(this._debouncers.keys());
    for (const id of ids) {
      const t = this._debouncers.get(id);
      if (t) {
        clearTimeout(t);
        this._debouncers.delete(id);
      }
      this._dirtySet.delete(id);
    }
    this._writeKey(ns, key, sc, value);
    this._dirtySet.delete(ns + "\0" + key);
    await this._doSaveDb();
    if (sc.cloud && this.onCloudDirty) {
      try {
        this.onCloudDirty(ns, key);
      } catch {
      }
    }
  }
  async append(ns, key, event) {
    await this._ensureReady();
    const sc = this._requireSchema(ns);
    if (sc.form !== "log")
      throw new Error(`state.append only valid for form=log; ns=${ns}`);
    const cid = ns + "\0" + key;
    let arr = this._memCache.get(cid);
    if (arr === void 0) {
      arr = await this.get(ns, key);
    }
    if (!Array.isArray(arr))
      arr = [];
    arr.push(event);
    this._memCache.set(cid, arr);
    this._markDirty(ns, key, sc, arr);
    if (sc.cloud && this.onCloudDirty) {
      try {
        this.onCloudDirty(ns, key);
      } catch {
      }
    }
  }
  async del(ns, key) {
    await this._ensureReady();
    this._requireSchema(ns);
    try {
      const id = ns + "\0" + key;
      const t = this._debouncers.get(id);
      if (t) {
        clearTimeout(t);
        this._debouncers.delete(id);
      }
      this._dirtySet.delete(id);
      this._memCache.delete(id);
      const info = this._stmtRun("DELETE FROM state WHERE ns=? AND key=?", [ns, key]);
      const any = info.changes > 0;
      if (any) {
        this.emit("changed", { ns, key, value: null, deleted: true });
        const sc = this.schemas.get(ns);
        if (sc && sc.cloud) {
          this._queueOutbox(ns, key, null, true);
        }
      }
      return any;
    } catch (e) {
      console.warn("[state-sqlite] del error", ns, key, e);
      return false;
    }
  }
  async list(ns) {
    await this._ensureReady();
    this._requireSchema(ns);
    try {
      const rows = this._stmtAll("SELECT key FROM state WHERE ns=?", [ns]);
      return rows.map((r) => r.key);
    } catch (e) {
      return [];
    }
  }
  // ----- internal: dirty + debounce + write ---------------------------------
  _markDirty(ns, key, sc, value) {
    const id = ns + "\0" + key;
    this._dirtySet.add(id);
    const existing = this._debouncers.get(id);
    if (existing)
      clearTimeout(existing);
    const debounceMs = typeof sc.debounceMs === "number" ? sc.debounceMs : DEFAULT_DEBOUNCE_MS;
    this._debouncers.set(id, setTimeout(() => {
      this._debouncers.delete(id);
      this._dirtySet.delete(id);
      try {
        this._writeKey(ns, key, sc, value);
      } catch (e) {
        console.warn("[state-sqlite] debounced write error", ns, key, e);
      }
    }, debounceMs));
  }
  _writeKey(ns, key, sc, value) {
    if (!this._readyOk || !this._db)
      return;
    try {
      const encoded = this._encode(sc.form, value);
      const meta = JSON.stringify({
        v: sc.v,
        ts: Date.now(),
        deviceId: this.deviceId,
        form: sc.form
      });
      this._db.run(
        `INSERT OR REPLACE INTO state (ns, key, value, meta, updated_at) VALUES (?,?,?,?,?)`,
        [ns, key, encoded, meta, Date.now()]
      );
      this._memCache.set(ns + "\0" + key, value);
      this._scheduleSaveDb();
      if (sc.cloud) {
        this._queueOutbox(ns, key, value, false);
      }
      this.emit("changed", { ns, key, value, deleted: false });
    } catch (e) {
      console.warn("[state-sqlite] _writeKey error", ns, key, e);
    }
  }
  // ★ Schedule batched DB export (50ms window, multiple writes share one export)
  _scheduleSaveDb() {
    this._saveDbPending = true;
    if (this._saveDbTimer)
      return;
    this._saveDbTimer = setTimeout(() => {
      this._saveDbTimer = null;
      if (!this._saveDbPending)
        return;
      this._doSaveDb();
    }, 50);
  }
  // ★ async export — yields to event loop during file I/O, avoids blocking main process
  async _doSaveDb() {
    if (!this._readyOk || !this._db)
      return;
    this._saveDbPending = false;
    if (this._saveDbTimer) {
      clearTimeout(this._saveDbTimer);
      this._saveDbTimer = null;
    }
    const tmp = this.dbPath + ".tmp." + Date.now();
    try {
      const data = this._db.export();
      if (!this._tryValidateDb(data)) {
        console.error("[state-sqlite] CRITICAL: exported data is invalid SQLite \u2014 SKIPPING save to prevent corruption (dbPath=" + this.dbPath + ")");
        return;
      }
      const buf = Buffer.from(data);
      try {
        fs18.mkdirSync(path20.dirname(this.dbPath), { recursive: true });
      } catch {
      }
      await fs18.promises.writeFile(tmp, buf);
      await this._atomicRename(tmp, this.dbPath);
    } catch (e) {
      console.warn("[state-sqlite] _doSaveDb failed:", e);
    } finally {
      try {
        await fs18.promises.unlink(tmp);
      } catch {
      }
    }
  }
  /** 原子 rename，带重试和降级策略。绝不先删后改（防崩溃丢数据）。 */
  async _atomicRename(tmp, dest) {
    try {
      await fs18.promises.rename(tmp, dest);
      return;
    } catch (e) {
      if (!e || e.code !== "EEXIST" && e.code !== "EPERM" && e.code !== "EACCES") {
        throw e;
      }
    }
    const data = await fs18.promises.readFile(tmp);
    await fs18.promises.writeFile(dest, data);
    try {
      await fs18.promises.unlink(tmp);
    } catch {
    }
  }
  /** Synchronous flush for crash/shutdown — must not use async I/O */
  _doSaveDbSync() {
    if (!this._readyOk || !this._db)
      return;
    this._saveDbPending = false;
    if (this._saveDbTimer) {
      clearTimeout(this._saveDbTimer);
      this._saveDbTimer = null;
    }
    const tmp = this.dbPath + ".tmp." + Date.now();
    try {
      const data = this._db.export();
      if (!this._tryValidateDb(data)) {
        console.error("[state-sqlite] CRITICAL: exported data is invalid SQLite \u2014 SKIPPING save to prevent corruption (dbPath=" + this.dbPath + ")");
        return;
      }
      const buf = Buffer.from(data);
      try {
        fs18.mkdirSync(path20.dirname(this.dbPath), { recursive: true });
      } catch {
      }
      fs18.writeFileSync(tmp, buf);
      try {
        fs18.renameSync(tmp, this.dbPath);
      } catch (e) {
        if (e && (e.code === "EEXIST" || e.code === "EPERM" || e.code === "EACCES")) {
          const data2 = fs18.readFileSync(tmp);
          fs18.writeFileSync(this.dbPath, data2);
          try {
            fs18.unlinkSync(tmp);
          } catch {
          }
        } else {
          throw e;
        }
      }
    } catch (e) {
      console.warn("[state-sqlite] _doSaveDb failed:", e);
    } finally {
      try {
        fs18.unlinkSync(tmp);
      } catch {
      }
    }
  }
  // ----- flush --------------------------------------------------------------
  async flush() {
    if (!this._readyOk || !this._db)
      return;
    const ids = Array.from(this._debouncers.keys());
    for (const id of ids) {
      const t = this._debouncers.get(id);
      if (t) {
        clearTimeout(t);
        this._debouncers.delete(id);
      }
      this._dirtySet.delete(id);
    }
    await this._doSaveDb();
  }
  /** Synchronous flush for crash/shutdown. */
  flushSync() {
    if (!this._readyOk || !this._db)
      return;
    for (const [id, t] of this._debouncers) {
      clearTimeout(t);
      this._debouncers.delete(id);
    }
    this._dirtySet.clear();
    this._memCache.clear();
    this._doSaveDbSync();
  }
  async flushOne(ns, key) {
    const id = ns + "\0" + key;
    const t = this._debouncers.get(id);
    if (t) {
      clearTimeout(t);
      this._debouncers.delete(id);
    }
    this._dirtySet.delete(id);
    this._memCache.delete(id);
    await this._doSaveDb();
  }
  /** Atomically increment a counter key and return the NEW value.
   *  Zero-race: all IPC calls serialize in the main process, and SQLite
   *  operations are synchronous within that single thread. */
  async atomicIncr(ns, key) {
    await this._ensureReady();
    const sc = this._requireSchema(ns);
    if (sc.form !== "doc")
      throw new Error(`atomicIncr only valid for form=doc; ns=${ns}`);
    let cur = 0;
    try {
      const row = this._stmtGet("SELECT value FROM state WHERE ns=? AND key=?", [ns, key]);
      if (row && row.value !== null && row.value !== void 0) {
        cur = parseInt(row.value, 10) || 0;
      }
    } catch {
    }
    const next = cur + 1;
    const encoded = this._encode(sc.form, next);
    const meta = JSON.stringify({ v: sc.v, ts: Date.now(), deviceId: this.deviceId, form: sc.form });
    this._db.run(
      `INSERT OR REPLACE INTO state (ns, key, value, meta, updated_at) VALUES (?,?,?,?,?)`,
      [ns, key, encoded, meta, Date.now()]
    );
    this._memCache.set(ns + "\0" + key, next);
    await this._doSaveDb();
    if (sc.cloud && this.onCloudDirty) {
      try {
        this.onCloudDirty(ns, key);
      } catch {
      }
    }
    if (sc.cloud) {
      this._queueOutbox(ns, key, next, false);
    }
    this.emit("changed", { ns, key, value: next, deleted: false });
    return next;
  }
  // ----- schema helpers -----------------------------------------------------
  _requireSchema(ns) {
    const sc = this.schemas.get(ns);
    if (!sc)
      throw new Error(`state: ns "${ns}" not registered`);
    return sc;
  }
  // ----- outbox (cloud sync queue; state-cloud.ts drains it) ----------------
  _queueOutbox(ns, key, value, deleted) {
    let tmp = "";
    try {
      this.outboxSeq += 1;
      const seq = String(this.outboxSeq).padStart(12, "0");
      const f = path20.join(this.outboxDir, seq + ".json");
      const payload = { seq, ns, key, ts: Date.now(), deleted, value: deleted ? null : value };
      tmp = f + ".tmp." + Date.now();
      fs18.writeFileSync(tmp, JSON.stringify(payload));
      try {
        fs18.renameSync(tmp, f);
      } catch {
        try {
          const data = fs18.readFileSync(tmp);
          fs18.writeFileSync(f, data);
        } catch {
        }
      }
    } catch (e) {
      console.warn("[state-sqlite] _queueOutbox failed:", e);
    } finally {
      if (tmp) {
        try {
          fs18.unlinkSync(tmp);
        } catch {
        }
      }
    }
  }
  listOutbox() {
    const out = [];
    try {
      const files = fs18.readdirSync(this.outboxDir).filter((f) => f.endsWith(".json")).sort();
      for (const f of files) {
        out.push({ seq: f.replace(/\.json$/, ""), file: path20.join(this.outboxDir, f) });
      }
    } catch {
    }
    return out;
  }
  dropOutbox(seq) {
    const f = path20.join(this.outboxDir, seq + ".json");
    try {
      fs18.unlinkSync(f);
      return true;
    } catch {
      return false;
    }
  }
  // ----- merge-on-save (delegated to schema.merger) -------------------------
  // SQLite WAL mode provides natural isolation. Multi-window merge is handled
  // at the application level (q4.js) rather than at the storage level.
  // The 'merger' property in NsSchema is still used by state-cloud.ts for
  // cloud sync merge logic.
  // ----- onChange convenience -----------------------------------------------
  onChange(ns, key, cb) {
    const h = (msg) => {
      if (msg.ns === ns && msg.key === key)
        cb(msg.value, msg.deleted);
    };
    this.on("changed", h);
    return () => {
      this.off("changed", h);
    };
  }
};

// shell/state-cloud.ts
var fs19 = __toESM(require("fs"));
var https3 = __toESM(require("https"));
var http5 = __toESM(require("http"));
var import_url4 = require("url");
var CLOUD_BASE = process.env.QQQ_CLOUD_BASE || "https://gh555.com";
var REQ_TIMEOUT_MS = 12e3;
var _cachedAuth = null;
function readAuth() {
  return _cachedAuth;
}
function httpsPostJson(urlStr, body) {
  return new Promise((resolve3, reject) => {
    let u;
    try {
      u = new import_url4.URL(urlStr);
    } catch (e) {
      return reject(e);
    }
    const isHttps = u.protocol === "https:";
    const lib = isHttps ? https3 : http5;
    const data = Buffer.from(JSON.stringify(body || {}), "utf8");
    const req = lib.request({
      method: "POST",
      protocol: u.protocol,
      host: u.hostname,
      port: u.port || (isHttps ? 443 : 80),
      path: u.pathname + (u.search || ""),
      headers: {
        "content-type": "application/json",
        "content-length": String(data.length),
        "user-agent": "qqq-shell-state-cloud/1"
      },
      timeout: REQ_TIMEOUT_MS
    }, (res) => {
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => {
        const raw = Buffer.concat(chunks).toString("utf8");
        let json = null;
        try {
          json = raw ? JSON.parse(raw) : {};
        } catch {
          json = { _raw: raw };
        }
        resolve3({ status: res.statusCode || 0, json });
      });
    });
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy(new Error("timeout"));
    });
    req.write(data);
    req.end();
  });
}
var StateCloud = class {
  constructor(store) {
    this.store = store;
    this.store.onCloudDirty = (_ns, _key) => {
    };
  }
  // ★ 登录态变更时由 renderer 经 IPC 调用
  static setAuth(auth) {
    _cachedAuth = auth;
  }
  // -----------------------------------------------------------------------
  // List all cloud-eligible keys from currently registered namespaces.
  // -----------------------------------------------------------------------
  async _enumerateCloudKeys() {
    const out = [];
    for (const ns of this.store.getRegisteredNs()) {
      const sc = this.store.getSchema(ns);
      if (!sc || !sc.cloud) {
        continue;
      }
      const keys = await this.store.list(ns);
      for (const k of keys) {
        out.push(ns + "/" + k);
      }
    }
    return out;
  }
  // -----------------------------------------------------------------------
  // pull(): GET server blobs for all cloud keys; merge into local via store.
  // -----------------------------------------------------------------------
  async pull() {
    const auth = readAuth();
    if (!auth) {
      return { ok: false, reason: "no-auth", pulled: [], conflicts: [] };
    }
    const keys = await this._enumerateCloudKeys();
    const body = {
      phone: auth.phone,
      token: auth.token,
      device_id: this.store.getDeviceId(),
      device_name: auth.device_name,
      keys
    };
    let resp;
    try {
      resp = await httpsPostJson(CLOUD_BASE + "/api/gaea/qqqide/user-data/pull", body);
    } catch (e) {
      return { ok: false, reason: "network: " + (e && e.message), pulled: [], conflicts: [] };
    }
    if (resp.status !== 200 || !resp.json || !resp.json.ok) {
      return { ok: false, reason: "http " + resp.status + ": " + (resp.json && resp.json.error), pulled: [], conflicts: [] };
    }
    const blobs = resp.json.blobs || {};
    const pulled = [];
    const conflicts = [];
    for (const fullKey of Object.keys(blobs)) {
      const slash = fullKey.indexOf("/");
      if (slash <= 0) {
        continue;
      }
      const ns = fullKey.slice(0, slash);
      const key = fullKey.slice(slash + 1);
      const sc = this.store.getSchema(ns);
      if (!sc) {
        continue;
      }
      const blob = blobs[fullKey];
      if (blob.deleted) {
        try {
          await this.store.del(ns, key);
          pulled.push(fullKey);
        } catch {
        }
        continue;
      }
      try {
        const local = await this.store.get(ns, key);
        let merged;
        if (sc.merger) {
          merged = sc.merger(local, blob.data, { ns, key });
        } else {
          const localTs = 0;
          merged = blob.ts >= localTs ? blob.data : local;
        }
        await this.store.setNow(ns, key, merged);
        pulled.push(fullKey);
      } catch (e) {
        console.warn("[cloud.pull] merge failed", fullKey, e);
        conflicts.push(fullKey);
      }
    }
    return { ok: true, pulled, conflicts };
  }
  // -----------------------------------------------------------------------
  // push(): send all outbox-queued payloads, drop on success.
  // -----------------------------------------------------------------------
  async push() {
    const auth = readAuth();
    if (!auth) {
      return { ok: false, reason: "no-auth", pushed: [], failed: [] };
    }
    const entries = this.store.listOutbox();
    if (entries.length === 0) {
      return { ok: true, pushed: [], failed: [] };
    }
    const lastByKey = /* @__PURE__ */ new Map();
    for (const ent of entries) {
      try {
        const raw = fs19.readFileSync(ent.file, "utf8");
        const p = JSON.parse(raw);
        if (!p || !p.ns || !p.key) {
          continue;
        }
        lastByKey.set(p.ns + "/" + p.key, { seq: ent.seq, payload: p });
      } catch (e) {
        console.warn("[cloud.push] bad outbox entry", ent.file, e);
      }
    }
    const blobs = {};
    for (const [fullKey, item] of lastByKey.entries()) {
      const sc = this.store.getSchema(item.payload.ns);
      if (!sc) {
        continue;
      }
      blobs[fullKey] = {
        data: item.payload.value,
        ts: item.payload.ts || Date.now(),
        v: sc.v,
        form: sc.form,
        deleted: !!item.payload.deleted
      };
    }
    const body = {
      phone: auth.phone,
      token: auth.token,
      device_id: this.store.getDeviceId(),
      device_name: auth.device_name,
      blobs
    };
    let resp;
    try {
      resp = await httpsPostJson(CLOUD_BASE + "/api/gaea/qqqide/user-data", body);
    } catch (e) {
      return { ok: false, reason: "network: " + (e && e.message), pushed: [], failed: Object.keys(blobs) };
    }
    if (resp.status !== 200 || !resp.json || !resp.json.ok) {
      return { ok: false, reason: "http " + resp.status + ": " + (resp.json && resp.json.error), pushed: [], failed: Object.keys(blobs) };
    }
    const accepted = Array.isArray(resp.json.accepted) ? resp.json.accepted : Object.keys(blobs);
    const rejected = Array.isArray(resp.json.rejected) ? resp.json.rejected : [];
    const failedKeys = new Set(rejected.map((r) => r.key));
    for (const ent of entries) {
      try {
        const raw = fs19.readFileSync(ent.file, "utf8");
        const p = JSON.parse(raw);
        const fullKey = p.ns + "/" + p.key;
        if (!failedKeys.has(fullKey)) {
          this.store.dropOutbox(ent.seq);
        }
      } catch {
      }
    }
    this.store.markSyncedAt(Date.now());
    return { ok: true, pushed: accepted, failed: rejected.map((r) => r.key) };
  }
  // -----------------------------------------------------------------------
  // sync(): three-step pull → flush → push.
  // -----------------------------------------------------------------------
  async sync() {
    const auth = readAuth();
    if (!auth) {
      return { ok: false, reason: "no-auth" };
    }
    const pullR = await this.pull();
    try {
      await this.store.flush();
    } catch {
    }
    const pushR = await this.push();
    return {
      ok: pullR.ok && pushR.ok,
      reason: !pullR.ok ? pullR.reason : !pushR.ok ? pushR.reason : void 0,
      pull: pullR,
      push: pushR
    };
  }
};

// shell/qgf.ts
var path21 = __toESM(require("path"));
var fs20 = __toESM(require("fs"));
var zlib2 = __toESM(require("zlib"));
var crypto4 = __toESM(require("crypto"));
var import_events2 = require("events");
var DEFAULT_DEBOUNCE_MS2 = 250;
var DEFAULT_LOG_COMPACT_BYTES = 2 * 1024 * 1024;
var LOCK_STALE_MS = 6e4;
var MAX_SAFE_NAME = 200;
var BAD_CHARS_RE = /[/\\:*?"<>|\x00-\x1f]/g;
function nowMs() {
  return Date.now();
}
function safeName(s) {
  if (s === null || s === void 0)
    return "_";
  let v = String(s).replace(BAD_CHARS_RE, "_").replace(/^\.+/, "_").trim();
  if (!v)
    v = "_";
  if (v.length > MAX_SAFE_NAME) {
    const h = crypto4.createHash("sha256").update(v).digest("hex").slice(0, 32);
    v = v.slice(0, MAX_SAFE_NAME - 33) + "_" + h;
  }
  return v;
}
async function atomicWrite(absPath, data) {
  const dir = path21.dirname(absPath);
  await fs20.promises.mkdir(dir, { recursive: true });
  const tmp = absPath + ".tmp." + process.pid + "." + Math.random().toString(36).slice(2, 8);
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(data, "utf8");
  await fs20.promises.writeFile(tmp, buf);
  try {
    await fs20.promises.rename(tmp, absPath);
  } catch (e) {
    if (e && (e.code === "EEXIST" || e.code === "EPERM" || e.code === "EACCES")) {
      try {
        const data2 = await fs20.promises.readFile(tmp);
        await fs20.promises.writeFile(absPath, data2);
      } catch (e2) {
        try {
          await fs20.promises.unlink(tmp);
        } catch {
        }
        throw e2;
      }
    } else {
      try {
        await fs20.promises.unlink(tmp);
      } catch {
      }
      throw e;
    }
  }
}
function atomicWriteSync(absPath, data) {
  const dir = path21.dirname(absPath);
  try {
    fs20.mkdirSync(dir, { recursive: true });
  } catch {
  }
  const tmp = absPath + ".tmp." + process.pid + "." + Math.random().toString(36).slice(2, 8);
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(data, "utf8");
  fs20.writeFileSync(tmp, buf);
  try {
    fs20.renameSync(tmp, absPath);
  } catch (e) {
    if (e && (e.code === "EEXIST" || e.code === "EPERM" || e.code === "EACCES")) {
      try {
        const data2 = fs20.readFileSync(tmp);
        fs20.writeFileSync(absPath, data2);
      } catch (e2) {
        try {
          fs20.unlinkSync(tmp);
        } catch {
        }
        throw e2;
      }
    } else {
      try {
        fs20.unlinkSync(tmp);
      } catch {
      }
      throw e;
    }
  }
}
async function atomicRead(absPath) {
  const buf = await fs20.promises.readFile(absPath);
  return buf.toString("utf8");
}
var _Qgf = class _Qgf extends import_events2.EventEmitter {
  // ----- constructor --------------------------------------------------------
  /**
   * @param rootDir  e.g. "/path/to/project/.qqq/qgf"
   */
  constructor(rootDir) {
    super();
    this.outboxSeq = 0;
    this.schemas = /* @__PURE__ */ new Map();
    this.states = /* @__PURE__ */ new Map();
    this._dirCache = /* @__PURE__ */ new Map();
    // ★ ns → key list cache
    /** Hook for cloud sync (qgf doesn't auto-push; state-cloud.ts drains outbox). */
    this.onCloudDirty = null;
    this.setMaxListeners(0);
    this.rootDir = rootDir;
    this.nsDir = path21.join(rootDir, "ns");
    this.locksDir = path21.join(rootDir, "locks");
    this.outboxDir = path21.join(rootDir, "outbox");
    this.corruptDir = path21.join(rootDir, "corrupt");
    for (const d of [this.nsDir, this.locksDir, this.outboxDir, this.corruptDir]) {
      try {
        fs20.mkdirSync(d, { recursive: true });
      } catch {
      }
    }
    this._restoreOutboxSeq();
  }
  _restoreOutboxSeq() {
    try {
      for (const f of fs20.readdirSync(this.outboxDir)) {
        const m = f.match(/^(\d+)\.json$/);
        if (m) {
          const n = parseInt(m[1], 10);
          if (n > this.outboxSeq)
            this.outboxSeq = n;
        }
      }
    } catch {
    }
  }
  // ----- introspection ------------------------------------------------------
  stats() {
    let dirty = 0;
    for (const st of this.states.values()) {
      if (st.dirty)
        dirty++;
    }
    let outbox = 0;
    try {
      outbox = fs20.readdirSync(this.outboxDir).filter((f) => f.endsWith(".json")).length;
    } catch {
    }
    return { dirtyKeys: dirty, queuedOutbox: outbox, lastSyncAt: this.lastSyncAt, namespaces: this.schemas.size };
  }
  markSyncedAt(t) {
    this.lastSyncAt = t;
  }
  getRegisteredNs() {
    return Array.from(this.schemas.keys());
  }
  getSchema(ns) {
    return this.schemas.get(ns);
  }
  // ----- registration -------------------------------------------------------
  register(ns, schema) {
    if (!ns || typeof ns !== "string")
      throw new Error("qgf.register: bad ns");
    if (!schema || !["doc", "blob", "log"].includes(schema.form))
      throw new Error("qgf.register: schema.form must be doc/blob/log");
    if (typeof schema.v !== "number" || schema.v < 1)
      throw new Error("qgf.register: schema.v >=1");
    const existing = this.schemas.get(ns);
    if (existing && existing.form !== schema.form)
      throw new Error(`qgf.register: ns "${ns}" form mismatch`);
    this.schemas.set(ns, schema);
  }
  // ----- path helpers -------------------------------------------------------
  _payloadPath(safeNs, safeKey, form) {
    const ext = form === "doc" ? ".json" : form === "blob" ? ".bin" : ".log";
    return path21.join(this.nsDir, safeNs, safeKey + ext);
  }
  _lockPath(safeNs, safeKey) {
    return path21.join(this.locksDir, safeNs + "__" + safeKey + ".lock");
  }
  _resolveKeyState(ns, key) {
    const id = ns + "\0" + key;
    let st = this.states.get(id);
    if (!st) {
      st = {
        ns,
        key,
        safeNs: safeName(ns),
        safeKey: safeName(key),
        value: void 0,
        dirty: false,
        saveChain: Promise.resolve(),
        loaded: false
      };
      this.states.set(id, st);
    }
    return st;
  }
  _requireSchema(ns) {
    const sc = this.schemas.get(ns);
    if (!sc)
      throw new Error(`qgf: ns "${ns}" not registered`);
    return sc;
  }
  // ★ Invalidate directory cache for a namespace.
  _invalidateDirCache(ns) {
    this._dirCache.delete(ns);
  }
  // ----- encode / decode ----------------------------------------------------
  _encode(form, value) {
    if (form === "doc")
      return Buffer.from(JSON.stringify(value), "utf8");
    if (form === "blob") {
      const json = Buffer.from(JSON.stringify(value), "utf8");
      if (json.length <= _Qgf.BLOB_NOCOMPRESS_BYTES)
        return json;
      return zlib2.brotliCompressSync(json);
    }
    if (!Array.isArray(value))
      value = [];
    const lines = value.map((ev) => JSON.stringify(ev)).join("\n");
    return Buffer.from(lines + (lines ? "\n" : ""), "utf8");
  }
  _decode(form, buf) {
    if (form === "doc")
      return JSON.parse(buf.toString("utf8"));
    if (form === "blob") {
      const first = buf.length > 0 ? buf[0] : 0;
      if (first === 123 || first === 91) {
        return JSON.parse(buf.toString("utf8"));
      }
      const json = zlib2.brotliDecompressSync(buf).toString("utf8");
      return JSON.parse(json);
    }
    const txt = buf.toString("utf8");
    const out = [];
    for (const line of txt.split(/\r?\n/)) {
      const t = line.trim();
      if (!t)
        continue;
      try {
        out.push(JSON.parse(t));
      } catch {
      }
    }
    return out;
  }
  // ----- file lock (O_EXCL + stale detection) --------------------------------
  async _acquireLock(safeNs, safeKey) {
    const lp = this._lockPath(safeNs, safeKey);
    await fs20.promises.mkdir(path21.dirname(lp), { recursive: true });
    for (let i = 0; i < 40; i++) {
      try {
        const fd = fs20.openSync(lp, "wx");
        fs20.writeSync(fd, JSON.stringify({ pid: process.pid, ts: nowMs() }));
        fs20.closeSync(fd);
        return lp;
      } catch (e) {
        if (e && e.code === "EEXIST") {
          let stale = false;
          try {
            const info = JSON.parse(fs20.readFileSync(lp, "utf8"));
            if (typeof info.ts === "number" && nowMs() - info.ts > LOCK_STALE_MS)
              stale = true;
          } catch {
            stale = true;
          }
          if (stale) {
            try {
              fs20.unlinkSync(lp);
            } catch {
            }
            continue;
          }
          await new Promise((r) => setTimeout(r, 50));
          continue;
        }
        throw e;
      }
    }
    console.warn("[qgf] _acquireLock timeout", lp);
    return lp;
  }
  _releaseLock(lp) {
    try {
      fs20.unlinkSync(lp);
    } catch {
    }
  }
  // ----- corrupt isolation --------------------------------------------------
  _quarantine(safeNs, safeKey, form, reason) {
    try {
      const src = this._payloadPath(safeNs, safeKey, form);
      if (!fs20.existsSync(src))
        return;
      const ext = path21.extname(src);
      const ts = nowMs();
      const dst = path21.join(this.corruptDir, safeNs + "__" + safeKey + "." + ts + ext);
      fs20.mkdirSync(this.corruptDir, { recursive: true });
      fs20.renameSync(src, dst);
      console.warn("[qgf] quarantined", src, "->", dst, "reason=", reason);
    } catch (e) {
      console.warn("[qgf] _quarantine failed:", e);
    }
  }
  // ----- load ---------------------------------------------------------------
  async _loadFromDisk(st) {
    const sc = this._requireSchema(st.ns);
    const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
    if (!fs20.existsSync(payload)) {
      st.value = sc.form === "log" ? [] : null;
      st.loaded = true;
      return;
    }
    try {
      const buf = await fs20.promises.readFile(payload);
      st.value = this._decode(sc.form, buf);
      if (sc.form === "log") {
        const tailPath = payload + ".tail";
        if (fs20.existsSync(tailPath)) {
          try {
            const tailBuf = await fs20.promises.readFile(tailPath);
            const tailEvents = this._decode(sc.form, tailBuf);
            if (Array.isArray(tailEvents) && tailEvents.length > 0) {
              if (!Array.isArray(st.value))
                st.value = [];
              st.value.push(...tailEvents);
            }
          } catch {
          }
        }
        st._logTail = [];
      }
      st.loaded = true;
    } catch (e) {
      console.warn("[qgf] decode failed for", st.ns, st.key, "\u2014 quarantining:", e);
      this._quarantine(st.safeNs, st.safeKey, sc.form, String(e));
      st.value = sc.form === "log" ? [] : null;
      st.loaded = true;
    }
  }
  async _ensureLoaded(st) {
    if (!st.loaded)
      await this._loadFromDisk(st);
  }
  // ----- public API ---------------------------------------------------------
  async get(ns, key) {
    this._requireSchema(ns);
    const st = this._resolveKeyState(ns, key);
    await this._ensureLoaded(st);
    return st.value;
  }
  async set(ns, key, value) {
    const sc = this._requireSchema(ns);
    if (sc.form === "log" && !Array.isArray(value))
      throw new Error(`qgf.set on log form requires array; ns=${ns} key=${key}`);
    const st = this._resolveKeyState(ns, key);
    await this._ensureLoaded(st);
    st.value = value;
    st.dirty = true;
    this._scheduleSave(st, sc);
    if (sc.cloud && this.onCloudDirty) {
      try {
        this.onCloudDirty(ns, key);
      } catch {
      }
    }
  }
  async setNow(ns, key, value) {
    const sc = this._requireSchema(ns);
    if (sc.form === "log" && !Array.isArray(value))
      throw new Error(`qgf.setNow on log form requires array; ns=${ns} key=${key}`);
    const st = this._resolveKeyState(ns, key);
    await this._ensureLoaded(st);
    st.value = value;
    st.dirty = true;
    await this._flushKey(st, sc);
    if (sc.cloud && this.onCloudDirty) {
      try {
        this.onCloudDirty(ns, key);
      } catch {
      }
    }
  }
  async append(ns, key, event) {
    const sc = this._requireSchema(ns);
    if (sc.form !== "log")
      throw new Error(`qgf.append only for log form; ns=${ns}`);
    const st = this._resolveKeyState(ns, key);
    await this._ensureLoaded(st);
    if (!Array.isArray(st.value))
      st.value = [];
    if (!st._logTail)
      st._logTail = [];
    st.value.push(event);
    st._logTail.push(event);
    st.dirty = true;
    const tailPath = this._payloadPath(st.safeNs, st.safeKey, sc.form) + ".tail";
    const line = JSON.stringify(event) + "\n";
    try {
      await fs20.promises.mkdir(path21.dirname(tailPath), { recursive: true });
      await fs20.promises.appendFile(tailPath, line, "utf8");
    } catch {
    }
    this._scheduleSave(st, sc);
    if (sc.cloud && this.onCloudDirty) {
      try {
        this.onCloudDirty(ns, key);
      } catch {
      }
    }
  }
  async del(ns, key) {
    const sc = this._requireSchema(ns);
    const st = this._resolveKeyState(ns, key);
    if (st.debounceTimer) {
      clearTimeout(st.debounceTimer);
      st.debounceTimer = void 0;
    }
    const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
    let any = false;
    try {
      if (fs20.existsSync(payload)) {
        await fs20.promises.unlink(payload);
        any = true;
      }
    } catch {
    }
    try {
      const tp = payload + ".tail";
      if (fs20.existsSync(tp))
        await fs20.promises.unlink(tp);
    } catch {
    }
    this.states.delete(ns + "\0" + key);
    this._invalidateDirCache(ns);
    if (any) {
      this.emit("changed", { ns, key, value: null, deleted: true });
      if (sc.cloud)
        this._queueOutbox(ns, key, null, true);
    }
    return any;
  }
  async list(ns) {
    this._requireSchema(ns);
    const cached = this._dirCache.get(ns);
    if (cached)
      return cached;
    const dir = path21.join(this.nsDir, safeName(ns));
    const out = [];
    try {
      for (const f of await fs20.promises.readdir(dir)) {
        if (f.endsWith(".tmp"))
          continue;
        if (f.endsWith(".tail"))
          continue;
        const m = f.match(/^(.+)\.(json|bin|log)$/);
        if (m)
          out.push(m[1]);
      }
    } catch {
    }
    this._dirCache.set(ns, out);
    return out;
  }
  // ----- save chain ---------------------------------------------------------
  _scheduleSave(st, sc) {
    const ms = typeof sc.debounceMs === "number" ? sc.debounceMs : DEFAULT_DEBOUNCE_MS2;
    if (st.debounceTimer)
      clearTimeout(st.debounceTimer);
    st.debounceTimer = setTimeout(() => {
      st.debounceTimer = void 0;
      st.saveChain = st.saveChain.then(() => this._doSaveOnce(st, sc)).catch((e) => {
        console.warn("[qgf] save error", st.ns, st.key, e);
      });
    }, ms);
  }
  async _flushKey(st, sc) {
    if (st.debounceTimer) {
      clearTimeout(st.debounceTimer);
      st.debounceTimer = void 0;
    }
    st.saveChain = st.saveChain.then(() => this._doSaveOnce(st, sc));
    await st.saveChain;
  }
  async flush() {
    const tasks = [];
    for (const st of this.states.values()) {
      const sc = this.schemas.get(st.ns);
      if (!sc)
        continue;
      if (st.dirty || st.debounceTimer)
        tasks.push(this._flushKey(st, sc));
    }
    await Promise.all(tasks);
  }
  async flushOne(ns, key) {
    const id = ns + "\0" + key;
    const st = this.states.get(id);
    if (!st)
      return;
    const sc = this.schemas.get(ns);
    if (!sc)
      return;
    await this._flushKey(st, sc);
  }
  flushSync() {
    for (const st of this.states.values()) {
      const sc = this.schemas.get(st.ns);
      if (!sc)
        continue;
      if (st.debounceTimer) {
        clearTimeout(st.debounceTimer);
        st.debounceTimer = void 0;
      }
      if (!st.dirty)
        continue;
      try {
        this._doSaveOnceSync(st, sc);
      } catch (e) {
        console.warn("[qgf] flushSync error", st.ns, st.key, e);
      }
    }
  }
  // ----- the actual save ----------------------------------------------------
  async _doSaveOnce(st, sc) {
    if (!st.dirty)
      return;
    const lp = await this._acquireLock(st.safeNs, st.safeKey);
    try {
      if (sc.form === "log") {
        const tailPath = this._payloadPath(st.safeNs, st.safeKey, sc.form) + ".tail";
        if (fs20.existsSync(tailPath)) {
          try {
            const tailBuf = await fs20.promises.readFile(tailPath);
            const tailEvents = this._decode(sc.form, tailBuf);
            if (Array.isArray(tailEvents) && tailEvents.length > 0) {
              if (!Array.isArray(st.value))
                st.value = [];
              const seen = new Set(st.value.map((e) => JSON.stringify(e)));
              for (const ev of tailEvents) {
                const k = JSON.stringify(ev);
                if (!seen.has(k)) {
                  seen.add(k);
                  st.value.push(ev);
                }
              }
            }
          } catch {
          }
        }
      }
      await this._mergeFromDisk(st, sc);
      let buf = this._encode(sc.form, st.value);
      if (sc.quotaBytes && buf.length > sc.quotaBytes) {
        if (sc.form === "log" && Array.isArray(st.value)) {
          st.value = st.value.slice(Math.floor(st.value.length / 2));
          buf = this._encode(sc.form, st.value);
        }
        if (buf.length > sc.quotaBytes)
          throw new Error("quota exceeded");
      }
      const needsCompact = sc.form === "log" && sc.compactThresholdBytes && buf.length > sc.compactThresholdBytes;
      const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
      await atomicWrite(payload, buf);
      if (sc.form === "log") {
        st._logTail = [];
        const tailPath = payload + ".tail";
        try {
          if (fs20.existsSync(tailPath))
            await fs20.promises.unlink(tailPath);
        } catch {
        }
      }
      st.dirty = false;
      this._invalidateDirCache(st.ns);
      if (sc.cloud)
        this._queueOutbox(st.ns, st.key, st.value, false);
      this.emit("changed", { ns: st.ns, key: st.key, value: st.value, deleted: false });
      if (needsCompact) {
        setImmediate(() => this._maybeCompact(st, sc).catch(() => {
        }));
      }
    } finally {
      this._releaseLock(lp);
    }
  }
  _doSaveOnceSync(st, sc) {
    if (!st.dirty)
      return;
    const buf = this._encode(sc.form, st.value);
    const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
    atomicWriteSync(payload, buf);
    st.dirty = false;
    this._invalidateDirCache(st.ns);
    if (sc.cloud)
      this._queueOutbox(st.ns, st.key, st.value, false);
  }
  // ----- merge-on-save ------------------------------------------------------
  async _mergeFromDisk(st, sc) {
    const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
    if (!fs20.existsSync(payload))
      return;
    let diskVal;
    try {
      diskVal = this._decode(sc.form, await fs20.promises.readFile(payload));
    } catch {
      return;
    }
    try {
      if (sc.form === "log" && Array.isArray(diskVal) && Array.isArray(st.value)) {
        const seen = /* @__PURE__ */ new Set();
        const out = [];
        for (const ev of diskVal) {
          const k = JSON.stringify(ev);
          if (!seen.has(k)) {
            seen.add(k);
            out.push(ev);
          }
        }
        for (const ev of st.value) {
          const k = JSON.stringify(ev);
          if (!seen.has(k)) {
            seen.add(k);
            out.push(ev);
          }
        }
        st.value = sc.merger ? sc.merger(diskVal, st.value, { ns: st.ns, key: st.key }) : out;
      } else {
        st.value = sc.merger ? sc.merger(diskVal, st.value, { ns: st.ns, key: st.key }) : st.value;
      }
    } catch (e) {
      console.warn("[qgf] merger threw \u2014 keeping in-memory value", st.ns, st.key, e);
    }
  }
  // ----- log compaction -----------------------------------------------------
  _compactLog(st, sc) {
    if (!Array.isArray(st.value))
      return null;
    if (sc.merger) {
      try {
        const compacted = sc.merger([], st.value, { ns: st.ns, key: st.key });
        if (Array.isArray(compacted))
          return compacted;
      } catch (e) {
        console.warn("[qgf] compactLog merger threw", st.ns, st.key, e);
      }
    }
    return st.value.slice(Math.floor(st.value.length / 2));
  }
  /** ★ Async log compaction — non-blocking, runs after save completes. */
  async _maybeCompact(st, sc) {
    if (!Array.isArray(st.value))
      return;
    const compacted = this._compactLog(st, sc);
    if (!compacted)
      return;
    st.value = compacted;
    st.dirty = true;
    const buf = this._encode(sc.form, st.value);
    const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
    await atomicWrite(payload, buf);
    st.dirty = false;
    this._invalidateDirCache(st.ns);
    if (sc.cloud)
      this._queueOutbox(st.ns, st.key, st.value, false);
  }
  // ----- outbox (cloud-sync queue) ------------------------------------------
  _queueOutbox(ns, key, value, deleted) {
    try {
      this.outboxSeq += 1;
      const seq = String(this.outboxSeq).padStart(12, "0");
      const f = path21.join(this.outboxDir, seq + ".json");
      const payload = { seq, ns, key, ts: nowMs(), deleted, value: deleted ? null : value };
      atomicWriteSync(f, JSON.stringify(payload));
    } catch (e) {
      console.warn("[qgf] _queueOutbox failed:", e);
    }
  }
  listOutbox() {
    const out = [];
    try {
      const files = fs20.readdirSync(this.outboxDir).filter((f) => f.endsWith(".json")).sort();
      for (const f of files)
        out.push({ seq: f.replace(/\.json$/, ""), file: path21.join(this.outboxDir, f) });
    } catch {
    }
    return out;
  }
  dropOutbox(seq) {
    const f = path21.join(this.outboxDir, seq + ".json");
    try {
      fs20.unlinkSync(f);
      return true;
    } catch {
      return false;
    }
  }
  // ----- onChange convenience -----------------------------------------------
  onChange(ns, key, cb) {
    const h = (msg) => {
      if (msg.ns === ns && msg.key === key)
        cb(msg.value, msg.deleted);
    };
    this.on("changed", h);
    return () => {
      this.off("changed", h);
    };
  }
};
// ★ blob fast path threshold
_Qgf.BLOB_NOCOMPRESS_BYTES = 4096;
var Qgf = _Qgf;

// shell/ipc-state-handlers.ts
function registerStateHandlersIpc(stateStore2, stateCloud2, projectStateStores, qgfInstances, getMainWindow) {
  import_electron15.ipcMain.handle("qqqide:state:register", async (_e, ns, schema) => {
    const safeSchema = {
      v: schema.v,
      form: schema.form,
      quotaBytes: schema.quotaBytes,
      cloud: !!schema.cloud,
      debounceMs: schema.debounceMs,
      compactThresholdBytes: schema.compactThresholdBytes
    };
    stateStore2.register(ns, safeSchema);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:get", async (_e, ns, key) => stateStore2.get(ns, key));
  import_electron15.ipcMain.handle("qqqide:state:set", async (_e, ns, key, v) => {
    await stateStore2.set(ns, key, v);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:setNow", async (_e, ns, key, v) => {
    await stateStore2.setNow(ns, key, v);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:append", async (_e, ns, key, ev) => {
    await stateStore2.append(ns, key, ev);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:del", async (_e, ns, key) => stateStore2.del(ns, key));
  import_electron15.ipcMain.handle("qqqide:state:list", async (_e, ns) => stateStore2.list(ns));
  import_electron15.ipcMain.handle("qqqide:state:flush", async () => {
    await stateStore2.flush();
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:flushOne", async (_e, ns, key) => {
    await stateStore2.flushOne(ns, key);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:stats", () => stateStore2.stats());
  import_electron15.ipcMain.handle("qqqide:state:sql", async (_e, query, params) => stateStore2.sql(query, params));
  import_electron15.ipcMain.handle("qqqide:state:cloud:pull", async () => stateCloud2.pull());
  import_electron15.ipcMain.handle("qqqide:state:cloud:push", async () => stateCloud2.push());
  import_electron15.ipcMain.handle("qqqide:state:cloud:sync", async () => stateCloud2.sync());
  import_electron15.ipcMain.handle("qqqide:state:cloud:setAuth", async (_e, auth) => {
    StateCloud.setAuth(auth);
    return true;
  });
  function _getProjectStateStore(dbPath) {
    let inst = projectStateStores.get(dbPath);
    if (!inst) {
      inst = new StateStore("", dbPath);
      const mainWindow2 = getMainWindow();
      inst.on("changed", (msg) => {
        if (mainWindow2 && !mainWindow2.isDestroyed()) {
          try {
            mainWindow2.webContents.send("qqqide:state:project:changed", { ...msg, dbPath });
          } catch {
          }
        }
      });
      projectStateStores.set(dbPath, inst);
    }
    return inst;
  }
  import_electron15.ipcMain.handle("qqqide:state:project:register", async (_e, dbPath, ns, schema) => {
    const safeSchema = {
      v: schema.v,
      form: schema.form,
      quotaBytes: schema.quotaBytes,
      cloud: false,
      debounceMs: schema.debounceMs,
      compactThresholdBytes: schema.compactThresholdBytes
    };
    _getProjectStateStore(dbPath).register(ns, safeSchema);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:project:get", async (_e, dbPath, ns, key) => _getProjectStateStore(dbPath).get(ns, key));
  import_electron15.ipcMain.handle("qqqide:state:project:set", async (_e, dbPath, ns, key, v) => {
    await _getProjectStateStore(dbPath).set(ns, key, v);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:project:setNow", async (_e, dbPath, ns, key, v) => {
    await _getProjectStateStore(dbPath).setNow(ns, key, v);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:project:append", async (_e, dbPath, ns, key, ev) => {
    await _getProjectStateStore(dbPath).append(ns, key, ev);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:project:del", async (_e, dbPath, ns, key) => _getProjectStateStore(dbPath).del(ns, key));
  import_electron15.ipcMain.handle("qqqide:state:project:list", async (_e, dbPath, ns) => _getProjectStateStore(dbPath).list(ns));
  import_electron15.ipcMain.handle("qqqide:state:project:flush", async (_e, dbPath) => {
    await _getProjectStateStore(dbPath).flush();
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:project:flushOne", async (_e, dbPath, ns, key) => {
    await _getProjectStateStore(dbPath).flushOne(ns, key);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:state:project:stats", async (_e, dbPath) => _getProjectStateStore(dbPath).stats());
  import_electron15.ipcMain.handle("qqqide:state:project:atomicIncr", async (_e, dbPath, ns, key) => _getProjectStateStore(dbPath).atomicIncr(ns, key));
  function _getQgf(rootDir) {
    let inst = qgfInstances.get(rootDir);
    if (!inst) {
      inst = new Qgf(rootDir);
      const mainWindow2 = getMainWindow();
      inst.on("changed", (msg) => {
        if (mainWindow2 && !mainWindow2.isDestroyed()) {
          try {
            mainWindow2.webContents.send("qqqide:qgf:changed", { ...msg, rootDir });
          } catch {
          }
        }
      });
      qgfInstances.set(rootDir, inst);
    }
    return inst;
  }
  import_electron15.ipcMain.handle("qqqide:qgf:register", async (_e, rootDir, ns, schema) => {
    const safeSchema = { v: schema.v, form: schema.form, cloud: false };
    _getQgf(rootDir).register(ns, safeSchema);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:qgf:get", async (_e, rootDir, ns, key) => _getQgf(rootDir).get(ns, key));
  import_electron15.ipcMain.handle("qqqide:qgf:set", async (_e, rootDir, ns, key, v) => {
    const qf = _getQgf(rootDir);
    await qf.set(ns, key, v);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:qgf:setNow", async (_e, rootDir, ns, key, v) => {
    const qf = _getQgf(rootDir);
    await qf.setNow(ns, key, v);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:qgf:append", async (_e, rootDir, ns, key, ev) => {
    const qf = _getQgf(rootDir);
    await qf.append(ns, key, ev);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:qgf:del", async (_e, rootDir, ns, key) => _getQgf(rootDir).del(ns, key));
  import_electron15.ipcMain.handle("qqqide:qgf:list", async (_e, rootDir, ns) => _getQgf(rootDir).list(ns));
  import_electron15.ipcMain.handle("qqqide:qgf:flush", async (_e, rootDir) => {
    const qf = _getQgf(rootDir);
    await qf.flush();
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:qgf:stats", async (_e, rootDir) => _getQgf(rootDir).stats());
  import_electron15.ipcMain.handle("qqqide:qgf:flushOne", async (_e, rootDir, ns, key) => {
    await _getQgf(rootDir).flushOne(ns, key);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:qgf:atomicWrite", async (_e, absPath, data) => {
    await atomicWrite(absPath, data);
    return true;
  });
  import_electron15.ipcMain.handle("qqqide:qgf:atomicRead", async (_e, absPath) => {
    return await atomicRead(absPath);
  });
}

// shell/shutdown.ts
var import_electron16 = require("electron");
var path24 = __toESM(require("path"));
var fs23 = __toESM(require("fs"));
var import_url5 = require("url");
var AUTO_VERSION_TOGGLE_OFF = "auto-version-off";
function autoIncrementVersion(portableRoot) {
  try {
    const toggleOff = path24.join(portableRoot, "Data", AUTO_VERSION_TOGGLE_OFF);
    if (fs23.existsSync(toggleOff)) {
      console.log("[auto-version] OFF (toggle file exists), skip");
      return;
    }
    const versionTs = path24.join(portableRoot, "shell", "version.ts");
    const mainJs = path24.join(portableRoot, "shell-out", "main.js");
    const pkgJson = path24.join(portableRoot, "package.json");
    let oldVer = "";
    const tsExists = fs23.existsSync(versionTs);
    if (tsExists) {
      const ts = fs23.readFileSync(versionTs, "utf8");
      const m = ts.match(/export const APP_VERSION\s*=\s*'(\d+)\.(\d+)\.(\d+)'/);
      if (m)
        oldVer = `${m[1]}.${m[2]}.${m[3]}`;
    }
    if (!oldVer && fs23.existsSync(mainJs)) {
      const js = fs23.readFileSync(mainJs, "utf8");
      const m = js.match(/var APP_VERSION\s*=\s*"(\d+)\.(\d+)\.(\d+)"/);
      if (m)
        oldVer = `${m[1]}.${m[2]}.${m[3]}`;
    }
    if (!oldVer) {
      console.log("[auto-version] cannot read current version, skip");
      return;
    }
    const parts = oldVer.split(".");
    const newPatch = parseInt(parts[2], 10) + 1;
    const newVer = `${parts[0]}.${parts[1]}.${newPatch}`;
    console.log("[auto-version] " + oldVer + " \u2192 " + newVer);
    if (tsExists) {
      let ts = fs23.readFileSync(versionTs, "utf8");
      ts = ts.replace(
        /export const APP_VERSION\s*=\s*'\d+\.\d+\.\d+'/,
        `export const APP_VERSION = '${newVer}'`
      );
      fs23.writeFileSync(versionTs, ts, "utf8");
      console.log("[auto-version] version.ts updated");
    }
    if (fs23.existsSync(mainJs)) {
      let js = fs23.readFileSync(mainJs, "utf8");
      js = js.replace(
        /var APP_VERSION\s*=\s*"\d+\.\d+\.\d+"/,
        `var APP_VERSION = "${newVer}"`
      );
      fs23.writeFileSync(mainJs, js, "utf8");
      console.log("[auto-version] main.js updated");
    }
    if (fs23.existsSync(pkgJson)) {
      let pkg = fs23.readFileSync(pkgJson, "utf8");
      pkg = pkg.replace(
        /"version"\s*:\s*"\d+\.\d+\.\d+"/,
        `"version": "${newVer}"`
      );
      fs23.writeFileSync(pkgJson, pkg, "utf8");
      console.log("[auto-version] package.json updated");
    }
    const dataDir = path24.join(portableRoot, "Data");
    try {
      fs23.mkdirSync(dataDir, { recursive: true });
    } catch {
    }
    fs23.writeFileSync(path24.join(dataDir, "shell-version"), newVer, "utf8");
    fs23.writeFileSync(path24.join(dataDir, "webapp-version"), newVer, "utf8");
    console.log("[auto-version] Data/shell-version + webapp-version \u2192 " + newVer);
    console.log("[auto-version] done: " + oldVer + " \u2192 " + newVer);
  } catch (err) {
    console.warn("[auto-version] error:", err.message || err);
  }
}
function saveAllOpenWindows(stateStore2, winProjectMap) {
  try {
    const seen = /* @__PURE__ */ new Set();
    const windows = [];
    for (const win of import_electron16.BrowserWindow.getAllWindows()) {
      try {
        if (win.isDestroyed())
          continue;
        const rawFolder = (winProjectMap.get(win.id) || "").replace(/\\/g, "/").replace(/\/$/, "");
        let mainFolder = "";
        if (rawFolder && fs23.existsSync(rawFolder) && fs23.existsSync(rawFolder + "/qqq")) {
          mainFolder = rawFolder;
        } else if (rawFolder) {
          console.warn("[shutdown] skip invalid project:", rawFolder);
        }
        if (!mainFolder)
          continue;
        if (seen.has(mainFolder))
          continue;
        seen.add(mainFolder);
        const bounds = win.getBounds();
        const maximized = win.isMaximized();
        windows.push({
          mainFolder,
          bounds: {
            x: bounds.x,
            y: bounds.y,
            w: bounds.width,
            h: bounds.height,
            maximized
          }
        });
      } catch (e) {
        try {
          console.warn("[shutdown] skip window (destroyed mid-save):", e.message);
        } catch (_) {
        }
      }
    }
    if (windows.length > 0) {
      stateStore2.setNow("qqqide", "open_windows", windows);
      console.log("[shutdown] saved " + windows.length + " open window(s) for next-startup restore");
    }
  } catch (e) {
    console.warn("[shutdown] saveAllOpenWindows failed:", e);
  }
}
function hardenSession() {
  const ses = import_electron16.session.defaultSession;
  ses.setPermissionRequestHandler((_wc, _perm, callback) => callback(false));
  ses.webRequest.onHeadersReceived((details, cb) => {
    const headers = details.responseHeaders || {};
    delete headers["x-frame-options"];
    delete headers["X-Frame-Options"];
    if (details.url.includes("gh555.com")) {
      headers["access-control-allow-origin"] = ["*"];
      headers["access-control-allow-headers"] = ["Content-Type, Authorization"];
      headers["access-control-allow-methods"] = ["GET, POST, PUT, DELETE, OPTIONS"];
      if (details.method === "OPTIONS") {
        cb({ responseHeaders: headers, statusLine: "HTTP/1.1 200 OK" });
        return;
      }
    }
    cb({ responseHeaders: headers });
  });
}
function registerExitHandlers(portableRoot, portableLogs, stateStore2, bootConfig2, qgfInstances) {
  function _flushStateSync(label) {
    try {
      stateStore2.flushSync();
    } catch (err) {
      try {
        console.warn("[state] " + label + " flush failed:", err);
      } catch (_) {
      }
    }
  }
  function _flushQgfSync(label) {
    for (const [rootDir, qf] of qgfInstances) {
      try {
        qf.flushSync();
      } catch (err) {
        try {
          console.warn("[qgf] " + label + " flush failed for", rootDir, err);
        } catch (_) {
        }
      }
    }
  }
  let _flushedOnce = false;
  import_electron16.app.on("before-quit", async (event) => {
    if (_flushedOnce)
      return;
    _flushedOnce = true;
    event.preventDefault();
    try {
      const { stopPyBroker: stopPyBroker3 } = (init_py_broker(), __toCommonJS(py_broker_exports));
      stopPyBroker3();
    } catch {
    }
    try {
      const { cleanupAllGaeaProcesses: cleanupAllGaeaProcesses2 } = (init_gaea_process(), __toCommonJS(gaea_process_exports));
      cleanupAllGaeaProcesses2();
    } catch {
    }
    try {
      const { EngineHost: EngineHost2 } = (init_engines(), __toCommonJS(engines_exports));
    } catch {
    }
    try {
      _flushStateSync("before-quit");
    } catch {
    }
    try {
      _flushQgfSync("before-quit");
    } catch {
    }
    try {
      await stateStore2.flush();
    } catch (err) {
      try {
        console.warn("[state] async flush before-quit failed:", err);
      } catch (_) {
      }
    }
    _flushStateSync("before-quit");
    _timelineDbs.forEach((db, dbPath) => {
      try {
        const projectRoot = path24.dirname(path24.dirname(path24.dirname(dbPath)));
        _tlFlushNow(db, dbPath, projectRoot);
      } catch (_) {
      }
    });
    try {
      saveAllOpenWindows(stateStore2, _windowProjectMap);
    } catch {
    }
    for (const [winId, projectRoot] of _windowProjectMap) {
      try {
        fs23.unlinkSync(projectRoot + "/qqq/alphal/.lock");
      } catch (_) {
      }
    }
    try {
      autoIncrementVersion(portableRoot);
    } catch {
    }
    try {
      _flushStateSync("exit");
    } catch {
    }
    try {
      _flushQgfSync("exit");
    } catch {
    }
    import_electron16.app.exit(0);
    setTimeout(() => {
      process.exit(0);
    }, 500);
  });
  process.on("SIGINT", () => {
    _flushStateSync("SIGINT");
    _flushQgfSync("SIGINT");
    try {
      import_electron16.app.quit();
    } catch {
      process.exit(0);
    }
  });
  process.on("SIGTERM", () => {
    _flushStateSync("SIGTERM");
    _flushQgfSync("SIGTERM");
    try {
      import_electron16.app.quit();
    } catch {
      process.exit(0);
    }
  });
  let _ueInHandler = false;
  let _ueLastLogTs = 0;
  process.on("uncaughtException", (err) => {
    if (_ueInHandler)
      return;
    _ueInHandler = true;
    try {
      const _msg = err && err.message || "";
      if (_msg.indexOf("EPIPE") >= 0 || _msg.indexOf("broken pipe") >= 0 || _msg.indexOf("ECONNRESET") >= 0) {
        return;
      }
      if (err && err.message === "Object has been destroyed") {
        try {
          console.warn("[main] uncaughtException (Object destroyed) suppressed");
        } catch (_) {
        }
        return;
      }
      try {
        console.error("[uncaughtException]", err);
      } catch (_) {
      }
      _flushStateSync("uncaughtException");
      _flushQgfSync("uncaughtException");
      if (_msg.indexOf("Object has been destroyed") < 0) {
        const now = Date.now();
        if (now - _ueLastLogTs > 5e3) {
          _ueLastLogTs = now;
          try {
            const f = path24.join(portableLogs, "crash-" + now + ".log");
            fs23.writeFileSync(f, String(err && err.stack || err));
          } catch (_) {
          }
        }
      }
    } finally {
      _ueInHandler = false;
    }
  });
  process.on("unhandledRejection", (reason) => {
    try {
      console.warn("[unhandledRejection]", reason);
    } catch (_) {
    }
  });
  import_electron16.app.on("window-all-closed", () => {
    console.log("[window-all-closed] FIRED \u2014 all windows closed, quitting");
    if (process.platform !== "darwin") {
      import_electron16.app.quit();
    }
  });
  import_electron16.app.on("web-contents-created", (_e, contents) => {
    contents.setWindowOpenHandler(({ url }) => {
      openUrl(url);
      return { action: "deny" };
    });
    contents.on("will-navigate", (e, url) => {
      try {
        const target = new import_url5.URL(url);
        const allowed = new import_url5.URL(bootConfig2.url);
        if (target.origin !== allowed.origin && !url.startsWith("file://")) {
          e.preventDefault();
          openUrl(url);
        }
      } catch {
        e.preventDefault();
      }
    });
  });
}

// shell/main.ts
init_component_checker();
init_py_broker();
init_gaea_process();

// shell/ipc-kope.ts
var path25 = __toESM(require("path"));
var fs24 = __toESM(require("fs"));
var os6 = __toESM(require("os"));
var import_electron17 = require("electron");
var initSqlJs2 = require("sql.js");
function getDbPath() {
  const localAppData = path25.join(os6.homedir(), "AppData", "Local");
  const dir = path25.join(localAppData, "kope-a");
  if (!fs24.existsSync(dir))
    fs24.mkdirSync(dir, { recursive: true });
  return path25.join(dir, "kope.sq3");
}
var _SQL = null;
var _db = null;
var _initPromise = null;
var _lastDiskMtime = 0;
async function _ensureDb() {
  if (_db)
    return;
  if (_initPromise) {
    await _initPromise;
    return;
  }
  _initPromise = (async () => {
    _SQL = await initSqlJs2();
    const dbPath = getDbPath();
    const buf = fs24.existsSync(dbPath) ? fs24.readFileSync(dbPath) : null;
    _db = new _SQL.Database(buf);
    _db.run("PRAGMA journal_mode=WAL");
    _db.run(`CREATE TABLE IF NOT EXISTS clipboard_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            content_hash TEXT NOT NULL UNIQUE,
            preview TEXT,
            size_bytes INTEGER DEFAULT 0,
            content_type TEXT DEFAULT 'text',
            pinned INTEGER DEFAULT 0,
            pinned_at TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
        )`);
    _db.run("CREATE INDEX IF NOT EXISTS idx_clipboard_pinned ON clipboard_history(pinned DESC, pinned_at DESC)");
    _db.run("CREATE INDEX IF NOT EXISTS idx_clipboard_updated ON clipboard_history(updated_at DESC)");
    _saveDb();
    _lastDiskMtime = fs24.statSync(dbPath).mtimeMs;
  })();
  await _initPromise;
}
function _saveDb() {
  if (!_db)
    return;
  const dbPath = getDbPath();
  const data = _db.export();
  const buf = Buffer.from(data);
  fs24.writeFileSync(dbPath, buf);
  _lastDiskMtime = fs24.statSync(dbPath).mtimeMs;
}
function _reloadIfChanged() {
  const dbPath = getDbPath();
  if (!fs24.existsSync(dbPath))
    return;
  const mtime = fs24.statSync(dbPath).mtimeMs;
  if (mtime <= _lastDiskMtime)
    return;
  const buf = fs24.readFileSync(dbPath);
  if (_db)
    _db.close();
  _db = new _SQL.Database(buf);
  _db.run("PRAGMA journal_mode=WAL");
  _lastDiskMtime = mtime;
}
function _getHistory(limit, offset, keyword) {
  _reloadIfChanged();
  let sql = `SELECT id, content, content_hash, preview, size_bytes, content_type,
                      pinned, pinned_at, created_at, updated_at
               FROM clipboard_history `;
  const params = [];
  if (keyword) {
    const k = "%" + keyword + "%";
    sql += `WHERE preview LIKE ? OR content LIKE ? `;
    params.push(k, k);
  }
  sql += `ORDER BY pinned DESC, pinned_at DESC, updated_at DESC LIMIT ? OFFSET ?`;
  params.push(limit, offset);
  const rows = _db.exec(sql, params);
  if (!rows.length)
    return [];
  const cols = rows[0].columns;
  const vals = rows[0].values;
  return vals.map((row) => {
    const obj = {};
    cols.forEach((c, i) => {
      obj[c] = row[i];
    });
    return obj;
  });
}
function _getStats() {
  _reloadIfChanged();
  const r = _db.exec(`SELECT COUNT(*) as total, SUM(pinned) as pinned, MAX(updated_at) as max_updated_at FROM clipboard_history`);
  if (!r.length)
    return { total: 0, pinned: 0, max_updated_at: "" };
  const row = r[0].values[0];
  return { total: row[0], pinned: row[1] || 0, max_updated_at: row[2] || "" };
}
function _togglePin(id) {
  _reloadIfChanged();
  const r = _db.exec("SELECT pinned, pinned_at FROM clipboard_history WHERE id=?", [id]);
  if (!r.length || !r[0].values.length)
    return false;
  const cur = r[0].values[0];
  const newPinned = cur[0] ? 0 : 1;
  const pinnedAt = newPinned ? (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").substring(0, 19) : null;
  _db.run(
    "UPDATE clipboard_history SET pinned=?, pinned_at=?, updated_at=datetime('now','localtime') WHERE id=?",
    [newPinned, pinnedAt, id]
  );
  _saveDb();
  return true;
}
function _deleteItem(id) {
  _reloadIfChanged();
  _db.run("DELETE FROM clipboard_history WHERE id=?", [id]);
  _saveDb();
  return true;
}
function registerKopeIpc() {
  import_electron17.ipcMain.handle("qqqide:kope:getHistory", async (_e, limit, offset, keyword) => {
    await _ensureDb();
    return _getHistory(limit || 50, offset || 0, keyword || "");
  });
  import_electron17.ipcMain.handle("qqqide:kope:getStats", async () => {
    await _ensureDb();
    return _getStats();
  });
  import_electron17.ipcMain.handle("qqqide:kope:togglePin", async (_e, id) => {
    await _ensureDb();
    return _togglePin(id);
  });
  import_electron17.ipcMain.handle("qqqide:kope:deleteItem", async (_e, id) => {
    await _ensureDb();
    return _deleteItem(id);
  });
}

// shell/auth-state.ts
var _authPhone = "";
var _authToken = "";
function setAuthPhone(phone) {
  _authPhone = phone;
}
function getAuthPhone() {
  return _authPhone;
}
function setAuthToken(token) {
  _authToken = token;
}

// shell/wq-ping.ts
var fs25 = __toESM(require("fs"));
var path26 = __toESM(require("path"));
var os7 = __toESM(require("os"));
var crypto5 = __toESM(require("crypto"));
var https4 = __toESM(require("https"));
var import_electron18 = require("electron");
var PING_API_HOST = "direct-cn.gh555.com";
var PING_API_PATH = "/api/wq/ping";
var GOOD_SLG = "qqqide";
var DISTRIBUTION = "gh555.com";
var PING_JITTER_MIN_MS = 5e3;
var PING_JITTER_MAX_MS = 15e3;
var PING_FALLBACK_SEC = 43200;
var RETRY_MIN_MS = 6e4;
var RETRY_MAX_MS = 36e5;
var _deviceId = "";
var _factoryVersion = "";
var _cumulativeSeconds = 0;
var _sessionStartedAt = Date.now();
var _stopped = false;
var _retryDelayMs = RETRY_MIN_MS;
var _timer = null;
var _userDataPath2 = "";
var _logPath2 = "";
function pingLog(msg) {
  if (!_logPath2) {
    const base = _userDataPath2 || path26.join(path26.dirname(process.execPath), "Data");
    _logPath2 = path26.join(base, "alphal", "wq-ping.log");
    try {
      fs25.mkdirSync(path26.dirname(_logPath2), { recursive: true });
    } catch (_) {
    }
  }
  const line = (/* @__PURE__ */ new Date()).toISOString() + " " + msg + "\n";
  try {
    fs25.appendFileSync(_logPath2, line);
  } catch (_) {
  }
}
function alphalDir() {
  const base = _userDataPath2 || path26.join(path26.dirname(process.execPath), "Data");
  const dataDir = path26.join(base, "alphal");
  try {
    fs25.mkdirSync(dataDir, { recursive: true });
  } catch (_) {
  }
  return dataDir;
}
function deviceIdPath() {
  return path26.join(alphalDir(), "device_id");
}
function factoryVersionPath() {
  return path26.join(alphalDir(), "factory_version");
}
function cumulativeSecondsPath() {
  return path26.join(alphalDir(), "cumulative_seconds");
}
function loadOrCreateDeviceId() {
  const fp = deviceIdPath();
  try {
    if (fs25.existsSync(fp)) {
      const raw = fs25.readFileSync(fp, "utf8").trim();
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(raw)) {
        return raw.toLowerCase();
      }
    }
  } catch (_) {
  }
  const bytes = crypto5.randomBytes(16);
  bytes[6] = bytes[6] & 15 | 64;
  bytes[8] = bytes[8] & 63 | 128;
  const hex = bytes.toString("hex");
  const uuid = `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  try {
    fs25.writeFileSync(fp, uuid, "utf8");
  } catch (_) {
  }
  return uuid;
}
function loadOrCreateFactoryVersion() {
  const fp = factoryVersionPath();
  try {
    if (fs25.existsSync(fp)) {
      const raw = fs25.readFileSync(fp, "utf8").trim();
      if (raw.length > 0 && raw.length <= 50)
        return raw;
    }
  } catch (_) {
  }
  const fv = APP_VERSION;
  try {
    fs25.writeFileSync(fp, fv, "utf8");
  } catch (_) {
  }
  return fv;
}
function loadCumulativeSeconds() {
  const fp = cumulativeSecondsPath();
  try {
    if (fs25.existsSync(fp)) {
      const raw = fs25.readFileSync(fp, "utf8").trim();
      const n = parseInt(raw, 10);
      if (n >= 0 && n < 31536e4)
        return n;
    }
  } catch (_) {
  }
  return 0;
}
function persistCumulativeSeconds(total) {
  try {
    fs25.writeFileSync(cumulativeSecondsPath(), String(Math.floor(total)), "utf8");
  } catch (_) {
  }
}
function currentTotalSeconds() {
  return _cumulativeSeconds + Math.floor((Date.now() - _sessionStartedAt) / 1e3);
}
function authFilePath() {
  return path26.join(alphalDir(), "auth.enc");
}
function readDoerID() {
  const cached = getAuthPhone();
  if (cached && /^\d{7,20}$/.test(cached))
    return cached;
  try {
    if (import_electron18.safeStorage.isEncryptionAvailable()) {
      const fp = authFilePath();
      if (fs25.existsSync(fp)) {
        const encrypted = fs25.readFileSync(fp);
        const auth = JSON.parse(import_electron18.safeStorage.decryptString(encrypted));
        if (auth && auth.phone && /^\d{7,20}$/.test(auth.phone))
          return auth.phone;
      }
    }
  } catch (_) {
  }
  try {
    const phoneFile = path26.join(alphalDir(), "phone.txt");
    if (fs25.existsSync(phoneFile)) {
      const phone = fs25.readFileSync(phoneFile, "utf8").trim();
      if (phone && /^\d{7,20}$/.test(phone))
        return phone;
    }
  } catch (_) {
  }
  return "";
}
function collectPingBody() {
  const nowSec = Math.floor(Date.now() / 1e3);
  const totalSec = currentTotalSeconds();
  const body = {
    good_slg: GOOD_SLG,
    device_id: _deviceId,
    doer_id: readDoerID(),
    total_seconds: totalSec,
    event_time: nowSec,
    client_ver: APP_VERSION,
    factory_version: _factoryVersion,
    distribution: DISTRIBUTION,
    pkg_name: "qqqide",
    pkg_display_name: "qqqide",
    pkg_publisher: "gh555.com",
    os_platform: os7.platform(),
    os_arch: os7.arch(),
    os_ver: os7.release().slice(0, 30),
    cpu_cores: os7.cpus().length,
    mem_mb: Math.round(os7.totalmem() / (1024 * 1024))
  };
  return JSON.stringify(body);
}
function sendPing() {
  return new Promise((resolve3) => {
    pingLog("sendPing START host=" + PING_API_HOST);
    const bodyStr = collectPingBody();
    const req = https4.request({
      hostname: PING_API_HOST,
      port: 443,
      path: PING_API_PATH,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(bodyStr)
      },
      timeout: 1e4
    }, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk.toString();
      });
      res.on("end", () => {
        try {
          const json = JSON.parse(data);
          resolve3({
            ok: json.ok === true,
            minNextPingAt: json.min_next_ping_at
          });
        } catch {
          resolve3({ ok: false });
        }
      });
    });
    req.on("error", (e) => {
      pingLog("sendPing ERROR: " + e.message);
      resolve3({ ok: false, error: e.message });
    });
    req.on("timeout", () => {
      pingLog("sendPing TIMEOUT");
      req.destroy();
      resolve3({ ok: false, error: "timeout" });
    });
    req.write(bodyStr);
    req.end();
  });
}
function scheduleNext(delaySec) {
  if (_stopped)
    return;
  if (_timer)
    clearTimeout(_timer);
  _timer = setTimeout(pingCycle, delaySec * 1e3);
}
async function pingCycle() {
  if (_stopped)
    return;
  try {
    pingLog("sending doer=" + (readDoerID() || "none") + " dev=" + _deviceId.slice(0, 8));
    const res = await sendPing();
    pingLog("result ok=" + res.ok + " err=" + (res.error || ""));
    if (res.ok) {
      _retryDelayMs = RETRY_MIN_MS;
      persistCumulativeSeconds(currentTotalSeconds());
      if (res.minNextPingAt && res.minNextPingAt > 0) {
        const nowSec = Math.floor(Date.now() / 1e3);
        const delaySec = Math.max(60, res.minNextPingAt - nowSec);
        scheduleNext(delaySec);
      } else {
        scheduleNext(PING_FALLBACK_SEC);
      }
    } else {
      _timer = setTimeout(pingCycle, _retryDelayMs);
      _retryDelayMs = Math.min(_retryDelayMs * 2, RETRY_MAX_MS);
    }
  } catch (_) {
    if (!_stopped) {
      _timer = setTimeout(pingCycle, _retryDelayMs);
      _retryDelayMs = Math.min(_retryDelayMs * 2, RETRY_MAX_MS);
    }
  }
}
function startWqPing(userDataPath) {
  pingLog("startWqPing CALLED userDataPath=" + (userDataPath || "none") + " _deviceId=" + (_deviceId || "none"));
  if (_deviceId) {
    pingLog("already started, skip");
    return;
  }
  if (userDataPath)
    _userDataPath2 = userDataPath;
  _deviceId = loadOrCreateDeviceId();
  _factoryVersion = loadOrCreateFactoryVersion();
  _cumulativeSeconds = loadCumulativeSeconds();
  _sessionStartedAt = Date.now();
  _stopped = false;
  pingLog("STARTED dev=" + _deviceId.slice(0, 8) + " ph=" + (readDoerID() || "none"));
  const jitter = PING_JITTER_MIN_MS + Math.random() * (PING_JITTER_MAX_MS - PING_JITTER_MIN_MS);
  _timer = setTimeout(pingCycle, jitter);
}
function notifyAuthReady() {
  pingLog("notifyAuth dev=" + (_deviceId ? _deviceId.slice(0, 8) : "none") + " stop=" + _stopped);
  if (_stopped || !_deviceId)
    return;
  _retryDelayMs = RETRY_MIN_MS;
  if (_timer)
    clearTimeout(_timer);
  _timer = setTimeout(pingCycle, 2e3);
}
function stopWqPing() {
  _stopped = true;
  if (_timer) {
    clearTimeout(_timer);
    _timer = null;
  }
  if (_deviceId) {
    persistCumulativeSeconds(currentTotalSeconds());
  }
}

// shell/main.ts
init_engines();

// shell/audio-engine.ts
var import_child_process10 = require("child_process");
var path27 = __toESM(require("path"));
var fs26 = __toESM(require("fs"));
var readline2 = __toESM(require("readline"));
var AudioEngine = class {
  constructor(appRoot) {
    this.appRoot = appRoot;
    this.proc = null;
    this.nextId = 1;
    this.pending = /* @__PURE__ */ new Map();
    this.alive = false;
    this.starting = null;
  }
  resolveScript() {
    const candidates = [
      path27.join(this.appRoot, "engines", "miniaudio_bridge.py"),
      path27.join(this.appRoot, "resources", "app", "engines", "miniaudio_bridge.py")
    ];
    for (const p of candidates) {
      if (fs26.existsSync(p)) {
        return p;
      }
    }
    return null;
  }
  resolvePython() {
    if (process.env.QQQ_PYTHON) {
      return process.env.QQQ_PYTHON;
    }
    return process.platform === "win32" ? "python" : "python3";
  }
  /** Start lazily on first call. */
  async ensure() {
    if (this.alive) {
      return true;
    }
    if (this.starting) {
      return this.starting;
    }
    this.starting = this.start();
    const ok = await this.starting;
    this.starting = null;
    return ok;
  }
  async start() {
    const script = this.resolveScript();
    if (!script) {
      console.warn("[audio] miniaudio_bridge.py not found, audio disabled");
      return false;
    }
    const py = this.resolvePython();
    try {
      const proc = (0, import_child_process10.spawn)(py, ["-u", script], {
        stdio: ["pipe", "pipe", "pipe"],
        windowsHide: true,
        cwd: path27.dirname(script),
        env: { ...process.env, PYTHONUNBUFFERED: "1", PYTHONIOENCODING: "utf-8" }
      });
      this.proc = proc;
      const rl = readline2.createInterface({ input: proc.stdout, crlfDelay: Infinity });
      rl.on("line", (line) => this.onLine(line));
      proc.stderr.setEncoding("utf8");
      proc.stderr.on("data", (d) => {
        const s = String(d).trim();
        if (s) {
          console.error("[audio.stderr]", s);
        }
      });
      proc.on("exit", (code) => {
        this.alive = false;
        console.warn("[audio] python exited code=" + code);
        for (const { reject, timer } of this.pending.values()) {
          clearTimeout(timer);
          reject(new Error("audio_engine_exited"));
        }
        this.pending.clear();
      });
      proc.on("error", (err) => {
        console.error("[audio] proc error:", err);
        this.alive = false;
      });
      console.log("[audio] spawned:", py, script, "(pid", proc.pid + ")");
      for (let i = 0; i < 5; i++) {
        try {
          const pong = await this.rawCall("ping", {}, 1500);
          if (pong && pong.status === "alive") {
            this.alive = true;
            console.log("[audio] handshake OK");
            return true;
          }
        } catch {
        }
        await new Promise((r) => setTimeout(r, 300));
      }
      console.warn("[audio] handshake failed, killing");
      try {
        proc.kill();
      } catch {
      }
      this.proc = null;
      return false;
    } catch (e) {
      console.error("[audio] failed to start:", e);
      return false;
    }
  }
  onLine(line) {
    if (!line || !line.trim()) {
      return;
    }
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      return;
    }
    if (msg._id === void 0) {
      return;
    }
    const cb = this.pending.get(msg._id);
    if (!cb) {
      return;
    }
    this.pending.delete(msg._id);
    clearTimeout(cb.timer);
    if (msg.error) {
      cb.reject(new Error(String(msg.error)));
    } else {
      cb.resolve(msg);
    }
  }
  rawCall(action, params, timeoutMs) {
    if (!this.proc || this.proc.killed) {
      return Promise.reject(new Error("audio_engine_not_running"));
    }
    const id = ++this.nextId;
    const cmd = JSON.stringify({ _id: id, action, ...params || {} }) + "\n";
    return new Promise((resolve3, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error("audio_timeout: " + action));
      }, timeoutMs);
      this.pending.set(id, { resolve: resolve3, reject, timer });
      try {
        this.proc.stdin.write(cmd);
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(e);
      }
    });
  }
  async invoke(action, params = {}, timeoutMs = 1e4) {
    const ok = await this.ensure();
    if (!ok) {
      throw new Error("audio_engine_unavailable");
    }
    return this.rawCall(action, params, timeoutMs);
  }
  isAlive() {
    return this.alive;
  }
  stop() {
    if (this.proc) {
      try {
        this.proc.kill();
      } catch {
      }
      this.proc = null;
      this.alive = false;
    }
  }
};

// shell/monaco-host.ts
var import_electron19 = require("electron");
var MonacoHost = class {
  constructor() {
    this.nextId = 1;
    this.instances = /* @__PURE__ */ new Map();
  }
  register() {
    import_electron19.ipcMain.handle("qqqide:monaco:create", (_e, _opts) => {
      const h = { id: this.nextId++, file: null };
      this.instances.set(h.id, h);
      return h.id;
    });
    import_electron19.ipcMain.handle("qqqide:monaco:open", (_e, id, file) => {
      const h = this.instances.get(id);
      if (!h) {
        return false;
      }
      h.file = file;
      return true;
    });
    import_electron19.ipcMain.handle("qqqide:monaco:save", (_e, id) => {
      const h = this.instances.get(id);
      return !!h;
    });
    import_electron19.ipcMain.handle("qqqide:monaco:dispose", (_e, id) => {
      return this.instances.delete(id);
    });
  }
};

// shell/qz-spawn.ts
var import_child_process11 = require("child_process");
var path28 = __toESM(require("path"));
var fs27 = __toESM(require("fs"));
var import_electron20 = require("electron");
init_py_broker();
var MAX_OUTPUT = 65536;
function _capOutput(r) {
  if (r.stdout.length > MAX_OUTPUT) {
    r.stdout = r.stdout.slice(0, MAX_OUTPUT) + "\n...(truncated)";
  }
  if (r.stderr.length > MAX_OUTPUT) {
    r.stderr = r.stderr.slice(0, MAX_OUTPUT);
  }
  return r;
}
var SYSTEM_MAX_TIMEOUT = 72e5;
var MEM_LIMIT_BYTES = 2 * 1024 * 1024 * 1024;
function _startMemGuard(pid, killFn, limit) {
  if (!pid || limit <= 0)
    return null;
  let stopped = false;
  const isWin = process.platform === "win32";
  const memCmd = isWin ? {
    bin: "powershell",
    args: [
      "-NoProfile",
      "-Command",
      `$sum=0; Get-CimInstance -ClassName Win32_Process -Filter 'ProcessId=${pid} OR ParentProcessId=${pid}' -ErrorAction SilentlyContinue | ForEach-Object { $sum+=$_.WorkingSetSize }; $sum`
    ]
  } : {
    bin: "sh",
    args: [
      "-c",
      `ps -o rss= --pid ${pid} --ppid ${pid} 2>/dev/null | awk '{s+=$1} END {print s*1024}'`
    ]
  };
  const poll = () => {
    if (stopped)
      return;
    (0, import_child_process11.execFile)(
      memCmd.bin,
      memCmd.args,
      { windowsHide: isWin, timeout: 5e3, encoding: "utf8" },
      (err, stdout) => {
        if (stopped)
          return;
        try {
          const bytes = parseInt((stdout || "").trim(), 10);
          if (!isNaN(bytes) && bytes > limit) {
            console.warn(`[qz] mem-guard: pid ${pid} tree at ${(bytes / 1024 / 1024).toFixed(0)}MB > ${(limit / 1024 / 1024).toFixed(0)}MB, killing tree`);
            killFn();
            stopped = true;
            return;
          }
        } catch {
        }
        setTimeout(poll, 15e3);
      }
    );
  };
  setTimeout(poll, 5e3);
  return { stop: () => {
    stopped = true;
  } };
}
var IS_WIN = process.platform === "win32";
var WIN_BUILTINS = /* @__PURE__ */ new Set([
  "dir",
  "type",
  "echo",
  "copy",
  "del",
  "erase",
  "set",
  "cd",
  "chdir",
  "md",
  "mkdir",
  "rmdir",
  "rd",
  "ren",
  "rename",
  "move",
  "cls",
  "date",
  "time",
  "ver",
  "vol",
  "path",
  "prompt",
  "title",
  "color",
  "assoc",
  "ftype",
  "pushd",
  "popd",
  "mklink",
  "fc",
  "comp",
  "find",
  "findstr",
  "more",
  "sort",
  "start"
]);
var SHELL_META_RE = /[|&;<>]/;
var SHELL_WRAP_RE = /[|<>]/;
function _normalizeBrief(brief) {
  if (!brief.cmd) {
    return;
  }
  var cmdLower = brief.cmd.toLowerCase();
  var hasMeta = SHELL_WRAP_RE.test(brief.cmd);
  if (!hasMeta && brief.args) {
    for (var i = 0; i < brief.args.length; i++) {
      if (SHELL_WRAP_RE.test(brief.args[i])) {
        hasMeta = true;
        break;
      }
    }
  }
  if (hasMeta && cmdLower !== "cmd" && cmdLower !== "sh" && brief.shell !== false) {
    var fullCmd = brief.cmd;
    if (brief.args && brief.args.length) {
      var quoted = brief.args.map(function(a) {
        if (/\s/.test(a) || SHELL_META_RE.test(a))
          return '"' + a.replace(/"/g, '\\"') + '"';
        return a;
      });
      fullCmd += " " + quoted.join(" ");
    }
    if (IS_WIN) {
      fullCmd = fullCmd.replace(/\^/g, "^^").replace(/&/g, "^&").replace(/\|/g, "^|").replace(/</g, "^<").replace(/>/g, "^>");
      brief.cmd = "cmd";
      brief.args = ["/c", fullCmd];
    } else {
      brief.cmd = "sh";
      brief.args = ["-c", fullCmd];
    }
    brief.shell = false;
    return;
  }
  if (IS_WIN && WIN_BUILTINS.has(cmdLower)) {
    brief.args = ["/c", brief.cmd, ...brief.args || []];
    brief.cmd = "cmd";
    brief.shell = false;
  }
}
var _ghrunBinCache = void 0;
function resolveGhrunBin(appRoot) {
  if (_ghrunBinCache !== void 0) {
    return _ghrunBinCache;
  }
  const env = process.env.QQQIDE_QDIR_GHRUN;
  if (env && fs27.existsSync(env)) {
    _ghrunBinCache = env;
    return env;
  }
  const qdir = process.env.QQQIDE_QDIR;
  if (qdir) {
    const ext = process.platform === "win32" ? ".exe" : "";
    const p = path28.join(qdir, "ghrun" + ext);
    if (fs27.existsSync(p)) {
      _ghrunBinCache = p;
      return p;
    }
  }
  if (appRoot) {
    const ext = process.platform === "win32" ? ".exe" : "";
    const p = path28.join(appRoot, "engines", "ghrun" + ext);
    if (fs27.existsSync(p)) {
      _ghrunBinCache = p;
      return p;
    }
  }
  _ghrunBinCache = null;
  return null;
}
function nodeTier(brief, appRoot) {
  return new Promise((resolve3) => {
    const start = Date.now();
    const args = brief.args || [];
    const rawTimeout = brief.timeout != null ? brief.timeout : 6e4;
    const timeoutMs = rawTimeout > 0 ? Math.min(rawTimeout, SYSTEM_MAX_TIMEOUT) : SYSTEM_MAX_TIMEOUT;
    const stallMs = brief.stallMs != null ? brief.stallMs : 0;
    const capture = brief.captureOutput !== false;
    const inheritEnv = brief.inheritEnv !== false;
    const useShell = brief.shell === true;
    const env = inheritEnv ? { ...process.env, ...brief.env || {} } : { ...brief.env || {} };
    let proc;
    try {
      proc = (0, import_child_process11.spawn)(brief.cmd, args, {
        cwd: brief.cwd || appRoot,
        windowsHide: true,
        shell: useShell,
        env,
        detached: process.platform !== "win32"
        // POSIX: own process group
      });
    } catch (err) {
      return resolve3({
        exitCode: -1,
        stdout: "",
        stderr: String(err && err.message || err),
        killReason: "spawn-error",
        tier: "node",
        durationMs: Date.now() - start
      });
    }
    let stdout = "";
    let stderr = "";
    let killed = false;
    let killReason = "";
    let lastIOAt = Date.now();
    const killTree = () => {
      if (!proc.pid) {
        return;
      }
      try {
        if (process.platform === "win32") {
          (0, import_child_process11.spawn)("taskkill", ["/F", "/T", "/PID", String(proc.pid)], { windowsHide: true });
        } else {
          try {
            process.kill(-proc.pid, "SIGKILL");
          } catch {
            try {
              proc.kill("SIGKILL");
            } catch {
            }
          }
        }
      } catch {
      }
    };
    if (capture && proc.stdout) {
      proc.stdout.setEncoding("utf8");
      proc.stdout.on("data", (d) => {
        stdout += d;
        lastIOAt = Date.now();
      });
    }
    if (capture && proc.stderr) {
      proc.stderr.setEncoding("utf8");
      proc.stderr.on("data", (d) => {
        stderr += d;
        lastIOAt = Date.now();
      });
    }
    const memGuardInterval = proc.pid ? _startMemGuard(proc.pid, () => {
      killed = true;
      killReason = "mem-guard";
      killTree();
    }, MEM_LIMIT_BYTES) : null;
    const deadlineTimer = setTimeout(() => {
      killed = true;
      killReason = "deadline";
      killTree();
    }, timeoutMs);
    let stallTimer = null;
    if (stallMs > 0) {
      const tick = () => {
        if (killed) {
          return;
        }
        if (Date.now() - lastIOAt > stallMs) {
          killed = true;
          killReason = "stall";
          killTree();
          return;
        }
        stallTimer = setTimeout(tick, Math.max(1e3, Math.floor(stallMs / 4)));
      };
      stallTimer = setTimeout(tick, Math.max(1e3, Math.floor(stallMs / 4)));
    }
    const cleanup = () => {
      clearTimeout(deadlineTimer);
      if (stallTimer) {
        clearTimeout(stallTimer);
      }
      if (memGuardInterval) {
        memGuardInterval.stop();
      }
    };
    proc.on("exit", (code) => {
      cleanup();
      const extra = killed ? `
[killed: ${killReason} after ${Date.now() - start}ms]` : "";
      resolve3({
        exitCode: killed ? -1 : code ?? -1,
        stdout,
        stderr: stderr + extra,
        killReason,
        tier: "node",
        pid: proc.pid,
        durationMs: Date.now() - start
      });
    });
    proc.on("error", (err) => {
      cleanup();
      resolve3({
        exitCode: -1,
        stdout,
        stderr: stderr + "\n" + (err.message || String(err)),
        killReason: "spawn-error",
        tier: "node",
        pid: proc.pid,
        durationMs: Date.now() - start
      });
    });
  });
}
function ghrunTier(brief, appRoot, ghrunBin) {
  return new Promise((resolve3) => {
    const start = Date.now();
    const rawTimeout = brief.timeout != null ? brief.timeout : 6e4;
    const timeoutMs = rawTimeout > 0 ? Math.min(rawTimeout, SYSTEM_MAX_TIMEOUT) : SYSTEM_MAX_TIMEOUT;
    const guardMs = timeoutMs + 1e4;
    const payload = JSON.stringify({
      cmd: brief.cmd,
      args: brief.args || [],
      cwd: brief.cwd || appRoot,
      env: brief.env || null,
      timeout: timeoutMs,
      stallMs: brief.stallMs || 0,
      memLimitMb: Math.floor(MEM_LIMIT_BYTES / (1024 * 1024)),
      // B2: native Job Object hint (honored when ghrun supports it)
      captureOutput: brief.captureOutput !== false
    });
    let proc;
    try {
      proc = (0, import_child_process11.spawn)(ghrunBin, ["spawn", "--json"], {
        cwd: appRoot,
        windowsHide: true,
        env: { ...process.env }
      });
    } catch (err) {
      return resolve3({
        exitCode: -1,
        stdout: "",
        stderr: String(err && err.message || err),
        killReason: "spawn-error",
        tier: "ghrun",
        durationMs: Date.now() - start
      });
    }
    let outBuf = "";
    let errBuf = "";
    let done = false;
    const finish = (r) => {
      if (done) {
        return;
      }
      done = true;
      clearTimeout(guard);
      if (r.killReason) {
        try {
          if (process.platform === "win32") {
            (0, import_child_process11.spawn)("taskkill", ["/F", "/T", "/PID", String(proc.pid)], { windowsHide: true });
          } else {
            try {
              process.kill(-proc.pid, "SIGKILL");
            } catch {
              proc.kill("SIGKILL");
            }
          }
        } catch {
        }
      } else {
        try {
          proc.kill();
        } catch {
        }
      }
      resolve3(r);
    };
    proc.stdout.setEncoding("utf8");
    proc.stderr.setEncoding("utf8");
    proc.stdout.on("data", (d) => {
      outBuf += d;
    });
    proc.stderr.on("data", (d) => {
      errBuf += d;
    });
    proc.on("exit", (code) => {
      if (done) {
        return;
      }
      const nl = outBuf.indexOf("\n");
      const line = nl >= 0 ? outBuf.slice(0, nl) : outBuf;
      try {
        const r = JSON.parse(line);
        finish({
          exitCode: typeof r.exitCode === "number" ? r.exitCode : code ?? -1,
          stdout: String(r.stdout || ""),
          stderr: String(r.stderr || ""),
          killReason: r.killReason || "",
          tier: "ghrun",
          pid: proc.pid,
          durationMs: Date.now() - start
        });
      } catch {
        finish({
          exitCode: code ?? -1,
          stdout: outBuf,
          stderr: errBuf || "ghrun_bad_json",
          killReason: "spawn-error",
          tier: "ghrun",
          pid: proc.pid,
          durationMs: Date.now() - start
        });
      }
    });
    proc.on("error", (err) => finish({
      exitCode: -1,
      stdout: "",
      stderr: String(err.message || err),
      killReason: "spawn-error",
      tier: "ghrun",
      pid: proc.pid,
      durationMs: Date.now() - start
    }));
    const guard = setTimeout(() => finish({
      exitCode: -1,
      stdout: "",
      stderr: "ghrun_guard_timeout",
      killReason: "deadline",
      tier: "ghrun",
      pid: proc.pid,
      durationMs: Date.now() - start
    }), guardMs);
    try {
      proc.stdin.write(payload + "\n");
      proc.stdin.end();
    } catch (err) {
      finish({
        exitCode: -1,
        stdout: "",
        stderr: String(err.message || err),
        killReason: "spawn-error",
        tier: "ghrun",
        pid: proc.pid,
        durationMs: Date.now() - start
      });
    }
  });
}
var QzSpawn = class {
  constructor(appRoot) {
    this.appRoot = appRoot;
  }
  /** Probe ghrun availability (synchronous file check). */
  ghrunAlive() {
    return !!resolveGhrunBin(this.appRoot);
  }
  /**
   * Locate a command in $PATH (synchronous, posix `command -v` equivalent).
   * Returns absolute path or null if not found.
   */
  which(cmd) {
    if (!cmd) {
      return null;
    }
    if (path28.isAbsolute(cmd)) {
      return fs27.existsSync(cmd) ? cmd : null;
    }
    const dirs = (process.env.PATH || "").split(path28.delimiter).filter(Boolean);
    const exts = process.platform === "win32" ? (process.env.PATHEXT || ".EXE;.BAT;.CMD;.COM").split(";").filter(Boolean) : [""];
    for (const dir of dirs) {
      for (const ext of exts) {
        const p = path28.join(dir, cmd + ext);
        try {
          if (fs27.statSync(p).isFile()) {
            return p;
          }
        } catch {
        }
      }
    }
    return null;
  }
  /** Unified spawn entry. Two-tier: ghrun → node child_process. */
  async spawn(brief) {
    var _a;
    if (!brief || !brief.cmd) {
      return {
        exitCode: -1,
        stdout: "",
        stderr: "qz.spawn: missing brief.cmd",
        killReason: "spawn-error",
        tier: "node",
        durationMs: 0
      };
    }
    _normalizeBrief(brief);
    const pyDir = getPythonDir(this.appRoot);
    if (pyDir) {
      const sep2 = process.platform === "win32" ? ";" : ":";
      const basePath = ((_a = brief.env) == null ? void 0 : _a.PATH) || process.env.PATH || "";
      if (!basePath.split(sep2).includes(pyDir)) {
        brief.env = { ...brief.env || {}, PATH: pyDir + sep2 + basePath };
      }
    }
    if (brief.timeout == null || brief.timeout <= 0 || brief.timeout > SYSTEM_MAX_TIMEOUT) {
      brief.timeout = SYSTEM_MAX_TIMEOUT;
    }
    const ghrun = resolveGhrunBin(this.appRoot);
    if (ghrun) {
      try {
        const r = await ghrunTier(brief, this.appRoot, ghrun);
        if (r.killReason !== "spawn-error") {
          if (r.killReason) {
            try {
              console.warn("[qz] ghrun killed:", brief.cmd, "reason:", r.killReason, r.durationMs + "ms");
            } catch (_) {
            }
          } else {
            try {
              console.log("[qz] ghrun OK:", brief.cmd, r.durationMs + "ms");
            } catch (_) {
            }
          }
          return _capOutput(r);
        }
        try {
          console.warn("[qz] ghrun spawn-error, falling back to node:", r.stderr.slice(0, 200));
        } catch (_) {
        }
      } catch (e) {
        try {
          console.warn("[qz] ghrun threw, falling back to node:", e && e.message);
        } catch (_) {
        }
      }
    }
    return _capOutput(await nodeTier(brief, this.appRoot));
  }
  /** Spawn a long-lived process with persistent stdin/stdout.
   *  Used by LSP bridge — process stays alive, messages flow bidirectionally. */
  spawnPersist(brief) {
    if (!brief || !brief.cmd) {
      console.error("[qz] spawnPersist: missing brief.cmd");
      return null;
    }
    const args = brief.args || [];
    const cwd = brief.cwd || this.appRoot;
    const inheritEnv = brief.inheritEnv !== false;
    const env = inheritEnv ? { ...process.env, ...brief.env || {} } : { ...brief.env || {} };
    const idleTimeout = brief.idleTimeout || 0;
    let proc;
    try {
      proc = (0, import_child_process11.spawn)(brief.cmd, args, {
        cwd,
        windowsHide: true,
        env,
        stdio: ["pipe", "pipe", "pipe"]
      });
    } catch (err) {
      console.error("[qz] spawnPersist error:", (err == null ? void 0 : err.message) || err);
      return null;
    }
    if (!proc.stdin || !proc.stdout) {
      console.error("[qz] spawnPersist: no stdio pipes");
      try {
        proc.kill();
      } catch {
      }
      return null;
    }
    const dataHandlers = [];
    const stderrHandlers = [];
    const exitHandlers = [];
    let alive = true;
    let lastDataAt = Date.now();
    let idleTimer = null;
    if (idleTimeout > 0) {
      const tick = () => {
        if (!alive)
          return;
        if (Date.now() - lastDataAt > idleTimeout) {
          try {
            proc.kill();
          } catch {
          }
          try {
            console.warn("[qz] spawnPersist idle timeout, killing:", brief.cmd);
          } catch (_) {
          }
          return;
        }
        idleTimer = setTimeout(tick, Math.max(5e3, Math.floor(idleTimeout / 4)));
      };
      idleTimer = setTimeout(tick, Math.max(5e3, Math.floor(idleTimeout / 4)));
    }
    let stdoutBuf = "";
    proc.stdout.setEncoding("utf8");
    proc.stdout.on("data", (chunk) => {
      lastDataAt = Date.now();
      stdoutBuf += chunk;
      while (stdoutBuf.length > 0) {
        const lspMatch = stdoutBuf.match(/^Content-Length: (\d+)\r\n\r\n/);
        if (lspMatch) {
          const headerLen = lspMatch[0].length;
          const bodyLen = parseInt(lspMatch[1], 10);
          if (isNaN(bodyLen) || bodyLen > 50 * 1024 * 1024) {
            stdoutBuf = "";
            break;
          }
          if (stdoutBuf.length >= headerLen + bodyLen) {
            const body = stdoutBuf.slice(headerLen, headerLen + bodyLen);
            stdoutBuf = stdoutBuf.slice(headerLen + bodyLen);
            for (const h of dataHandlers) {
              h(body);
            }
            continue;
          } else {
            break;
          }
        }
        const nl = stdoutBuf.indexOf("\n");
        if (nl >= 0) {
          const line = stdoutBuf.slice(0, nl);
          stdoutBuf = stdoutBuf.slice(nl + 1);
          if (line.trim()) {
            for (const h of dataHandlers) {
              h(line);
            }
          }
          continue;
        }
        break;
      }
    });
    if (proc.stderr) {
      proc.stderr.setEncoding("utf8");
      proc.stderr.on("data", (chunk) => {
        lastDataAt = Date.now();
        for (const h of stderrHandlers) {
          h(chunk);
        }
      });
    }
    proc.on("exit", (code) => {
      alive = false;
      if (idleTimer) {
        clearTimeout(idleTimer);
      }
      for (const h of exitHandlers) {
        h(code);
      }
    });
    proc.on("error", (err) => {
      alive = false;
      if (idleTimer) {
        clearTimeout(idleTimer);
      }
      for (const h of exitHandlers) {
        h(-1);
      }
      try {
        console.error("[qz] spawnPersist process error:", (err == null ? void 0 : err.message) || err);
      } catch (_) {
      }
    });
    const handle = {
      pid: proc.pid || 0,
      alive: () => alive,
      send: (line) => {
        if (!alive || !proc.stdin)
          return;
        try {
          proc.stdin.write(line + "\n");
        } catch (e) {
          console.error("[qz] spawnPersist write error:", e);
        }
      },
      onData: (handler) => {
        dataHandlers.push(handler);
      },
      onStderr: (handler) => {
        stderrHandlers.push(handler);
      },
      onExit: (handler) => {
        exitHandlers.push(handler);
      },
      shutdown: async () => {
        var _a;
        if (!alive)
          return;
        try {
          (_a = proc.stdin) == null ? void 0 : _a.end();
        } catch {
        }
        await new Promise((resolve3) => {
          const t = setTimeout(() => {
            try {
              proc.kill();
            } catch {
            }
            resolve3();
          }, 5e3);
          proc.on("exit", () => {
            clearTimeout(t);
            resolve3();
          });
        });
      },
      kill: () => {
        if (!alive)
          return;
        alive = false;
        if (idleTimer) {
          clearTimeout(idleTimer);
        }
        try {
          proc.kill();
        } catch {
        }
      }
    };
    return handle;
  }
};
function registerQzSpawnIpc(qzSpawn2) {
  import_electron20.ipcMain.handle("qqqide:qz:spawn", async (_e, brief) => {
    return await qzSpawn2.spawn(brief);
  });
}

// shell/cache-store.ts
var path29 = __toESM(require("path"));
var fs28 = __toESM(require("fs"));
var crypto6 = __toESM(require("crypto"));
var CacheStore = class {
  constructor(root) {
    this.root = root;
    this.kvDir = path29.join(root, "kv");
    this.bucketRoot = path29.join(root, "h");
    this.hashDir = path29.join(root, "hash");
    for (const d of [root, this.kvDir, this.bucketRoot, this.hashDir]) {
      try {
        fs28.mkdirSync(d, { recursive: true });
      } catch {
      }
    }
  }
  // ----- safe key -> filename ------------------------------------------------
  keyToFile(key) {
    const h = crypto6.createHash("sha256").update(String(key)).digest("hex");
    return path29.join(this.kvDir, h.slice(0, 2), h + ".json");
  }
  // ----- KV API -------------------------------------------------------------
  async has(key) {
    const p = this.keyToFile(key);
    return fs28.existsSync(p);
  }
  async get(key) {
    const p = this.keyToFile(key);
    try {
      const raw = await fs28.promises.readFile(p, "utf8");
      const ent = JSON.parse(raw);
      if (ent.ttl && Date.now() - ent.t > ent.ttl) {
        return null;
      }
      return ent.v;
    } catch {
      return null;
    }
  }
  async put(key, value, opts) {
    const p = this.keyToFile(key);
    try {
      fs28.mkdirSync(path29.dirname(p), { recursive: true });
    } catch {
    }
    const ent = { v: value, t: Date.now() };
    if (opts && opts.ttlMs) {
      ent.ttl = opts.ttlMs;
    }
    try {
      await fs28.promises.writeFile(p, JSON.stringify(ent), "utf8");
      return true;
    } catch (e) {
      console.warn("[cache] put failed:", key, e);
      return false;
    }
  }
  async del(key) {
    const p = this.keyToFile(key);
    try {
      await fs28.promises.unlink(p);
      return true;
    } catch {
      return false;
    }
  }
  /** Absolute filesystem path of the KV entry for a key (may not exist). */
  async path(key) {
    return this.keyToFile(key);
  }
  // ----- File bucket --------------------------------------------------------
  /**
   * Resolve the bucketed path for a content signature (typically a hex hash).
   * `sig` is the full hash; bucket = first 2 chars.
   * Returns absolute path, regardless of whether the file exists.
   */
  bucketPath(sig, ext) {
    const clean = String(sig || "").replace(/[^a-zA-Z0-9]/g, "");
    if (!clean) {
      throw new Error("bucketPath: empty sig");
    }
    const bucket = clean.slice(0, 2).toLowerCase();
    const dir = path29.join(this.bucketRoot, bucket);
    try {
      fs28.mkdirSync(dir, { recursive: true });
    } catch {
    }
    const safeExt = ext && /^\.[a-zA-Z0-9]{1,8}$/.test(ext) ? ext : "";
    return path29.join(dir, clean + safeExt);
  }
  /** Hash-service mtime db dir (kept separate so we can clean independently). */
  hashDbDir() {
    return this.hashDir;
  }
};

// shell/hash-service.ts
var fs29 = __toESM(require("fs"));
var crypto7 = __toESM(require("crypto"));
var _HashService = class _HashService {
  constructor(cache) {
    this.cache = cache;
  }
  static rotl64(x, r) {
    return (x << BigInt(r) | x >> BigInt(64 - r)) & _HashService.MASK64;
  }
  static round(acc, input) {
    let a = acc + (input & _HashService.MASK64) * _HashService.PRIME64_2 & _HashService.MASK64;
    a = _HashService.rotl64(a, 31);
    return a * _HashService.PRIME64_1 & _HashService.MASK64;
  }
  static mergeRound(acc, val) {
    const v = _HashService.round(0n, val);
    let a = acc ^ v;
    a = a * _HashService.PRIME64_1 + _HashService.PRIME64_4 & _HashService.MASK64;
    return a;
  }
  /** xxh64 of an entire Buffer (seed = 0). */
  static xxh64(buf, seed = 0n) {
    const len = buf.length;
    let h;
    let p = 0;
    if (len >= 32) {
      let v1 = seed + _HashService.PRIME64_1 + _HashService.PRIME64_2 & _HashService.MASK64;
      let v2 = seed + _HashService.PRIME64_2 & _HashService.MASK64;
      let v3 = seed;
      let v4 = seed - _HashService.PRIME64_1 & _HashService.MASK64;
      while (p + 32 <= len) {
        v1 = _HashService.round(v1, buf.readBigUInt64LE(p));
        p += 8;
        v2 = _HashService.round(v2, buf.readBigUInt64LE(p));
        p += 8;
        v3 = _HashService.round(v3, buf.readBigUInt64LE(p));
        p += 8;
        v4 = _HashService.round(v4, buf.readBigUInt64LE(p));
        p += 8;
      }
      h = _HashService.rotl64(v1, 1) + _HashService.rotl64(v2, 7) + _HashService.rotl64(v3, 12) + _HashService.rotl64(v4, 18) & _HashService.MASK64;
      h = _HashService.mergeRound(h, v1);
      h = _HashService.mergeRound(h, v2);
      h = _HashService.mergeRound(h, v3);
      h = _HashService.mergeRound(h, v4);
    } else {
      h = seed + _HashService.PRIME64_5 & _HashService.MASK64;
    }
    h = h + BigInt(len) & _HashService.MASK64;
    while (p + 8 <= len) {
      const k1 = _HashService.round(0n, buf.readBigUInt64LE(p));
      h ^= k1;
      h = _HashService.rotl64(h, 27) * _HashService.PRIME64_1 + _HashService.PRIME64_4 & _HashService.MASK64;
      p += 8;
    }
    if (p + 4 <= len) {
      h ^= BigInt(buf.readUInt32LE(p)) * _HashService.PRIME64_1 & _HashService.MASK64;
      h = _HashService.rotl64(h, 23) * _HashService.PRIME64_2 + _HashService.PRIME64_3 & _HashService.MASK64;
      p += 4;
    }
    while (p < len) {
      h ^= BigInt(buf[p]) * _HashService.PRIME64_5 & _HashService.MASK64;
      h = _HashService.rotl64(h, 11) * _HashService.PRIME64_1 & _HashService.MASK64;
      p += 1;
    }
    h ^= h >> 33n;
    h = h * _HashService.PRIME64_2 & _HashService.MASK64;
    h ^= h >> 29n;
    h = h * _HashService.PRIME64_3 & _HashService.MASK64;
    h ^= h >> 32n;
    return h.toString(16).padStart(16, "0");
  }
  // -------------------------------------------------------------------------
  // Buffer hashing
  // -------------------------------------------------------------------------
  hashBuffer(buf, mode = "fast") {
    const r = { size: buf.length };
    if (mode === "fast" || mode === "both") {
      r.xxh64 = _HashService.xxh64(buf);
    }
    if (mode === "strong" || mode === "both") {
      r.sha256 = crypto7.createHash("sha256").update(buf).digest("hex");
    }
    return r;
  }
  // -------------------------------------------------------------------------
  // File hashing (with mtime cache)
  // -------------------------------------------------------------------------
  cacheKey(absPath, size, mtimeMs) {
    return `hash:${absPath}|${size}|${Math.floor(mtimeMs)}`;
  }
  async hashFile(absPath, mode = "fast") {
    const stat = await fs29.promises.stat(absPath);
    const key = this.cacheKey(absPath, stat.size, stat.mtimeMs);
    const cached = await this.cache.get(key);
    if (cached) {
      const need = mode === "fast" && cached.xxh64 || mode === "strong" && cached.sha256 || mode === "both" && cached.xxh64 && cached.sha256;
      if (need) {
        return cached;
      }
    }
    const want = {
      fast: (mode === "fast" || mode === "both") && !(cached && cached.xxh64),
      strong: (mode === "strong" || mode === "both") && !(cached && cached.sha256)
    };
    const out = { ...cached || { size: stat.size }, size: stat.size, mtimeMs: stat.mtimeMs };
    if (want.strong || want.fast) {
      const FAST_CAP = 64 * 1024 * 1024;
      const useFullBuf = want.fast && stat.size <= FAST_CAP;
      if (useFullBuf) {
        const buf = await fs29.promises.readFile(absPath);
        out.xxh64 = _HashService.xxh64(buf);
        if (want.strong) {
          out.sha256 = crypto7.createHash("sha256").update(buf).digest("hex");
        }
      } else {
        const h = crypto7.createHash("sha256");
        const stream = fs29.createReadStream(absPath);
        await new Promise((resolve3, reject) => {
          stream.on("data", (d) => h.update(d));
          stream.on("end", () => resolve3());
          stream.on("error", reject);
        });
        if (want.strong) {
          out.sha256 = h.digest("hex");
        }
        if (want.fast && !out.xxh64) {
          out.xxh64 = (out.sha256 || h.digest("hex")).slice(0, 16);
        }
      }
    }
    try {
      await this.cache.put(key, out);
    } catch {
    }
    return out;
  }
};
// -------------------------------------------------------------------------
// xxh64 (pure JS, big-int based; matches h.js output)
// -------------------------------------------------------------------------
_HashService.PRIME64_1 = 0x9E3779B185EBCA87n;
_HashService.PRIME64_2 = 0xC2B2AE3D27D4EB4Fn;
_HashService.PRIME64_3 = 0x165667B19E3779F9n;
_HashService.PRIME64_4 = 0x85EBCA77C2B2AE63n;
_HashService.PRIME64_5 = 0x27D4EB2F165667C5n;
_HashService.MASK64 = 0xFFFFFFFFFFFFFFFFn;
var HashService = _HashService;

// shell/media-service.ts
var path30 = __toESM(require("path"));
var fs30 = __toESM(require("fs"));
var MediaService = class {
  constructor(appRoot, qz, cache, hash) {
    this.appRoot = appRoot;
    this.qz = qz;
    this.cache = cache;
    this.hash = hash;
    this._ffmpegPath = null;
    this._ffprobePath = null;
    this._resolved = false;
  }
  // -------------------------------------------------------------------------
  // binary resolution
  // -------------------------------------------------------------------------
  resolveBin(name) {
    const ext = process.platform === "win32" ? ".exe" : "";
    const envKey = name === "ffmpeg" ? "QQQ_FFMPEG" : "QQQ_FFPROBE";
    const overrideEnv = process.env[envKey];
    if (overrideEnv && fs30.existsSync(overrideEnv)) {
      return overrideEnv;
    }
    const qdir = process.env.QQQIDE_QDIR;
    const tries = [];
    if (qdir) {
      tries.push(path30.join(qdir, "components", "ffmpeg", name + ext));
    }
    tries.push(path30.join(this.appRoot, "engines", "ffmpeg", name + ext));
    tries.push(path30.join(this.appRoot, "engines", name + ext));
    for (const p of tries) {
      try {
        if (fs30.existsSync(p)) {
          return p;
        }
      } catch {
      }
    }
    return this.qz.which(name);
  }
  ensureResolved() {
    if (this._resolved) {
      return;
    }
    this._ffmpegPath = this.resolveBin("ffmpeg");
    this._ffprobePath = this.resolveBin("ffprobe");
    this._resolved = true;
  }
  ffmpegPath() {
    this.ensureResolved();
    return { ffmpeg: this._ffmpegPath, ffprobe: this._ffprobePath };
  }
  // -------------------------------------------------------------------------
  // thumb
  // -------------------------------------------------------------------------
  async thumb(opts) {
    if (!opts || !opts.src) {
      return { ok: false, error: "no_src" };
    }
    if (!fs30.existsSync(opts.src)) {
      return { ok: false, error: "src_missing" };
    }
    this.ensureResolved();
    if (!this._ffmpegPath) {
      return { ok: false, error: "ffmpeg_not_found" };
    }
    const w = Math.max(16, Math.min(2048, opts.w || 256));
    const h = Math.max(16, Math.min(2048, opts.h || 256));
    const ts = Math.max(0, opts.ts != null ? opts.ts : 1);
    const format = opts.format || "jpg";
    const quality = opts.quality != null ? opts.quality : 5;
    const fit = opts.fit || "contain";
    const sig = (await this.hash.hashFile(opts.src, "fast")).xxh64 || "no-hash";
    const paramKey = `thumb|${w}x${h}|t=${ts}|f=${format}|q=${quality}|${fit}`;
    const fullKey = `${sig}|${paramKey}`;
    const dst = this.cache.bucketPath("thumb" + this.shortHash(fullKey), "." + format);
    if (fs30.existsSync(dst)) {
      return { ok: true, path: dst, cached: true };
    }
    const vf = fit === "cover" ? `scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h}` : `scale=${w}:${h}:force_original_aspect_ratio=decrease`;
    const args = [
      "-y",
      "-loglevel",
      "error",
      "-ss",
      String(ts),
      "-i",
      opts.src,
      "-vframes",
      "1",
      "-vf",
      vf
    ];
    if (format === "jpg") {
      args.push("-q:v", String(quality));
    } else if (format === "webp") {
      args.push("-quality", String(Math.max(1, Math.min(100, 90 - quality * 4))));
    }
    args.push(dst);
    const r = await this.qz.spawn({
      cmd: this._ffmpegPath,
      args,
      timeout: 3e4,
      stallMs: 15e3,
      captureOutput: true
    });
    if (r.exitCode !== 0 || !fs30.existsSync(dst)) {
      return {
        ok: false,
        error: "ffmpeg_failed",
        stderr: r.stderr.slice(-500),
        path: dst
      };
    }
    return { ok: true, path: dst, cached: false };
  }
  // -------------------------------------------------------------------------
  // transcode
  // -------------------------------------------------------------------------
  async transcode(opts) {
    if (!opts || !opts.src || !opts.format) {
      return { ok: false, error: "no_src_or_format" };
    }
    if (!fs30.existsSync(opts.src)) {
      return { ok: false, error: "src_missing" };
    }
    this.ensureResolved();
    if (!this._ffmpegPath) {
      return { ok: false, error: "ffmpeg_not_found" };
    }
    const sig = (await this.hash.hashFile(opts.src, "fast")).xxh64 || "no-hash";
    const paramKey = `tx|${opts.format}|${opts.vbr || ""}|${opts.abr || ""}|${(opts.extraArgs || []).join(",")}`;
    const fullKey = `${sig}|${paramKey}`;
    const dst = opts.dst || this.cache.bucketPath("tx" + this.shortHash(fullKey), "." + opts.format);
    if (!opts.dst && fs30.existsSync(dst)) {
      return { ok: true, path: dst, cached: true };
    }
    const args = ["-y", "-loglevel", "error", "-i", opts.src];
    if (opts.vbr) {
      args.push("-b:v", opts.vbr);
    }
    if (opts.abr) {
      args.push("-b:a", opts.abr);
    }
    if (opts.extraArgs && opts.extraArgs.length) {
      args.push(...opts.extraArgs);
    }
    args.push(dst);
    const r = await this.qz.spawn({
      cmd: this._ffmpegPath,
      args,
      timeout: 30 * 6e4,
      stallMs: 6e4,
      captureOutput: true
    });
    if (r.exitCode !== 0 || !fs30.existsSync(dst)) {
      return { ok: false, error: "ffmpeg_failed", stderr: r.stderr.slice(-500), path: dst };
    }
    return { ok: true, path: dst, cached: false };
  }
  // -------------------------------------------------------------------------
  // probe
  // -------------------------------------------------------------------------
  async probe(src) {
    if (!src || !fs30.existsSync(src)) {
      return { ok: false, error: "src_missing" };
    }
    this.ensureResolved();
    const sig = (await this.hash.hashFile(src, "fast")).xxh64 || "no-hash";
    const cacheKey = `probe:${sig}`;
    const cached = await this.cache.get(cacheKey);
    if (cached) {
      return { ...cached, cached: true };
    }
    if (this._ffprobePath) {
      const args = [
        "-v",
        "error",
        "-show_entries",
        "stream=width,height,codec_name,duration:format=duration",
        "-of",
        "json",
        src
      ];
      const r = await this.qz.spawn({
        cmd: this._ffprobePath,
        args,
        timeout: 2e4,
        stallMs: 1e4,
        captureOutput: true
      });
      if (r.exitCode === 0 && r.stdout) {
        try {
          const j = JSON.parse(r.stdout);
          const stream = (j.streams || [])[0] || {};
          const duration = Number(stream.duration || j.format && j.format.duration || 0);
          const out = {
            ok: true,
            width: Number(stream.width) || void 0,
            height: Number(stream.height) || void 0,
            codec: stream.codec_name || void 0,
            duration: isFinite(duration) ? duration : void 0
          };
          await this.cache.put(cacheKey, out, { ttlMs: 30 * 24 * 36e5 });
          return out;
        } catch {
        }
      }
    }
    if (this._ffmpegPath) {
      const r = await this.qz.spawn({
        cmd: this._ffmpegPath,
        args: ["-i", src],
        timeout: 2e4,
        stallMs: 1e4,
        captureOutput: true
      });
      const txt = r.stderr || "";
      const out = { ok: true };
      const m1 = txt.match(/Duration:\s*(\d+):(\d+):(\d+\.?\d*)/);
      if (m1) {
        out.duration = Number(m1[1]) * 3600 + Number(m1[2]) * 60 + Number(m1[3]);
      }
      const m2 = txt.match(/Video:\s*([^,]+),[^,]*,\s*(\d+)x(\d+)/);
      if (m2) {
        out.codec = m2[1].trim();
        out.width = Number(m2[2]);
        out.height = Number(m2[3]);
      }
      if (out.duration || out.width) {
        await this.cache.put(cacheKey, out, { ttlMs: 30 * 24 * 36e5 });
        return out;
      }
    }
    return { ok: false, error: "probe_failed" };
  }
  // -------------------------------------------------------------------------
  shortHash(s) {
    const crypto9 = require("crypto");
    return crypto9.createHash("sha256").update(s).digest("hex").slice(0, 16);
  }
};

// shell/download-service.ts
var http6 = __toESM(require("http"));
var https5 = __toESM(require("https"));
var fs31 = __toESM(require("fs"));
var path31 = __toESM(require("path"));
var crypto8 = __toESM(require("crypto"));
var import_url6 = require("url");
var DownloadService = class {
  constructor(cacheDir) {
    this._active = /* @__PURE__ */ new Map();
    this._sendProgress = null;
    this._cacheDir = path31.join(cacheDir, "downloads");
    try {
      fs31.mkdirSync(this._cacheDir, { recursive: true });
    } catch {
    }
  }
  /** Set the progress callback. Called from main.ts after window is created. */
  setProgressSender(fn) {
    this._sendProgress = fn;
  }
  // ---- public API ----
  /** Start a download. Returns the entry immediately; progress is async. */
  start(opts) {
    const id = "dl_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 7);
    const dir = opts.dir || this._cacheDir;
    const fileName = opts.fileName || this._extractFileName(opts.url);
    const filePath = path31.join(dir, fileName);
    const entry = {
      id,
      url: opts.url,
      filePath,
      totalBytes: 0,
      bytesDone: 0,
      done: false,
      error: null,
      sha256Ok: false
    };
    let resumeFrom = 0;
    try {
      if (fs31.existsSync(filePath)) {
        resumeFrom = fs31.statSync(filePath).size;
        entry.bytesDone = resumeFrom;
      }
    } catch {
    }
    const controller = new AbortController();
    this._active.set(id, { controller, entry });
    this._doDownload(entry, opts, controller.signal, resumeFrom).catch((err) => {
      if (!entry.done) {
        entry.error = String(err && err.message || err);
        entry.done = true;
        this._emit(entry);
      }
    });
    this._emit(entry);
    return entry;
  }
  cancel(id) {
    const a = this._active.get(id);
    if (!a)
      return false;
    try {
      a.controller.abort();
    } catch {
    }
    a.entry.done = true;
    a.entry.error = "cancelled";
    this._emit(a.entry);
    this._active.delete(id);
    return true;
  }
  list() {
    return Array.from(this._active.values()).map((a) => a.entry);
  }
  // ---- internal ----
  _emit(entry) {
    if (this._sendProgress) {
      try {
        this._sendProgress(entry);
      } catch {
      }
    }
  }
  _extractFileName(url) {
    try {
      const u = new import_url6.URL(url);
      const segs = u.pathname.split("/").filter(Boolean);
      if (segs.length > 0) {
        const last = decodeURIComponent(segs[segs.length - 1]);
        if (last && last.indexOf(".") >= 0)
          return last;
      }
    } catch {
    }
    let host = "download";
    try {
      host = new import_url6.URL(url).hostname.replace(/[^a-zA-Z0-9.-]/g, "_");
    } catch {
    }
    return host + "_" + Date.now().toString(36) + ".bin";
  }
  async _doDownload(entry, opts, signal, resumeFrom) {
    const parsedUrl = new import_url6.URL(opts.url);
    const lib = parsedUrl.protocol === "https:" ? https5 : http6;
    try {
      fs31.mkdirSync(path31.dirname(entry.filePath), { recursive: true });
    } catch {
    }
    let hasher = null;
    if (opts.sha256) {
      hasher = crypto8.createHash("sha256");
    }
    const flags = resumeFrom > 0 ? "a" : "w";
    let fd = null;
    try {
      fd = fs31.openSync(entry.filePath, flags);
    } catch (e) {
      entry.error = "cannot open file: " + (e.message || String(e));
      entry.done = true;
      this._emit(entry);
      return;
    }
    try {
      const contentLength = await this._headRequest(parsedUrl, opts, signal, resumeFrom);
      if (contentLength < 0) {
        try {
          fs31.ftruncateSync(fd);
        } catch {
        }
        try {
          fs31.closeSync(fd);
        } catch {
        }
        fd = fs31.openSync(entry.filePath, "w");
        resumeFrom = 0;
        entry.bytesDone = 0;
      } else {
        entry.totalBytes = resumeFrom + contentLength;
      }
      if (signal.aborted) {
        entry.error = "cancelled";
        entry.done = true;
        this._emit(entry);
        try {
          fs31.closeSync(fd);
        } catch {
        }
        return;
      }
      const headers = {
        ...opts.headers || {},
        "User-Agent": "qqq-shell-v2/0.1",
        "Accept": "*/*"
      };
      if (resumeFrom > 0) {
        headers["Range"] = "bytes=" + resumeFrom + "-";
      }
      const reqOpts = {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (parsedUrl.protocol === "https:" ? 443 : 80),
        path: parsedUrl.pathname + (parsedUrl.search || ""),
        method: "GET",
        headers
      };
      await new Promise((resolve3, reject) => {
        const req = lib.request(reqOpts, (res) => {
          if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            try {
              fs31.closeSync(fd);
            } catch {
            }
            fd = null;
            req.destroy();
            const loc = Array.isArray(res.headers.location) ? res.headers.location[0] : res.headers.location;
            const nextUrl = new import_url6.URL(loc, opts.url).toString();
            const nextOpts = { ...opts, url: nextUrl };
            this._doDownload(entry, nextOpts, signal, 0).then(resolve3, reject);
            return;
          }
          const cl = res.headers["content-length"];
          if (cl) {
            const clStr = Array.isArray(cl) ? cl[0] : cl;
            const parsed = parseInt(clStr, 10);
            if (!isNaN(parsed)) {
              if (res.statusCode === 206) {
                entry.totalBytes = resumeFrom + parsed;
              } else if (res.statusCode === 200) {
                entry.totalBytes = parsed;
              }
            }
          }
          if (hasher && resumeFrom > 0) {
            const h = hasher;
            try {
              const existing = fs31.readFileSync(entry.filePath);
              h.update(existing);
            } catch {
            }
          }
          res.on("data", (chunk) => {
            if (signal.aborted) {
              req.destroy();
              return;
            }
            try {
              fs31.writeSync(fd, chunk);
              entry.bytesDone += chunk.length;
              if (hasher)
                hasher.update(chunk);
              this._emit(entry);
            } catch (e) {
              req.destroy();
              reject(e);
            }
          });
          res.on("end", () => {
            try {
              fs31.closeSync(fd);
            } catch {
            }
            fd = null;
            if (hasher) {
              const digest = hasher.digest("hex");
              entry.sha256Ok = digest === opts.sha256;
              if (!entry.sha256Ok) {
                entry.error = "sha256 mismatch: expected " + opts.sha256 + " got " + digest;
                entry.done = true;
                this._emit(entry);
                reject(new Error(entry.error));
                return;
              }
            }
            entry.done = true;
            entry.error = null;
            this._emit(entry);
            this._active.delete(entry.id);
            resolve3();
          });
          res.on("error", (e) => {
            try {
              fs31.closeSync(fd);
            } catch {
            }
            fd = null;
            reject(e);
          });
        });
        req.on("error", (e) => {
          if (e.name === "AbortError" || signal.aborted) {
            entry.error = "cancelled";
          } else {
            entry.error = String(e.message || e);
          }
          try {
            fs31.closeSync(fd);
          } catch {
          }
          fd = null;
          entry.done = true;
          this._emit(entry);
          reject(e);
        });
        if (signal.aborted) {
          req.destroy();
          try {
            fs31.closeSync(fd);
          } catch {
          }
          fd = null;
          entry.error = "cancelled";
          entry.done = true;
          this._emit(entry);
          reject(new Error("cancelled"));
          return;
        }
        signal.addEventListener("abort", () => {
          try {
            req.destroy();
          } catch {
          }
          try {
            fs31.closeSync(fd);
          } catch {
          }
          fd = null;
        });
        req.end();
      });
    } catch (e) {
      if (fd !== null) {
        try {
          fs31.closeSync(fd);
        } catch {
        }
      }
      if (!entry.error) {
        entry.error = String(e.message || e);
      }
      entry.done = true;
      this._emit(entry);
      this._active.delete(entry.id);
    }
  }
  /** HEAD request to check if server supports Range, returns content-length or -1 */
  _headRequest(parsedUrl, opts, signal, resumePos) {
    return new Promise((resolve3) => {
      const lib = parsedUrl.protocol === "https:" ? https5 : http6;
      const headers = {
        ...opts.headers || {},
        "User-Agent": "qqq-shell-v2/0.1"
      };
      if (resumePos > 0) {
        headers["Range"] = "bytes=0-0";
      }
      const req = lib.request({
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (parsedUrl.protocol === "https:" ? 443 : 80),
        path: parsedUrl.pathname + (parsedUrl.search || ""),
        method: resumePos > 0 ? "GET" : "HEAD",
        headers
      }, (res) => {
        if (res.statusCode === 206) {
          const cr = res.headers["content-range"];
          if (cr) {
            const crStr = Array.isArray(cr) ? cr[0] : cr;
            const m = /bytes \d+-\d+\/(\d+)/.exec(crStr);
            if (m) {
              resolve3(parseInt(m[1], 10) || -1);
              return;
            }
          }
          const cl = res.headers["content-length"];
          if (cl) {
            const clStr = Array.isArray(cl) ? cl[0] : cl;
            resolve3(parseInt(clStr, 10));
            return;
          }
          resolve3(-1);
          return;
        }
        if (res.statusCode === 200) {
          const cl2 = res.headers["content-length"];
          if (cl2) {
            const cl2Str = Array.isArray(cl2) ? cl2[0] : cl2;
            resolve3(parseInt(cl2Str, 10));
          } else {
            resolve3(-1);
          }
          return;
        }
        resolve3(-1);
      });
      req.on("error", () => resolve3(-1));
      signal.addEventListener("abort", () => {
        try {
          req.destroy();
        } catch {
        }
      });
      if (resumePos > 0) {
        req.end();
      } else {
        req.end();
      }
      setTimeout(() => {
        try {
          req.destroy();
        } catch {
        }
        resolve3(-1);
      }, 8e3);
    });
  }
};

// shell/update-service.ts
var http7 = __toESM(require("http"));
var https6 = __toESM(require("https"));
var fs32 = __toESM(require("fs"));
var path32 = __toESM(require("path"));
var import_url7 = require("url");
var import_child_process12 = require("child_process");
var UPDATE_MANIFEST_URL = UPDATE_BASE_URL + "version.json";
var UPDATE_TAR_URL = UPDATE_BASE_URL + "server-app.tar.gz";
var SHELL_TAR_URL = UPDATE_BASE_URL + "shell-out.tar.gz";
var UPDATE_TAR_FALLBACK_URL = UPDATE_FALLBACK_URL + "server-app.tar.gz";
var SHELL_TAR_FALLBACK_URL = UPDATE_FALLBACK_URL + "shell-out.tar.gz";
var UpdateService = class {
  constructor(appRoot, shellVersion) {
    this._abortController = null;
    this._appRoot = appRoot;
    this._shellVersion = shellVersion || "0.0.0";
    this._statePath = path32.join(appRoot, "Data", "update-state.json");
    this._state = this._loadState();
  }
  // ---- public API ----
  /** Check for updates (both shell + webapp). */
  async check() {
    const info = await fetchServerVersionInfoWithFallback(UPDATE_BASE_URL, UPDATE_FALLBACK_URL);
    const localWebapp = this._readWebappVersion();
    this._state.currentVersion = localWebapp;
    this._state.lastCheck = Date.now();
    if (info) {
      this._state.lastVersion = info.shell || info.webapp || "";
    }
    this._saveState();
    const shellLatest = (info == null ? void 0 : info.shell) || "";
    const webappLatest = (info == null ? void 0 : info.webapp) || "";
    const needWebapp = !!webappLatest && this._compareVersions(localWebapp, webappLatest) < 0;
    const needShell = !!shellLatest && this._compareVersions(this._shellVersion, shellLatest) < 0;
    const shellStagingMain = path32.join(this._appRoot, "Data", "Cache", "staging", "shell-out-next", "main.js");
    const shellStaged = fs32.existsSync(shellStagingMain);
    const webappStagingIndex = path32.join(this._appRoot, "Data", "webapp-staging", "index.html");
    const webappStaged = fs32.existsSync(webappStagingIndex);
    return {
      latestVersion: webappLatest || localWebapp,
      currentVersion: localWebapp,
      needUpdate: needWebapp,
      latestShellVersion: shellLatest || this._shellVersion,
      currentShellVersion: this._shellVersion,
      needShellUpdate: needShell,
      shellStaged,
      webappStaged
    };
  }
  /**
   * Download and stage webapp update (server-app.tar.gz).
   * 下载到 Data/webapp-staging/，下次启动 ensureLocalWebapp 自动替换。
   */
  async apply() {
    this._abortController = new AbortController();
    try {
      const info = await fetchServerVersionInfoWithFallback(UPDATE_BASE_URL, UPDATE_FALLBACK_URL);
      const latestVersion = (info == null ? void 0 : info.webapp) || (info == null ? void 0 : info.shell) || "";
      if (!latestVersion) {
        return { success: false, version: "", error: "Failed to fetch latest version" };
      }
      const stagingDir = path32.join(this._appRoot, "Data", "webapp-staging");
      const dlDir = path32.join(this._appRoot, "Data", "webapp-dl");
      const tarPath = path32.join(dlDir, "server-app.tar.gz");
      try {
        fs32.mkdirSync(dlDir, { recursive: true });
      } catch {
      }
      try {
        fs32.rmSync(stagingDir, { recursive: true, force: true });
      } catch {
      }
      let downloadOk = await this._downloadFile(
        UPDATE_TAR_URL,
        tarPath,
        this._abortController.signal
      );
      if (!downloadOk) {
        downloadOk = await this._downloadFile(
          UPDATE_TAR_FALLBACK_URL,
          tarPath,
          this._abortController.signal
        );
      }
      if (!downloadOk) {
        return { success: false, version: "", error: "Download failed" };
      }
      try {
        fs32.mkdirSync(stagingDir, { recursive: true });
      } catch {
      }
      const extractOk = this._extractTarGz(tarPath, stagingDir);
      if (!extractOk) {
        try {
          fs32.unlinkSync(tarPath);
        } catch {
        }
        return { success: false, version: "", error: "Extraction failed" };
      }
      try {
        fs32.unlinkSync(tarPath);
      } catch {
      }
      try {
        fs32.writeFileSync(path32.join(stagingDir, ".staging-version"), latestVersion, "utf8");
      } catch {
      }
      this._state.lastApplied = latestVersion;
      this._saveState();
      return { success: true, version: latestVersion };
    } catch (e) {
      return { success: false, version: "", error: e.message || String(e) };
    } finally {
      this._abortController = null;
    }
  }
  /** Download shell-out.tar.gz and stage for bootstrap to apply on next restart. */
  async upgradeShell() {
    this._abortController = new AbortController();
    try {
      const stagingDir = path32.join(this._appRoot, "Data", "Cache", "staging", "shell-out-next");
      const tarPath = path32.join(this._appRoot, "Data", "Cache", "staging", "shell-out.tar.gz");
      const stagingParent = path32.dirname(tarPath);
      try {
        fs32.mkdirSync(stagingParent, { recursive: true });
      } catch {
      }
      try {
        fs32.rmSync(stagingDir, { recursive: true, force: true });
      } catch {
      }
      let downloadOk = await this._downloadFile(
        SHELL_TAR_URL,
        tarPath,
        this._abortController.signal
      );
      if (!downloadOk) {
        downloadOk = await this._downloadFile(
          SHELL_TAR_FALLBACK_URL,
          tarPath,
          this._abortController.signal
        );
      }
      if (!downloadOk) {
        return { success: false, version: "", error: "Shell download failed" };
      }
      try {
        fs32.mkdirSync(stagingDir, { recursive: true });
      } catch {
      }
      const extractResult = (0, import_child_process12.spawnSync)("tar", ["-xzf", tarPath, "-C", stagingDir], {
        stdio: "pipe",
        timeout: 15e3
      });
      if (extractResult.status !== 0) {
        try {
          fs32.unlinkSync(tarPath);
        } catch {
        }
        try {
          fs32.rmSync(stagingDir, { recursive: true, force: true });
        } catch {
        }
        return { success: false, version: "", error: "Shell extract failed, status=" + extractResult.status };
      }
      if (!fs32.existsSync(path32.join(stagingDir, "main.js"))) {
        try {
          fs32.rmSync(stagingDir, { recursive: true, force: true });
        } catch {
        }
        return { success: false, version: "", error: "Staging missing main.js" };
      }
      try {
        fs32.unlinkSync(tarPath);
      } catch {
      }
      const stagingVerFile = path32.join(stagingDir, ".staging-version");
      const shellVersion = this._state.lastVersion || this._shellVersion;
      try {
        fs32.writeFileSync(stagingVerFile, shellVersion, "utf8");
      } catch {
      }
      return { success: true, version: shellVersion };
    } catch (e) {
      return { success: false, version: "", error: e.message || String(e) };
    } finally {
      this._abortController = null;
    }
  }
  /** Get current update state. */
  getState() {
    return { ...this._state };
  }
  /** Abort current download. */
  abort() {
    if (this._abortController) {
      this._abortController.abort();
      this._abortController = null;
    }
  }
  // ---- internal ----
  /**
   * 加载本地持久化状态。
   * 铁律：_state.currentVersion 只反映 webapp 版本，shell 版本始终以 _shellVersion 为准。
   */
  _loadState() {
    const diskVersion = this._readWebappVersion();
    const defaults = {
      lastCheck: 0,
      lastVersion: "",
      currentVersion: diskVersion,
      lastApplied: ""
    };
    try {
      if (!fs32.existsSync(this._statePath))
        return defaults;
      const raw = fs32.readFileSync(this._statePath, "utf8");
      const parsed = JSON.parse(raw);
      let storedVer = typeof parsed.currentVersion === "string" ? parsed.currentVersion : "";
      if (!storedVer || storedVer === "0.0.0") {
        storedVer = diskVersion;
      }
      return {
        lastCheck: typeof parsed.lastCheck === "number" ? parsed.lastCheck : 0,
        lastVersion: typeof parsed.lastVersion === "string" ? parsed.lastVersion : "",
        currentVersion: storedVer,
        lastApplied: typeof parsed.lastApplied === "string" ? parsed.lastApplied : ""
      };
    } catch {
      return defaults;
    }
  }
  _saveState() {
    try {
      const dir = path32.dirname(this._statePath);
      try {
        fs32.mkdirSync(dir, { recursive: true });
      } catch {
      }
      fs32.writeFileSync(this._statePath, JSON.stringify(this._state, null, 2), "utf8");
    } catch {
    }
  }
  // ---- low-level I/O ----
  /** Read local webapp version from Data/webapp-version. boot.ts 的 ensureLocalWebapp 确保初始存在。 */
  _readWebappVersion() {
    try {
      const p = path32.join(this._appRoot, "Data", "webapp-version");
      if (fs32.existsSync(p))
        return fs32.readFileSync(p, "utf8").trim();
    } catch {
    }
    return "0.0.0";
  }
  /** Write Data/webapp-version. */
  _writeWebappVersion(v) {
    try {
      fs32.writeFileSync(path32.join(this._appRoot, "Data", "webapp-version"), v, "utf8");
    } catch {
    }
  }
  /** Download a file from url to dest, with timeout + redirect + abort support. */
  _downloadFile(url, dest, signal) {
    return new Promise((resolve3) => {
      const u = new import_url7.URL(url);
      const get5 = u.protocol === "https:" ? https6.get : http7.get;
      const opts = { timeout: 12e4 };
      if (u.protocol === "https:") {
        opts.rejectUnauthorized = false;
      }
      const req = get5(url, opts, (res) => {
        if (res.statusCode !== 200) {
          if (res.statusCode === 301 || res.statusCode === 302) {
            const loc = res.headers.location;
            if (loc) {
              this._downloadFile(loc, dest, signal).then(resolve3);
              return;
            }
          }
          resolve3(false);
          return;
        }
        const file = fs32.createWriteStream(dest);
        let bytes = 0;
        res.on("data", (chunk) => {
          bytes += chunk.length;
          file.write(chunk);
        });
        res.on("end", () => {
          file.end();
          resolve3(bytes > 0);
        });
        res.on("error", () => {
          try {
            file.close();
          } catch {
          }
          resolve3(false);
        });
      });
      req.on("error", () => resolve3(false));
      req.on("timeout", () => {
        req.destroy();
        resolve3(false);
      });
      signal.addEventListener("abort", () => {
        req.destroy();
        resolve3(false);
      });
    });
  }
  /** Extract .tar.gz to destDir. */
  _extractTarGz(tarPath, destDir) {
    try {
      try {
        fs32.mkdirSync(destDir, { recursive: true });
      } catch {
      }
      const result = (0, import_child_process12.spawnSync)("tar", ["-xzf", tarPath, "-C", destDir], {
        stdio: "pipe",
        timeout: 3e4
      });
      if (result.status !== 0) {
        try {
          fs32.rmSync(destDir, { recursive: true, force: true });
        } catch {
        }
        return false;
      }
      return true;
    } catch {
      try {
        fs32.rmSync(destDir, { recursive: true, force: true });
      } catch {
      }
      return false;
    }
  }
  /** Compare two semver-like version strings. Returns -1/0/1 */
  _compareVersions(a, b) {
    const pa = (a || "0.0.0").split(".").map(Number);
    const pb = (b || "0.0.0").split(".").map(Number);
    for (let i = 0; i < 3; i++) {
      const na = pa[i] || 0;
      const nb = pb[i] || 0;
      if (na > nb)
        return 1;
      if (na < nb)
        return -1;
    }
    return 0;
  }
};

// shell/main.ts
process.env["ELECTRON_DISABLE_SECURITY_WARNINGS"] = "true";
var portable = applyPortablePaths();
import_electron21.app.commandLine.appendSwitch("forced-colors", "none");
import_electron21.app.commandLine.appendSwitch("force-color-profile", "srgb");
import_electron21.app.commandLine.appendSwitch("disable-features", "ForcedColors,AutoDarkMode");
import_electron21.app.commandLine.appendSwitch("remote-debugging-port", "8315");
if (import_electron21.app.isPackaged) {
  import_electron21.app.setAsDefaultProtocolClient("qqqide");
} else {
  import_electron21.app.setAsDefaultProtocolClient("qqqide", process.execPath, [import_electron21.app.getAppPath()]);
}
var gotTheLock = import_electron21.app.requestSingleInstanceLock();
var _shouldQuitEarly = false;
if (!gotTheLock) {
  _shouldQuitEarly = true;
}
import_electron21.app.on("certificate-error", (event, _webContents, _url, _error, certificate, callback) => {
  if (certificate && certificate.issuerName && certificate.issuerName.includes("gh555")) {
    event.preventDefault();
    callback(true);
  } else if (_url.includes("direct.gh555.com")) {
    event.preventDefault();
    callback(true);
  } else if (_url.includes("47.105.67.51")) {
    event.preventDefault();
    callback(true);
  } else {
    callback(false);
  }
});
import_electron21.app.on("second-instance", (_event, argv) => {
  const url = argv.find((a) => a.startsWith("qqqide://"));
  if (url)
    handleAuthProtocolUrl(url);
  if (mainWindow) {
    if (mainWindow.isMinimized())
      mainWindow.restore();
    mainWindow.focus();
  }
});
import_electron21.app.on("open-url", (event, url) => {
  event.preventDefault();
  handleAuthProtocolUrl(url);
});
function handleAuthProtocolUrl(url) {
  try {
    const parsed = new URL(url);
    if (parsed.hostname === "auth") {
      const token = parsed.searchParams.get("token");
      const phone = parsed.searchParams.get("phone");
      const countryISO2 = parsed.searchParams.get("country_iso2") || "";
      const purchased = parsed.searchParams.get("purchased") === "1";
      const sessionId = parsed.searchParams.get("session") || "";
      if (token && mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("qqqide-auth", { token, phone: phone || "", country_iso2: countryISO2, purchased, session_id: sessionId });
        console.log("[protocol] auth token pushed to renderer, phone=" + (phone || "?") + " cc=" + countryISO2 + " sid=" + (sessionId ? sessionId.slice(0, 8) : "-"));
      }
    }
  } catch (e) {
    console.warn("[protocol] bad auth url:", e);
  }
}
function checkStartupAuthUrl() {
  const url = process.argv.find((a) => a.startsWith("qqqide://"));
  if (url)
    handleAuthProtocolUrl(url);
}
var bootConfig = loadBootConfig(portable.root);
var { isOffline: isOfflineFlag, isDev: isDevFlag } = extractFlags();
var engineHost = new EngineHost(portable.root);
var audioEngine = new AudioEngine(portable.root);
var monacoHost = new MonacoHost();
var qzSpawn = new QzSpawn(portable.root);
var lspBridge = null;
var cacheStore = new CacheStore(portable.cache);
var hashService = new HashService(cacheStore);
var mediaService = new MediaService(portable.root, qzSpawn, cacheStore, hashService);
var stateStore = new StateStore(portable.userData);
var stateCloud = new StateCloud(stateStore);
var _qgfInstances = /* @__PURE__ */ new Map();
var _projectStateStores = /* @__PURE__ */ new Map();
var downloadService = new DownloadService(portable.cache);
var updateService = new UpdateService(portable.root, APP_VERSION);
var indexService = new IndexService(portable.root);
var mainWindow = null;
var lastBootMode = "fallback";
function setLastBootMode(m) {
  lastBootMode = m;
}
function getLastBootMode() {
  return lastBootMode;
}
import_electron21.protocol.registerSchemesAsPrivileged([
  { scheme: "qqqide-asset", privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } },
  { scheme: "qqqide-webapp", privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } }
]);
function registerShellState() {
  try {
    stateStore.register("qqqide", {
      v: 1,
      form: "doc",
      cloud: true,
      merger: (local, remote, ctx) => {
        if (!local) {
          return remote;
        }
        if (!remote) {
          return local;
        }
        if (typeof local === "object" && typeof remote === "object" && !Array.isArray(local) && !Array.isArray(remote)) {
          return { ...local, ...remote };
        }
        if (Array.isArray(local) && Array.isArray(remote)) {
          const s = /* @__PURE__ */ new Set([...local, ...remote]);
          return Array.from(s);
        }
        return remote;
      }
    });
    stateStore.register("qqqide.timeline", {
      v: 1,
      form: "doc",
      cloud: false
    });
  } catch (e) {
    console.warn("[state] registerShellState failed:", e);
  }
}
stateStore.on("changed", (msg) => {
  if (mainWindow && !mainWindow.isDestroyed() && !mainWindow.webContents.isDestroyed()) {
    try {
      mainWindow.webContents.send("qqqide:state:changed", msg);
    } catch {
    }
  }
});
function registerAllIpc() {
  registerFsIpc();
  registerAiToolsIpc();
  registerSearchIpc();
  registerEditIpc();
  registerBootIpc(
    portable.root,
    portable.userData,
    portable.cache,
    portable.logs,
    APP_VERSION,
    bootConfig,
    () => engineHost.isAlive(),
    () => lastBootMode,
    () => mainWindow
  );
  registerMiscIpc(
    portable.root,
    portable.cache,
    APP_VERSION,
    isDevFlag,
    lspBridge,
    downloadService,
    stateStore,
    updateService,
    () => mainWindow,
    bootConfig
    // lspBridge=null (LSP OFF)
  );
  registerTimelineIpc(portable.root, bootConfig);
  registerGitDiffIpc(portable.root, bootConfig);
  registerSmartSearchIpc(indexService);
  registerStateHandlersIpc(stateStore, stateCloud, _projectStateStores, _qgfInstances, () => mainWindow);
  registerQzSpawnIpc(qzSpawn);
  registerGaeaProcessIpc();
  registerKopeIpc();
  registerAuthPersistIpc();
  registerDesktopShortcutIpc();
}
function registerDesktopShortcutIpc() {
  import_electron21.ipcMain.handle("qqqide:desktop:sync-shortcut", async (_e, enabled) => {
    if (process.platform !== "win32")
      return { ok: true, skipped: true };
    try {
      const desktopDir = path33.join(os8.homedir(), "Desktop");
      const lnkPath = path33.join(desktopDir, "qqqide.lnk");
      let targetExe = path33.join(portable.root, "qqqide.exe");
      let rootDir = portable.root;
      if (!fs33.existsSync(targetExe)) {
        rootDir = path33.dirname(portable.root);
        targetExe = path33.join(rootDir, "qqqide.exe");
      }
      if (!fs33.existsSync(targetExe))
        return { ok: true, skipped: true, reason: "no-qqqide-exe" };
      let iconLocation = "";
      const jokerExe = path33.join(portable.root, "joker.exe");
      if (fs33.existsSync(jokerExe)) {
        iconLocation = jokerExe + ",0";
      } else {
        const icoPath = path33.join(portable.root, "shell", "icon.ico");
        if (fs33.existsSync(icoPath)) {
          iconLocation = icoPath;
        } else {
          iconLocation = targetExe + ",0";
        }
      }
      if (enabled) {
        const psScript = [
          "$ws = New-Object -ComObject WScript.Shell;",
          "$s = $ws.CreateShortcut('" + lnkPath.replace(/\\/g, "\\\\") + "');",
          "$s.TargetPath = '" + targetExe.replace(/\\/g, "\\\\") + "';",
          "$s.WorkingDirectory = '" + rootDir.replace(/\\/g, "\\\\") + "';",
          "$s.IconLocation = '" + iconLocation.replace(/\\/g, "\\\\") + "';",
          "$s.Save();"
        ].join(" ");
        require("child_process").execSync(
          'powershell -NoProfile -Command "' + psScript + '"',
          { timeout: 1e4, windowsHide: true }
        );
        return { ok: true, action: "created" };
      } else {
        return { ok: true, action: "skipped" };
      }
    } catch (e) {
      return { ok: false, error: e && e.message };
    }
  });
}
function registerAuthPersistIpc() {
  const AUTH_FILE = path33.join(portable.userData, "alphal", "auth.enc");
  const PHONE_FILE = path33.join(portable.userData, "alphal", "phone.txt");
  import_electron21.ipcMain.handle("qqqide:auth:save", async (_e, auth) => {
    if (auth && auth.phone) {
      setAuthPhone(auth.phone);
      notifyAuthReady();
    }
    if (auth && auth.token)
      setAuthToken(auth.token);
    if (auth && auth.phone) {
      try {
        const dir = path33.dirname(PHONE_FILE);
        if (!fs33.existsSync(dir))
          fs33.mkdirSync(dir, { recursive: true });
        fs33.writeFileSync(PHONE_FILE, auth.phone, "utf8");
      } catch (_) {
      }
    }
    if (!auth || !auth.token || !import_electron21.safeStorage.isEncryptionAvailable())
      return false;
    try {
      const encrypted = import_electron21.safeStorage.encryptString(JSON.stringify(auth));
      const dir = path33.dirname(AUTH_FILE);
      if (!fs33.existsSync(dir))
        fs33.mkdirSync(dir, { recursive: true });
      fs33.writeFileSync(AUTH_FILE, new Uint8Array(encrypted));
      if (auth.phone)
        setAuthPhone(auth.phone);
      if (auth.token)
        setAuthToken(auth.token);
      return true;
    } catch (e) {
      return false;
    }
  });
  import_electron21.ipcMain.handle("qqqide:auth:load", async () => {
    if (!import_electron21.safeStorage.isEncryptionAvailable())
      return null;
    try {
      if (!fs33.existsSync(AUTH_FILE))
        return null;
      const encrypted = fs33.readFileSync(AUTH_FILE);
      const auth = JSON.parse(import_electron21.safeStorage.decryptString(encrypted));
      if (auth && auth.phone) {
        setAuthPhone(auth.phone);
        notifyAuthReady();
      }
      if (auth && auth.token)
        setAuthToken(auth.token);
      return auth;
    } catch (e) {
      return null;
    }
  });
  import_electron21.ipcMain.handle("qqqide:auth:set-phone", async (_e, phone) => {
    if (phone && /^\d{7,20}$/.test(phone)) {
      setAuthPhone(phone);
      notifyAuthReady();
      return true;
    }
    return false;
  });
  import_electron21.ipcMain.handle("qqqide:auth:clear", async () => {
    try {
      if (fs33.existsSync(AUTH_FILE))
        fs33.unlinkSync(AUTH_FILE);
      setAuthPhone("");
      setAuthToken("");
      return true;
    } catch (e) {
      return false;
    }
  });
}
var _PROCESS_GOODS_AUTOSTART_DEFAULTS = {
  "kope-a": true,
  "window-there": false
};
function registerGaeaProcessIpc() {
  setGaeaUserDataPath(portable.userData);
  registerGoodsMeta("kope-a", false);
  registerGoodsMeta("window-there", false);
  import_electron21.ipcMain.handle("qqqide:gaea-process:start", async (_e, goodsId, scriptPath, runtime, lifecycle, allowMultiple) => {
    return startGaeaProcess(portable.root, goodsId, scriptPath, runtime || "python", lifecycle || "attached", allowMultiple !== false);
  });
  import_electron21.ipcMain.handle("qqqide:gaea-process:stop", async (_e, goodsId) => {
    return stopGaeaProcess(goodsId);
  });
  import_electron21.ipcMain.handle("qqqide:gaea-process:status", async (_e, goodsId) => {
    return { running: isGaeaProcessRunning(goodsId), pid: getGaeaProcessPid(goodsId) };
  });
  import_electron21.ipcMain.handle("qqqide:gaea-process:get-auto-start", async (_e, goodsId) => {
    try {
      const val = await stateStore.get("qqqide", goodsId + ".autoStart");
      if (val !== void 0 && val !== null)
        return !!val;
      const osVal = getOsGaeaAutoStart(goodsId);
      if (osVal !== null)
        return osVal;
      const def = _PROCESS_GOODS_AUTOSTART_DEFAULTS[goodsId];
      return def ?? false;
    } catch (e) {
      return false;
    }
  });
  import_electron21.ipcMain.handle("qqqide:gaea-process:set-auto-start", async (_e, goodsId, v, meta) => {
    try {
      await stateStore.setNow("qqqide", goodsId + ".autoStart", v);
      syncOsGaeaAutoStart(goodsId, v);
      if (v && meta && meta.scriptPath) {
        const runtime = meta.runtime || "python";
        const lifecycle = meta.lifecycle || "attached";
        const allowMultiple = meta.allowMultiple !== false;
        const result = startGaeaProcess(portable.root, goodsId, meta.scriptPath, runtime, lifecycle, allowMultiple);
        if (result.ok) {
          console.log("[" + goodsId + "] auto-start (via checkbox) pid=" + result.pid + (result.alreadyRunning ? " (already running)" : ""));
        }
        if (!allowMultiple) {
          startGaeaWatchdog(portable.root, goodsId, meta.scriptPath, runtime, lifecycle);
        }
      } else if (!v) {
        stopGaeaWatchdog(goodsId);
      }
      return true;
    } catch (e) {
      return false;
    }
  });
}
import_electron21.app.whenReady().then(async () => {
  if (_shouldQuitEarly) {
    import_electron21.app.quit();
    return;
  }
  const forced = checkForcedUpdate();
  if (forced.required) {
    const DOWNLOAD_URL = "https://gh555.com/qqqide/";
    const result = import_electron21.dialog.showMessageBoxSync({
      type: "warning",
      title: "qqqide \u2014 \u9700\u8981\u66F4\u65B0",
      message: "\u60A8\u7684 qqqide \u7248\u672C\u8FC7\u4F4E\uFF0C\u5FC5\u987B\u91CD\u65B0\u4E0B\u8F7D\u5B89\u88C5\u3002",
      detail: [
        "\u5F53\u524D\u7248\u672C: " + forced.currentVersion,
        "\u6700\u4F4E\u8981\u6C42: " + forced.minVersion,
        "",
        "\u7531\u4E8E\u67B6\u6784\u5347\u7EA7\uFF0C\u65E7\u7248\u672C\u65E0\u6CD5\u901A\u8FC7\u81EA\u52A8\u66F4\u65B0\u5B8C\u6210\u5347\u7EA7\u3002",
        "\u8BF7\u524D\u5F80\u4E0B\u8F7D\u9875\u9762\u83B7\u53D6\u6700\u65B0\u7EFF\u8272\u5305\u3002",
        "",
        "\u3010\u5B89\u88C5\u65B9\u6CD5\u3011",
        "\u2460 \u5173\u95ED IDE",
        "\u2461 \u4E0B\u8F7D\u6700\u65B0\u7EFF\u8272\u5305\uFF08\u7EA6 94MB\uFF09",
        "\u2462 \u76F4\u63A5\u89E3\u538B\u8986\u76D6\u5230\u539F\u4F4D\u7F6E\u5373\u53EF\uFF08\u63A8\u8350\uFF09",
        "",
        "\u3010\u504F\u597D\u4FDD\u7559\u3011",
        "\u9879\u76EE\u6570\u636E\uFF08\u5BF9\u8BDD\u8BB0\u5F55/\u8BBE\u7F6E\uFF09\u5728\u9879\u76EE\u6587\u4EF6\u5939\u7684 qqq/ \u76EE\u5F55\u4E0B\uFF0C",
        "\u8986\u76D6\u5B89\u88C5\u4E0D\u4F1A\u4E22\u5931\u3002\u767B\u5F55\u72B6\u6001\u548C\u5E94\u7528\u504F\u597D\u9700\u8981\u91CD\u65B0\u8BBE\u7F6E\u3002",
        "\u5982\u9700\u4FDD\u7559: \u5148\u5907\u4EFD gh555.com\\Data\\alphal\\ \u6587\u4EF6\u5939\uFF0C",
        "\u5B89\u88C5\u5E76\u9996\u6B21\u8FD0\u884C\u540E\u518D\u590D\u5236\u56DE\u53BB\u3002",
        "",
        "\u3010\u5E72\u51C0\u5B89\u88C5\u3011",
        "\u5220\u9664\u65E7\u7684 qqqide-win-x64 \u6587\u4EF6\u5939 \u2192 \u89E3\u538B\u65B0\u7EFF\u8272\u5305\u5373\u53EF\u3002"
      ].join("\n"),
      buttons: ["\u524D\u5F80\u4E0B\u8F7D", "\u9000\u51FA"],
      defaultId: 0,
      cancelId: 1
    });
    if (result === 0) {
      import_electron21.shell.openExternal(DOWNLOAD_URL);
    }
    import_electron21.app.quit();
    return;
  }
  import_electron21.nativeTheme.themeSource = "light";
  initAssetProtocol(portable.root, portable.cache, portable.userData);
  registerShellState();
  await hydrateAssetRootsFromState(stateStore);
  hardenSession();
  checkRank0Components(portable.root);
  startPyBroker(portable.root);
  (async () => {
    try {
      const processGoods = [
        { id: "kope-a", script: "goods/kope-a/q3.py", runtime: "python", lifecycle: "independent", allowMultiple: false, defaultAutoStart: true },
        { id: "window-there", script: "goods/window-there/q3.py", runtime: "python", lifecycle: "attached", allowMultiple: false, defaultAutoStart: false }
      ];
      for (const g of processGoods) {
        try {
          const autoStart = await stateStore.get("qqqide", g.id + ".autoStart");
          if (autoStart ?? g.defaultAutoStart) {
            const result = startGaeaProcess(portable.root, g.id, g.script, g.runtime, g.lifecycle, g.allowMultiple);
            if (result.ok) {
              console.log("[" + g.id + "] auto-started pid=" + result.pid + (result.alreadyRunning ? " (already running)" : ""));
            } else {
              console.log("[" + g.id + "] auto-start failed:", result.error);
            }
            if (!g.allowMultiple) {
              startGaeaWatchdog(portable.root, g.id, g.script, g.runtime, g.lifecycle);
            }
          }
        } catch (e) {
        }
      }
    } catch (e) {
    }
  })();
  mainWindow = createWindow(
    portable.root,
    portable.cache,
    APP_VERSION,
    lspBridge,
    downloadService,
    stateStore
  );
  onGaeaProcessStatusChange((goodsId, running, pid) => {
    import_electron21.BrowserWindow.getAllWindows().forEach((w) => {
      if (!w.isDestroyed()) {
        w.webContents.send("qqqide:gaea-process:status-changed", { goodsId, running, pid });
      }
    });
  });
  checkStartupAuthUrl();
  mainWindow.on("closed", () => {
    try {
      const all = import_electron21.BrowserWindow.getAllWindows();
      all.forEach((w) => {
        if (!w.isDestroyed() && w !== mainWindow) {
          try {
            w.destroy();
          } catch {
          }
        }
      });
    } catch {
    }
    try {
      engineHost.stop();
    } catch {
    }
    try {
      audioEngine.stop();
    } catch {
    }
    try {
      cleanupAllGaeaProcesses();
    } catch {
    }
    try {
      stopWqPing();
    } catch {
    }
    mainWindow = null;
  });
  registerAllIpc();
  registerExitHandlers(portable.root, portable.logs, stateStore, bootConfig, _qgfInstances);
  try {
    const openWindows = await stateStore.get("qqqide", "open_windows");
    if (openWindows && Array.isArray(openWindows) && openWindows.length > 0) {
      const w0 = openWindows[0];
      if (w0 && w0.mainFolder) {
        const n0 = w0.mainFolder.replace(/\\/g, "/").replace(/\/$/, "");
        if (n0) {
          const sep2 = bootConfig.url.includes("?") ? "&" : "?";
          bootConfig.url = bootConfig.url + sep2 + "restore=1&folder=" + encodeURIComponent(n0);
          _windowProjectMap.set(mainWindow.id, n0);
          _projectWindowMap.set(n0, mainWindow.id);
        }
      }
    }
  } catch (_) {
  }
  await bootSequence(
    mainWindow,
    bootConfig,
    portable.root,
    portable.cache,
    isDevFlag,
    isOfflineFlag,
    setLastBootMode,
    getLastBootMode
  );
  (async () => {
    try {
      const openWindows = await stateStore.get("qqqide", "open_windows");
      if (openWindows && Array.isArray(openWindows) && openWindows.length > 1) {
        const w0 = openWindows[0];
        if (w0 && w0.mainFolder) {
          var n0 = w0.mainFolder.replace(/\\/g, "/").replace(/\/$/, "");
          if (n0) {
            _windowProjectMap.set(mainWindow.id, n0);
            _projectWindowMap.set(n0, mainWindow.id);
          }
        }
        let restored = 0;
        for (let i = 1; i < openWindows.length; i++) {
          const w = openWindows[i];
          if (!w.mainFolder)
            continue;
          const normalized = w.mainFolder.replace(/\\/g, "/").replace(/\/$/, "");
          if (!normalized)
            continue;
          if (!fs33.existsSync(normalized)) {
            console.warn("[restore] skip missing project:", normalized);
            continue;
          }
          if (_projectWindowMap.has(normalized))
            continue;
          const newWin = createWindow(portable.root, portable.cache, APP_VERSION, lspBridge, downloadService, stateStore);
          _windowProjectMap.set(newWin.id, normalized);
          _projectWindowMap.set(normalized, newWin.id);
          const baseUrl = getWebappBaseUrl(portable.root, bootConfig, isDevFlag);
          const url = baseUrl + "?restore=1&folder=" + encodeURIComponent(normalized);
          newWin.loadURL(url).then(() => {
            if (!newWin.isDestroyed()) {
              try {
                if (w.bounds && typeof w.bounds.w === "number") {
                  if (w.bounds.maximized) {
                    newWin.maximize();
                  } else {
                    newWin.setBounds({ x: w.bounds.x || 0, y: w.bounds.y || 0, width: w.bounds.w, height: w.bounds.h });
                  }
                }
              } catch (_) {
              }
              newWin.show();
            }
          }).catch((err) => {
            console.warn("[restore] window loadURL failed:", err && err.message);
            _windowProjectMap.delete(newWin.id);
            _projectWindowMap.delete(normalized);
            try {
              newWin.close();
            } catch (_) {
            }
          });
          restored++;
          await new Promise((r) => setTimeout(r, 500));
        }
        if (restored > 0)
          console.log("[restore] " + restored + " additional window(s) restored");
      }
    } catch (e) {
      console.warn("[restore] multi-window restore failed:", e);
    }
  })();
  (function preloadAuthPhone() {
    try {
      if (import_electron21.safeStorage.isEncryptionAvailable()) {
        const authFile = path33.join(portable.userData, "alphal", "auth.enc");
        if (fs33.existsSync(authFile)) {
          const encrypted = fs33.readFileSync(authFile);
          const auth = JSON.parse(import_electron21.safeStorage.decryptString(encrypted));
          if (auth && auth.phone) {
            setAuthPhone(auth.phone);
            return;
          }
          if (auth && auth.token)
            setAuthToken(auth.token);
        }
      }
    } catch (_) {
    }
    try {
      const phoneFile = path33.join(portable.userData, "alphal", "phone.txt");
      if (fs33.existsSync(phoneFile)) {
        const phone = fs33.readFileSync(phoneFile, "utf8").trim();
        if (phone && /^\d{7,20}$/.test(phone))
          setAuthPhone(phone);
      }
    } catch (_) {
    }
  })();
  try {
    const bootLogPath = path33.join(portable.userData, "alphal", "wq-ping.log");
    fs33.mkdirSync(path33.dirname(bootLogPath), { recursive: true });
    fs33.appendFileSync(bootLogPath, (/* @__PURE__ */ new Date()).toISOString() + " [main.ts] calling startWqPing userData=" + portable.userData + "\n");
  } catch (_) {
  }
  startWqPing(portable.userData);
  indexService.init();
  import_electron21.app.on("activate", () => {
    if (import_electron21.BrowserWindow.getAllWindows().length === 0) {
      mainWindow = createWindow(
        portable.root,
        portable.cache,
        APP_VERSION,
        lspBridge,
        downloadService,
        stateStore
      );
      bootSequence(
        mainWindow,
        bootConfig,
        portable.root,
        portable.cache,
        isDevFlag,
        isOfflineFlag,
        setLastBootMode,
        getLastBootMode
      );
    }
  });
});
//# sourceMappingURL=main.js.map
