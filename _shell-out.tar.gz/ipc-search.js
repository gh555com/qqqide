"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// shell/ipc-search.ts
var ipc_search_exports = {};
__export(ipc_search_exports, {
  registerSearchIpc: () => registerSearchIpc
});
module.exports = __toCommonJS(ipc_search_exports);
var import_electron = require("electron");
var path = __toESM(require("path"));
var fs = __toESM(require("fs"));
var import_child_process = require("child_process");
var SEARCH_MAX_DEPTH = 20;
var SEARCH_MAX_FILE_MB = 5;
function _findRipgrep() {
  const rgName = process.platform === "win32" ? "rg.exe" : "rg";
  const tries = [];
  try {
    tries.push(path.join(import_electron.app.getPath("userData"), "components", "ripgrep", rgName));
  } catch {
  }
  tries.push(path.join(__dirname, "..", "engines", "ripgrep", rgName));
  tries.push(path.join(__dirname, "..", "..", "engines", "ripgrep", rgName));
  const platSuffix = { win32: "win-x64", linux: "linux-x64", darwin: "darwin-" + (process.arch === "arm64" ? "arm64" : "x64") };
  const suffix = platSuffix[process.platform];
  if (suffix) {
    const baseName = rgName.endsWith(".exe") ? rgName.slice(0, -4) : rgName;
    const suffixed = baseName + "-" + suffix + (process.platform === "win32" ? ".exe" : "");
    tries.push(path.join(__dirname, "..", "engines", "ripgrep", suffixed));
    tries.push(path.join(__dirname, "..", "..", "engines", "ripgrep", suffixed));
  }
  for (const p of tries) {
    try {
      if (fs.existsSync(p)) {
        console.log("[search] ripgrep found:", p);
        return p;
      }
    } catch {
    }
  }
  console.log("[search] ripgrep not found in known paths, trying PATH:", rgName);
  return rgName;
}
async function _ripgrepSearch(searchPath, query, isRegex, caseSensitive, wholeWord, includePattern, excludePattern, contextLines, maxResults, timeoutMs, respectGitignore, matchFilenames) {
  const rgPath = _findRipgrep();
  if (!rgPath) {
    return { error: "ripgrep \u672A\u5B89\u88C5\u3002\u8FD0\u884C: python op/components.py ensure ripgrep", results: [], total: 0, elapsed: 0, filesScanned: 0, truncated: false, fileStats: {} };
  }
  const startTime = Date.now();
  console.log("[search] spawning ripgrep:", rgPath, "query:", query.slice(0, 80));
  const args = [
    "--json",
    "--no-heading",
    "--with-filename",
    "--line-number",
    "--column",
    "--color",
    "never",
    "--max-depth",
    String(SEARCH_MAX_DEPTH),
    "--max-filesize",
    String(SEARCH_MAX_FILE_MB) + "M"
  ];
  let actualQuery = query;
  let forceRegex = false;
  const hasNewline = query.indexOf("\\n") !== -1 || query.indexOf("\n") !== -1;
  if (hasNewline) {
    args.push("--multiline");
    args.push("--crlf");
    actualQuery = query.replace(/\\n/g, "\n");
    if (!isRegex) {
      forceRegex = true;
      actualQuery = actualQuery.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      if (wholeWord)
        actualQuery = "\\b" + actualQuery + "\\b";
    }
  }
  if (!caseSensitive)
    args.push("--ignore-case");
  if (wholeWord && !forceRegex)
    args.push("--word-regexp");
  if (!isRegex && !forceRegex)
    args.push("--fixed-strings");
  if (!respectGitignore)
    args.push("--no-ignore");
  args.push("--glob", "!.git");
  args.push("--glob", "!node_modules");
  if (includePattern) {
    for (const p of includePattern.split(",").map((s) => s.trim()).filter(Boolean)) {
      args.push("--glob", p);
    }
  }
  if (excludePattern) {
    for (const p of excludePattern.split(",").map((s) => s.trim()).filter(Boolean)) {
      args.push("--glob", "!" + p);
    }
  }
  if (contextLines > 0) {
    args.push("--context", String(contextLines));
  }
  args.push("--regexp", actualQuery);
  args.push(searchPath);
  return new Promise((resolve) => {
    let rg;
    try {
      rg = (0, import_child_process.spawn)(rgPath, args, {
        cwd: searchPath,
        stdio: ["ignore", "pipe", "pipe"],
        windowsHide: true
      });
    } catch (e) {
      return resolve({ error: "\u65E0\u6CD5\u542F\u52A8 ripgrep: " + (e.message || e), results: [], total: 0, elapsed: 0, filesScanned: 0, truncated: false, fileStats: {} });
    }
    let stdout = "";
    let killed = false;
    const timer = setTimeout(() => {
      killed = true;
      try {
        rg.kill("SIGTERM");
      } catch {
      }
      setTimeout(() => {
        try {
          rg.kill("SIGKILL");
        } catch {
        }
      }, 2e3);
    }, timeoutMs);
    rg.stdout.on("data", (chunk) => {
      stdout += chunk.toString("utf8");
    });
    let stderr = "";
    rg.stderr.on("data", (chunk) => {
      stderr += chunk.toString("utf8");
    });
    rg.on("error", (err) => {
      clearTimeout(timer);
      resolve({ error: "ripgrep \u8FDB\u7A0B\u9519\u8BEF: " + err.message, results: [], total: 0, elapsed: 0, filesScanned: 0, truncated: false, fileStats: {} });
    });
    rg.on("close", async (code) => {
      clearTimeout(timer);
      if (killed || code === null && stdout.length === 0) {
        if (stdout.length > 0) {
          const parsed2 = _parseRgJson(stdout, maxResults, contextLines, searchPath);
          parsed2.elapsed = Date.now() - startTime;
          parsed2.truncated = true;
          return resolve(parsed2);
        }
        return resolve({ error: "\u641C\u7D22\u8D85\u65F6", results: [], total: 0, elapsed: Date.now() - startTime, filesScanned: 0, truncated: true, fileStats: {} });
      }
      if (code === 2 && stdout.length === 0) {
        const errMsg = stderr.split("\n").filter(Boolean).slice(-2).join("; ") || "ripgrep \u9000\u51FA\u7801 2";
        return resolve({ error: errMsg, results: [], total: 0, elapsed: Date.now() - startTime, filesScanned: 0, truncated: false, fileStats: {} });
      }
      const parsed = _parseRgJson(stdout, maxResults, contextLines, searchPath);
      parsed.elapsed = Date.now() - startTime;
      const fileSet = /* @__PURE__ */ new Set();
      for (const line of stdout.split("\n")) {
        try {
          const obj = JSON.parse(line);
          if (obj.data && obj.data.path && obj.data.path.text) {
            fileSet.add(obj.data.path.text);
          }
        } catch {
        }
      }
      parsed.filesScanned = fileSet.size;
      if (matchFilenames && parsed.results.length < maxResults && !parsed.error) {
        try {
          const fnameMatches = await _rgFilenameSearch(
            searchPath,
            query,
            isRegex,
            caseSensitive,
            wholeWord,
            includePattern,
            excludePattern,
            respectGitignore,
            maxResults - parsed.results.length
          );
          const existingFiles = new Set(parsed.results.map((r) => r.file));
          for (const m of fnameMatches.matches) {
            if (!existingFiles.has(m.file)) {
              parsed.results.push(m);
              existingFiles.add(m.file);
            }
          }
          parsed.total = parsed.results.length;
          Object.assign(parsed.fileStats, fnameMatches.fileStats);
        } catch {
        }
      }
      resolve(parsed);
    });
  });
}
async function _rgFilenameSearch(searchPath, query, isRegex, caseSensitive, wholeWord, includePattern, excludePattern, respectGitignore, maxResults) {
  const rgPath = _findRipgrep();
  if (!rgPath)
    return { matches: [], fileStats: {} };
  const args = ["--files", "--no-heading", "--max-depth", String(SEARCH_MAX_DEPTH)];
  if (!respectGitignore)
    args.push("--no-ignore");
  args.push("--glob", "!.git");
  args.push("--glob", "!node_modules");
  if (includePattern) {
    for (const p of includePattern.split(",").map((s) => s.trim()).filter(Boolean)) {
      args.push("--glob", p);
    }
  }
  if (excludePattern) {
    for (const p of excludePattern.split(",").map((s) => s.trim()).filter(Boolean)) {
      args.push("--glob", "!" + p);
    }
  }
  args.push(searchPath);
  return new Promise((resolve) => {
    let stdout = "";
    try {
      const child = (0, import_child_process.spawn)(rgPath, args, { cwd: searchPath, stdio: ["ignore", "pipe", "pipe"], windowsHide: true });
      const timer = setTimeout(() => {
        try {
          child.kill();
        } catch {
        }
      }, 15e3);
      child.stdout.on("data", (chunk) => {
        stdout += chunk.toString("utf8");
      });
      child.on("close", () => {
        clearTimeout(timer);
        const lines = stdout.split("\n").map((s) => s.trim()).filter(Boolean);
        const matches = [];
        const fileStats = {};
        let fnameMatcher;
        if (isRegex) {
          try {
            const re = new RegExp(query, caseSensitive ? "" : "i");
            fnameMatcher = (n) => re.test(n);
          } catch {
            fnameMatcher = () => false;
          }
        } else if (wholeWord) {
          const esc = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          const re = new RegExp("\\b" + esc + "\\b", caseSensitive ? "" : "i");
          fnameMatcher = (n) => re.test(n);
        } else {
          const q = caseSensitive ? query : query.toLowerCase();
          fnameMatcher = (n) => (caseSensitive ? n : n.toLowerCase()).indexOf(q) !== -1;
        }
        const searchNorm = searchPath.replace(/\\/g, "/").replace(/\/$/, "");
        for (const rawPath of lines) {
          if (matches.length >= maxResults)
            break;
          const relPath = rawPath.replace(/\\/g, "/");
          const displayPath = relPath.startsWith(searchNorm + "/") ? relPath.slice(searchNorm.length + 1) : relPath;
          const fname = path.basename(displayPath);
          if (fnameMatcher(fname)) {
            const absFp = path.join(searchPath, displayPath);
            matches.push({ file: displayPath, line: 1, col: 1, text: fname });
            try {
              const st = fs.statSync(absFp);
              fileStats[displayPath] = { mtime: st.mtimeMs, birthtime: st.birthtimeMs, size: st.size };
            } catch {
            }
          }
        }
        resolve({ matches, fileStats });
      });
      child.on("error", () => resolve({ matches: [], fileStats: {} }));
    } catch {
      resolve({ matches: [], fileStats: {} });
    }
  });
}
function _parseRgJson(raw, maxResults, contextLines, _searchPath) {
  const fileEntries = /* @__PURE__ */ new Map();
  const seenFiles = /* @__PURE__ */ new Set();
  for (const line of raw.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed)
      continue;
    try {
      const obj = JSON.parse(trimmed);
      if (!obj || !obj.type)
        continue;
      if (obj.type === "summary" || obj.type === "end")
        continue;
      const fpath = obj.data && obj.data.path && obj.data.path.text || "";
      if (!fpath)
        continue;
      seenFiles.add(fpath);
      const relPath = fpath.replace(/\\/g, "/");
      const searchNorm = _searchPath.replace(/\\/g, "/").replace(/\/$/, "");
      const displayPath = relPath.startsWith(searchNorm + "/") ? relPath.slice(searchNorm.length + 1) : relPath;
      if (obj.type === "match") {
        const lineNum = obj.data.line_number || 0;
        const text = obj.data.lines && obj.data.lines.text || "";
        const submatch = obj.data.submatches && obj.data.submatches[0];
        const col = submatch ? (submatch.start || 0) + 1 : 1;
        const cleanText = text.replace(/\r?\n$/, "").slice(0, 300);
        if (!fileEntries.has(displayPath))
          fileEntries.set(displayPath, []);
        fileEntries.get(displayPath).push({ type: "match", file: displayPath, line: lineNum, col, text: cleanText });
      } else if (obj.type === "context" && contextLines > 0) {
        const lineNum = obj.data.line_number || 0;
        const text = obj.data.lines && obj.data.lines.text || "";
        const cleanText = text.replace(/\r?\n$/, "").slice(0, 200);
        if (!fileEntries.has(displayPath))
          fileEntries.set(displayPath, []);
        fileEntries.get(displayPath).push({ type: "context", file: displayPath, line: lineNum, text: cleanText });
      }
    } catch {
    }
  }
  const results = [];
  for (const [filePath, entries] of fileEntries) {
    const matches = entries.filter((e) => e.type === "match");
    const contexts = entries.filter((e) => e.type === "context");
    for (const m of matches) {
      if (results.length >= maxResults)
        break;
      if (results.some((r) => r.file === filePath && r.line === m.line))
        continue;
      const match = { file: filePath, line: m.line, col: m.col || 1, text: m.text };
      if (contextLines > 0) {
        const before = contexts.filter((c) => c.line < m.line && m.line - c.line <= contextLines).sort((a, b) => a.line - b.line).map((c) => c.text);
        const after = contexts.filter((c) => c.line > m.line && c.line - m.line <= contextLines).sort((a, b) => a.line - b.line).map((c) => c.text);
        if (before.length > 0)
          match.before = before;
        if (after.length > 0)
          match.after = after;
      }
      results.push(match);
    }
  }
  const fileStats = {};
  const uniqueFiles = new Set(results.map((r) => r.file));
  for (const fp of uniqueFiles) {
    try {
      const absFp = path.join(_searchPath, fp);
      const st = fs.statSync(absFp);
      fileStats[fp] = { mtime: st.mtimeMs, birthtime: st.birthtimeMs, size: st.size };
    } catch {
    }
  }
  return {
    results,
    total: results.length,
    elapsed: 0,
    // filled by caller
    filesScanned: seenFiles.size,
    truncated: results.length >= maxResults,
    fileStats
  };
}
function registerSearchIpc() {
  import_electron.ipcMain.handle("qqqide:search:query", async (_e, args) => {
    const searchPath = args.searchPath || args.rootDir || "";
    const {
      query,
      isRegex = false,
      caseSensitive = false,
      wholeWord = false,
      contextLines = 1,
      maxResults = 5e3,
      timeoutMs = 6e4,
      respectGitignore = false
    } = args;
    if (!searchPath || !query) {
      return { error: "\u7F3A\u5C11\u641C\u7D22\u5173\u952E\u8BCD\u6216\u641C\u7D22\u8DEF\u5F84", results: [], total: 0, elapsed: 0, filesScanned: 0, truncated: false, fileStats: {} };
    }
    return await _ripgrepSearch(
      searchPath,
      query,
      isRegex,
      caseSensitive,
      wholeWord,
      args.includePattern,
      args.excludePattern,
      contextLines,
      maxResults,
      timeoutMs,
      respectGitignore,
      args.matchFilenames !== false
    );
  });
  import_electron.ipcMain.handle("qqqide:search:replace", async (_e, args) => {
    if (args.replacements && Array.isArray(args.replacements) && args.replacements.length > 0) {
      const byFile = /* @__PURE__ */ new Map();
      for (const r of args.replacements) {
        if (!byFile.has(r.file))
          byFile.set(r.file, []);
        byFile.get(r.file).push(r);
      }
      let totalReplaced2 = 0, filesChanged2 = 0;
      const errors2 = [];
      for (const [fpath, reps] of byFile) {
        try {
          reps.sort((a, b) => b.line - a.line || b.col - a.col);
          const content = await fs.promises.readFile(fpath, "utf8");
          const lines = content.split("\n");
          let changed = false;
          for (const rep of reps) {
            const li = rep.line - 1;
            if (li < 0 || li >= lines.length)
              continue;
            const col0 = rep.col - 1;
            const line = lines[li];
            if (col0 + rep.matchLen > line.length)
              continue;
            lines[li] = line.slice(0, col0) + rep.replacement + line.slice(col0 + rep.matchLen);
            changed = true;
            totalReplaced2++;
          }
          if (changed) {
            await fs.promises.writeFile(fpath, lines.join("\n"), "utf8");
            filesChanged2++;
          }
        } catch (e) {
          errors2.push(fpath + ": " + (e.message || e));
        }
      }
      return { replaced: totalReplaced2, files: filesChanged2, errors: errors2 };
    }
    const { files, find, replace: replaceText, useRegex = false, caseSensitive = false, wholeWord = false } = args;
    if (!files || !find)
      return { replaced: 0, files: 0, errors: [] };
    let pattern;
    try {
      let flags = "g";
      if (!caseSensitive)
        flags += "i";
      if (useRegex) {
        pattern = new RegExp(find, flags);
      } else {
        let esc = find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        if (wholeWord)
          esc = "\\b" + esc + "\\b";
        pattern = new RegExp(esc, flags);
      }
    } catch (e) {
      return { replaced: 0, files: 0, errors: [e.message] };
    }
    let totalReplaced = 0, filesChanged = 0;
    const errors = [];
    for (const fp of files) {
      try {
        const content = await fs.promises.readFile(fp, "utf8");
        const newContent = content.replace(pattern, replaceText);
        if (newContent !== content) {
          await fs.promises.writeFile(fp, newContent, "utf8");
          totalReplaced += (content.match(pattern) || []).length;
          filesChanged++;
        }
      } catch (e) {
        errors.push(fp + ": " + (e.message || e));
      }
    }
    return { replaced: totalReplaced, files: filesChanged, errors };
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  registerSearchIpc
});
