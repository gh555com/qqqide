"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// shell/portable-paths.ts
var portable_paths_exports = {};
__export(portable_paths_exports, {
  applyPortablePaths: () => applyPortablePaths,
  getAppRoot: () => getAppRoot
});
module.exports = __toCommonJS(portable_paths_exports);
var path = __toESM(require("path"));
var fs = __toESM(require("fs"));
function getAppRoot() {
  const execLower = process.execPath.replace(/\\/g, "/").toLowerCase();
  if (execLower.includes("node_modules") || execLower.includes("electron/dist")) {
    return path.resolve(__dirname, "..");
  }
  return path.dirname(process.execPath);
}
function applyPortablePaths() {
  const root = getAppRoot();
  const userData = path.join(root, "Data");
  const cache = path.join(userData, "Cache");
  const temp = path.join(userData, "Temp");
  const logs = path.join(userData, "Logs");
  const crashDumps = path.join(userData, "CrashDumps");
  process.env.TMP = temp;
  process.env.TEMP = temp;
  if (process.platform === "win32") {
    process.env.LOCALAPPDATA = path.join(userData, "LocalAppData");
  }
  for (const d of [
    userData,
    cache,
    temp,
    logs,
    crashDumps,
    path.join(userData, "LocalAppData")
  ]) {
    try {
      fs.mkdirSync(d, { recursive: true });
    } catch {
    }
  }
  let app;
  try {
    app = require("electron").app;
  } catch {
    console.warn("[portable-paths] electron.app not available, skipping path redirects");
    return { root, userData, cache, logs };
  }
  if (!app) {
    console.warn("[portable-paths] electron.app is undefined, skipping path redirects");
    return { root, userData, cache, logs };
  }
  app.setPath("userData", userData);
  app.setPath("sessionData", userData);
  app.setPath("cache", cache);
  app.setPath("temp", temp);
  app.setPath("logs", logs);
  app.setPath("crashDumps", crashDumps);
  try {
    app.setAppLogsPath(logs);
  } catch {
  }
  app.commandLine.appendSwitch("user-data-dir", userData);
  app.commandLine.appendSwitch("disk-cache-dir", cache);
  app.commandLine.appendSwitch(
    "disable-features",
    "DefaultBrowser,MediaRouter,OptimizationHints,PreloadMediaEngagementData,SafeBrowsing,TranslateUI,InterestFeedContentSuggestions,PrivacySandboxSettings4"
  );
  app.commandLine.appendSwitch("no-default-browser-check");
  app.commandLine.appendSwitch("disable-background-networking");
  app.commandLine.appendSwitch("disable-component-update");
  app.commandLine.appendSwitch("disable-domain-reliability");
  app.commandLine.appendSwitch("disable-sync");
  app.commandLine.appendSwitch("metrics-recording-only");
  app.commandLine.appendSwitch("disable-default-apps");
  try {
    const crashReporter = require("electron").crashReporter;
    if (crashReporter) {
      crashReporter.start({ uploadToServer: false });
    }
  } catch {
  }
  setImmediate(() => cleanupStaleTemp(temp, 24 * 60 * 60 * 1e3));
  setImmediate(() => cleanupStaleTemp(path.join(userData, "LocalAppData"), 24 * 60 * 60 * 1e3));
  return { root, userData, cache, logs };
}
function cleanupStaleTemp(dir, maxAgeMs) {
  const now = Date.now();
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      try {
        const stat = fs.statSync(full);
        if (now - stat.mtimeMs <= maxAgeMs)
          continue;
        if (entry.isDirectory()) {
          fs.rmSync(full, { recursive: true, force: true });
        } else {
          fs.unlinkSync(full);
        }
      } catch {
      }
    }
  } catch {
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  applyPortablePaths,
  getAppRoot
});
