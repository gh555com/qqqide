"use strict";
// ============================================================================
// portable-paths.ts
// MUST be imported BEFORE any other electron module that touches paths.
// Redirects ALL chromium/electron writable paths to the app directory,
// so we never write a single byte to C:\Users\... / AppData / Registry.
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.applyPortablePaths = exports.getAppRoot = void 0;
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
/** Returns the directory containing the running executable. */
function getAppRoot() {
    // Detect dev mode without relying on electron.app (which may not be ready
    // at bundle top-level execution time in some environments).
    // Dev: process.execPath = .../node_modules/electron/dist/electron.exe
    // Packaged: process.execPath = .../qqq-shell.exe (no node_modules in path)
    const execLower = process.execPath.replace(/\\/g, '/').toLowerCase();
    if (execLower.includes('node_modules') || execLower.includes('electron/dist')) {
        return path.resolve(__dirname, '..');
    }
    return path.dirname(process.execPath);
}
exports.getAppRoot = getAppRoot;
/** Apply portable redirects. Call this BEFORE app.whenReady(). */
function applyPortablePaths() {
    const root = getAppRoot();
    const userData = path.join(root, 'userData');
    const cache = path.join(root, 'cache');
    const temp = path.join(root, 'temp');
    const logs = path.join(root, 'logs');
    const crashDumps = path.join(root, 'crashDumps');
    // ensure directories exist
    for (const d of [userData, cache, temp, logs, crashDumps]) {
        try {
            fs.mkdirSync(d, { recursive: true });
        }
        catch { /* ignore */ }
    }
    // Lazily access electron.app — at this point electron main process is running
    // so require('electron') WILL return the API object.
    let app;
    try {
        app = require('electron').app;
    }
    catch {
        console.warn('[portable-paths] electron.app not available, skipping path redirects');
        return { root, userData, cache, logs };
    }
    if (!app) {
        console.warn('[portable-paths] electron.app is undefined, skipping path redirects');
        return { root, userData, cache, logs };
    }
    app.setPath('userData', userData);
    app.setPath('sessionData', userData);
    app.setPath('cache', cache);
    app.setPath('temp', temp);
    app.setPath('logs', logs);
    app.setPath('crashDumps', crashDumps);
    try {
        app.setAppLogsPath(logs);
    }
    catch { /* older electron */ }
    // chromium-level redirects (some still leak to default unless cli switches set)
    app.commandLine.appendSwitch('user-data-dir', userData);
    app.commandLine.appendSwitch('disk-cache-dir', cache);
    // explicitly disable features that may write registry / appdata
    app.commandLine.appendSwitch('no-default-browser-check');
    app.commandLine.appendSwitch('disable-background-networking');
    app.commandLine.appendSwitch('disable-component-update');
    app.commandLine.appendSwitch('disable-domain-reliability');
    app.commandLine.appendSwitch('disable-sync');
    app.commandLine.appendSwitch('metrics-recording-only');
    app.commandLine.appendSwitch('disable-default-apps');
    return { root, userData, cache, logs };
}
exports.applyPortablePaths = applyPortablePaths;
//# sourceMappingURL=portable-paths.js.map