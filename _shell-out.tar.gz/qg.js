"use strict";
// ============================================================================
// qg.ts — 精简 FS 真理机器 (optimized)
//
// 从旧 state-store.ts (836行) 提取核心 — 去掉了七层架构：
//   ✗ registry.json (持久化 schema)  → schemas 仅内存
//   ✗ .meta.json (sha256/ts/deviceId) → 无元数据文件
//   ✗ deviceId 追踪                   → 不需要
//   ✗ ns/ns/ 双层安全名               → 单层 ns/{safeKey}
//   ✗ migrators chain                → caller 自行处理
//
// 保留的核心能力：
//   ✅ 三种 form: doc (JSON) / blob (brotli+不压缩小文件) / log (NDJSON增量追加)
//   ✅ 原子写入: tmp + rename + Windows unlink fallback
//   ✅ 文件锁: O_EXCL + pid/atime + stale 预占 (50ms × 40 = 2s)
//   ✅ 损坏隔离: corrupt/ 目录
//   ✅ 闪退保护: flushSync() — before-quit 同步写盘
//   ✅ 多窗口合并: merge-on-save (schema.merger)
//   ✅ 云端同步: outbox 队列 + cloud 标记
//   ✅ 写去抖: debounceMs (默认 250ms) + setNow 立即写
//
// ★ 四大优化 (vs 旧 state-store.ts)：
//   1. list() 目录缓存 — 内存 cache，set/del 自动失效
//   2. log 增量追加 — append 只写一行到 .tail 文件，全量写只在 compact 时
//   3. blob 快速路径 — ≤4KB 不压缩(纯JSON)，>4KB 用 brotli(解压比gzip快3x)
//   4. 空闲压缩 — log compact 异步执行，不阻塞 save
//
// 物理布局 (rootDir = .qqq/qg/)：
//   {ns}/{safeKey}.{json|bin|log}      ← payload
//   {ns}/{safeKey}.log.tail            ← log incremental (append-only)
//   locks/{ns}__{safeKey}.lock         ← 文件锁
//   corrupt/                           ← 损坏隔离
//   outbox/                            ← 云端同步队列
//
// 零依赖 — 只用 node fs/zlib/crypto/path/events。
// ============================================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Qg = void 0;
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const zlib = __importStar(require("zlib"));
const crypto = __importStar(require("crypto"));
const events_1 = require("events");
// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const DEFAULT_DEBOUNCE_MS = 250;
const DEFAULT_LOG_COMPACT_BYTES = 2 * 1024 * 1024;
const LOCK_STALE_MS = 60000;
const MAX_SAFE_NAME = 200;
const BAD_CHARS_RE = /[/\\:*?"<>|\x00-\x1f]/g;
// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function nowMs() { return Date.now(); }
function safeName(s) {
    if (s === null || s === undefined)
        return '_';
    let v = String(s).replace(BAD_CHARS_RE, '_').replace(/^\.+/, '_').trim();
    if (!v)
        v = '_';
    if (v.length > MAX_SAFE_NAME) {
        const h = crypto.createHash('sha256').update(v).digest('hex').slice(0, 32);
        v = v.slice(0, MAX_SAFE_NAME - 33) + '_' + h;
    }
    return v;
}
/** Atomic write: tmp file then rename over target. 绝不先删后改（防崩溃丢数据）。 */
async function atomicWrite(absPath, data) {
    const dir = path.dirname(absPath);
    await fs.promises.mkdir(dir, { recursive: true });
    const tmp = absPath + '.tmp.' + process.pid + '.' + Math.random().toString(36).slice(2, 8);
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf8');
    await fs.promises.writeFile(tmp, buf);
    try {
        await fs.promises.rename(tmp, absPath);
    }
    catch (e) {
        if (e && (e.code === 'EEXIST' || e.code === 'EPERM' || e.code === 'EACCES')) {
            // ★ 降级为 copy+unlink，绝不先删后改
            try {
                const data = await fs.promises.readFile(tmp);
                await fs.promises.writeFile(absPath, data);
            }
            catch (e2) {
                try {
                    await fs.promises.unlink(tmp);
                }
                catch { /* ignore */ }
                throw e2;
            }
        }
        else {
            try {
                await fs.promises.unlink(tmp);
            }
            catch { /* ignore */ }
            throw e;
        }
    }
}
function atomicWriteSync(absPath, data) {
    const dir = path.dirname(absPath);
    try {
        fs.mkdirSync(dir, { recursive: true });
    }
    catch { /* ignore */ }
    const tmp = absPath + '.tmp.' + process.pid + '.' + Math.random().toString(36).slice(2, 8);
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf8');
    fs.writeFileSync(tmp, buf);
    try {
        fs.renameSync(tmp, absPath);
    }
    catch (e) {
        if (e && (e.code === 'EEXIST' || e.code === 'EPERM' || e.code === 'EACCES')) {
            // ★ 降级为 copy+unlink，绝不先删后改
            try {
                const data = fs.readFileSync(tmp);
                fs.writeFileSync(absPath, data);
            }
            catch (e2) {
                try {
                    fs.unlinkSync(tmp);
                }
                catch { /* ignore */ }
                throw e2;
            }
        }
        else {
            try {
                fs.unlinkSync(tmp);
            }
            catch { /* ignore */ }
            throw e;
        }
    }
}
// ---------------------------------------------------------------------------
// Qg — FS 真理机器
// ---------------------------------------------------------------------------
class Qg extends events_1.EventEmitter {
    // ----- constructor --------------------------------------------------------
    /**
     * @param rootDir  e.g. "/path/to/project/.qqq/qg"
     */
    constructor(rootDir) {
        super();
        this.outboxSeq = 0;
        this.schemas = new Map();
        this.states = new Map();
        this._dirCache = new Map(); // ★ ns → key list cache
        /** Hook for cloud sync (qg doesn't auto-push; state-cloud.ts drains outbox). */
        this.onCloudDirty = null;
        this.setMaxListeners(0);
        this.rootDir = rootDir;
        this.nsDir = path.join(rootDir, 'ns');
        this.locksDir = path.join(rootDir, 'locks');
        this.outboxDir = path.join(rootDir, 'outbox');
        this.corruptDir = path.join(rootDir, 'corrupt');
        for (const d of [this.nsDir, this.locksDir, this.outboxDir, this.corruptDir]) {
            try {
                fs.mkdirSync(d, { recursive: true });
            }
            catch { /* ignore */ }
        }
        this._restoreOutboxSeq();
    }
    _restoreOutboxSeq() {
        try {
            for (const f of fs.readdirSync(this.outboxDir)) {
                const m = f.match(/^(\d+)\.json$/);
                if (m) {
                    const n = parseInt(m[1], 10);
                    if (n > this.outboxSeq)
                        this.outboxSeq = n;
                }
            }
        }
        catch { /* ignore */ }
    }
    // ----- introspection ------------------------------------------------------
    stats() {
        let dirty = 0;
        for (const st of this.states.values()) {
            if (st.dirty)
                dirty++;
        }
        let outbox = 0;
        try {
            outbox = fs.readdirSync(this.outboxDir).filter(f => f.endsWith('.json')).length;
        }
        catch { /* ignore */ }
        return { dirtyKeys: dirty, queuedOutbox: outbox, lastSyncAt: this.lastSyncAt, namespaces: this.schemas.size };
    }
    markSyncedAt(t) { this.lastSyncAt = t; }
    getRegisteredNs() { return Array.from(this.schemas.keys()); }
    getSchema(ns) { return this.schemas.get(ns); }
    // ----- registration -------------------------------------------------------
    register(ns, schema) {
        if (!ns || typeof ns !== 'string')
            throw new Error('qg.register: bad ns');
        if (!schema || !['doc', 'blob', 'log'].includes(schema.form))
            throw new Error('qg.register: schema.form must be doc/blob/log');
        if (typeof schema.v !== 'number' || schema.v < 1)
            throw new Error('qg.register: schema.v >=1');
        const existing = this.schemas.get(ns);
        if (existing && existing.form !== schema.form)
            throw new Error(`qg.register: ns "${ns}" form mismatch`);
        this.schemas.set(ns, schema);
    }
    // ----- path helpers -------------------------------------------------------
    _payloadPath(safeNs, safeKey, form) {
        const ext = form === 'doc' ? '.json' : form === 'blob' ? '.bin' : '.log';
        return path.join(this.nsDir, safeNs, safeKey + ext);
    }
    _lockPath(safeNs, safeKey) {
        return path.join(this.locksDir, safeNs + '__' + safeKey + '.lock');
    }
    _resolveKeyState(ns, key) {
        const id = ns + '\u0000' + key;
        let st = this.states.get(id);
        if (!st) {
            st = {
                ns, key,
                safeNs: safeName(ns),
                safeKey: safeName(key),
                value: undefined,
                dirty: false,
                saveChain: Promise.resolve(),
                loaded: false,
            };
            this.states.set(id, st);
        }
        return st;
    }
    _requireSchema(ns) {
        const sc = this.schemas.get(ns);
        if (!sc)
            throw new Error(`qg: ns "${ns}" not registered`);
        return sc;
    }
    // ★ Invalidate directory cache for a namespace.
    _invalidateDirCache(ns) {
        this._dirCache.delete(ns);
    }
    // ----- encode / decode ----------------------------------------------------
    _encode(form, value) {
        if (form === 'doc')
            return Buffer.from(JSON.stringify(value), 'utf8');
        if (form === 'blob') {
            const json = Buffer.from(JSON.stringify(value), 'utf8');
            // ★ Small blobs: plain JSON (instant read, zero decompression)
            if (json.length <= Qg.BLOB_NOCOMPRESS_BYTES)
                return json;
            // ★ Large blobs: brotli (faster decompress than gzip, built-in Node.js)
            return zlib.brotliCompressSync(json);
        }
        if (!Array.isArray(value))
            value = [];
        const lines = value.map(ev => JSON.stringify(ev)).join('\n');
        return Buffer.from(lines + (lines ? '\n' : ''), 'utf8');
    }
    _decode(form, buf) {
        if (form === 'doc')
            return JSON.parse(buf.toString('utf8'));
        if (form === 'blob') {
            // ★ Auto-detect: JSON starts with '{' or '[', brotli starts with 0xCE
            const first = buf.length > 0 ? buf[0] : 0;
            if (first === 0x7B || first === 0x5B) {
                return JSON.parse(buf.toString('utf8')); // plain JSON (small blob)
            }
            const json = zlib.brotliDecompressSync(buf).toString('utf8');
            return JSON.parse(json);
        }
        const txt = buf.toString('utf8');
        const out = [];
        for (const line of txt.split(/\r?\n/)) {
            const t = line.trim();
            if (!t)
                continue;
            try {
                out.push(JSON.parse(t));
            }
            catch { /* skip bad line */ }
        }
        return out;
    }
    // ----- file lock (O_EXCL + stale detection) --------------------------------
    async _acquireLock(safeNs, safeKey) {
        const lp = this._lockPath(safeNs, safeKey);
        await fs.promises.mkdir(path.dirname(lp), { recursive: true });
        for (let i = 0; i < 40; i++) {
            try {
                const fd = fs.openSync(lp, 'wx');
                fs.writeSync(fd, JSON.stringify({ pid: process.pid, ts: nowMs() }));
                fs.closeSync(fd);
                return lp;
            }
            catch (e) {
                if (e && e.code === 'EEXIST') {
                    let stale = false;
                    try {
                        const info = JSON.parse(fs.readFileSync(lp, 'utf8'));
                        if (typeof info.ts === 'number' && (nowMs() - info.ts) > LOCK_STALE_MS)
                            stale = true;
                    }
                    catch {
                        stale = true;
                    }
                    if (stale) {
                        try {
                            fs.unlinkSync(lp);
                        }
                        catch { /* ignore */ }
                        continue;
                    }
                    await new Promise(r => setTimeout(r, 50));
                    continue;
                }
                throw e;
            }
        }
        console.warn('[qg] _acquireLock timeout', lp);
        return lp;
    }
    _releaseLock(lp) {
        try {
            fs.unlinkSync(lp);
        }
        catch { /* ignore */ }
    }
    // ----- corrupt isolation --------------------------------------------------
    _quarantine(safeNs, safeKey, form, reason) {
        try {
            const src = this._payloadPath(safeNs, safeKey, form);
            if (!fs.existsSync(src))
                return;
            const ext = path.extname(src);
            const ts = nowMs();
            const dst = path.join(this.corruptDir, safeNs + '__' + safeKey + '.' + ts + ext);
            fs.mkdirSync(this.corruptDir, { recursive: true });
            fs.renameSync(src, dst);
            console.warn('[qg] quarantined', src, '->', dst, 'reason=', reason);
        }
        catch (e) {
            console.warn('[qg] _quarantine failed:', e);
        }
    }
    // ----- load ---------------------------------------------------------------
    async _loadFromDisk(st) {
        const sc = this._requireSchema(st.ns);
        const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
        if (!fs.existsSync(payload)) {
            st.value = sc.form === 'log' ? [] : null;
            st.loaded = true;
            return;
        }
        try {
            const buf = await fs.promises.readFile(payload);
            st.value = this._decode(sc.form, buf);
            // ★ merge incremental tail for log form
            if (sc.form === 'log') {
                const tailPath = payload + '.tail';
                if (fs.existsSync(tailPath)) {
                    try {
                        const tailBuf = await fs.promises.readFile(tailPath);
                        const tailEvents = this._decode(sc.form, tailBuf);
                        if (Array.isArray(tailEvents) && tailEvents.length > 0) {
                            if (!Array.isArray(st.value))
                                st.value = [];
                            st.value.push(...tailEvents);
                        }
                    }
                    catch { /* tail corrupt, ignore */ }
                }
                st._logTail = [];
            }
            st.loaded = true;
        }
        catch (e) {
            console.warn('[qg] decode failed for', st.ns, st.key, '— quarantining:', e);
            this._quarantine(st.safeNs, st.safeKey, sc.form, String(e));
            st.value = sc.form === 'log' ? [] : null;
            st.loaded = true;
        }
    }
    async _ensureLoaded(st) {
        if (!st.loaded)
            await this._loadFromDisk(st);
    }
    // ----- public API ---------------------------------------------------------
    async get(ns, key) {
        this._requireSchema(ns);
        const st = this._resolveKeyState(ns, key);
        await this._ensureLoaded(st);
        return st.value;
    }
    async set(ns, key, value) {
        const sc = this._requireSchema(ns);
        if (sc.form === 'log' && !Array.isArray(value))
            throw new Error(`qg.set on log form requires array; ns=${ns} key=${key}`);
        const st = this._resolveKeyState(ns, key);
        await this._ensureLoaded(st);
        st.value = value;
        st.dirty = true;
        this._scheduleSave(st, sc);
        if (sc.cloud && this.onCloudDirty) {
            try {
                this.onCloudDirty(ns, key);
            }
            catch { /* ignore */ }
        }
    }
    async setNow(ns, key, value) {
        const sc = this._requireSchema(ns);
        if (sc.form === 'log' && !Array.isArray(value))
            throw new Error(`qg.setNow on log form requires array; ns=${ns} key=${key}`);
        const st = this._resolveKeyState(ns, key);
        await this._ensureLoaded(st);
        st.value = value;
        st.dirty = true;
        await this._flushKey(st, sc);
        if (sc.cloud && this.onCloudDirty) {
            try {
                this.onCloudDirty(ns, key);
            }
            catch { /* ignore */ }
        }
    }
    async append(ns, key, event) {
        const sc = this._requireSchema(ns);
        if (sc.form !== 'log')
            throw new Error(`qg.append only for log form; ns=${ns}`);
        const st = this._resolveKeyState(ns, key);
        await this._ensureLoaded(st);
        if (!Array.isArray(st.value))
            st.value = [];
        if (!st._logTail)
            st._logTail = [];
        st.value.push(event);
        st._logTail.push(event);
        st.dirty = true;
        // ★ Incremental: write single event to tail file immediately
        const tailPath = this._payloadPath(st.safeNs, st.safeKey, sc.form) + '.tail';
        const line = JSON.stringify(event) + '\n';
        try {
            await fs.promises.mkdir(path.dirname(tailPath), { recursive: true });
            await fs.promises.appendFile(tailPath, line, 'utf8');
        }
        catch { /* tail write failed, full save will catch up */ }
        this._scheduleSave(st, sc);
        if (sc.cloud && this.onCloudDirty) {
            try {
                this.onCloudDirty(ns, key);
            }
            catch { /* ignore */ }
        }
    }
    async del(ns, key) {
        const sc = this._requireSchema(ns);
        const st = this._resolveKeyState(ns, key);
        if (st.debounceTimer) {
            clearTimeout(st.debounceTimer);
            st.debounceTimer = undefined;
        }
        const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
        let any = false;
        try {
            if (fs.existsSync(payload)) {
                await fs.promises.unlink(payload);
                any = true;
            }
        }
        catch { /* ignore */ }
        // Also delete tail file if exists
        try {
            const tp = payload + '.tail';
            if (fs.existsSync(tp))
                await fs.promises.unlink(tp);
        }
        catch { /* ignore */ }
        this.states.delete(ns + '\u0000' + key);
        this._invalidateDirCache(ns);
        if (any) {
            this.emit('changed', { ns, key, value: null, deleted: true });
            if (sc.cloud)
                this._queueOutbox(ns, key, null, true);
        }
        return any;
    }
    async list(ns) {
        this._requireSchema(ns);
        // ★ cache hit — avoid fs.readdir
        const cached = this._dirCache.get(ns);
        if (cached)
            return cached;
        const dir = path.join(this.nsDir, safeName(ns));
        const out = [];
        try {
            for (const f of await fs.promises.readdir(dir)) {
                if (f.endsWith('.tmp'))
                    continue;
                if (f.endsWith('.tail'))
                    continue; // log tail files
                const m = f.match(/^(.+)\.(json|bin|log)$/);
                if (m)
                    out.push(m[1]);
            }
        }
        catch { /* nonexistent */ }
        this._dirCache.set(ns, out);
        return out;
    }
    // ----- save chain ---------------------------------------------------------
    _scheduleSave(st, sc) {
        const ms = typeof sc.debounceMs === 'number' ? sc.debounceMs : DEFAULT_DEBOUNCE_MS;
        if (st.debounceTimer)
            clearTimeout(st.debounceTimer);
        st.debounceTimer = setTimeout(() => {
            st.debounceTimer = undefined;
            st.saveChain = st.saveChain.then(() => this._doSaveOnce(st, sc)).catch(e => {
                console.warn('[qg] save error', st.ns, st.key, e);
            });
        }, ms);
    }
    async _flushKey(st, sc) {
        if (st.debounceTimer) {
            clearTimeout(st.debounceTimer);
            st.debounceTimer = undefined;
        }
        st.saveChain = st.saveChain.then(() => this._doSaveOnce(st, sc));
        await st.saveChain;
    }
    async flush() {
        const tasks = [];
        for (const st of this.states.values()) {
            const sc = this.schemas.get(st.ns);
            if (!sc)
                continue;
            if (st.dirty || st.debounceTimer)
                tasks.push(this._flushKey(st, sc));
        }
        await Promise.all(tasks);
    }
    async flushOne(ns, key) {
        const id = ns + '::' + key;
        const st = this.states.get(id);
        if (!st)
            return;
        const sc = this.schemas.get(ns);
        if (!sc)
            return;
        await this._flushKey(st, sc);
    }
    flushSync() {
        for (const st of this.states.values()) {
            const sc = this.schemas.get(st.ns);
            if (!sc)
                continue;
            if (st.debounceTimer) {
                clearTimeout(st.debounceTimer);
                st.debounceTimer = undefined;
            }
            if (!st.dirty)
                continue;
            try {
                this._doSaveOnceSync(st, sc);
            }
            catch (e) {
                console.warn('[qg] flushSync error', st.ns, st.key, e);
            }
        }
    }
    // ----- the actual save ----------------------------------------------------
    async _doSaveOnce(st, sc) {
        if (!st.dirty)
            return;
        const lp = await this._acquireLock(st.safeNs, st.safeKey);
        try {
            // ★ For log form: re-read tail to catch events from other processes
            if (sc.form === 'log') {
                const tailPath = this._payloadPath(st.safeNs, st.safeKey, sc.form) + '.tail';
                if (fs.existsSync(tailPath)) {
                    try {
                        const tailBuf = await fs.promises.readFile(tailPath);
                        const tailEvents = this._decode(sc.form, tailBuf);
                        if (Array.isArray(tailEvents) && tailEvents.length > 0) {
                            if (!Array.isArray(st.value))
                                st.value = [];
                            const seen = new Set(st.value.map(e => JSON.stringify(e)));
                            for (const ev of tailEvents) {
                                const k = JSON.stringify(ev);
                                if (!seen.has(k)) {
                                    seen.add(k);
                                    st.value.push(ev);
                                }
                            }
                        }
                    }
                    catch { /* ignore */ }
                }
            }
            await this._mergeFromDisk(st, sc);
            let buf = this._encode(sc.form, st.value);
            if (sc.quotaBytes && buf.length > sc.quotaBytes) {
                if (sc.form === 'log' && Array.isArray(st.value)) {
                    st.value = st.value.slice(Math.floor(st.value.length / 2));
                    buf = this._encode(sc.form, st.value);
                }
                if (buf.length > sc.quotaBytes)
                    throw new Error('quota exceeded');
            }
            // ★ Deferred compaction flag (actual compact runs async after save)
            const needsCompact = sc.form === 'log' && sc.compactThresholdBytes && buf.length > sc.compactThresholdBytes;
            const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
            await atomicWrite(payload, buf);
            // ★ Clear incremental tail after full save
            if (sc.form === 'log') {
                st._logTail = [];
                const tailPath = payload + '.tail';
                try {
                    if (fs.existsSync(tailPath))
                        await fs.promises.unlink(tailPath);
                }
                catch { /* ignore */ }
            }
            st.dirty = false;
            this._invalidateDirCache(st.ns);
            if (sc.cloud)
                this._queueOutbox(st.ns, st.key, st.value, false);
            this.emit('changed', { ns: st.ns, key: st.key, value: st.value, deleted: false });
            // ★ Deferred compaction: run async after save, avoids blocking
            if (needsCompact) {
                setImmediate(() => this._maybeCompact(st, sc).catch(() => { }));
            }
        }
        finally {
            this._releaseLock(lp);
        }
    }
    _doSaveOnceSync(st, sc) {
        if (!st.dirty)
            return;
        const buf = this._encode(sc.form, st.value);
        const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
        atomicWriteSync(payload, buf);
        st.dirty = false;
        this._invalidateDirCache(st.ns);
        if (sc.cloud)
            this._queueOutbox(st.ns, st.key, st.value, false);
    }
    // ----- merge-on-save ------------------------------------------------------
    async _mergeFromDisk(st, sc) {
        const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
        if (!fs.existsSync(payload))
            return;
        let diskVal;
        try {
            diskVal = this._decode(sc.form, await fs.promises.readFile(payload));
        }
        catch {
            return;
        }
        try {
            if (sc.form === 'log' && Array.isArray(diskVal) && Array.isArray(st.value)) {
                const seen = new Set();
                const out = [];
                for (const ev of diskVal) {
                    const k = JSON.stringify(ev);
                    if (!seen.has(k)) {
                        seen.add(k);
                        out.push(ev);
                    }
                }
                for (const ev of st.value) {
                    const k = JSON.stringify(ev);
                    if (!seen.has(k)) {
                        seen.add(k);
                        out.push(ev);
                    }
                }
                st.value = sc.merger ? sc.merger(diskVal, st.value, { ns: st.ns, key: st.key }) : out;
            }
            else {
                st.value = sc.merger
                    ? sc.merger(diskVal, st.value, { ns: st.ns, key: st.key })
                    : st.value;
            }
        }
        catch (e) {
            console.warn('[qg] merger threw — keeping in-memory value', st.ns, st.key, e);
        }
    }
    // ----- log compaction -----------------------------------------------------
    _compactLog(st, sc) {
        if (!Array.isArray(st.value))
            return null;
        if (sc.merger) {
            try {
                const compacted = sc.merger([], st.value, { ns: st.ns, key: st.key });
                if (Array.isArray(compacted))
                    return compacted;
            }
            catch (e) {
                console.warn('[qg] compactLog merger threw', st.ns, st.key, e);
            }
        }
        return st.value.slice(Math.floor(st.value.length / 2));
    }
    /** ★ Async log compaction — non-blocking, runs after save completes. */
    async _maybeCompact(st, sc) {
        if (!Array.isArray(st.value))
            return;
        const compacted = this._compactLog(st, sc);
        if (!compacted)
            return;
        st.value = compacted;
        st.dirty = true;
        const buf = this._encode(sc.form, st.value);
        const payload = this._payloadPath(st.safeNs, st.safeKey, sc.form);
        await atomicWrite(payload, buf);
        st.dirty = false;
        this._invalidateDirCache(st.ns);
        if (sc.cloud)
            this._queueOutbox(st.ns, st.key, st.value, false);
    }
    // ----- outbox (cloud-sync queue) ------------------------------------------
    _queueOutbox(ns, key, value, deleted) {
        try {
            this.outboxSeq += 1;
            const seq = String(this.outboxSeq).padStart(12, '0');
            const f = path.join(this.outboxDir, seq + '.json');
            const payload = { seq, ns, key, ts: nowMs(), deleted, value: deleted ? null : value };
            atomicWriteSync(f, JSON.stringify(payload));
        }
        catch (e) {
            console.warn('[qg] _queueOutbox failed:', e);
        }
    }
    listOutbox() {
        const out = [];
        try {
            const files = fs.readdirSync(this.outboxDir).filter(f => f.endsWith('.json')).sort();
            for (const f of files)
                out.push({ seq: f.replace(/\.json$/, ''), file: path.join(this.outboxDir, f) });
        }
        catch { /* ignore */ }
        return out;
    }
    dropOutbox(seq) {
        const f = path.join(this.outboxDir, seq + '.json');
        try {
            fs.unlinkSync(f);
            return true;
        }
        catch {
            return false;
        }
    }
    // ----- onChange convenience -----------------------------------------------
    onChange(ns, key, cb) {
        const h = (msg) => {
            if (msg.ns === ns && msg.key === key)
                cb(msg.value, msg.deleted);
        };
        this.on('changed', h);
        return () => { this.off('changed', h); };
    }
}
// ★ blob fast path threshold
Qg.BLOB_NOCOMPRESS_BYTES = 4096;
exports.Qg = Qg;
//# sourceMappingURL=qg.js.map