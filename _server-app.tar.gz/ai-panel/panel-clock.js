// Copyright (C) 2025-2026 Sichuan Dream Technology Co., Ltd. All Rights Reserved.

'use strict';
// \u2550\u2550\u2550 panel-clock.js \u2550\u2550\u2550
// Floor timer, pie chart, autoSave, quest dropdown, tofu, boot

// ★ 全局变量已移除：_floorTimerId / _floorStartPerf / _floorCurrentTiming / _activeAiDiv
//   全部移入 agent 对象（agent._floorTimerId / agent._floorStartPerf 等）
//   保留：_lastPieTiming（canvas 去重缓存，无关 agent）、_autoSaveTimer（面板级）
var _lastPieTiming = null;
var _autoSaveTimer = null;

// ── 保存单个 agent 的当前楼层到 all.json（auto-save + beforeunload 共用）──
//   force: true → 跳过去重检查（beforeunload 用）
function _saveAgentFloor(ag, questId, force) {
    if (!ag || !ag._currentFloorNum || ag._currentFloorNum <= 0) return;
    if (typeof questStore === 'undefined' || !questStore || !questStore.saveFloor) return;
    var floorNum = ag._currentFloorNum;

    // ★ 安全网：_houses 为空且非新楼层时跳过，防重启后覆盖已有数据
    //   _lastAutoSaveLen === 0 仅在新楼层初始化时设置（panel-send.js），是唯一准入空 houses 的路径
    if ((!ag._houses || ag._houses.length === 0) && ag._lastAutoSaveLen !== 0) return;
    // ★ 跨面板写保护：只有建楼中的 agent（stopState='sending'）有权 auto-save
    //   非建楼面板的 agent（从 all.json 恢复，stopState='idle'）禁止写盘，防止覆盖真理数据
    //   force=true（beforeunload）绕过此限制
    if (!force && ag._stopState !== 'sending') return;
    // ★ 压缩保护：_compressing 期间 _ctx 处于不完整状态（三专家产出/回滚中间态），禁止 auto-save
    if (ag._compressing) return;
    if (!force) {
        // ★ 去重：仅在 conversation 增长时才写盘（避免无变化的 O(n) slice + payload 构建）
        var convLen = ag.conversation ? ag.conversation.length : 0;
        if (ag._lastAutoSaveLen && convLen <= ag._lastAutoSaveLen) return;
        ag._lastAutoSaveLen = convLen;
    }
    var payload;
    if (typeof window._a4BuildCompleteFloorPayload === 'function') {
        payload = window._a4BuildCompleteFloorPayload(ag, floorNum, { skipDomFlush: true });
    } else {
        payload = {
            question: (ag._lastUserInput && ag._lastUserInput.text) || '',
            conversation: ag.conversation ? ag.conversation.slice() : [],
            houses: (ag._houses || []).slice(),
            costWge: ag._floorCostWge,
            lastUserInput: ag._lastUserInput,
            passbyHouses: (ag._passbyBaseHouses || 0) + (ag._houses ? ag._houses.length : 0),
            passbyTokens: (ag._passbyBaseTokens || 0) + (typeof _computeFloorTokens === 'function' ? _computeFloorTokens(ag) : 0),
            passbyWge: (ag._passbyBaseWge || 0) + (ag._floorCostWge || 0),
            passbyTime: Date.now() + (ag._serverDrift || 0),
            passbyCity: ag._serverCity || '',
            createdAt: Date.now()
        };
    }
    questStore.saveFloor(questId, floorNum, payload).catch(function (e) {
        console.warn('[auto-save] saveFloor failed for q=' + questId + ' f=' + floorNum + ': ' + (e && e.message || e));
        if (typeof _writeFileLog === 'function') _writeFileLog('⚠ auto-save fail q=' + questId + ' f=' + floorNum + ': ' + (e && e.message || e));
    });
}

var _AUTOSAVE_INTERVAL = 5000;
var _autoSaveRunning = false;
// ★ 面板级持久定时器：仅主面板(panelId===1)执行，遍历共享 agentPool
//   三面板共享 parent.__qqq_agentPool，单一 auto-save 避免三写一读
function _ensureAutoSave() {
    if (typeof _panelId !== 'undefined' && _panelId !== 1) return;  // ★ 仅主面板写盘
    if (_autoSaveRunning) return;
    _autoSaveRunning = true;
    _autoSaveTimer = setInterval(function () {
        var pool = parent.__qqq_agentPool;
        if (!pool) return;
        var ids = Object.keys(pool);
        for (var i = 0; i < ids.length; i++) {
            _saveAgentFloor(pool[ids[i]], ids[i]);
        }
    }, _AUTOSAVE_INTERVAL);
}

// ── beforeunload：保存所有在建楼层（防崩溃丢数据）──
function _saveAllBeforeUnload() {
    var pool = parent.__qqq_agentPool;
    if (!pool) return;
    var ids = Object.keys(pool);
    for (var i = 0; i < ids.length; i++) {
        _saveAgentFloor(pool[ids[i]], ids[i], true);
    }
}
if (typeof window !== 'undefined') {
    window.addEventListener('beforeunload', _saveAllBeforeUnload);
    // ★ auto-save 面板级持久 timer：模块加载即启动，永不停止
    _ensureAutoSave();
}

function _showPieTooltip(html, cx, cy) {
    _postToHost({ type: 'qqq-pie-tooltip', action: 'show', html: html, clientX: cx, clientY: cy });
}
function _hidePieTooltip() {
    _postToHost({ type: 'qqq-pie-tooltip', action: 'hide' });
}

function drawPie(canvas, timing) {
    if (_lastPieTiming && timing &&
        _lastPieTiming.networkMs === timing.networkMs &&
        _lastPieTiming.aiMs === timing.aiMs &&
        _lastPieTiming.otherMs === timing.otherMs) return;
    _lastPieTiming = timing ? { networkMs: timing.networkMs, aiMs: timing.aiMs, otherMs: timing.otherMs } : null;
    var ctx = canvas.getContext('2d');
    var w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    var n = timing.networkMs || 0;
    var d = timing.aiMs || 0;
    var t = timing.otherMs || 0;
    var total = timing.totalMs || (n + d + t);
    if (total <= 0) { ctx.fillStyle = '#555'; ctx.beginPath(); ctx.arc(w / 2, h / 2, w / 2 - 3, 0, Math.PI * 2); ctx.fill(); canvas._segments = null; return; }
    t = Math.max(0, total - n - d);
    var parts = [
        { val: d, color: '#859900', label: 'AI', key: 'ai' },
        { val: n, color: '#cb4b16', label: 'Network', key: 'network' },
        { val: t, color: '#e6b800', label: 'Other', key: 'other' }
    ];
    var start = -Math.PI / 2;
    var segments = [];
    for (var i = 0; i < parts.length; i++) {
        if (parts[i].val <= 0) continue;
        var slice = (parts[i].val / total) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(w / 2, h / 2);
        ctx.arc(w / 2, h / 2, w / 2 - 3, start, start + slice);
        ctx.fillStyle = parts[i].color;
        ctx.fill();
        segments.push({ startAngle: start, endAngle: start + slice, label: parts[i].label, key: parts[i].key, ms: parts[i].val, color: parts[i].color });
        start += slice;
    }
    canvas._segments = segments;
    canvas._total = total;
}

// ── ge 显示格式化：2位小数，四舍五入，最小0.01 ──
function _formatGeDisplay(rawValue) {
    if (rawValue <= 0) return '0.00';
    var rounded = Math.round(rawValue * 100) / 100;
    if (rounded < 0.01) return '0.01';
    return rounded.toFixed(2);
}
function _formatGeRaw(rawValue) {
    // 保留最多6位小数，去尾零
    return rawValue.toFixed(6).replace(/\.?0+$/, '') || '0';
}

// ── 计费明细表格（点击 ge 消费区弹出悬浮层）──
function _buildBillingTable(houses, passby) {
    var _i2 = window._i || function (k, f) { return f; };
    var _fNum = passby ? passby.floorNum : 0;
    // ★ 列序：House → type → 工具数 → AI Lv → 时间消耗 → wge → 缓存命中率 → prompt_tokens → completion_tokens → total_tokens → 查账凭据
    var headers = [
        'House',
        'type',
        _i2('ai.billing.toolCount', '工具数'),
        'AI Lv',
        _i2('ai.billing.time', '时间消耗'),
        _i2('ai.billing.wge', 'wge'),
        _i2('ai.billing.cacheHit', '缓存命中率'),
        'prompt<br>tokens',
        'compl<br>tokens',
        'total<br>tokens',
        _i2('ai.billing.receipt', '查账凭据')
    ];
    // 表头：居中 + 自动换行（overlay 会跳过已设 whiteSpace）
    var html = '<table><thead><tr>';
    for (var i = 0; i < headers.length; i++) {
        var _thStyle = 'text-align:center;white-space:normal';
        if (i === 5) _thStyle += ';background:rgba(133,153,0,0.08)';
        html += '<th style="' + _thStyle + '">' + headers[i] + '</th>';
    }
    html += '</tr></thead><tbody>';
    for (var j = 0; j < houses.length; j++) {
        var h = houses[j];
        // ★ House 列：本层楼内编号 1 2 3 4 ...
        var houseLabel = (j + 1);
        var type = h.type === 'effect' ? (h.effectType || 'effect') : (h.type || '?');
        // toolCount: 运行时是 tools 数组，恢复后是 toolCount 数字
        var toolCount = (h.tools && Array.isArray(h.tools)) ? h.tools.length : (typeof h.toolCount === 'number' ? h.toolCount : 0);
        // AI 等级：从 tier label 提取数字
        var aiLv = '?';
        if (h.tier) {
            var parsed = parseInt(h.tier, 10);
            if (!isNaN(parsed)) aiLv = String(parsed);
        }
        // 时间消耗：ms → 四舍五入到整数 s
        var ms = h.ms || 0;
        var timeStr = Math.round(ms / 1000) + 's';
        var wge = h.wgeCost || 0;
        // 缓存命中率 / tokens / 查账凭据：effect 类型无 LLM 概念，统一 —
        var isEffect = h.type === 'effect';
        var cacheHit = isEffect ? '-' : (h.cacheHitRate >= 0 ? h.cacheHitRate.toFixed(1) + '%' : '?');
        var usage = h.usage;
        var promptTokens, completionTokens, totalTokens;
        if (isEffect) {
            promptTokens = '-';
            completionTokens = '-';
            totalTokens = '-';
        } else {
            promptTokens = usage ? (usage.prompt_tokens || 0) : 0;
            completionTokens = usage ? (usage.completion_tokens || 0) : 0;
            totalTokens = promptTokens + completionTokens;
        }
        var _cacheStyle = 'text-align:right';
        if (!isEffect && h.cacheHitRate >= 0 && h.cacheHitRate < 90) _cacheStyle += ';background:rgba(203,75,22,0.10)';
        var receipt = h.billingRequestId || '';
        html += '<tr>'
            + '<td style="text-align:right">' + houseLabel + '</td>'
            + '<td style="text-align:right">' + type + '</td>'
            + '<td style="text-align:right">' + toolCount + '</td>'
            + '<td style="text-align:right">' + aiLv + '</td>'
            + '<td style="text-align:right">' + timeStr + '</td>'
            + '<td style="text-align:right;background:rgba(133,153,0,0.08)">' + wge + '</td>'
            + '<td style="' + _cacheStyle + '">' + cacheHit + '</td>'
            + '<td style="text-align:right">' + promptTokens + '</td>'
            + '<td style="text-align:right">' + completionTokens + '</td>'
            + '<td style="text-align:right">' + totalTokens + '</td>'
            + '<td style="text-align:left">' + receipt + '</td>'
            + '</tr>';
    }
    html += '</tbody></table>';
    // ★ passby 行  "at 2026-07-03 12:23:17  Chengdu  ▶  q64.f12 passby: 6houses, 52k tokens, 9595 wge ≈ 1.0 ge"
    if (passby && passby.questId) {
        var _pbHouses = passby.houses || 0;
        var _pbTokens = passby.tokens || 0;
        var _pbWge = passby.wge || 0;
        var _pbGe = (_pbWge / 10000).toFixed(1);
        var _qNum = passby.questId.replace('q', '');
        var _fNum = passby.floorNum || 0;
        var _pbServerMs = passby.time || (Date.now() + (passby.drift || 0));
        var _pbTimeStr = _fmtTime(new Date(_pbServerMs));
        var _pbTokenStr = String(_pbTokens);
        html += '<div class="billing-passby" style="margin-top:8px;font-size:13px;color:var(--text-secondary,#888);text-align:center">'
            + '<span style="color:var(--text-tertiary,#666)">at ' + _pbTimeStr + '</span>'
            + (passby.city ? '\u3000<span style="color:var(--text-tertiary,#666)">' + passby.city + '</span>' : '')
            + '\u3000\u25b6\u3000q <span style="color:#cb4b16">' + _qNum + '</span> f <span style="color:#cb4b16">' + _fNum + '</span>'
            + ' passby: ' + _pbHouses + ' houses;\u3000'
            + _pbTokenStr + ' tokens;\u3000'
            + _pbWge + ' wge'
            + ' \u2248 ' + _pbGe + ' ge'
            + '</div>';
    }
    return html;
}

function _initClockBlock(aiDiv) {
    if (aiDiv._clockBlock) return;
    var block = document.createElement('div');
    block.className = 'msg-ai-clock';
    block.innerHTML = '<span class="clock"><span class="clock-min">0m</span><span class="clock-sec">:0s</span></span><canvas width="112" height="112"></canvas><span class="clock-cost" style="display:none;font-family:ui-monospace,monospace;font-weight:700;font-size:18px;color:var(--text-primary);margin-left:auto">0.00 ge</span>';
    aiDiv.appendChild(block);
    aiDiv._clockBlock = block;
    aiDiv._clockMin = block.querySelector('.clock-min');
    aiDiv._clockSec = block.querySelector('.clock-sec');
    aiDiv._clockCanvas = block.querySelector('canvas');
    aiDiv._clockCost = block.querySelector('.clock-cost');
    var clockCost = aiDiv._clockCost;
    clockCost.addEventListener('mouseenter', function (e) {
        var raw = clockCost._rawGe;
        if (raw === undefined || raw === null) return;
        _showPieTooltip('<span style="color:#fff">' + raw + ' ge</span>', e.clientX, e.clientY);
    });
    clockCost.addEventListener('mouseleave', function () { _hidePieTooltip(); });
    // ★ 点击 ge 消费区 → 悬浮层打开计费明细表格
    clockCost.addEventListener('click', function (e) {
        var houses = clockCost._houses;
        if (!houses || !houses.length) return;
        var html = _buildBillingTable(houses, clockCost._passby);
        if (html && typeof _postToHost === 'function') {
            _postToHost({ type: 'qqqide-overlay', action: 'open-table', html: '<div class="msg-ai">' + html + '</div>' });
        }
    });
    clockCost.style.cursor = 'pointer';
    var canvas = aiDiv._clockCanvas;
    canvas.addEventListener('mousemove', function (e) {
        if (!canvas._segments || !canvas._total) { _hidePieTooltip(); return; }
        var parts = [
            { key: 'ai', color: '#859900', label: 'AI' },
            { key: 'network', color: '#cb4b16', label: 'Net' },
            { key: 'other', color: '#e6b800', label: 'Other' }
        ];
        var segs = canvas._segments;
        var map = {};
        for (var si = 0; si < segs.length; si++) { map[segs[si].key] = segs[si]; }
        var html = '';
        for (var pi = 0; pi < parts.length; pi++) {
            var p = parts[pi];
            var s = map[p.key];
            var ms = s ? s.ms : 0;
            html += '<span style="display:inline-flex;align-items:center;gap:8px;margin-right:16px">'
                + '<svg width="20" height="20" style="flex-shrink:0"><circle cx="10" cy="10" r="9" fill="' + p.color + '"/></svg>'
                + '<span style="color:#fff">' + Math.round(ms / 1000) + 's</span></span>';
        }
        _showPieTooltip(html, e.clientX, e.clientY);
    });
    canvas.addEventListener('mouseleave', function () { _hidePieTooltip(); });
}

function startFloorTimer(aiDiv, ag, resume) {
    ag._activeAiDiv = aiDiv;
    if (!resume || !ag._floorStartPerf) {
        ag._floorStartPerf = performance.now();
    }
    ag._floorCurrentTiming = null;
    _initClockBlock(aiDiv);
    var clockMin = aiDiv._clockMin;
    var clockSec = aiDiv._clockSec;
    var canvas = aiDiv._clockCanvas;
    var elapsed = performance.now() - ag._floorStartPerf;
    var totalS = Math.floor(elapsed / 1000);
    var min = Math.floor(totalS / 60);
    var sec = totalS % 60;
    clockMin.textContent = min + 'm';
    clockSec.textContent = ':' + (sec < 10 ? '0' : '') + sec + 's';
    aiDiv._clockBlock.className = 'msg-ai-clock clock-ai';
    canvas.style.visibility = 'hidden';
    if (aiDiv._clockCost) {
        aiDiv._clockCost.textContent = '0.00 ge';
        aiDiv._clockCost.style.display = 'inline';
        aiDiv._clockCost._rawGe = null;
        aiDiv._clockCost._houses = null;
        aiDiv._clockCost._floorNum = null;
        aiDiv._clockCost._passby = null;
    }
    var _pieShown = false;
    var _lastN = 0, _lastD = 0, _lastT = 0;
    var _ag = ag;
    // ★ 防御：先清除可能残存的旧 timer（防止重复 start 产生僵尸）
    if (ag._floorTimerId) { clearInterval(ag._floorTimerId); ag._floorTimerId = null; }
    ag._floorTimerId = setInterval(function () {
        // ★ 守卫：用本地闭包 aiDiv 而非 _ag._activeAiDiv，防压缩/恢复路径篡改
        //   若 aiDiv 已脱离 DOM（Card 被驱逐），自停 timer
        if (!aiDiv || !aiDiv._clockBlock || !aiDiv._clockBlock.isConnected) {
            clearInterval(_ag._floorTimerId);
            _ag._floorTimerId = null;
            return;
        }
        var elapsed = performance.now() - _ag._floorStartPerf;
        var totalS = Math.floor(elapsed / 1000);
        var min = Math.floor(totalS / 60);
        var sec = totalS % 60;
        clockMin.textContent = min + 'm';
        clockSec.textContent = ':' + (sec < 10 ? '0' : '') + sec + 's';
        var at = _ag._floorTiming;
        var n = (at && at.networkMs) || 0;
        var d = (at && at.aiMs) || 0;
        var t = (at && at.otherMs) || 0;
        if (!_pieShown && (n > 0 || d > 0 || t > 0)) { _pieShown = true; canvas.style.visibility = 'visible'; }
        if (!_pieShown) return;
        var state = 'ai';
        if (t > _lastT) state = 'tool';
        else if (d > _lastD) state = 'ai';
        else if (n > _lastN) state = 'network';
        _lastN = n; _lastD = d; _lastT = t;
        aiDiv._clockBlock.className = 'msg-ai-clock clock-' + state;
        drawPie(canvas, { networkMs: n, aiMs: d, otherMs: t, totalMs: elapsed });
    }, 1000);
}

function stopFloorTimer(timing, ag) {
    if (ag._floorTimerId) { clearInterval(ag._floorTimerId); ag._floorTimerId = null; }
    ag._floorCurrentTiming = timing;
    var elapsed = performance.now() - ag._floorStartPerf;
    var totalS = Math.floor(elapsed / 1000);
    var min = Math.floor(totalS / 60);
    var sec = totalS % 60;
    var aiDiv = ag._activeAiDiv;
    if (aiDiv && aiDiv._clockBlock) {
        aiDiv._clockBlock.className = 'msg-ai-clock';
    }
    if (aiDiv && aiDiv._clockMin && aiDiv._clockCanvas) {
        aiDiv._clockMin.textContent = min + 'm';
        aiDiv._clockSec.textContent = ':' + (sec < 10 ? '0' : '') + sec + 's';
        var tm = timing || { networkMs: 0, aiMs: 0, otherMs: 0 };
        tm.totalMs = elapsed;
        if (elapsed > 0) { aiDiv._clockCanvas.style.visibility = 'visible'; drawPie(aiDiv._clockCanvas, tm); }
    }
    // ★ 不再清空 _activeAiDiv：它是 agent 与 Card DOM 的永久绑定，切 quest 时 switchQuest 负责重绑
    var durationMs = Math.round(elapsed);
    var record = {
        floorIndex: ag._ctx.totalFloors,
        durationMs: durationMs,
        networkMs: (timing && timing.networkMs) || 0,
        aiMs: (timing && timing.aiMs) || 0,
        otherMs: (timing && timing.otherMs) || 0,
        finishedAt: new Date().toISOString()
    };
    ag._floorTimings = ag._floorTimings || [];
    ag._floorTimings.push(record);
    ag._lastFloorTimingRecord = record;
}

// ── Quest 豆腐块 + hover 下拉 ──
var _questDrop = null;
var _q2Shimmer = null;
var _questDropTimer = null;
var _questSearchText = '';
var _questDropLimit = 20;
var _questSearchFocused = false;  // ★ 搜索框焦点追踪
function closeQuestDrop() {
    if (_questDrop) { _questDrop.remove(); _questDrop = null; }
    if (_q2Shimmer) { _q2Shimmer.remove(); _q2Shimmer = null; }
    _questSearchText = '';
    _questDropLimit = 20;
    _questSearchFocused = false;
    var bar = document.getElementById('quest-bar');
    if (bar) bar.classList.remove('quest-expanded');
}
function _matchQuest(query, title) {
    if (!query) return true;
    var tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (tokens.length === 0) return true;
    var lower = title.toLowerCase();
    for (var i = 0; i < tokens.length; i++) {
        var t = tokens[i];
        var pos = 0;
        var matched = true;
        for (var ci = 0; ci < t.length; ci++) {
            pos = lower.indexOf(t[ci], pos);
            if (pos === -1) { matched = false; break; }
            pos++;
        }
        if (!matched) return false;
    }
    return true;
}
async function renderQuestDrop() {
    if (!_questDrop) return;
    var allQuests = await questStore.list();
    if (!_questDrop) return;
    var query = _questSearchText;
    var filtered = query
        ? allQuests.filter(function (q) {
            var displayName = 'q' + (q.numericId || '?') + '.' + (q.title || '');
            return _matchQuest(query, displayName);
        })
        : allQuests;
    var displayCount = Math.min(filtered.length, _questDropLimit);
    var oldBody = _questDrop.querySelector('.quest-drop-body');
    if (oldBody) oldBody.remove();
    var body = document.createElement('div');
    body.className = 'quest-drop-body';
    for (var i = 0; i < displayCount; i++) {
        (function (s) {
            var item = document.createElement('div');
            item.className = 'quest-drop-item' + (s.id === questActiveId ? ' active' : '');
            var line = document.createElement('span');
            line.className = 'quest-drop-line';
            var prefix = document.createElement('span');
            prefix.className = 'quest-drop-prefix';
            prefix.textContent = 'q' + (s.numericId || '?') + '.  ';
            var title = document.createElement('span');
            title.className = 'quest-drop-title';
            title.textContent = s.title || '';
            line.appendChild(prefix);
            line.appendChild(title);
            item.appendChild(line);
            item.onclick = function (e) { e.stopPropagation(); closeQuestDrop(); switchQuest(s.id); };
            body.appendChild(item);
            // ★ 彗星电子钟：必须在 body.appendChild 之后插入，确保时钟在 document 中。
            //    否则 _tickCometClocks 在 _ensureCometClockTicking 的首次 tick 中 querySelectorAll 找不到。
            var _bq = window.__qqq_localBuildingQuests || {};
            var _reg = window.parent && window.parent.__qqq_buildingRegistry;
            var _isBld = _bq[s.id] || (_reg && _reg[s.id] && _reg[s.id].stopState === 'sending');
            if (_isBld) {
                _insertCometClock(prefix, s.id, item);
            }
            // ★ 豆沙包：未发送草稿标记，item 最右侧
            if (typeof _hasDraftFlag === 'function' && _hasDraftFlag(s.id)) {
                var bean = document.createElement('span');
                bean.className = 'quest-drop-draft-bean';
                bean.title = (typeof _i === 'function') ? _i('ai.draftBean', '有未发送的编辑内容') : '有未发送的编辑内容';
                item.appendChild(bean);
            }
        })(filtered[i]);
    }
    if (displayCount < filtered.length) {
        var more = document.createElement('div');
        more.className = 'quest-drop-item';
        more.style.cssText = 'color:var(--base01);font-style:italic;text-align:center;pointer-events:none';
        more.textContent = '\u2026 \u8fd8\u6709 ' + (filtered.length - displayCount) + ' \u6761 \u2026';
        body.appendChild(more);
    }
    if (filtered.length === 0) {
        var empty = document.createElement('div');
        empty.className = 'quest-drop-item';
        empty.style.cssText = 'color:var(--base01);font-style:italic';
        empty.textContent = query ? '(\u65e0\u5339\u914d)' : '(\u7a7a)';
        body.appendChild(empty);
    }
    _questDrop.appendChild(body);
    _questDrop._hasScrollbar = _questDrop.scrollHeight > _questDrop.clientHeight + 2;
    // ★ 更新悬浮层流光高度（豆腐块+下拉可视区，滚动加载更多时变高）
    if (_q2Shimmer) {
        var tofu2 = document.getElementById('quest-tofu');
        if (tofu2 && _questDrop) _q2Shimmer.style.height = (tofu2.offsetHeight + _questDrop.clientHeight) + 'px';
    }
}
async function openQuestDrop() {
    closeQuestDrop();
    _questDropLimit = 20;
    var tofu = document.getElementById('quest-tofu');
    if (!tofu) return;
    var bar = document.getElementById('quest-bar');
    var drop = document.createElement('div');
    drop.className = 'quest-drop show';
    var head = document.createElement('div');
    head.className = 'quest-drop-head';
    var addBtn = document.createElement('div');
    addBtn.className = 'quest-drop-add';
    addBtn.textContent = '+';
    addBtn.title = '\u65b0\u5efa Quest';
    addBtn.onclick = function (e) { e.stopPropagation(); closeQuestDrop(); createNewQuest(); };
    head.appendChild(addBtn);
    var search = document.createElement('input');
    search.className = 'quest-drop-search';
    search.placeholder = '\u7b5b\u9009...';
    search.value = _questSearchText;
    search.oninput = function () {
        _questSearchText = search.value;
        renderQuestDrop();
    };
    // ★ 搜索框获得焦点 → 阻止鼠标移出自动关闭
    search.addEventListener('focus', function () {
        _questSearchFocused = true;
    });
    search.addEventListener('blur', function () {
        _questSearchFocused = false;
        // 延迟关闭：允许 click 先落到下拉列表项上
        setTimeout(function () {
            if (!_questSearchFocused && _questDrop) {
                closeQuestDrop();
            }
        }, 150);
    });
    head.appendChild(search);
    drop.appendChild(head);
    bar.appendChild(drop);
    _questDrop = drop;
    // ★ 展开统一虚线框
    bar.classList.add('quest-expanded');
    drop.addEventListener('mouseenter', function () { clearTimeout(_questDropTimer); });
    drop.addEventListener('mouseleave', function () {
        // 搜索框有焦点 → 不自动关闭
        if (_questSearchFocused) return;
        _questDropTimer = setTimeout(closeQuestDrop, 120);
    });
    drop.addEventListener('click', function (e) { e.stopPropagation(); });
    drop.addEventListener('wheel', function (e) {
        if (_questDropLimit >= 60) return;
        if (drop._hasScrollbar) {
            if (drop.scrollTop + drop.clientHeight >= drop.scrollHeight - 4) {
                if (_questDropLimit < 40) _questDropLimit = 40;
                else _questDropLimit = 60;
                renderQuestDrop();
            }
        } else {
            if (_questDropLimit < 40) _questDropLimit = 40;
            else _questDropLimit = 60;
            renderQuestDrop();
        }
    });
    await renderQuestDrop();
    // ★ 悬浮层流光：覆盖整个虚线框区域（豆腐块+下拉可视区）
    if (_q2Shimmer) { _q2Shimmer.remove(); _q2Shimmer = null; }
    var sOverlay = document.createElement('div');
    sOverlay.className = 'q2-shimmer-overlay';
    sOverlay.style.top = '0';
    sOverlay.style.height = (tofu.offsetHeight + drop.clientHeight) + 'px';
    bar.appendChild(sOverlay);
    _q2Shimmer = sOverlay;
}
var _tofuEntry = null;  // 当前活跃 quest 的 index 条目，供编辑用

// ═══ 彗星电子钟：唯一真理机器驱动 ═══
// 中央真理：读 parent.__qqq_agentPool（所有面板读同一池），零脑分裂
// 位置：quest-tofu-prefix（招牌行）+ quest-drop-prefix（下拉每行）右下角
// 200ms 滴答 → 楼层封顶消失
var _cometClockTimer = null;

function _tickCometClocks() {
    var clocks = document.querySelectorAll('.comet-clock');
    var pool = window.parent && window.parent.__qqq_agentPool;
    var reg = window.parent && window.parent.__qqq_buildingRegistry;  // 兜底用
    var localBQ = window.__qqq_localBuildingQuests || {};   // ★ IPC 同步的本地集合，优先
    var now = performance.now();
    var hasVisible = false;
    for (var i = 0; i < clocks.length; i++) {
        var clk = clocks[i];
        var qid = clk.getAttribute('data-qid');
        // ★ 本地集合为主（IPC 可靠同步），注册表兜底（面板重启等错过广播场景）
        var isBuilding = localBQ[qid] || (reg && reg[qid] && reg[qid].stopState === 'sending');
        if (!pool || !isBuilding) {
            clk.style.display = 'none';
            continue;
        }
        var ag = pool[qid];
        // 计时：优先 agent._floorStartPerf，缺失则 fallback registry.startedAt
        var startMs = (ag && ag._floorStartPerf > 0) ? ag._floorStartPerf : (reg[qid].startedAt || 0);
        if (startMs <= 0) {
            clk.style.display = 'none';
            continue;
        }
        var elapsed = (startMs === reg[qid].startedAt) ? (Date.now() - startMs) : (now - startMs);
        clk.textContent = Math.floor(elapsed / 1000);
        clk.style.display = '';
        hasVisible = true;
    }
    // ★ 定时器不再自动停止。由 _maybeStopCometClockTimer 基于建楼状态显式管理。
    //    旧自动停止逻辑：无可显示时钟→停定时器，但时钟可能因 DOM 未挂载而暂时不可见，
    //    导致定时器永久死亡（_ensureCometClockTicking 的 gate 已过，无人重启）。
}

function _ensureCometClockTicking() {
    if (!_cometClockTimer) {
        _cometClockTimer = setInterval(_tickCometClocks, 200);
        // ★ 延迟 50ms 首次 tick：给 DOM 挂载留时间（renderQuestDrop 先插钟后挂 body）。
        //    tofu 路径（已挂载）50ms 延迟肉眼无感。
        setTimeout(_tickCometClocks, 50);
    }
}

// ★ 检查是否还有建楼中的 quest，没有则停止彗星电子钟定时器
function _maybeStopCometClockTimer() {
    var localBQ = window.__qqq_localBuildingQuests || {};
    var reg = window.parent && window.parent.__qqq_buildingRegistry;
    var hasAny = false;
    for (var k in localBQ) {
        if (localBQ[k]) { hasAny = true; break; }
    }
    if (!hasAny && reg) {
        for (var k2 in reg) {
            if (reg[k2] && reg[k2].stopState === 'sending') { hasAny = true; break; }
        }
    }
    if (!hasAny) {
        _stopQuestClock();
    }
}

// ★ 在 prefix 元素内插入彗星电子钟子钟
//   如已存在且 qid 不同 → 移除旧钟重建（防 data-qid 串号）
function _insertCometClock(prefixEl, qid, container) {
    if (!prefixEl) return;
    var parent = container || prefixEl;
    var existing = parent.querySelector('.comet-clock');
    if (existing) {
        if (existing.getAttribute('data-qid') === qid) return;  // 同 quest，无需重建
        existing.remove();  // 不同 quest → 移除旧钟
    }
    var clk = document.createElement('span');
    clk.className = 'comet-clock';
    clk.setAttribute('data-qid', qid);
    clk.style.display = 'none';
    parent.appendChild(clk);
    _ensureCometClockTicking();
}

// ★ 从 prefix 移除彗星电子钟
function _removeCometClock(prefixEl) {
    if (!prefixEl) return;
    var clk = prefixEl.querySelector('.comet-clock');
    if (clk) clk.remove();
}

function _startQuestClock() {
    _ensureCometClockTicking();
}

function _stopQuestClock() {
    if (_cometClockTimer) {
        clearInterval(_cometClockTimer);
        _cometClockTimer = null;
    }
    // 隐藏所有彗星电子钟（下拉关闭后 DOM 没了无所谓，豆腐块残留需清）
    var clocks = document.querySelectorAll('.comet-clock');
    for (var i = 0; i < clocks.length; i++) {
        clocks[i].style.display = 'none';
    }
}

// ★ 兼容旧调用：_updateQuestClock 由 updateQuestTofu/switchQuest 调用
function _updateQuestClock() {
    _tickCometClocks();
    _ensureCometClockTicking();
}

async function updateQuestTofu() {
    var prefixEl = document.getElementById('quest-tofu-prefix');
    var textEl = document.getElementById('quest-tofu-text');
    var pen = document.getElementById('quest-tofu-pen');
    var quests = await questStore.list();
    var entry = quests.find(function (q) { return q.id === questActiveId; });
    _tofuEntry = entry || null;
    if (entry) {
        var num = entry.numericId || '?';
        if (prefixEl) prefixEl.textContent = 'q' + num + '.\u00a0 ';
        textEl.textContent = entry.title || '';
        textEl.parentElement.classList.remove('quest-tofu-new');
        if (pen) pen.style.display = '';
        // ★ 彗星电子钟：本地集合（IPC同步）为主，注册表兜底
        var _bq2 = window.__qqq_localBuildingQuests || {};
        var _reg2 = window.parent && window.parent.__qqq_buildingRegistry;
        var isBuilding = _bq2[questActiveId] || (_reg2 && _reg2[questActiveId] && _reg2[questActiveId].stopState === 'sending');
        if (isBuilding) {
            _insertCometClock(prefixEl, questActiveId);
        } else {
            _removeCometClock(prefixEl);
        }
        _updateQuestClock();
    } else {
        if (prefixEl) prefixEl.textContent = '';
        textEl.textContent = '~ New quest ~';
        textEl.parentElement.classList.add('quest-tofu-new');
        if (pen) pen.style.display = 'none';
        _removeCometClock(prefixEl);
        _updateQuestClock();
    }
    var title = 'qqqide';
    var root = questStore.getProjectRoot();
    if (root) {
        var parts = root.replace(/\\/g, '/').split('/');
        var folderName = parts[parts.length - 1] || parts[parts.length - 2] || root;
        title = folderName;
    }
    try { document.title = title; } catch (_) { }
    try {
        var b = _getBridge();
        if (b && b.window && b.window.setTitle) b.window.setTitle(title);
    } catch (_) { }
}

// ── 豆腐块内联编辑 ──
function _tofuStartEdit() {
    if (!_tofuEntry) return;
    var textEl = document.getElementById('quest-tofu-text');
    var editEl = document.getElementById('quest-tofu-edit');
    var pen = document.getElementById('quest-tofu-pen');
    if (!textEl || !editEl) return;
    textEl.style.display = 'none';
    editEl.style.display = 'block';
    editEl.value = _tofuEntry.title || '';
    editEl.focus();
    editEl.select();
    if (pen) pen.style.display = 'none';
}
function _tofuCommitEdit() {
    var textEl = document.getElementById('quest-tofu-text');
    var editEl = document.getElementById('quest-tofu-edit');
    var pen = document.getElementById('quest-tofu-pen');
    if (!textEl || !editEl) return;
    if (editEl.style.display === 'none') return;  // 未在编辑态
    var newTitle = editEl.value.trim();
    editEl.style.display = 'none';
    textEl.style.display = '';
    if (pen && _tofuEntry) pen.style.display = '';
    if (newTitle && _tofuEntry && newTitle !== _tofuEntry.title) {
        _tofuEntry.title = newTitle;
        textEl.textContent = newTitle;
        renameQuest(_tofuEntry.id, newTitle);
    } else {
        // 恢复原标题显示
        if (_tofuEntry) {
            textEl.textContent = _tofuEntry.title || '';
        }
    }
}
function _tofuCancelEdit() {
    var textEl = document.getElementById('quest-tofu-text');
    var editEl = document.getElementById('quest-tofu-edit');
    var pen = document.getElementById('quest-tofu-pen');
    if (!textEl || !editEl) return;
    editEl.style.display = 'none';
    textEl.style.display = '';
    if (pen && _tofuEntry) pen.style.display = '';
}
// hover \u5c55\u5f00/\u6536\u8d77 + \u7F16\u8F91\u7B14\u7ED1\u5B9A
(function () {
    var tofu = document.getElementById('quest-tofu');
    var pen = document.getElementById('quest-tofu-pen');
    var editEl = document.getElementById('quest-tofu-edit');
    if (tofu) {
        tofu.addEventListener('mouseenter', function () {
            clearTimeout(_questDropTimer);
            if (!_questDrop) openQuestDrop();
        });
        tofu.addEventListener('mouseleave', function () {
            _questDropTimer = setTimeout(closeQuestDrop, 120);
        });
    }
    if (pen) {
        pen.addEventListener('mousedown', function (e) {
            e.stopPropagation();
            e.preventDefault();
            _tofuStartEdit();
        });
        pen.addEventListener('click', function (e) {
            e.stopPropagation();
        });
    }
    if (editEl) {
        editEl.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); _tofuCommitEdit(); }
            if (e.key === 'Escape') { e.preventDefault(); _tofuCancelEdit(); }
        });
        editEl.addEventListener('blur', function () { _tofuCommitEdit(); });
    }
})();

document.addEventListener('click', function () {
    // 搜索框有焦点 → 不关闭（由 blur 延迟处理）
    if (_questSearchFocused) return;
    closeQuestDrop();
});

async function renderTabs() { await updateQuestTofu(); }

// ═══ Boot sequence ═══
(async function () {
    loadQqqideRules();
    await bindMainProject();
})();
